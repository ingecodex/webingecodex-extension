<?php
if (!defined('ABSPATH')) {
    exit;
}

function cm_generate_ticket_code() {
    $prefixes = array('CL', 'NX', 'AG', 'ST', 'TX', 'VR', 'MK', 'IC', 'PR', 'KB', 'DX', 'RM');
    $prefix   = $prefixes[array_rand($prefixes)];
    $number   = str_pad(wp_rand(100000, 999999), 6, '0', STR_PAD_LEFT);
    return $prefix . $number;
}

/**
 * Obtiene la URL de la página de seguimiento de casos con el código de ticket.
 */
function cm_get_case_tracker_url($ticket_code = '') {
    $custom_url = get_option('cm_tracking_page_url', '');
    if (!empty($custom_url)) {
        return !empty($ticket_code) ? add_query_arg('codigo', $ticket_code, $custom_url) : $custom_url;
    }

    // Buscar automáticamente página publicada con shortcode de seguimiento
    global $wpdb;
    $post_id = $wpdb->get_var("SELECT ID FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type = 'page' AND (post_content LIKE '%[seguimiento_caso%' OR post_content LIKE '%[consultar_caso%' OR post_content LIKE '%[ingecodex_seguimiento%') LIMIT 1");
    if ($post_id) {
        $link = get_permalink($post_id);
        return !empty($ticket_code) ? add_query_arg('codigo', $ticket_code, $link) : $link;
    }

    return !empty($ticket_code) ? add_query_arg('codigo', $ticket_code, home_url('/')) : home_url('/');
}

function cm_build_executive_email_html($args) {
    $is_confirmation     = !empty($args['is_confirmation']);
    $ticket_code         = esc_html($args['ticket_code'] ?? 'CL000000');
    $site_name           = esc_html($args['site_name'] ?? get_bloginfo('name'));
    $site_url            = esc_url($args['site_url'] ?? home_url());
    $sender_name         = esc_html($args['sender_name'] ?? 'Usuario');
    $sender_email        = esc_html($args['sender_email'] ?? '');
    $nombre_departamento = esc_html($args['nombre_departamento'] ?? 'General');
    $submitted_data      = $args['submitted_data'] ?? array();
    $date_time           = current_time('d/m/Y H:i') . ' hrs';
    $tracking_url        = !empty($args['tracking_url']) ? esc_url($args['tracking_url']) : esc_url(cm_get_case_tracker_url($ticket_code));

    $badge_title = $is_confirmation ? 'COMPROBANTE OFICIAL DE RECEPCIÓN' : 'NOTIFICACIÓN DE NUEVO MENSAJE';
    $main_title  = $is_confirmation ? 'Confirmación de Mensaje Recibido' : 'Nueva Solicitud de Contacto';

    ob_start();
    ?>
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo $main_title; ?></title>
    </head>
    <body style="margin: 0; padding: 0; background-color: #f1f5f9; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; -webkit-font-smoothing: antialiased; color: #1e293b;">
        <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%" style="background-color: #f1f5f9; padding: 30px 15px;">
            <tr>
                <td align="center">
                    <!-- Contenedor Principal -->
                    <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 640px; background-color: #ffffff; border-radius: 18px; overflow: hidden; box-shadow: 0 10px 30px rgba(15, 23, 42, 0.08); border: 1px solid #e2e8f0;">
                        
                        <!-- Encabezado con Gradiente Elegante -->
                        <tr>
                            <td style="background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 60%, #312e81 100%); padding: 32px 36px; text-align: left;">
                                <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
                                    <tr>
                                        <td>
                                            <div style="display: inline-block; background: rgba(255, 255, 255, 0.15); backdrop-filter: blur(8px); padding: 4px 12px; border-radius: 20px; font-size: 11px; font-weight: 700; color: #c7d2fe; letter-spacing: 0.08em; text-transform: uppercase; margin-bottom: 10px;">
                                                ✓ <?php echo $badge_title; ?>
                                            </div>
                                            <h1 style="margin: 0; font-size: 22px; font-weight: 800; color: #ffffff; letter-spacing: -0.02em; line-height: 1.3;">
                                                <?php echo $site_name; ?>
                                            </h1>
                                            <p style="margin: 6px 0 0 0; font-size: 13.5px; color: #e2e8f0; line-height: 1.4;">
                                                <?php echo $is_confirmation ? 'Tu solicitud ha sido registrada exitosamente en nuestro sistema.' : 'Se ha recibido un nuevo registro a través del portal web.'; ?>
                                            </p>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>

                        <!-- Tarjeta del Código de Seguimiento (Ticket) -->
                        <tr>
                            <td style="padding: 28px 36px 14px 36px;">
                                <div style="background: linear-gradient(135deg, #f8faff 0%, #eef2ff 100%); border: 2px dashed #818cf8; border-radius: 14px; padding: 20px 24px; text-align: center;">
                                    <div style="font-size: 11.5px; font-weight: 700; color: #4338ca; text-transform: uppercase; letter-spacing: 0.12em;">
                                        CÓDIGO DE SEGUIMIENTO ÚNICO
                                    </div>
                                    <div style="font-family: 'Courier New', Courier, monospace, 'SFMono-Regular', Consolas, monospace; font-size: 28px; font-weight: 900; color: #1e1b4b; letter-spacing: 3px; margin: 6px 0;">
                                        <?php echo $ticket_code; ?>
                                    </div>
                                    <div style="font-size: 12px; color: #64748b; line-height: 1.4; margin-bottom: 12px;">
                                        <?php echo $is_confirmation ? 'Guarda este código para cualquier consulta o seguimiento de tu requerimiento.' : 'Código de referencia generado para auditoría y control de este mensaje.'; ?>
                                    </div>
                                    <?php if ($is_confirmation) : ?>
                                        <div style="margin-top: 10px;">
                                            <a href="<?php echo $tracking_url; ?>" target="_blank" style="display: inline-block; background: #4f46e5; color: #ffffff; text-decoration: none; padding: 10px 20px; border-radius: 8px; font-size: 13px; font-weight: 700; letter-spacing: 0.02em;">
                                                🔍 Consultar Estado de mi Caso en Línea &rarr;
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>

                        <!-- Saludo y Mensaje Personalizado -->
                        <tr>
                            <td style="padding: 20px 36px 10px 36px;">
                                <p style="margin: 0; font-size: 14.5px; line-height: 1.6; color: #334155;">
                                    <?php if ($is_confirmation) : ?>
                                        Estimado(a) <strong><?php echo $sender_name; ?></strong>, gracias por comunicarte con nosotros. Hemos recibido tu mensaje dirigido al área de <strong><?php echo $nombre_departamento; ?></strong>. Un ejecutivo revisará tus antecedentes y se pondrá en contacto contigo a la brevedad.
                                    <?php else : ?>
                                        Has recibido un nuevo mensaje enviado por <strong><?php echo $sender_name; ?></strong> dirigido al departamento de <strong><?php echo $nombre_departamento; ?></strong>.
                                    <?php endif; ?>
                                </p>
                            </td>
                        </tr>

                        <!-- Tabla con el Detalle de la Solicitud -->
                        <tr>
                            <td style="padding: 15px 36px 25px 36px;">
                                <div style="font-size: 13px; font-weight: 700; color: #0f172a; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 12px; border-bottom: 2px solid #e2e8f0; padding-bottom: 6px;">
                                    📋 Resumen de la Solicitud
                                </div>
                                <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-collapse: collapse; font-size: 13.5px; border: 1px solid #e2e8f0; border-radius: 10px; overflow: hidden;">
                                    <tr style="background-color: #f8fafc;">
                                        <td style="padding: 10px 14px; font-weight: 600; color: #475569; width: 36%; border-bottom: 1px solid #e2e8f0;">Departamento / Área:</td>
                                        <td style="padding: 10px 14px; font-weight: 700; color: #4f46e5; border-bottom: 1px solid #e2e8f0;"><?php echo $nombre_departamento; ?></td>
                                    </tr>
                                    <tr style="background-color: #ffffff;">
                                        <td style="padding: 10px 14px; font-weight: 600; color: #475569; border-bottom: 1px solid #e2e8f0;">Fecha y Hora:</td>
                                        <td style="padding: 10px 14px; color: #1e293b; border-bottom: 1px solid #e2e8f0;"><?php echo $date_time; ?></td>
                                    </tr>
                                    <?php 
                                    $row_index = 0;
                                    foreach ($submitted_data as $title => $val) : 
                                        $bg = ($row_index % 2 === 0) ? '#f8fafc' : '#ffffff';
                                        $row_index++;
                                    ?>
                                    <tr style="background-color: <?php echo $bg; ?>;">
                                        <td style="padding: 10px 14px; font-weight: 600; color: #475569; border-bottom: 1px solid #e2e8f0; vertical-align: top;"><?php echo esc_html($title); ?>:</td>
                                        <td style="padding: 10px 14px; color: #0f172a; border-bottom: 1px solid #e2e8f0; line-height: 1.5; vertical-align: top;"><?php echo nl2br(esc_html($val)); ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </table>
                            </td>
                        </tr>

                        <!-- Aviso de Seguridad / Pie Informativo -->
                        <tr>
                            <td style="padding: 0 36px 30px 36px;">
                                <div style="background-color: #f8fafc; border-left: 3px solid #6366f1; padding: 12px 16px; border-radius: 0 8px 8px 0; font-size: 12px; color: #64748b; line-height: 1.5;">
                                    🔒 <strong>Aviso de Privacidad:</strong> Este mensaje y sus datos adjuntos son estrictamente confidenciales y están dirigidos exclusivamente al destinatario registrado bajo el ticket <strong><?php echo $ticket_code; ?></strong>.
                                </div>
                            </td>
                        </tr>

                        <!-- Footer Institucional -->
                        <tr>
                            <td style="background-color: #f8fafc; border-top: 1px solid #e2e8f0; padding: 22px 36px; text-align: center;">
                                <p style="margin: 0 0 6px 0; font-size: 13px; font-weight: 700; color: #334155;">
                                    <?php echo $site_name; ?>
                                </p>
                                <p style="margin: 0 0 10px 0; font-size: 11.5px; color: #94a3b8;">
                                    <a href="<?php echo $site_url; ?>" style="color: #4f46e5; text-decoration: none; font-weight: 600;"><?php echo $site_url; ?></a>
                                </p>
                                <p style="margin: 0; font-size: 11px; color: #94a3b8;">
                                    Sistema de Formulario Multidestino desarrollado por <a href="https://ingecodex.com" target="_blank" style="color: #6366f1; text-decoration: none; font-weight: 600;">Ingecodex.com</a>
                                </p>
                            </td>
                        </tr>

                    </table>
                </td>
            </tr>
        </table>
    </body>
    </html>
    <?php
    return ob_get_clean();
}

function cm_process_form_submission() {
    
    $nonce = $_POST['cm_nonce'] ?? $_POST['cm_nonce_field'] ?? $_POST['nonce'] ?? '';
    if (!wp_verify_nonce($nonce, 'cm_contacto_nonce')) {
        wp_send_json_error(array('message' => __('Sesión no válida o expirada. Por favor recarga la página.', 'contacto-multidestino')));
    }

    
    if (!empty($_POST['cm_website'])) {
        wp_send_json_success(array('message' => __('Mensaje recibido.', 'contacto-multidestino')));
    }

    
    $ticket_code = cm_generate_ticket_code();

    
    $form_id = isset($_POST['cm_form_id']) ? sanitize_key($_POST['cm_form_id']) : '';
    $schema  = null;

    if (!empty($form_id)) {
        $forms = get_option('cm_forms', array());
        if (isset($forms[$form_id]['schema'])) {
            $schema = $forms[$form_id]['schema'];
        }
    }

    if (!$schema && function_exists('cm_get_default_form_id')) {
        $default_id = cm_get_default_form_id();
        if ($default_id) {
            $schema = cm_get_form($default_id);
        }
    }

    if (!$schema) {
        $schema = get_option('cm_form_builder_schema', null);
    }
    if (!$schema) {
        require_once CM_PLUGIN_DIR . 'includes/admin-builder.php';
        $schema = cm_get_default_schema();
    }

    $fields       = isset($schema['fields']) ? $schema['fields'] : array();
    $settings     = isset($schema['settings']) ? $schema['settings'] : array();
    $success_msg  = !empty($settings['success_msg']) ? $settings['success_msg'] : __('¡Tu mensaje ha sido enviado exitosamente!', 'contacto-multidestino');

    
    $form_dest_emails = !empty($settings['destination_emails']) ? $settings['destination_emails'] : get_option('cm_default_email', get_option('admin_email'));
    $parsed_dest = array_map('trim', explode(',', $form_dest_emails));
    $valid_dest  = array_values(array_filter($parsed_dest, 'is_email'));
    if (empty($valid_dest)) {
        $valid_dest = array(get_option('admin_email'));
    }

    $submitted_data      = array();
    $sender_name         = 'Remitente';
    $sender_email        = '';
    $destinatarios_list  = $valid_dest;
    $nombre_departamento = !empty($settings['default_area_name']) ? $settings['default_area_name'] : (!empty($settings['title']) ? $settings['title'] : 'General / Consultas');
    $attachments         = array();
    $uploaded_file_path  = '';

    
    foreach ($fields as $field) {
        $field_id = $field['id'];
        $type     = $field['type'];
        $label    = $field['label'];
        $required = !empty($field['required']);

        if ($type === 'heading' || $type === 'divider') {
            continue;
        }

        
        if ($type === 'file') {
            if (isset($_FILES[$field_id]) && $_FILES[$field_id]['error'] === UPLOAD_ERR_OK) {
                $file = $_FILES[$field_id];
                $max_size_mb = get_option('cm_max_file_size', 5);
                $max_size_bytes = $max_size_mb * 1024 * 1024;

                if ($file['size'] > $max_size_bytes) {
                    wp_send_json_error(array('message' => sprintf(__('El archivo excede el tamaño máximo permitido de %d MB.', 'contacto-multidestino'), $max_size_mb)));
                }

                $allowed_exts = array('jpg', 'jpeg', 'png', 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'zip', 'txt');
                $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

                if (!in_array($file_ext, $allowed_exts)) {
                    wp_send_json_error(array('message' => __('Formato de archivo no permitido.', 'contacto-multidestino')));
                }

                if (!function_exists('wp_handle_upload')) {
                    require_once(ABSPATH . 'wp-admin/includes/file.php');
                }

                $upload_overrides = array('test_form' => false);
                $movefile = wp_handle_upload($file, $upload_overrides);

                if ($movefile && !isset($movefile['error'])) {
                    $uploaded_file_path = $movefile['file'];
                    $attachments[] = $uploaded_file_path;
                    $submitted_data[$label] = basename($uploaded_file_path) . ' (Adjunto)';
                }
            } elseif ($required) {
                wp_send_json_error(array('message' => sprintf(__('El campo "%s" es obligatorio.', 'contacto-multidestino'), $label)));
            }
            continue;
        }

        $val = isset($_POST[$field_id]) ? sanitize_text_field($_POST[$field_id]) : '';

        if ($required && ($val === '' || $val === null)) {
            wp_send_json_error(array('message' => sprintf(__('Por favor completa el campo obligatorio "%s".', 'contacto-multidestino'), $label)));
        }

        if ($type === 'email') {
            if (!empty($val) && !is_email($val)) {
                wp_send_json_error(array('message' => __('Ingresa una dirección de correo válida.', 'contacto-multidestino')));
            }
            $sender_email = $val;
        }

        if (($type === 'text' || $type === 'name') && empty($sender_name) && !empty($val)) {
            $sender_name = $val;
        }

        
        if ($type === 'department' || $type === 'select') {
            $opt_idx = $val;
            if (isset($field['options'][$opt_idx])) {
                $option_data = $field['options'][$opt_idx];
                
                if (is_array($option_data)) {
                    $nombre_departamento = isset($option_data['nombre']) ? $option_data['nombre'] : 'Área Seleccionada';
                    $raw_emails = isset($option_data['email']) ? $option_data['email'] : '';
                } else {
                    $nombre_departamento = $option_data;
                    $raw_emails = '';
                }

                if (!empty($raw_emails)) {
                    $parsed_emails = array_map('trim', explode(',', $raw_emails));
                    $valid_emails  = array_filter($parsed_emails, 'is_email');

                    if (!empty($valid_emails)) {
                        $destinatarios_list = array_values($valid_emails);
                    }
                }

                // Verificar si hay correos adicionales o usuario asignado en el registro de áreas
                if (function_exists('cm_get_available_departments')) {
                    $all_deps = cm_get_available_departments(false);
                    if (isset($all_deps[$nombre_departamento])) {
                        $dep_reg = $all_deps[$nombre_departamento];
                        if (!empty($dep_reg['emails'])) {
                            $dep_emails = array_filter(array_map('trim', explode(',', $dep_reg['emails'])), 'is_email');
                            $destinatarios_list = array_unique(array_merge($destinatarios_list, $dep_emails));
                        }
                        if (!empty($dep_reg['user_id'])) {
                            $u_obj = get_userdata($dep_reg['user_id']);
                            if ($u_obj && is_email($u_obj->user_email)) {
                                $destinatarios_list = array_unique(array_merge($destinatarios_list, array($u_obj->user_email)));
                            }
                        }
                    }
                }

                $submitted_data[$label] = $nombre_departamento;
            } else {
                $submitted_data[$label] = !empty($val) ? $val : 'General';
            }
            continue;
        }

        if ($type === 'phone' || $type === 'tel') {
            if (empty($sender_phone) && !empty($val)) {
                $sender_phone = $val;
            }
        }

        if ($type === 'terms' || $type === 'checkbox') {
            $submitted_data[$label] = !empty($val) ? '✓ Aceptado' : 'No aceptado';
            continue;
        }

        if ($type === 'rating') {
            $submitted_data[$label] = !empty($val) ? str_repeat('★', (int)$val) . " ({$val}/5)" : 'Sin calificación';
            continue;
        }

        if (!empty($val)) {
            $submitted_data[$label] = $val;
        }
    }

    $site_name = get_bloginfo('name');
    $site_url  = home_url();

    // Obtener nombre del formulario
    $all_forms = function_exists('cm_get_all_forms') ? cm_get_all_forms() : array();
    $form_name = isset($all_forms[$form_id]['name']) ? $all_forms[$form_id]['name'] : (!empty($settings['title']) ? $settings['title'] : 'Formulario');

    if (!empty($settings['custom_subject'])) {
        $admin_subject = sprintf('[%s] %s', $ticket_code, $settings['custom_subject']);
    } else {
        $admin_subject = sprintf('[%s] Nuevo Mensaje: %s — %s', $ticket_code, $sender_name, $nombre_departamento);
    }

    $admin_body = cm_build_executive_email_html(array(
        'is_confirmation'     => false,
        'ticket_code'         => $ticket_code,
        'site_name'           => $site_name,
        'site_url'            => $site_url,
        'sender_name'         => $sender_name,
        'sender_email'        => $sender_email,
        'nombre_departamento' => $nombre_departamento,
        'submitted_data'      => $submitted_data,
    ));

    // Remitente configurado en Ingecodex Form (con fallbacks seguros)
    $from_email = get_option('cm_smtp_from', '');
    if (!is_email($from_email)) {
        $from_email = get_option('cm_smtp_user', '');
    }
    if (!is_email($from_email)) {
        $from_email = get_option('admin_email');
    }

    $admin_headers   = array();
    $admin_headers[] = 'Content-Type: text/html; charset=UTF-8';
    $admin_headers[] = 'From: ' . esc_html($site_name) . ' <' . $from_email . '>';
    if (!empty($sender_email)) {
        $admin_headers[] = 'Reply-To: ' . esc_html($sender_name) . ' <' . esc_html($sender_email) . '>';
    }

    delete_option('cm_last_mail_error');
    $sent = wp_mail($destinatarios_list, $admin_subject, $admin_body, $admin_headers, $attachments);

    // Correo de Confirmación al Usuario (Auto-responder)
    $enable_autoresponder = !isset($settings['enable_autoresponder']) || !empty($settings['enable_autoresponder']);
    if ($enable_autoresponder && !empty($sender_email) && is_email($sender_email)) {
        $user_subject = sprintf('[%s] Confirmación de Recepción — %s', $ticket_code, $site_name);
        $user_body    = cm_build_executive_email_html(array(
            'is_confirmation'     => true,
            'ticket_code'         => $ticket_code,
            'site_name'           => $site_name,
            'site_url'            => $site_url,
            'sender_name'         => $sender_name,
            'sender_email'        => $sender_email,
            'nombre_departamento' => $nombre_departamento,
            'submitted_data'      => $submitted_data,
        ));

        $user_headers   = array();
        $user_headers[] = 'Content-Type: text/html; charset=UTF-8';
        $user_headers[] = 'From: ' . esc_html($site_name) . ' <' . $from_email . '>';

        wp_mail($sender_email, $user_subject, $user_body, $user_headers);
    }

    // REGISTRO OBLIGATORIO EN BASE DE DATOS DE ENVÍOS Y GESTIÓN DE CASOS (v2.4.8)
    if (function_exists('cm_insert_submission')) {
        cm_insert_submission(array(
            'ticket_code'    => $ticket_code,
            'form_id'        => $form_id,
            'form_name'      => $form_name,
            'sender_name'    => $sender_name,
            'sender_email'   => $sender_email,
            'sender_phone'   => $sender_phone,
            'department'     => $nombre_departamento,
            'subject'        => $admin_subject,
            'submitted_data' => $submitted_data,
            'status'         => 'recibido',
        ));
    }

    // Limpieza de archivos adjuntos temporales tras el envío
    if (!empty($uploaded_file_path) && file_exists($uploaded_file_path)) {
        @unlink($uploaded_file_path);
    }

    $tracking_url = cm_get_case_tracker_url($ticket_code);

    if ($sent) {
        wp_send_json_success(array(
            'message'      => esc_html($success_msg),
            'ticket_code'  => $ticket_code,
            'tracking_url' => $tracking_url,
        ));
    } else {
        $msg = __('Ocurrió un problema al enviar el correo mediante el servidor. Por favor intenta más tarde.', 'contacto-multidestino');
        if (current_user_can('manage_options')) {
            $last_err = get_option('cm_last_mail_error', '');
            if ($last_err) {
                $msg .= '<br><small style="color:#991b1b;">🔧 Detalle técnico (solo administradores): ' . esc_html(mb_substr($last_err, 0, 300)) . '</small>';
            }
            if (get_option('cm_smtp_enabled', false)) {
                $msg .= '<br><small style="color:#854d0e;">💡 Si tu hosting bloquea SMTP, desactiva el interruptor en <strong>Ajustes de Correo SMTP</strong> y guarda: el envío interno funcionará.</small>';
            }
        }
        wp_send_json_error(array('message' => $msg));
    }
}

add_action('wp_ajax_cm_submit_form', 'cm_process_form_submission');
add_action('wp_ajax_nopriv_cm_submit_form', 'cm_process_form_submission');

