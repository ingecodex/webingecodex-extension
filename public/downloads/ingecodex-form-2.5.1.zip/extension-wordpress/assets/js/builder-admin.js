
(function ($) {
    'use strict';

    const initialFromServer = (window.cmBuilderVars && cmBuilderVars.initial_schema) || window.cmInitialSchema || null;
    let schema = JSON.parse(JSON.stringify(initialFromServer || { settings: {}, fields: [] }));
    if (typeof schema.settings.show_header === 'undefined') schema.settings.show_header = true;
    if (typeof schema.settings.card_preset === 'undefined') schema.settings.card_preset = 'modern';
    if (typeof schema.settings.border_width === 'undefined') schema.settings.border_width = '1';
    if (typeof schema.settings.container_border_color === 'undefined') schema.settings.container_border_color = '#e2e8f0';
    if (typeof schema.settings.show_credit === 'undefined') schema.settings.show_credit = true;
    if (typeof schema.settings.canvas_h === 'undefined') schema.settings.canvas_h = 760;

    let currentFormId = (window.cmBuilderVars && cmBuilderVars.form_id) || '';
    let editDevice = 'desktop';
    if (!currentFormId && window.cmBuilderVars && cmBuilderVars.forms) {

        for (const [id, label] of Object.entries(cmBuilderVars.forms)) {
            currentFormId = id;
            if (label.includes('★')) break;
        }
    }

    let selectedFieldId = null;

    function cmToast(msg, type) {
        let wrap = document.getElementById('cm-toast-wrap');
        if (!wrap) {
            wrap = document.createElement('div');
            wrap.id = 'cm-toast-wrap';
            document.body.appendChild(wrap);
        }
        const t = document.createElement('div');
        t.className = 'cm-toast' + (type === 'error' ? ' error' : '');
        t.textContent = msg;
        wrap.appendChild(t);
        requestAnimationFrame(() => t.classList.add('show'));
        setTimeout(() => { t.classList.remove('show'); setTimeout(() => t.remove(), 350); }, 3200);
    }

    function cmConfirm(opts) {
        return new Promise(resolve => {
            const ov = document.getElementById('cm-confirm-overlay');
            if (!ov) { resolve(window.confirm((opts.title || '') + '\n' + (opts.message || ''))); return; }
            document.getElementById('cm-confirm-icon').textContent = opts.icon || '⚠️';
            document.getElementById('cm-confirm-title').textContent = opts.title || '¿Estás seguro?';
            document.getElementById('cm-confirm-msg').textContent = opts.message || '';
            const ok = document.getElementById('cm-confirm-ok');
            ok.textContent = opts.okText || 'Confirmar';
            ok.classList.toggle('danger', opts.danger !== false);
            ov.classList.add('open');
            const close = val => {
                ov.classList.remove('open');
                ok.onclick = cancel.onclick = ov.onmousedown = null;
                resolve(val);
            };
            const cancel = document.getElementById('cm-confirm-cancel');
            ok.onclick = () => close(true);
            cancel.onclick = () => close(false);
            ov.onmousedown = e => { if (e.target === ov) close(false); };
        });
    }

    const FIELD_DEFAULTS = {
        text:       { label: 'Campo de Texto',          placeholder: 'Escribe aquí...',      required: false, width: '100', help: '' },
        email:      { label: 'Correo Electrónico',       placeholder: 'ejemplo@correo.com',   required: true,  width: '50',  help: '' },
        phone:      { label: 'Teléfono',                 placeholder: '+56 9 0000 0000',      required: false, width: '50',  help: '' },
        textarea:   { label: 'Mensaje',                  placeholder: 'Escribe tu mensaje...', required: true, width: '100', help: '' },
        number:     { label: 'Número',                   placeholder: '0',                    required: false, width: '50',  help: '' },
        url:        { label: 'Sitio Web',                placeholder: 'https://',             required: false, width: '100', help: '' },
        department: { label: 'Dirigido a / Departamento', required: true, width: '50', help: '',
            options: [
                { nombre: 'General / Consultas',  email: '' },
                { nombre: 'Convivencia Escolar',  email: 'convivencia@colegio.cl' },
                { nombre: 'Programa PIE',         email: 'pie@colegio.cl' },
                { nombre: 'Dirección',            email: 'direccion@colegio.cl' }
            ]
        },
        select:     { label: 'Seleccionar opción',       required: false, width: '100', help: '', options: [{ nombre: 'Opción 1', email: '' }, { nombre: 'Opción 2', email: '' }] },
        radio:      { label: 'Selecciona una opción',    required: false, width: '100', help: '', options: [{ nombre: 'Sí', email: '' }, { nombre: 'No', email: '' }] },
        checkbox:   { label: 'Acepto recibir notificaciones', required: false, width: '100', help: '' },
        terms:      {
            label: 'He leído y acepto los',
            required: true,
            width: '100',
            help: '',
            has_terms: true,
            terms_link_text: 'Términos y Condiciones',
            terms_title: 'Políticas y Términos de Servicio',
            terms_content: "1. PROTECCIÓN DE DATOS\nLos datos suministrados a través de este formulario serán tratados con confidencialidad.\n\n2. FINALIDAD DEL CONTACTO\nSe utilizarán para responder a su requerimiento.\n\n3. SEGURIDAD\nNo compartimos información con terceros."
        },
        file:       { label: 'Adjuntar Archivo (opcional)', required: false, width: '100', help: 'PDF, DOCX, JPG, PNG, ZIP. Máx 5 MB.' },
        date:       { label: 'Fecha',                    placeholder: 'dd/mm/aaaa',          required: false, width: '50',  help: '' },
        rating:     { label: 'Calificación',             required: false, width: '100', help: '' },
        heading:    { label: 'Título de Sección',        required: false, width: '100', help: '' },
        divider:    { label: 'Separador',                required: false, width: '100', help: '' },
        hidden:     { label: 'Campo Oculto',             placeholder: '', required: false, width: '100', help: '' },
    };

    const FIELD_ICON = {
        text: '📝', email: '✉️', phone: '📞', textarea: '💬', number: '#',
        url: '🔗', department: '👥', select: '▼', radio: '⚬', checkbox: '☑',
        terms: '📜', file: '📎', date: '📅', rating: '★', heading: 'H', divider: '—', hidden: '🔒'
    };

    const FIELD_NAME = {
        text: 'Texto Corto', email: 'Correo Electrónico', phone: 'Teléfono',
        textarea: 'Área de Texto', number: 'Número', url: 'Sitio Web / URL',
        department: 'Departamentos ✉️', select: 'Lista Desplegable',
        radio: 'Opción Única', checkbox: 'Casilla Simple',
        terms: 'Términos / Modal', file: 'Subir Archivo', date: 'Fecha', rating: 'Calificación',
        heading: 'Encabezado', divider: 'Separador', hidden: 'Campo Oculto'
    };

    function uid() { return 'field_' + Math.random().toString(36).substr(2, 9); }
    function getField(id) { return schema.fields.find(f => f.id === id); }

    const posModeOn = () => !!schema.settings.pos_mode;

    function syncPosInputsVisibility() {
        $('#cm-prop-pos-group').toggle(posModeOn());
        $('#cm-prop-width').closest('.cm-prop-row').toggle(!posModeOn());
    }

    function captureFlowPositions() {
        const $c = $('#cm-canvas-fields-container');
        if (!$c.length || !$c[0]) return;
        const cb = $c[0].getBoundingClientRect();
        const cw = cb.width || 1;
        let maxBottomPx = 0;
        $c.find('> .cm-canvas-field-item').each(function () {
            const f = getField($(this).data('id'));
            if (!f || f.type === 'hidden') return;
            const r = this.getBoundingClientRect();
            f.x = Math.max(0, Math.round(((r.left - cb.left) / cw) * 100 * 2) / 2);
            f.w = Math.min(98, Math.max(5, Math.round((r.width / cw) * 100 * 2) / 2));
            maxBottomPx = Math.max(maxBottomPx, r.bottom - cb.top);
        });

        const H = Math.max(240, Math.ceil(maxBottomPx + 16));
        $c.find('> .cm-canvas-field-item').each(function () {
            const f = getField($(this).data('id'));
            if (!f || typeof f.x === 'undefined' || typeof f.y !== 'undefined') return;
            const r = this.getBoundingClientRect();
            f.y = Math.max(0, Math.round(((r.top - cb.top) / H) * 100 * 2) / 2);
        });
        schema.settings.canvas_h = H;
        $('#cm-setting-canvas-h').val(H);
    }

    function autoArrangeLayout() {
        const $c = $('#cm-canvas-fields-container');
        if (!$c.length) return;

        const items = [];
        $c.find('> .cm-canvas-field-item').each(function () {
            const f = getField($(this).data('id'));
            if (!f || f.type === 'hidden') return;
            items.push({ f, h: this.getBoundingClientRect().height || 64 });
        });

        const GAP = 14;
        let yPx = 0, rowH = 0, rowUsed = 0;
        items.forEach(m => {
            const half = m.f.width === '50';
            const wPct = half ? 48 : 96;
            const fitsRow = half && (rowUsed === 0 || rowUsed + wPct <= 100);
            if (!fitsRow && rowUsed > 0) { yPx += rowH + GAP; rowH = 0; rowUsed = 0; }
            m.f.x = rowUsed === 0 ? 2 : 52;
            m.f.w = wPct;
            m.yPx = yPx;
            rowH = Math.max(rowH, m.h);
            rowUsed += wPct;
            if (!half) { yPx += rowH + GAP; rowH = 0; rowUsed = 0; }
        });
        if (rowUsed > 0) yPx += rowH + GAP;

        const total = Math.max(240, Math.ceil(yPx + 10));
        items.forEach(m => {
            m.f.y = Math.round(m.yPx / total * 100 * 10) / 10;
        });
        schema.settings.canvas_h = total;
        $('#cm-setting-canvas-h').val(total);
        renderCanvas();
    }

    function autofitCanvasHeight() {
        const $c = $('#cm-canvas-fields-container');
        if (!$c.length || !$c[0]) return;
        const ch = $c[0].getBoundingClientRect().height || parseFloat(schema.settings.canvas_h) || 760;
        let maxBottomPx = 0;
        $c.find('> .cm-canvas-field-item').each(function () {
            const f = getField($(this).data('id'));
            if (!f || typeof f.y === 'undefined') return;
            const topPx = (parseFloat(f.y) / 100) * ch;
            const hPx = this.getBoundingClientRect().height;
            f._topPx = topPx;
            maxBottomPx = Math.max(maxBottomPx, topPx + hPx);
        });
        const H = Math.max(240, Math.ceil(maxBottomPx + 14));
        $c.find('> .cm-canvas-field-item').each(function () {
            const f = getField($(this).data('id'));
            if (!f || typeof f._topPx === 'undefined') return;
            f.y = Math.round((f._topPx / H) * 100 * 10) / 10;
            delete f._topPx;
        });
        schema.settings.canvas_h = H;
        $('#cm-setting-canvas-h').val(H);
        $c.css('minHeight', H + 'px');
    }

    function fieldPosStyle(field) {
        if (!posModeOn() || typeof field.x === 'undefined') return '';
        const h = (typeof field.h !== 'undefined' && parseFloat(field.h) > 3) ? `min-height:${parseFloat(field.h)}%;` : '';
        return `position:absolute;left:${parseFloat(field.x)}%;top:${parseFloat(field.y || 0)}%;width:${parseFloat(field.w || 30)}%;${h}z-index:5;`;
    }

    function renderCanvasFieldHTML(field) {
        const icon  = FIELD_ICON[field.type] || '▪';
        const name  = FIELD_NAME[field.type] || field.type;

        const width = posModeOn() ? '' : (field.width === '50' ? 'cm-col-50' : 'cm-col-100');

        const customBg     = field.custom_bg ? `background:${field.custom_bg} !important;` : '';
        const customBorder = field.custom_border ? `border-color:${field.custom_border} !important;` : '';
        const customStyle  = customBg + customBorder;

        let preview = '';
        switch (field.type) {
            case 'textarea':
                preview = `<textarea class="cm-field-mock" rows="3" placeholder="${field.placeholder || ''}" style="${customStyle}" disabled></textarea>`;
                break;
            case 'select':
            case 'department':
                const opts = (field.options || []).map(o => `<option>${o.nombre}</option>`).join('');
                preview = `<select class="cm-field-mock" style="${customStyle}" disabled><option>— Seleccionar una opción —</option>${opts}</select>`;
                break;
            case 'radio':
                const radios = (field.options || []).map(o => `<label style="display:flex;gap:8px;align-items:center;font-size:13px;color:#334155;"><input type="radio" disabled> ${o.nombre}</label>`).join('');
                preview = `<div style="display:flex;flex-direction:column;gap:6px;padding:4px 0;">${radios}</div>`;
                break;
            case 'checkbox':
                preview = `<label style="display:flex;gap:8px;align-items:center;font-size:13px;color:#334155;"><input type="checkbox" disabled> ${field.label}</label>`;
                break;
            case 'terms':
                const linkTxt = field.terms_link_text || 'Términos y Condiciones';
                preview = `<label style="display:flex;gap:8px;align-items:center;font-size:13px;color:#334155;"><input type="checkbox" disabled> <span>${field.label} <a href="#" style="color:#4f46e5;text-decoration:underline;font-weight:600;" onclick="return false;">${linkTxt}</a> (abre ventana flotante)</span></label>`;
                break;
            case 'file':
                preview = `<div class="cm-field-mock" style="text-align:center;padding:16px;border:1.5px dashed #c7d2fe;border-radius:8px;color:#64748b;font-size:12px;background:#f8fafc;${customStyle}">📎 Haz clic o arrastra un archivo aquí</div>`;
                break;
            case 'date':
                preview = `<input type="text" class="cm-field-mock" placeholder="dd/mm/aaaa" style="${customStyle}" disabled>`;
                break;
            case 'rating':
                preview = `<div style="font-size:22px;letter-spacing:4px;color:#fbbf24;padding:2px 0;">★★★★★</div>`;
                break;
            case 'heading':
                preview = `<h3 style="font-size:15px;font-weight:700;color:#0f172a;margin:2px 0 0;border-bottom:1.5px solid #e2e8f0;padding-bottom:6px;">${field.label}</h3>`;
                break;
            case 'divider':
                return `<div class="${width} cm-canvas-field-item cm-divider-item" data-id="${field.id}" style="${fieldPosStyle(field)}">
                    <div class="cm-field-actions"><button type="button" class="cm-action-btn cm-del-btn" data-id="${field.id}" title="Eliminar">✕</button></div>
                    <hr style="border:none;border-top:2px dashed #e2e8f0;margin:6px 0;">
                    ${posModeOn() ? '<span class="cm-resize-handle" title="Arrastra para redimensionar"></span>' : ''}
                </div>`;
            case 'hidden':
                preview = `<div style="font-size:11px;color:#94a3b8;background:#f1f5f9;padding:6px 10px;border-radius:6px;">🔒 Campo Oculto — no visible en frontend</div>`;
                break;
            default:
                preview = `<input type="text" class="cm-field-mock" placeholder="${field.placeholder || ''}" style="${customStyle}" disabled>`;
        }

        const labelRow = (field.type !== 'heading' && field.type !== 'divider' && field.type !== 'checkbox' && field.type !== 'terms')
            ? `<div class="cm-field-label-mock" style="font-size:12px;font-weight:600;color:#0f172a;margin-bottom:5px;">${field.label || ''}${field.required ? ' <span style="color:#ef4444;">*</span>' : ''}</div>`
            : '';
        const helpRow = field.help ? `<div style="font-size:11px;color:#94a3b8;margin-top:4px;">${field.help}</div>` : '';

        return `<div class="${width} cm-canvas-field-item" data-id="${field.id}" style="${fieldPosStyle(field)}">
            <div class="cm-field-actions">
                <button type="button" class="cm-action-btn cm-dup-btn" data-id="${field.id}" title="Duplicar" style="color:#4f46e5;">⧉</button>
                <button type="button" class="cm-action-btn cm-del-btn" data-id="${field.id}" title="Eliminar">✕</button>
            </div>
            ${labelRow}
            ${preview}
            ${helpRow}
            ${posModeOn() ? '<span class="cm-resize-handle" title="Arrastra para redimensionar ancho y alto"></span>' : ''}
        </div>`;
    }

    function renderCanvas() {
        const $container = $('#cm-canvas-fields-container');
        $container.html('');
        $container.toggleClass('cm-wysiwyg', posModeOn());
        if (posModeOn()) {
            const h = Math.max(200, parseInt(schema.settings.canvas_h || 760, 10));
            $container.css({ position: 'relative', minHeight: h + 'px', height: 'auto', display: 'block' });
        } else {
            $container.css({ position: '', minHeight: '', display: '' });
        }
        schema.fields.forEach(f => { $container.append(renderCanvasFieldHTML(f)); });
        if (schema.fields.length === 0) {
            $container.html('<div style="text-align:center;padding:40px 20px;color:#94a3b8;border:2px dashed #e2e8f0;border-radius:12px;width:100%;box-sizing:border-box;"><p style="margin:0;font-size:13px;font-weight:500;">👈 Haz clic en cualquier elemento de la izquierda para agregarlo.</p></div>');
        }
        if (selectedFieldId) {
            $container.find(`[data-id="${selectedFieldId}"]`).addClass('selected');
        }

        if ($.fn.sortable && !posModeOn()) {
            $container.sortable({
                placeholder: 'cm-field-sortable-placeholder cm-col-100',
                items: '> .cm-canvas-field-item',
                cursor: 'grabbing',
                opacity: 0.85,
                stop: function () {
                    const newOrder = [];
                    $container.find('> .cm-canvas-field-item').each(function () {
                        const id = $(this).data('id');
                        const f = getField(id);
                        if (f) newOrder.push(f);
                    });
                    schema.fields = newOrder;
                    updateFieldSelector();
                }
            });
        } else if ($container.hasClass('ui-sortable')) {
            try { $container.sortable('destroy'); } catch (e) {}
        }

        if (posModeOn()) enableFreePositioning($container);

        updateHeaderUI();
        applyDesignPreview();
        updateFieldSelector();
    }

    function enableFreePositioning($container) {
        const round = v => Math.round(v * 2) / 2;
        const SNAP_PX = 7;
        let $drag = null, mode = null, startX = 0, startY = 0, orig = null;

        if (!$container.find('> .cm-align-guide-v').length) {
            $container.append('<div class="cm-align-guide cm-align-guide-v" style="display:none;"></div><div class="cm-align-guide cm-align-guide-h" style="display:none;"></div>');
        }
        const $gv = $container.find('> .cm-align-guide-v');
        const $gh = $container.find('> .cm-align-guide-h');

        function containerBox() {
            const el = $container[0].getBoundingClientRect();
            return { w: el.width || 1, h: Math.max(el.height, 1), l: el.left, t: el.top };
        }

        function otherRects() {
            const box = containerBox(), out = [];
            $container.find('> .cm-canvas-field-item').not($drag).each(function () {
                const f = getField($(this).data('id'));
                if (!f || typeof f.x === 'undefined') return;
                const r = this.getBoundingClientRect();
                out.push({
                    left: r.left - box.l, right: r.right - box.l,
                    cx: r.left - box.l + r.width / 2,
                    top: r.top - box.t, bottom: r.bottom - box.t,
                    cy: r.top - box.t + r.height / 2,
                });
            });
            return out;
        }

        function snap(val, targets, threshold) {
            let best = null, bestD = threshold;
            targets.forEach(t => { const d = Math.abs(val - t.v); if (d < bestD) { bestD = d; best = t; } });
            return best;
        }

        $container.off('mousedown.cmpos').on('mousedown.cmpos', '.cm-canvas-field-item', function (e) {
            if (!posModeOn()) return;
            const $f = $(this);
            const field = getField($f.data('id'));
            if (!field || $(e.target).is('.cm-action-btn')) return;
            const box = containerBox();

            if (typeof field.x === 'undefined') {

                const fr = this.getBoundingClientRect();
                field.x = round(((fr.left - box.l) / box.w) * 100);
                field.y = round(((fr.top - box.t) / (parseFloat(schema.settings.canvas_h) || 760)) * 100);
                field.w = round((fr.width / box.w) * 100);
            }
            mode = $(e.target).hasClass('cm-resize-handle') ? 'resize' : 'move';
            startX = e.clientX; startY = e.clientY;

            const fr = this.getBoundingClientRect();
            orig = {
                x: parseFloat(field.x), y: parseFloat(field.y), w: parseFloat(field.w),
                h: typeof field.h !== 'undefined' ? parseFloat(field.h) : round((fr.height / box.h) * 100),
            };
            if (typeof field.h === 'undefined') field.h = orig.h;

            $f.attr('style', fieldPosStyle(field));
            $drag = $f;
            e.preventDefault();
            return false;
        });

        $(document).off('mousemove.cmpos mouseup.cmpos')
            .on('mousemove.cmpos', function (e) {
                if (!$drag || !mode) return;
                const field = getField($drag.data('id'));
                if (!field) return;
                const box = containerBox();
                const dxPct = ((e.clientX - startX) / box.w) * 100;

                let guideV = false, guideH = false;
                const others = otherRects();

                if (mode === 'move') {
                    field.x = Math.min(98, Math.max(0, round(orig.x + dxPct)));
                    field.y = Math.min(95, Math.max(0, round(orig.y + ((e.clientY - startY) / box.h) * 100)));

                    const maxXFits = 100 - parseFloat(field.w || 30);
                    if (field.x > maxXFits) field.x = Math.max(0, maxXFits);
                    $('#cm-prop-pos-x').val(field.x); $('#cm-prop-pos-y').val(field.y);

                    const myL = (field.x / 100) * box.w, myW = ($drag[0].getBoundingClientRect().width), myR = myL + myW, myC = myL + myW / 2;
                    for (const mine of [[myL, 'l'], [myR, 'r'], [myC, 'c']]) {
                        const hit = snap(mine[0], others.flatMap(o => [
                            { v: o.left, g: o.left }, { v: o.right, g: o.right }, { v: o.cx, g: o.cx },
                        ]), SNAP_PX);
                        if (hit) {
                            const deltaPx = hit.g - mine[0];
                            field.x = Math.round(Math.min(98, Math.max(0, field.x + (deltaPx / box.w) * 100)) * 10) / 10;
                            $gv.css({ left: hit.g + 'px' }).show(); guideV = true;
                            break;
                        }
                    }

                    const myT = (field.y / 100) * box.h, frH = $drag[0].getBoundingClientRect().height, myB = myT + frH;
                    for (const mine of [myT, myB]) {
                        const hit = snap(mine, others.flatMap(o => [{ v: o.top, g: o.top }, { v: o.bottom, g: o.bottom }, { v: o.cy, g: o.cy }]), SNAP_PX);
                        if (hit) {
                            const deltaPx = hit.v - mine;
                            field.y = Math.round(Math.min(95, Math.max(0, field.y + (deltaPx / box.h) * 100)) * 10) / 10;
                            $gh.css({ top: hit.g + 'px' }).show(); guideH = true;
                            break;
                        }
                    }
                    $drag.css({ left: field.x + '%', top: field.y + '%' });
                } else {

                    field.w = Math.min(100, Math.max(5, round(orig.w + dxPct)));
                    field.h = Math.max(3, round(orig.h + ((e.clientY - startY) / box.h) * 100));
                    $('#cm-prop-pos-w').val(field.w);

                    const myR = (field.x / 100) * box.w + (field.w / 100) * box.w;
                    const hitR = snap(myR, others.flatMap(o => [{ v: o.right, g: o.right }, { v: o.left, g: o.left }, { v: o.cx, g: o.cx }]), SNAP_PX);
                    if (hitR) {
                        const newWPx = hitR.v - (field.x / 100) * box.w;
                        field.w = Math.round(Math.min(100, Math.max(5, (newWPx / box.w) * 100)) * 10) / 10;
                        $gv.css({ left: hitR.g + 'px' }).show(); guideV = true;
                    }

                    const chNow = $drag[0].getBoundingClientRect().height;
                    const myB = (field.y / 100) * box.h + chNow;
                    const hitB = snap(myB, others.flatMap(o => [{ v: o.bottom, g: o.bottom }, { v: o.top, g: o.top }]), SNAP_PX);
                    if (hitB) {
                        const newHPx = hitB.v - (field.y / 100) * box.h;
                        field.h = Math.round(Math.max(3, (newHPx / box.h) * 100) * 10) / 10;
                        $gh.css({ top: hitB.g + 'px' }).show(); guideH = true;
                    }
                    $drag.attr('style', fieldPosStyle(field) + (field.h ? `min-height:${field.h}%;` : ''));
                }

                if (!guideV) $gv.hide();
                if (!guideH) $gh.hide();
            })
            .on('mouseup.cmpos', function () {
                $gv.hide(); $gh.hide();
                $drag = null; mode = null;
            });
    }

    function updateHeaderUI() {
        const s = schema.settings;
        const showHeader = s.show_header !== false;
        const title = (s.title || '').trim();
        const subtitle = (s.subtitle || '').trim();

        if (showHeader) {
            $('#cm-canvas-form-header').show();
            $('#cm-add-header-btn-wrap').hide();
            $('#cm-header-inputs-group').show();
            $('#cm-setting-show-header').prop('checked', true);

            $('#cm-live-title').show().text(title || '(Sin título - haz clic para escribir)');
            $('#cm-live-subtitle').show().text(subtitle || '(Sin subtítulo - haz clic para escribir)');
        } else {
            $('#cm-canvas-form-header').hide();
            $('#cm-add-header-btn-wrap').show();
            $('#cm-header-inputs-group').hide();
            $('#cm-setting-show-header').prop('checked', false);
        }
    }

    function effVal(key) {
        if (editDevice === 'desktop') return schema.settings[key];
        const ov = (schema.settings.device_overrides || {})[editDevice];
        return (ov && ov[key] !== undefined && ov[key] !== 'inherit' && ov[key] !== '') ? ov[key] : schema.settings[key];
    }
    function setDevVal(key, val) {
        if (editDevice === 'desktop') {
            schema.settings[key] = val;
        } else {
            schema.settings.device_overrides = schema.settings.device_overrides || {};
            schema.settings.device_overrides[editDevice] = schema.settings.device_overrides[editDevice] || {};
            schema.settings.device_overrides[editDevice][key] = val;
        }
        refreshDeviceUI();
    }
    function hasOverride(key) {
        if (editDevice === 'desktop') return false;
        const ov = (schema.settings.device_overrides || {})[editDevice];
        return !!(ov && ov[key] !== undefined && ov[key] !== 'inherit' && ov[key] !== '');
    }
    function refreshDeviceUI() {
        const $badge = $('#cm-editing-device-badge');
        if (editDevice === 'desktop') { $badge.hide(); }
        else { $badge.text(editDevice === 'mobile' ? '📲 Editando MÓVIL' : '📱 Editando TABLET').show(); }
        $('#cm-inherit-max-width').toggle(hasOverride('max_width'));
        $('#cm-inherit-density').toggle(hasOverride('density'));
    }
    function loadMaxWidthControl() {
        const _mw = effVal('max_width') || '840px';
        $('#cm-setting-max-width-full').prop('checked', _mw === '100%');
        const pxv = _mw === '100%' ? 840 : (parseInt(_mw, 10) || 840);
        $('#cm-setting-max-width-range').val(Math.min(1200, Math.max(280, pxv)));
        $('#cm-setting-max-width-num').val(pxv);
    }

    function applyDesignPreview() {
        const s  = schema.settings;
        const pc = s.primary_color || '#4f46e5';
        const preset = s.card_preset || 'modern';
        const r  = (s.border_radius || '12') + 'px';
        const bw = (typeof s.border_width !== 'undefined' ? s.border_width : '1') + 'px';
        const bc = s.container_border_color || '#e2e8f0';

        const $canvas = $('#cm-form-canvas');
        const mw = effVal('max_width') || '840px';
        $canvas.css({ maxWidth: mw });
        const effDens = effVal('density') || 'normal';
        $canvas.toggleClass('cm-density-compact', effDens === 'compact')
               .toggleClass('cm-density-roomy',  effDens === 'roomy');

        if (s.bg_color === 'transparent' || s.bg_color === 'rgba(0, 0, 0, 0)') {
            $canvas.css({
                background: 'transparent',
                boxShadow: 'none',
                border: '2px dashed #cbd5e1',
                borderRadius: r
            });
        } else if (preset === 'flat') {
            $canvas.css({
                background: s.bg_color || '#ffffff',
                boxShadow: 'none',
                border: `${bw} solid ${bc}`,
                borderRadius: r
            });
        } else if (preset === 'glassmorphism') {
            $canvas.css({
                background: 'rgba(255, 255, 255, 0.75)',
                backdropFilter: 'blur(16px)',
                boxShadow: '0 8px 32px rgba(31, 38, 135, 0.12)',
                border: '1px solid rgba(255, 255, 255, 0.5)',
                borderRadius: r
            });
        } else if (preset === 'paper') {
            $canvas.css({
                backgroundColor: s.bg_color || '#ffffff',
                backgroundImage: `linear-gradient(${bc} 1px, transparent 1px), linear-gradient(90deg, ${bc} 1px, transparent 1px)`,
                backgroundSize: '22px 22px',
                boxShadow: '0 4px 24px rgba(0,0,0,0.08)',
                border: `${bw} solid ${bc}`,
                borderRadius: r
            });
        } else if (preset === 'rounded') {
            $canvas.css({
                background: s.bg_color || '#ffffff',
                boxShadow: '0 4px 24px rgba(0,0,0,0.08)',
                border: `${bw} solid ${bc}`,
                borderRadius: '26px'
            });
        } else {

            const shadows = {
                none: 'none',
                sm: '0 1px 4px rgba(0,0,0,0.06)',
                md: '0 4px 24px rgba(0,0,0,0.08)',
                lg: '0 12px 40px rgba(0,0,0,0.14)'
            };
            $canvas.css({
                background: s.bg_color || '#ffffff',
                boxShadow: shadows[s.shadow || 'md'] || shadows.md,
                border: `${bw} solid ${bc}`,
                borderRadius: r
            });
        }

        const btnStyle = s.button_style || 'gradient';
        let btnCss = {};
        if (btnStyle === 'gradient') {
            btnCss = { background: `linear-gradient(135deg, ${pc}, ${shadeColor(pc, -20)})`, color: s.button_text_color || '#fff', border: 'none', borderRadius: r };
        } else if (btnStyle === 'solid') {
            btnCss = { background: pc, color: s.button_text_color || '#fff', border: 'none', borderRadius: r };
        } else if (btnStyle === 'outline') {
            btnCss = { background: 'transparent', color: pc, border: `2px solid ${pc}`, borderRadius: r };
        } else if (btnStyle === 'rounded') {
            btnCss = { background: `linear-gradient(135deg, ${pc}, ${shadeColor(pc, -20)})`, color: s.button_text_color || '#fff', border: 'none', borderRadius: '50px' };
        }
        $('#cm-preview-submit').css(btnCss).text(s.button_text || 'Enviar Mensaje');
        const btnSizes = { sm: { padding: '8px 18px', fontSize: '13px' }, md: { padding: '12px 26px', fontSize: '15px' }, lg: { padding: '16px 34px', fontSize: '17px' } };
        const btnSz = btnSizes[s.btn_size || 'md'];
        $('.cm-canvas-submit-preview').css('textAlign', s.btn_align || 'left');
        $('#cm-preview-submit').css({
            width: s.btn_fullwidth ? '100%' : '',
            display: s.btn_fullwidth ? 'block' : '',
            padding: btnSz.padding,
            fontSize: btnSz.fontSize
        });

        $('#cm-form-canvas .cm-field-label-mock').css('color', s.label_color || '#0f172a');
        $('#cm-live-title').css('color', s.label_color || '#0f172a');

        if (s.show_credit !== false) {
            $('#cm-canvas-credit-preview').show();
        } else {
            $('#cm-canvas-credit-preview').hide();
        }
    }

    function shadeColor(color, percent) {
        if (!color || color === 'transparent') return '#4f46e5';
        let R = parseInt(color.substring(1,3), 16) || 0;
        let G = parseInt(color.substring(3,5), 16) || 0;
        let B = parseInt(color.substring(5,7), 16) || 0;
        R = Math.min(255, Math.max(0, R + percent));
        G = Math.min(255, Math.max(0, G + percent));
        B = Math.min(255, Math.max(0, B + percent));
        return "#" + ((1 << 24) + (R << 16) + (G << 8) + B).toString(16).slice(1);
    }

    function updateFieldSelector() {
        const $sel = $('#cm-inspector-field-selector');
        $sel.html('<option value="">— Seleccionar campo —</option>');
        schema.fields.forEach(f => {
            const icon = FIELD_ICON[f.type] || '▪';
            $sel.append(`<option value="${f.id}" ${f.id === selectedFieldId ? 'selected' : ''}>${icon} ${f.label || FIELD_NAME[f.type]}</option>`);
        });
    }

    function selectField(id) {
        selectedFieldId = id;
        const field = getField(id);
        if (!field) { deselectAll(); return; }

        $('#cm-canvas-fields-container .cm-canvas-field-item').removeClass('selected');
        $(`[data-id="${id}"]`).addClass('selected');
        $('#cm-no-field-selected').hide();
        $('#cm-field-inspector-form').show();

        $('#cm-field-type-badge').text((FIELD_ICON[field.type] || '') + ' ' + (FIELD_NAME[field.type] || field.type));
        $('#cm-prop-label').val(field.label || '');
        $('#cm-prop-placeholder').val(field.placeholder || '');
        $('#cm-prop-help').val(field.help || '');
        $('#cm-prop-width').val(field.width || '100');
        $('#cm-prop-required').prop('checked', !!field.required);
        $('#cm-req-label').text(field.required ? 'Obligatorio' : 'Opcional');

        syncPosInputsVisibility();
        $('#cm-prop-pos-x').val(typeof field.x !== 'undefined' ? field.x : '');
        $('#cm-prop-pos-y').val(typeof field.y !== 'undefined' ? field.y : '');
        $('#cm-prop-pos-w').val(typeof field.w !== 'undefined' ? field.w : '');

        if (field.type === 'terms' || field.type === 'checkbox') {
            $('#cm-prop-terms-section').show();
            $('#cm-prop-terms-link').val(field.terms_link_text || 'Términos y Condiciones');
            $('#cm-prop-terms-title').val(field.terms_title || 'Políticas y Términos');
            $('#cm-prop-terms-content').val(field.terms_content || '');
        } else {
            $('#cm-prop-terms-section').hide();
        }

        if (['department', 'select', 'radio'].includes(field.type)) {
            $('#cm-prop-department-section').show();
            renderDeptOptions(field);
        } else {
            $('#cm-prop-department-section').hide();
        }

        $('#cm-prop-custom-border').val(field.custom_border || '#e2e8f0');
        $('#cm-prop-custom-border-hex').val(field.custom_border || '#e2e8f0');
        $('#cm-prop-custom-bg').val(field.custom_bg || '#f8fafc');
        $('#cm-prop-custom-bg-hex').val(field.custom_bg || '#f8fafc');

        activateTab('field-properties');
        $('#cm-inspector-field-selector').val(id);
    }

    function deselectAll() {
        selectedFieldId = null;
        $('#cm-no-field-selected').show();
        $('#cm-field-inspector-form').hide();
        $('#cm-canvas-fields-container .cm-canvas-field-item').removeClass('selected');
        $('#cm-inspector-field-selector').val('');
    }

    function renderDeptOptions(field) {
        const $list = $('#cm-department-options-list').html('');
        const opts  = field.options || [];
        const isDept = field.type === 'department';
        opts.forEach((opt, i) => {
            const emailRow = isDept
                ? `<label style="font-size:11px;color:#64748b;margin-top:4px;">Correos destino (separados por coma)</label>
                   <input type="text" class="cm-dep-email cm-prop-input" data-index="${i}" value="${opt.email || ''}" placeholder="ejemplo@colegio.cl, otro@colegio.cl" />`
                : '';
            $list.append(`
                <div class="cm-dep-option-card" data-index="${i}">
                    <div class="cm-dep-option-header">
                        <div class="cm-dep-option-number">${i + 1}</div>
                        <button type="button" class="cm-remove-dep-btn" data-index="${i}">Eliminar</button>
                    </div>
                    <label style="font-size:11px;color:#64748b;">Nombre de la opción</label>
                    <input type="text" class="cm-dep-name cm-prop-input" data-index="${i}" value="${opt.nombre || ''}" placeholder="Ej. Convivencia Escolar" />
                    ${emailRow}
                </div>
            `);
        });

        $list.find('.cm-dep-name').on('input', function () {
            const idx = parseInt($(this).data('index'));
            const f2  = getField(selectedFieldId);
            if (f2 && f2.options[idx]) {
                f2.options[idx].nombre = $(this).val();
                renderCanvas();
                selectField(selectedFieldId);
            }
        });
        $list.find('.cm-dep-email').on('input', function () {
            const idx = parseInt($(this).data('index'));
            const f2  = getField(selectedFieldId);
            if (f2 && f2.options[idx]) {
                f2.options[idx].email = $(this).val();
            }
        });
        $list.find('.cm-remove-dep-btn').on('click', function () {
            const idx = parseInt($(this).data('index'));
            const f2  = getField(selectedFieldId);
            if (f2 && f2.options.length > 1) {
                f2.options.splice(idx, 1);
                renderCanvas();
                selectField(selectedFieldId);
            }
        });
    }

    function activateTab(tabId) {
        $('.cm-tab-btn').removeClass('active');
        $(`.cm-tab-btn[data-tab="${tabId}"]`).addClass('active');
        $('.cm-tab-content').removeClass('active');
        $(`#tab-${tabId}`).addClass('active');
    }

    function init() {
        const s = schema.settings;
        $('#cm-setting-primary-color').val(s.primary_color || '#4f46e5');
        $('#cm-setting-primary-color-hex').val(s.primary_color || '#4f46e5');
        $('#cm-setting-btn-text-color').val(s.button_text_color || '#ffffff');
        $('#cm-setting-btn-text-color-hex').val(s.button_text_color || '#ffffff');
        const bgInit = s.bg_color === 'transparent' ? '#ffffff' : (s.bg_color || '#ffffff');
        $('#cm-setting-bg-color').val(bgInit);
        $('#cm-setting-bg-color-hex').val(bgInit);
        $('#cm-setting-bg-transparent').prop('checked', s.bg_color === 'transparent' || s.bg_color === 'rgba(0, 0, 0, 0)');
        $('#cm-setting-btn-align').val(s.btn_align || 'left');
        $('#cm-setting-btn-size').val(s.btn_size || 'md');
        $('#cm-setting-btn-fullwidth').prop('checked', !!s.btn_fullwidth);
        $('#cm-setting-label-color').val(s.label_color || '#0f172a');
        $('#cm-setting-label-color-hex').val(s.label_color || '#0f172a');
        $('#cm-setting-input-bg').val(s.input_bg_color || '#f8fafc');
        $('#cm-setting-input-bg-hex').val(s.input_bg_color || '#f8fafc');
        $('#cm-setting-input-border').val(s.input_border_color || '#e2e8f0');
        $('#cm-setting-input-border-hex').val(s.input_border_color || '#e2e8f0');
        $('#cm-setting-radius').val(s.border_radius || '12');
        $('#cm-radius-val').text((s.border_radius || '12') + 'px');
        $('#cm-setting-shadow').val(s.shadow || 'md');
        loadMaxWidthControl();

        loadMaxWidthControl();
        $('#cm-setting-density').val(effVal('density') || 'normal');
        $('#cm-setting-card-preset').val(s.card_preset || 'modern');
        $('#cm-setting-border-width').val(s.border_width || '1');
        $('#cm-setting-container-border').val(s.container_border_color || '#e2e8f0');
        $('#cm-setting-container-border-hex').val(s.container_border_color || '#e2e8f0');
        $('#cm-setting-btn-text').val(s.button_text || 'Enviar Mensaje');
        $('#cm-setting-btn-style').val(s.button_style || 'gradient');
        $('#cm-setting-show-credit').prop('checked', s.show_credit !== false);

        $('#cm-setting-pos-mode').val(s.pos_mode ? '1' : '');
        $('#cm-group-canvas-h').toggle(!!s.pos_mode);
        $('#cm-setting-canvas-h').val(s.canvas_h || 760);

        $('#cm-setting-show-header').prop('checked', s.show_header !== false);
        $('#cm-setting-title').val(s.title || '');
        $('#cm-setting-subtitle').val(s.subtitle || '');
        $('#cm-setting-success-msg').val(s.success_msg || '');

        $('#cm-setting-dest-emails').val(s.destination_emails || '');
        $('#cm-setting-default-area').val(s.default_area_name || 'General / Consultas');
        $('#cm-setting-custom-subject').val(s.custom_subject || '');
        $('#cm-setting-enable-autoresponder').prop('checked', s.enable_autoresponder !== false);

        renderCanvas();
    }

    $(function () {
        init();

        $(document).on('click', '.cm-component-card', function () {
            const type    = $(this).data('type');
            const def     = FIELD_DEFAULTS[type] || { label: type, required: false, width: '100', help: '' };
            const newField = Object.assign({ id: uid(), type }, JSON.parse(JSON.stringify(def)));
            schema.fields.push(newField);
            renderCanvas();
            selectField(newField.id);
        });

        $(document).on('click', '.cm-canvas-field-item', function (e) {
            if ($(e.target).closest('.cm-field-actions').length) return;
            const id = $(this).data('id');
            if (id) selectField(id);
        });

        $(document).on('click', '#cm-canvas-form-header', function (e) {
            if ($(e.target).is('#cm-hide-header-btn')) return;
            activateTab('form-settings');
            $('#cm-setting-title').focus();
        });

        $(document).on('click', '#cm-hide-header-btn', function (e) {
            e.stopPropagation();
            schema.settings.show_header = false;
            $('#cm-setting-show-header').prop('checked', false);
            updateHeaderUI();
        });

        $(document).on('click', '#cm-show-header-btn', function () {
            schema.settings.show_header = true;
            $('#cm-setting-show-header').prop('checked', true);
            updateHeaderUI();
            activateTab('form-settings');
            $('#cm-setting-title').focus();
        });

        $('#cm-setting-show-header').on('change', function () {
            schema.settings.show_header = $(this).is(':checked');
            updateHeaderUI();
        });

        $('#cm-clear-title-btn').on('click', function () {
            $('#cm-setting-title').val('').trigger('input');
        });
        $('#cm-clear-subtitle-btn').on('click', function () {
            $('#cm-setting-subtitle').val('').trigger('input');
        });

        $('#cm-inspector-field-selector').on('change', function () {
            const id = $(this).val();
            if (id) selectField(id); else deselectAll();
        });

        $(document).on('click', '.cm-del-btn', async function (e) {
            e.stopPropagation();
            const id = $(this).data('id');
            const f = getField(id);
            if (!(await cmConfirm({
                icon: '🗑',
                title: 'Eliminar campo',
                message: 'Se eliminará "' + (f ? f.label : 'este campo') + '" del formulario.',
                okText: 'Eliminar'
            }))) return;
            schema.fields = schema.fields.filter(fl => fl.id !== id);
            if (selectedFieldId === id) deselectAll();
            renderCanvas();
        });

        $(document).on('click', '.cm-dup-btn', function (e) {
            e.stopPropagation();
            const id = $(this).data('id');
            const orig = getField(id);
            if (!orig) return;
            const clone = JSON.parse(JSON.stringify(orig));
            clone.id = uid();
            clone.label = clone.label + ' (copia)';
            const idx = schema.fields.findIndex(f => f.id === id);
            schema.fields.splice(idx + 1, 0, clone);
            renderCanvas();
            selectField(clone.id);
        });

        $('#cm-prop-label').on('input', function () {
            const f = getField(selectedFieldId); if (!f) return;
            f.label = $(this).val();
            renderCanvas();
            selectField(selectedFieldId);
        });
        $('#cm-prop-placeholder').on('input', function () {
            const f = getField(selectedFieldId); if (!f) return;
            f.placeholder = $(this).val();
            renderCanvas();
        });
        $('#cm-prop-help').on('input', function () {
            const f = getField(selectedFieldId); if (!f) return;
            f.help = $(this).val();
            renderCanvas();
        });
        $('#cm-prop-width').on('change', function () {
            const f = getField(selectedFieldId); if (!f) return;
            f.width = $(this).val();
            renderCanvas();
        });
        $('#cm-prop-required').on('change', function () {
            const f = getField(selectedFieldId); if (!f) return;
            f.required = $(this).is(':checked');
            $('#cm-req-label').text(f.required ? 'Obligatorio' : 'Opcional');
            renderCanvas();
        });

        $('#cm-prop-pos-x, #cm-prop-pos-y, #cm-prop-pos-w').on('input', function () {
            if (!selectedFieldId) return;
            const f = getField(selectedFieldId); if (!f) return;
            f.x = parseFloat($('#cm-prop-pos-x').val()) || 0;
            f.y = parseFloat($('#cm-prop-pos-y').val()) || 0;
            f.w = parseFloat($('#cm-prop-pos-w').val()) || 30;
            $(`#cm-canvas-fields-container [data-id="${f.id}"]`).attr('style', fieldPosStyle(f));
        });

        $('#cm-prop-terms-link').on('input', function () {
            const f = getField(selectedFieldId); if (!f) return;
            f.terms_link_text = $(this).val();
            renderCanvas();
        });
        $('#cm-prop-terms-title').on('input', function () {
            const f = getField(selectedFieldId); if (!f) return;
            f.terms_title = $(this).val();
        });
        $('#cm-prop-terms-content').on('input', function () {
            const f = getField(selectedFieldId); if (!f) return;
            f.terms_content = $(this).val();
        });

        function syncFieldColor(pickerId, hexId, key) {
            $(`#${pickerId}`).on('input change', function () {
                const v = $(this).val();
                $(`#${hexId}`).val(v);
                const f = getField(selectedFieldId);
                if (f) { f[key] = v; renderCanvas(); selectField(selectedFieldId); }
            });
            $(`#${hexId}`).on('input', function () {
                const v = $(this).val();
                if (/^#[0-9A-Fa-f]{6}$/.test(v)) {
                    $(`#${pickerId}`).val(v);
                    const f = getField(selectedFieldId);
                    if (f) { f[key] = v; renderCanvas(); selectField(selectedFieldId); }
                }
            });
        }
        syncFieldColor('cm-prop-custom-border', 'cm-prop-custom-border-hex', 'custom_border');
        syncFieldColor('cm-prop-custom-bg', 'cm-prop-custom-bg-hex', 'custom_bg');

        $(document).on('click', '#cm-add-dep-option-btn', function () {
            const f = getField(selectedFieldId); if (!f || !f.options) return;
            f.options.push({ nombre: 'Nueva área / opción', email: '' });
            renderCanvas();
            selectField(selectedFieldId);
        });

        $(document).on('click', '.cm-tab-btn', function () {
            activateTab($(this).data('tab'));
        });

        function exitTransparentPreset() {
            if (!isTransparentBg(schema.settings.bg_color)) return;
            schema.settings.card_preset = 'modern';
            schema.settings.shadow = schema.settings.shadow && schema.settings.shadow !== 'none' ? schema.settings.shadow : 'md';
            $('#cm-setting-card-preset').val('modern');
            $('#cm-setting-shadow').val(schema.settings.shadow);
        }
        function syncColorPair(pickerId, hexId, schemaKey) {
            $(`#${pickerId}`).on('input change', function () {
                const v = $(this).val();
                $(`#${hexId}`).val(v);
                schema.settings[schemaKey] = v;
                if (schemaKey === 'bg_color') exitTransparentPreset();
                applyDesignPreview();
            });
            $(`#${hexId}`).on('input', function () {
                const v = $(this).val();
                if (/^#[0-9A-Fa-f]{6}$/.test(v)) {
                    $(`#${pickerId}`).val(v);
                    schema.settings[schemaKey] = v;
                    if (schemaKey === 'bg_color') exitTransparentPreset();
                    applyDesignPreview();
                }
            });
        }
        syncColorPair('cm-setting-primary-color', 'cm-setting-primary-color-hex', 'primary_color');
        syncColorPair('cm-setting-btn-text-color', 'cm-setting-btn-text-color-hex', 'button_text_color');
        syncColorPair('cm-setting-bg-color', 'cm-setting-bg-color-hex', 'bg_color');
        syncColorPair('cm-setting-label-color', 'cm-setting-label-color-hex', 'label_color');
        syncColorPair('cm-setting-input-bg', 'cm-setting-input-bg-hex', 'input_bg_color');
        syncColorPair('cm-setting-input-border', 'cm-setting-input-border-hex', 'input_border_color');
        syncColorPair('cm-setting-container-border', 'cm-setting-container-border-hex', 'container_border_color');

        $('#cm-setting-pos-mode').on('change', function () {
            const turningOn = $(this).val() === '1';
            if (turningOn && !schema.settings.pos_mode) {
                captureFlowPositions();
            }
            schema.settings.pos_mode = turningOn;
            if (posModeOn() && typeof schema.settings.canvas_h === 'undefined') schema.settings.canvas_h = 760;
            $('#cm-group-canvas-h').toggle(posModeOn());
            syncPosInputsVisibility();
            renderCanvas();
        });
        $('#cm-setting-canvas-h').on('input', function () {
            schema.settings.canvas_h = parseInt($(this).val(), 10) || 760;
            if (posModeOn()) {
                $('#cm-canvas-fields-container').css('minHeight', Math.max(200, schema.settings.canvas_h) + 'px');
            }
        });
        $('#cm-btn-auto-arrange').on('click', autoArrangeLayout);
        $('#cm-btn-autofit-h').on('click', autofitCanvasHeight);

        const isTransparentBg = v => v === 'transparent' || v === 'rgba(0, 0, 0, 0)';
        const restoreSolidBg = () => {
            schema.settings.bg_color = '#ffffff';
            $('#cm-setting-bg-color').val('#ffffff');
            $('#cm-setting-bg-color-hex').val('#ffffff');
        };
        $('#cm-setting-bg-transparent').on('change', function () {
            if (this.checked) {
                schema.settings.card_preset = 'modern';
                schema.settings.bg_color = 'transparent';
                schema.settings.shadow = 'none';
                $('#cm-setting-card-preset').val('modern');
                $('#cm-setting-shadow').val('none');
            } else {
                restoreSolidBg();
                if (!schema.settings.shadow || schema.settings.shadow === 'none') {
                    schema.settings.shadow = 'md';
                    $('#cm-setting-shadow').val('md');
                }
            }
            applyDesignPreview();
        });
        $('#cm-setting-card-preset').on('change', function () {
            const preset = $(this).val();
            schema.settings.card_preset = preset;
            if ($('#cm-setting-bg-transparent').prop('checked')) {
                $('#cm-setting-bg-transparent').prop('checked', false);
                restoreSolidBg();
            }
            if (isTransparentBg(schema.settings.bg_color)) restoreSolidBg();
            if (preset === 'flat') {
                schema.settings.shadow = 'none';
                $('#cm-setting-shadow').val('none');
            } else if (preset === 'rounded') {
                schema.settings.border_radius = '26';
                $('#cm-setting-radius').val('26');
                $('#cm-radius-val').text('26px');
                if (!schema.settings.shadow || schema.settings.shadow === 'none') {
                    schema.settings.shadow = 'md';
                    $('#cm-setting-shadow').val('md');
                }
            }
            applyDesignPreview();
        });

        $('#cm-setting-border-width').on('change', function () {
            schema.settings.border_width = $(this).val();
            applyDesignPreview();
        });

        $('#cm-setting-radius').on('input', function () {
            const v = $(this).val();
            $('#cm-radius-val').text(v + 'px');
            schema.settings.border_radius = v;
            applyDesignPreview();
        });

        $('#cm-setting-shadow').on('change', function () {
            schema.settings.shadow = $(this).val();
            applyDesignPreview();
        });

        $('#cm-setting-max-width-range').on('input', function () {
            $('#cm-setting-max-width-num').val($(this).val());
            $('#cm-setting-max-width-full').prop('checked', false);
            setDevVal('max_width', $(this).val() + 'px');
            applyDesignPreview();
        });
        $('#cm-setting-max-width-num').on('change input', function () {
            const v = Math.min(1600, Math.max(280, parseInt($(this).val(), 10) || 840));
            $(this).val(v);
            $('#cm-setting-max-width-range').val(Math.min(1200, v));
            $('#cm-setting-max-width-full').prop('checked', false);
            setDevVal('max_width', v + 'px');
            applyDesignPreview();
        });
        $('#cm-setting-max-width-full').on('change', function () {
            setDevVal('max_width', this.checked ? '100%' : (($('#cm-setting-max-width-num').val() || 840) + 'px'));
            applyDesignPreview();
        });
        $('#cm-inherit-max-width').on('click', function () {
            if (schema.settings.device_overrides && schema.settings.device_overrides[editDevice]) delete schema.settings.device_overrides[editDevice].max_width;
            refreshDeviceUI(); loadMaxWidthControl(); applyDesignPreview();
        });

        $('#cm-setting-density').on('change', function () {
            setDevVal('density', $(this).val());
            applyDesignPreview();
        });
        $('#cm-inherit-density').on('click', function () {
            if (schema.settings.device_overrides && schema.settings.device_overrides[editDevice]) delete schema.settings.device_overrides[editDevice].density;
            refreshDeviceUI();
            $('#cm-setting-density').val(effVal('density') || 'normal');
            applyDesignPreview();
        });

        $('#cm-setting-btn-style').on('change', function () {
            schema.settings.button_style = $(this).val();
            applyDesignPreview();
        });
        $('#cm-setting-btn-text').on('input', function () {
            schema.settings.button_text = $(this).val();
            applyDesignPreview();
        });
        $('#cm-setting-btn-align').on('change', function () {
            schema.settings.btn_align = $(this).val();
            applyDesignPreview();
        });
        $('#cm-setting-btn-size').on('change', function () {
            schema.settings.btn_size = $(this).val();
            applyDesignPreview();
        });
        $('#cm-setting-btn-fullwidth').on('change', function () {
            schema.settings.btn_fullwidth = $(this).is(':checked');
            applyDesignPreview();
        });
        $(document).on('click', '#cm-alert-fix-dest', function () {
            activateTab('form-settings');
            const el = document.getElementById('cm-setting-dest-emails');
            if (el) {
                el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                setTimeout(() => el.focus(), 450);
            }
        });

        $('#cm-setting-show-credit').on('change', function () {
            schema.settings.show_credit = $(this).is(':checked');
            applyDesignPreview();
        });

        $('#cm-setting-title').on('input', function () {
            schema.settings.title = $(this).val();
            updateHeaderUI();
        });
        $('#cm-setting-subtitle').on('input', function () {
            schema.settings.subtitle = $(this).val();
            updateHeaderUI();
        });
        $('#cm-setting-success-msg').on('input', function () {
            schema.settings.success_msg = $(this).val();
        });

        $('#cm-setting-dest-emails').on('input', function () {
            schema.settings.destination_emails = $(this).val();
        });
        $('#cm-setting-default-area').on('input', function () {
            schema.settings.default_area_name = $(this).val();
        });
        $('#cm-setting-custom-subject').on('input', function () {
            schema.settings.custom_subject = $(this).val();
        });
        $('#cm-setting-enable-autoresponder').on('change', function () {
            schema.settings.enable_autoresponder = $(this).is(':checked');
        });

        $(document).on('click', '#cm-preview-submit', function () {
            activateTab('form-settings');
            $('#cm-setting-dest-emails').focus();
        });

        $(document).on('input blur', '#cm-live-title', function () {
            const txt = $(this).text().trim();
            if (txt !== '(Sin título - haz clic para escribir)') {
                schema.settings.title = txt;
                $('#cm-setting-title').val(txt);
            }
        });
        $(document).on('input blur', '#cm-live-subtitle', function () {
            const txt = $(this).text().trim();
            if (txt !== '(Sin subtítulo - haz clic para escribir)') {
                schema.settings.subtitle = txt;
                $('#cm-setting-subtitle').val(txt);
            }
        });

        $('#cm-palette-filter').on('input', function () {
            const q = $(this).val().toLowerCase();
            $('.cm-component-card').each(function () {
                const txt = $(this).find('span').text().toLowerCase();
                $(this).toggle(!q || txt.includes(q));
            });
        });

        function refreshFormSelector(forms, keepId) {
            if (!forms) forms = (window.cmBuilderVars && cmBuilderVars.forms) || {};
            const $sel = $('#cm-form-selector').empty();
            $.each(forms, (id, label) => $sel.append($('<option>', { value: id, text: label })));
            const active = keepId && forms[keepId] ? keepId : currentFormId;
            if (active && forms[active]) $sel.val(active);

            const $name = $('#cm-form-name-input');
            if ($name.length && !$name.is(':focus')) {
                $name.val($sel.find('option:selected').text().replace(/\s*★$/, '').trim());
            }
            updateShortcodeChip();
        }

        function updateShortcodeChip() {
            const $chip = $('#cm-form-shortcode-chip');
            if (!$chip.length) return;
            const map = (window.cmBuilderVars && cmBuilderVars.shortcodes) || {};
            let tag = map[currentFormId] || '';

            if (!tag) {
                const base = (currentFormName() || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').replace(/-/g, '_');
                tag = base ? 'formulario_ingecodex_' + base : '';
            }
            $chip.text(tag ? '[' + tag + ']' : '').toggle(!!tag);
        }

        function currentFormName() {

            const $inp = $('#cm-form-name-input');
            const typed = $inp.length ? $inp.val().trim() : '';
            if (typed) return typed;
            const $opt = $('#cm-form-selector option:selected');
            return $opt.length ? $opt.text().replace(/\s*★$/, '').trim() : '';
        }

        function reloadWithForm(id) {
            const url = new URL(window.location.href);
            if (id) url.searchParams.set('form', id); else url.searchParams.delete('form');
            window.location.href = url.toString();
        }

        refreshFormSelector();

        $('#cm-form-shortcode-chip').on('click', function () {
            const text = $(this).text();
            if (!text) return;
            const done = () => {
                const $c = $(this), prev = text;
                $c.text('✓ Copiado');
                setTimeout(() => $c.text(prev), 1400);
            };
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(text).then(done).catch(() => {});
            } else {
                const ta = $('<textarea>').val(text).appendTo('body').select();
                document.execCommand('copy'); ta.remove(); done();
            }
        });

        $('#cm-form-name-input').on('input', updateShortcodeChip);

        $('#cm-form-selector').on('change', function () {
            currentFormId = $(this).val() || '';
            reloadWithForm(currentFormId);
        }).on('dblclick', function () {
            $('#cm-form-name-input').trigger('focus').trigger('select');
        });

        $('#cm-btn-new-form').on('click', () => {
            const modal = document.getElementById('cm-gallery-modal');
            if (modal) {
                modal.style.display = 'flex';
                $('#cm-new-form-name').val('Nuevo Formulario').focus();
            }
        });

        $('.cm-gallery-filter-btn').on('click', function () {
            $('.cm-gallery-filter-btn').removeClass('active').css({ background: '#fff', color: '#475569' });
            $(this).addClass('active').css({ background: '#4f46e5', color: '#fff' });
            const cat = $(this).data('cat');
            $('.cm-gallery-card').each(function () {
                const itemCat = $(this).data('category');
                $(this).toggle(cat === 'all' || itemCat === cat);
            });
        });

        $(document).on('mouseenter', '.cm-gallery-card', function () {
            $(this).css({ transform: 'translateY(-3px)', borderColor: '#4f46e5', boxShadow: '0 10px 24px rgba(79,70,229,0.12)' });
        }).on('mouseleave', '.cm-gallery-card', function () {
            $(this).css({ transform: 'none', borderColor: '#e2e8f0', boxShadow: '0 4px 12px rgba(0,0,0,0.04)' });
        });

        $(document).on('click', '.cm-use-template-btn', function (e) {
            e.stopPropagation();
            const $btn = $(this);
            const template = $btn.data('template');
            let formName = $('#cm-new-form-name').val().trim();
            if (!formName || formName === 'Nuevo Formulario') {
                formName = $btn.data('default-name') || 'Nuevo Formulario';
            }

            $btn.prop('disabled', true).text('Creando formulario...');
            $.post(cmBuilderVars.ajax_url, {
                action: 'cm_new_form',
                nonce: cmBuilderVars.nonce,
                form_name: formName,
                template: template
            }, res => {
                if (res.success) {
                    reloadWithForm(res.data.form_id);
                } else {
                    cmToast(res.data?.message || 'Error al crear formulario', 'error');
                    $btn.prop('disabled', false).text('✨ Usar Esta Plantilla');
                }
            }).fail(() => {
                cmToast('Error de conexión con el servidor.', 'error');
                $btn.prop('disabled', false).text('✨ Usar Esta Plantilla');
            });
        });

        $('#cm-btn-dup-form').on('click', async () => {
            if (!(await cmConfirm({
                icon: '⧉',
                title: 'Duplicar formulario',
                message: 'Se creará una copia de "' + currentFormName() + '" con todos sus campos.',
                okText: 'Duplicar',
                danger: false
            }))) return;
            $.post(cmBuilderVars.ajax_url, { action: 'cm_duplicate_form', nonce: cmBuilderVars.nonce, form_id: currentFormId }, res => {
                if (res.success) reloadWithForm(res.data.form_id);
                else cmToast(res.data?.message || 'Error', 'error');
            }).fail(() => cmToast('Error de conexión con el servidor.', 'error'));
        });

        $('#cm-btn-del-form').on('click', async () => {
            const n = Object.keys(schema.fields || {}).length;
            if (!(await cmConfirm({
                icon: '🗑',
                title: 'Eliminar formulario',
                message: 'Se eliminará "' + currentFormName() + '" y sus ' + n + ' campos. Esta acción no se puede deshacer.',
                okText: 'Eliminar'
            }))) return;
            $.post(cmBuilderVars.ajax_url, { action: 'cm_delete_form', nonce: cmBuilderVars.nonce, form_id: currentFormId }, res => {
                if (res.success) reloadWithForm('');
                else cmToast(res.data?.message || 'Error', 'error');
            }).fail(() => cmToast('Error de conexión con el servidor.', 'error'));
        });

        $('#cm-btn-preview-modal').on('click', function () {
            const doPreview = () => {
                const modal = document.getElementById('cm-preview-modal');
                if (modal) modal.style.display = 'flex';
                const frame = document.getElementById('cm-preview-iframe');
                if (frame) {
                    try {
                        const url = new URL(frame.src.split('&_t=')[0], window.location.origin);
                        if (currentFormId) url.searchParams.set('form', currentFormId);
                        url.searchParams.set('_t', Date.now());
                        frame.src = url.toString();
                    } catch (e) {
                        frame.src = frame.src.split('&_t=')[0] + '&_t=' + Date.now();
                    }
                }
            };
            $.post(cmBuilderVars.ajax_url, {
                action: 'cm_save_form_schema',
                nonce:  cmBuilderVars.nonce,
                schema: JSON.stringify(schema),
                form_id:   currentFormId || '',
                form_name: currentFormName()
            }, res => {
                if (res && res.success) {
                    currentFormId = res.data.form_id || currentFormId;
                    refreshFormSelector(res.data.forms, currentFormId);
                }
                doPreview();
            }).fail(doPreview);
        });

        $(document).on('click', '.cm-view-btn', function () {
            $('.cm-view-btn').removeClass('active');
            $(this).addClass('active');
            const view = $(this).data('view');
            const $vp  = $('#cm-canvas-viewport');
            $vp.removeClass('desktop-view tablet-view mobile-view');
            $vp.addClass(view + '-view');

            editDevice = view;
            refreshDeviceUI();
            loadMaxWidthControl();
            $('#cm-setting-density').val(effVal('density') || 'normal');
            applyDesignPreview();
        });
        refreshDeviceUI();

        $('#cm-save-schema-btn').on('click', function () {
            const $btn = $(this).prop('disabled', true).text('Guardando...');

            if (window.cmCurrentStudioMode === 'tracker') {
                var data = {
                    action: 'cm_save_tracker_settings',
                    nonce:  cmBuilderVars.nonce,
                    settings: {
                        badge_text: $('#cm-sb-tset-badge').val(),
                        title: $('#cm-sb-tset-title').val(),
                        subtitle: $('#cm-sb-tset-subtitle').val(),
                        search_btn_text: $('#cm-sb-tset-btn-text').val(),
                        search_placeholder: $('#cm-sb-tset-placeholder').val(),
                        hint_text: $('#cm-sb-tset-hint').val(),
                        btn_style: $('#cm-sb-tset-btn-style').val(),
                        btn_bg_color: $('#cm-sb-tset-btn-bg').val(),
                        btn_text_color: $('#cm-sb-tset-btn-color').val(),
                        btn_border_color: $('#cm-sb-tset-btn-border').val(),
                        btn_border_radius: $('#cm-sb-tset-btn-radius').val(),
                        primary_color: $('#cm-sb-tset-primary').val(),
                        card_bg_color: $('#cm-sb-tset-card-bg').val(),
                        card_style: $('#cm-sb-tset-style').val(),
                        show_seal: $('#cm-sb-tset-show-seal').is(':checked') ? 1 : 0,
                        seal_text: $('#cm-sb-tset-seal-text').val()
                    }
                };

                $.post(cmBuilderVars.ajax_url, data, function (res) {
                    if (res.success) {
                        $btn.text('✓ Guardado!').css({ background: 'linear-gradient(135deg, #10b981, #059669)' });
                        cmToast('✓ ¡Ajustes del Buscador por Código guardados exitosamente!', '');
                        setTimeout(() => {
                            $btn.prop('disabled', false).text('💾 Guardar Cambios').css({ background: '' });
                        }, 2000);
                    } else {
                        cmToast('Error al guardar: ' + (res.data?.message || 'Error desconocido'), 'error');
                        $btn.prop('disabled', false).text('💾 Guardar Cambios');
                    }
                }).fail(() => {
                    cmToast('Error de conexión con el servidor.', 'error');
                    $btn.prop('disabled', false).text('💾 Guardar Cambios');
                });
                return;
            }

            $.post(cmBuilderVars.ajax_url, {
                action: 'cm_save_form_schema',
                nonce:  cmBuilderVars.nonce,
                schema: JSON.stringify(schema),
                form_id:   currentFormId || '',
                form_name: currentFormName()
            }, function (res) {
                if (res.success) {
                    currentFormId = res.data.form_id || currentFormId;
                    $btn.text('✓ Guardado!').css({ background: 'linear-gradient(135deg, #10b981, #059669)' });
                    if ($('#cm-mail-alert').length && String(schema.settings.destination_emails || '').trim() !== '') {
                        cmToast('Destinatario guardado. Actualiza la página donde insertaste el formulario para verlo.', '');
                    }
                    setTimeout(() => {
                        $btn.prop('disabled', false).text('💾 Guardar Cambios')
                            .css({ background: '' });
                    }, 2000);
                    refreshFormSelector(res.data.forms);
                } else {
                    cmToast('Error al guardar: ' + (res.data?.message || 'Error desconocido'), 'error');
                    $btn.prop('disabled', false).text('💾 Guardar Cambios');
                }
            }).fail(() => {
                cmToast('Error de conexión con el servidor.', 'error');
                $btn.prop('disabled', false).text('💾 Guardar Cambios');
            });
        });

        window.cmCurrentStudioMode = 'forms';

        window.cmSwitchStudioMode = function(mode) {
            window.cmCurrentStudioMode = mode;
            if (mode === 'tracker') {
                $('#cm-tab-mode-tracker').addClass('active').css({ background: '#ffffff', color: '#0f172a', 'box-shadow': '0 1px 3px rgba(0,0,0,0.12)' });
                $('#cm-tab-mode-forms').removeClass('active').css({ background: 'transparent', color: '#475569', 'box-shadow': 'none' });
                $('#cm-formbar-controls-forms').hide();
                $('#cm-formbar-controls-tracker').css('display', 'flex');
                $('#cm-studio-view-forms').hide();
                $('#cm-studio-view-tracker').show();
                cmUpdateStudioTrackerPreview();
            } else {
                $('#cm-tab-mode-forms').addClass('active').css({ background: '#ffffff', color: '#0f172a', 'box-shadow': '0 1px 3px rgba(0,0,0,0.12)' });
                $('#cm-tab-mode-tracker').removeClass('active').css({ background: 'transparent', color: '#475569', 'box-shadow': 'none' });
                $('#cm-formbar-controls-tracker').hide();
                $('#cm-formbar-controls-forms').css('display', 'flex');
                $('#cm-studio-view-tracker').hide();
                $('#cm-studio-view-forms').show();
            }
        };

        window.cmUpdateStudioTrackerPreview = function() {
            var style       = $('#cm-sb-tset-style').val();
            var badge       = $('#cm-sb-tset-badge').val();
            var title       = $('#cm-sb-tset-title').val();
            var subtitle    = $('#cm-sb-tset-subtitle').val();
            var btnText     = $('#cm-sb-tset-btn-text').val();
            var placeholder = $('#cm-sb-tset-placeholder').val();
            var hint        = $('#cm-sb-tset-hint').val();
            var btnStyle    = $('#cm-sb-tset-btn-style').val();
            var btnBg       = $('#cm-sb-tset-btn-bg').val();
            var btnColor    = $('#cm-sb-tset-btn-color').val();
            var btnBorder   = $('#cm-sb-tset-btn-border').val() || btnBg;
            var btnRadius   = $('#cm-sb-tset-btn-radius').val() || '8';
            var primary     = $('#cm-sb-tset-primary').val();
            var cardBg      = $('#cm-sb-tset-card-bg').val();
            var showSeal    = $('#cm-sb-tset-show-seal').is(':checked');
            var sealText    = $('#cm-sb-tset-seal-text').val();

            $('#cm-sb-prev-badge').text(badge);
            $('#cm-sb-prev-title').text(title);
            $('#cm-sb-prev-subtitle').text(subtitle);
            $('#cm-sb-prev-btn-text').text(btnText);
            $('#cm-sb-prev-input').attr('placeholder', placeholder);
            $('#cm-sb-prev-hint').text(hint ? '💡 ' + hint : '');
            $('#cm-sb-prev-seal-text').text(sealText);

            if (showSeal) {
                $('#cm-sb-prev-seal-wrap').show();
            } else {
                $('#cm-sb-prev-seal-wrap').hide();
            }

            var btn = $('#cm-sb-prev-submit-btn');
            btn.css({
                'border-radius': btnRadius + 'px'
            });

            if (btnStyle === 'transparent') {
                btn.css({
                    'background': 'transparent',
                    'border': '2px solid ' + btnBorder,
                    'color': btnColor,
                    'box-shadow': 'none'
                });
            } else if (btnStyle === 'glass') {
                btn.css({
                    'background': 'rgba(255, 255, 255, 0.4)',
                    'backdrop-filter': 'blur(12px)',
                    '-webkit-backdrop-filter': 'blur(12px)',
                    'border': '1.5px solid rgba(255, 255, 255, 0.7)',
                    'color': btnColor,
                    'box-shadow': '0 4px 12px rgba(0,0,0,0.06)'
                });
            } else if (btnStyle === 'gradient') {
                btn.css({
                    'background': 'linear-gradient(135deg, ' + btnBg + ' 0%, ' + primary + ' 100%)',
                    'border': 'none',
                    'color': btnColor,
                    'box-shadow': '0 4px 14px rgba(0, 113, 227, 0.3)'
                });
            } else {
                btn.css({
                    'background': btnBg,
                    'border': 'none',
                    'color': btnColor,
                    'box-shadow': '0 3px 10px rgba(0,0,0,0.18)'
                });
            }

            var portal = $('#cm-sb-tracker-live-container');
            var card   = $('#cm-sb-prev-case-card');

            if (style === 'dark') {
                portal.css({
                    'background': '#111827',
                    'color': '#f8fafc',
                    'border': '1px solid #1f2937',
                    'border-radius': '16px',
                    'padding': '24px'
                });
                $('#cm-sb-prev-title').css('color', '#f8fafc');
                $('#cm-sb-prev-subtitle').css('color', '#94a3b8');
                $('#cm-sb-prev-badge').css({ 'background': '#1e293b', 'color': primary, 'border': '1px solid #334155' });
                card.css({ 'background': '#1f2937', 'border': '1px solid #374151', 'color': '#f8fafc' });
            } else if (style === 'glass') {
                portal.css({
                    'background': 'rgba(255, 255, 255, 0.85)',
                    'backdrop-filter': 'blur(16px)',
                    '-webkit-backdrop-filter': 'blur(16px)',
                    'color': '#0f172a',
                    'border': '1.5px solid rgba(255, 255, 255, 0.9)',
                    'border-radius': '18px',
                    'padding': '24px',
                    'box-shadow': '0 10px 30px rgba(0,0,0,0.06)'
                });
                $('#cm-sb-prev-title').css('color', '#0f172a');
                $('#cm-sb-prev-subtitle').css('color', '#475569');
                $('#cm-sb-prev-badge').css({ 'background': 'rgba(255,255,255,0.9)', 'color': primary, 'border': '1px solid rgba(0,0,0,0.06)' });
                card.css({ 'background': 'rgba(255,255,255,0.85)', 'border': '1px solid rgba(255,255,255,0.8)', 'color': '#0f172a' });
            } else if (style === 'signature') {
                portal.css({
                    'background': cardBg,
                    'color': '#0f172a',
                    'border': '2px solid ' + primary,
                    'border-top': '6px solid ' + primary,
                    'border-radius': '14px',
                    'padding': '26px',
                    'box-shadow': '0 4px 20px rgba(0, 113, 227, 0.08)'
                });
                $('#cm-sb-prev-title').css('color', '#0f172a');
                $('#cm-sb-prev-subtitle').css('color', '#475569');
                $('#cm-sb-prev-badge').css({ 'background': '#f0f9ff', 'color': primary, 'border': '1px solid #bae6fd' });
                card.css({ 'background': '#ffffff', 'border': '1.5px solid #e2e8f0', 'color': '#0f172a' });
                $('#cm-sb-prev-seal-badge').css({ 'border-color': primary, 'color': primary });
            } else {
                portal.css({
                    'background': cardBg,
                    'color': '#1d1d1f',
                    'border': '1px solid #e5e5ea',
                    'border-top': 'none',
                    'border-radius': '14px',
                    'padding': '22px',
                    'box-shadow': '0 2px 10px rgba(0,0,0,0.04)'
                });
                $('#cm-sb-prev-title').css('color', '#1d1d1f');
                $('#cm-sb-prev-subtitle').css('color', '#86868b');
                $('#cm-sb-prev-badge').css({ 'background': '#f5f5f7', 'color': primary, 'border': '1px solid #e5e5ea' });
                card.css({ 'background': '#ffffff', 'border': '1px solid #e5e5ea', 'color': '#1d1d1f' });
            }
        };
    });

})(jQuery);
