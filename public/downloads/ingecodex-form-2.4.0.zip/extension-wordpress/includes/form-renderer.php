<?php
if (!defined('ABSPATH')) { exit; }

function cm_render_dynamic_form($atts = array()) {
    $atts    = is_array($atts) ? $atts : array();
    $schema  = null;
    $form_id = '';
    if (!empty($atts['schema']) && is_array($atts['schema'])) {
        $schema = $atts['schema'];
    } elseif (!empty($atts['id']) && function_exists('cm_get_form')) {
        $schema  = cm_get_form($atts['id']);
        $form_id = $atts['id'];
    }
    if (!$schema && function_exists('cm_get_default_form_id')) {
        $default_id = cm_get_default_form_id();
        if ($default_id) {
            $schema  = cm_get_form($default_id);
            $form_id = $default_id;
        }
    }
    if (!$schema) {
        $schema = get_option('cm_form_builder_schema', null);
    }
    if (!$schema) {
        require_once CM_PLUGIN_DIR . 'includes/admin-builder.php';
        $schema = cm_get_default_schema();
    }

    $settings       = isset($schema['settings']) ? $schema['settings'] : array();
    $fields         = isset($schema['fields'])   ? $schema['fields']   : array();

    $cm_dest = isset($settings['destination_emails']) ? trim((string)$settings['destination_emails']) : '';
    if ($cm_dest === '') {
        if (current_user_can('manage_options')) {
            $cfg_url = function_exists('admin_url') ? admin_url('admin.php?page=cm-form-studio' . ($form_id ? '&form=' . rawurlencode($form_id) : '')) : '#';
            return '<div class="cm-unconfigured-card">'
                . '<span class="cm-unc-icon">✉️</span>'
                . '<div class="cm-unc-text"><strong>Falta configurar el correo principal</strong>'
                . '<small>La extensión Ingecodex Form no tiene destinatario asignado. Configúralo y actualiza esta página para que el formulario aparezca.</small></div>'
                . '<a class="cm-unc-btn" href="' . esc_url($cfg_url) . '">Configurar ahora</a>'
                . '</div>';
        }
        return '';
    }
    $primary_color  = !empty($settings['primary_color'])      ? esc_attr($settings['primary_color'])      : '#4f46e5';
    $btn_text_color = !empty($settings['button_text_color'])  ? esc_attr($settings['button_text_color'])  : '#ffffff';
    $bg_color       = !empty($settings['bg_color'])           ? esc_attr($settings['bg_color'])           : '#ffffff';
    $label_color    = !empty($settings['label_color'])        ? esc_attr($settings['label_color'])        : '#0f172a';
    $input_bg       = !empty($settings['input_bg_color'])     ? esc_attr($settings['input_bg_color'])     : '#f8fafc';
    $input_border   = !empty($settings['input_border_color']) ? esc_attr($settings['input_border_color']) : '#e2e8f0';
    $border_radius  = isset($settings['border_radius'])       ? esc_attr($settings['border_radius'])      : '12';
    $shadow         = !empty($settings['shadow'])             ? esc_attr($settings['shadow'])             : 'md';
    $card_preset    = !empty($settings['card_preset'])        ? esc_attr($settings['card_preset'])        : 'modern';
    $density        = !empty($settings['density'])            ? esc_attr($settings['density'])            : 'normal';

    
    $ov   = (isset($settings['device_overrides']) && is_array($settings['device_overrides'])) ? $settings['device_overrides'] : array();
    $t_ov = (isset($ov['tablet']) && is_array($ov['tablet']))   ? $ov['tablet']  : array();
    $m_ov = (isset($ov['mobile']) && is_array($ov['mobile']))   ? $ov['mobile']  : array();

    if (!function_exists('cm_density_rules_for')) {
        function cm_density_rules_for($d, $sel) {
            if ($d === 'compact') {
                return "$sel{padding:14px 16px!important}"
                     . "$sel .cm-form-grid{gap:7px 10px!important}"
                     . "$sel .cm-label{margin-bottom:3px!important;font-size:12.5px!important}"
                     . "$sel .cm-input,$sel textarea.cm-input,$sel select.cm-input{padding:6px 9px!important;font-size:13px!important}"
                     . "$sel .cm-textarea{min-height:60px!important}";
            }
            if ($d === 'roomy') {
                return "$sel{padding:clamp(28px,4.5vw,48px)!important}"
                     . "$sel .cm-form-grid{gap:24px 26px!important}"
                     . "$sel .cm-label{margin-bottom:9px!important;font-size:14px!important}"
                     . "$sel .cm-input,$sel textarea.cm-input,$sel select.cm-input{padding:14px 16px!important}"
                     . "$sel .cm-textarea{min-height:140px!important}";
            }
            return '';
        }
    }

    $instance_id = 'cmfi-' . substr(md5(uniqid('', true)), 0, 7);
    $mq_css      = '';
    $build_mq    = function ($ov_dev, $maxw_query) use ($instance_id) {
        if (empty($ov_dev)) return '';
        $parts = array();
        if (!empty($ov_dev['max_width']) && $ov_dev['max_width'] !== 'inherit') {
            $parts[] = "#" . $instance_id . "{max-width:" . esc_attr($ov_dev['max_width']) . "!important}";
        }
        if (!empty($ov_dev['density']) && $ov_dev['density'] !== 'inherit') {
            $parts[] = cm_density_rules_for($ov_dev['density'], "#" . $instance_id);
        }
        return $parts ? "@media(max-width:" . $maxw_query . "){" . implode('', $parts) . "}" : '';
    };
    $mq_css .= $build_mq($t_ov, '1024px');
    $mq_css .= $build_mq($m_ov, '767px');
    $border_width   = isset($settings['border_width'])        ? esc_attr($settings['border_width'])       : '1';
    $container_border_color = !empty($settings['container_border_color']) ? esc_attr($settings['container_border_color']) : '#e2e8f0';
    $button_text    = !empty($settings['button_text'])        ? esc_attr($settings['button_text'])        : 'Enviar Mensaje';
    $button_style   = !empty($settings['button_style'])       ? esc_attr($settings['button_style'])       : 'gradient';
    $show_credit    = isset($settings['show_credit'])         ? (bool)$settings['show_credit']             : true;
    $max_file_size  = get_option('cm_max_file_size', 5);

    
    $shadow_css = array(
        'none' => 'none',
        'sm'   => '0 1px 4px rgba(0,0,0,0.06)',
        'md'   => '0 4px 24px rgba(0,0,0,0.08)',
        'lg'   => '0 12px 40px rgba(0,0,0,0.14)',
    );
    $card_shadow = isset($shadow_css[$shadow]) ? $shadow_css[$shadow] : $shadow_css['md'];

    $extra_container_css = '';
    $preset_class = '';

    if ($bg_color === 'transparent' || $bg_color === 'rgba(0, 0, 0, 0)') {
        $preset_class = 'cm-preset-transparent';
        $extra_container_css = 'background: transparent !important; box-shadow: none !important; border: none !important; padding: 0 !important;';
    } elseif ($card_preset === 'flat') {
        $preset_class = 'cm-preset-flat';
        $extra_container_css = "background: {$bg_color}; box-shadow: none !important; border: {$border_width}px solid {$container_border_color} !important;";
    } elseif ($card_preset === 'glassmorphism') {
        $preset_class = 'cm-preset-glassmorphism';
        $extra_container_css = "background: rgba(255, 255, 255, 0.75) !important; backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px); border: 1px solid rgba(255, 255, 255, 0.5) !important; box-shadow: 0 8px 32px rgba(31, 38, 135, 0.1) !important;";
    } elseif ($card_preset === 'paper') {
        $preset_class = 'cm-preset-paper';
        $extra_container_css = "background-color: {$bg_color}; background-image: linear-gradient({$container_border_color} 1px, transparent 1px), linear-gradient(90deg, {$container_border_color} 1px, transparent 1px); background-size: 22px 22px; border: {$border_width}px solid {$container_border_color}; box-shadow: {$card_shadow};";
    } elseif ($card_preset === 'rounded') {
        $preset_class = 'cm-preset-rounded';
        $border_radius = '24';
        $extra_container_css = "background: {$bg_color}; border: {$border_width}px solid {$container_border_color}; box-shadow: {$card_shadow};";
    } else {
        $extra_container_css = "background: {$bg_color}; border: {$border_width}px solid {$container_border_color}; box-shadow: {$card_shadow};";
    }

    
    $btn_style_css = '';
    if ($button_style === 'gradient') {
        $btn_style_css = "background: linear-gradient(135deg, {$primary_color}, color-mix(in srgb, {$primary_color} 70%, #000)); color: {$btn_text_color}; border: none;";
    } elseif ($button_style === 'solid') {
        $btn_style_css = "background: {$primary_color}; color: {$btn_text_color}; border: none;";
    } elseif ($button_style === 'outline') {
        $btn_style_css = "background: transparent; color: {$primary_color}; border: 2px solid {$primary_color};";
    } elseif ($button_style === 'rounded') {
        $btn_style_css = "background: linear-gradient(135deg, {$primary_color}, color-mix(in srgb, {$primary_color} 70%, #000)); color: {$btn_text_color}; border: none; border-radius: 50px !important;";
    }

    $max_width      = !empty($settings['max_width']) ? esc_attr($settings['max_width']) : '840px';
    $show_header    = isset($settings['show_header']) ? (bool)$settings['show_header'] : true;
    $has_title      = !empty(trim($settings['title'] ?? ''));
    $has_subtitle   = !empty(trim($settings['subtitle'] ?? ''));

    
    $pos_mode  = !empty($settings['pos_mode']);
    $canvas_h  = isset($settings['canvas_h']) ? max(300, (int)$settings['canvas_h']) : 760;

    ob_start();
    ?>
    <?php if ($mq_css) : ?><style data-cm-device-mq><?php echo $mq_css; ?></style><?php endif; ?>
    <div id="<?php echo esc_attr($instance_id); ?>" class="cm-form-container <?php echo esc_attr($preset_class); ?> <?php echo ($density === 'compact' || $density === 'roomy') ? 'cm-density-' . esc_attr($density) : ''; ?>" style="
        --cm-primary: <?php echo $primary_color; ?>;
        --cm-btn-text: <?php echo $btn_text_color; ?>;
        --cm-bg: <?php echo $bg_color; ?>;
        --cm-label: <?php echo $label_color; ?>;
        --cm-input-bg: <?php echo $input_bg; ?>;
        --cm-input-border: <?php echo $input_border; ?>;
        --cm-radius: <?php echo $border_radius; ?>px;
        --cm-shadow: <?php echo $card_shadow; ?>;
        --cm-max-width: <?php echo $max_width; ?>;
        max-width: <?php echo $max_width; ?>;
        border-radius: <?php echo $border_radius; ?>px;
        <?php echo $extra_container_css; ?>
    ">
        <?php if ($show_header && ($has_title || $has_subtitle)) : ?>
            <div class="cm-form-header-wrap" style="margin-bottom: 24px; padding-bottom: <?php echo $has_subtitle ? '16px' : '8px'; ?>; <?php if ($has_subtitle) : ?>border-bottom: 1px solid <?php echo $input_border; ?>;<?php endif; ?>">
                <?php if ($has_title) : ?>
                    <h3 class="cm-form-title" style="color: <?php echo $label_color; ?>; margin: 0 0 <?php echo $has_subtitle ? '6px' : '0'; ?> 0;"><?php echo esc_html($settings['title']); ?></h3>
                <?php endif; ?>

                <?php if ($has_subtitle) : ?>
                    <p class="cm-form-subtitle" style="margin: 0; padding: 0; border: none;"><?php echo esc_html($settings['subtitle']); ?></p>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div id="cm-form-response" class="cm-response-msg" style="display: none;"></div>

        <form id="cm-contact-form" class="cm-contact-form" method="post" enctype="multipart/form-data" data-form-id="<?php echo esc_attr($form_id); ?>">
            <?php wp_nonce_field('cm_contacto_nonce', 'cm_nonce_field'); ?>
            <div style="display:none !important;" aria-hidden="true">
                <input type="text" name="cm_website" tabindex="-1" autocomplete="off" />
            </div>

            <div class="cm-form-grid <?php echo $pos_mode ? 'cm-pos-canvas' : ''; ?>" <?php if ($pos_mode) : ?>style="position: relative; min-height: <?php echo $canvas_h; ?>px;"<?php endif; ?>>
                <?php foreach ($fields as $field) :
                    
                    $in_pos = $pos_mode && isset($field['x']) && $field['type'] !== 'hidden';
                    if ($in_pos) :
                        $px = isset($field['x']) ? floatval($field['x']) : 0;
                        $py = isset($field['y']) ? floatval($field['y']) : 0;
                        $pw = isset($field['w']) ? floatval($field['w']) : 30;
                        $ph = (isset($field['h']) && floatval($field['h']) > 3) ? ' min-height: ' . floatval($field['h']) . '%;' : ''; ?>
                        <div class="cm-pos-field" style="position: absolute; left: <?php echo $px; ?>%; top: <?php echo $py; ?>%; width: <?php echo $pw; ?>%;<?php echo $ph; ?>">
                    <?php endif;
                    $field_id    = esc_attr($field['id']);
                    $type        = $field['type'];
                    $label       = esc_html($field['label'] ?? '');
                    $placeholder = isset($field['placeholder']) ? esc_attr($field['placeholder']) : '';
                    $help        = isset($field['help']) ? esc_html($field['help']) : '';
                    $required    = !empty($field['required']);
                    $width_class = (isset($field['width']) && $field['width'] == '50') ? 'cm-col-50' : 'cm-col-100';

                    
                    $f_custom_bg     = !empty($field['custom_bg']) ? esc_attr($field['custom_bg']) : $input_bg;
                    $f_custom_border = !empty($field['custom_border']) ? esc_attr($field['custom_border']) : $input_border;
                    $f_custom_color  = !empty($field['custom_color']) ? esc_attr($field['custom_color']) : $label_color;
                ?>

                    <?php if ($type === 'divider') : ?>
                        <div class="cm-form-group cm-col-100">
                            <hr class="cm-divider" style="border:none;border-top:2px dashed <?php echo $f_custom_border; ?>;margin:8px 0;" />
                        </div>

                    <?php elseif ($type === 'heading') : ?>
                        <div class="cm-form-group cm-col-100 cm-heading-group">
                            <h4 class="cm-field-heading" style="color: <?php echo $f_custom_color; ?>;"><?php echo $label; ?></h4>
                            <?php if ($help) : ?><p class="cm-field-help"><?php echo $help; ?></p><?php endif; ?>
                        </div>

                    <?php elseif ($type === 'hidden') : ?>
                        <input type="hidden" id="<?php echo $field_id; ?>" name="<?php echo $field_id; ?>" value="<?php echo $placeholder; ?>" />

                    <?php elseif ($type === 'checkbox' || $type === 'terms') : 
                        $has_terms       = !empty($field['has_terms']) || $type === 'terms' || !empty($field['terms_content']);
                        $terms_link_text = !empty($field['terms_link_text']) ? esc_html($field['terms_link_text']) : 'Términos y Condiciones';
                        $terms_title     = !empty($field['terms_title']) ? esc_html($field['terms_title']) : 'Términos y Condiciones';
                        $terms_content   = !empty($field['terms_content']) ? $field['terms_content'] : '';
                    ?>
                        <div class="cm-form-group <?php echo $width_class; ?> cm-checkbox-group">
                            <label class="cm-checkbox-label" for="<?php echo $field_id; ?>">
                                <input type="checkbox" name="<?php echo $field_id; ?>" id="<?php echo $field_id; ?>" class="cm-checkbox" <?php echo $required ? 'required' : ''; ?> />
                                <span class="cm-checkbox-box" style="border-color: <?php echo $f_custom_border; ?>; background: <?php echo $f_custom_bg; ?>;"></span>
                                <span class="cm-checkbox-text-content" style="color: <?php echo $f_custom_color; ?>;">
                                    <?php echo $label; ?>
                                    <?php if ($has_terms) : ?>
                                        <a href="javascript:void(0);" class="cm-open-terms-link" data-modal-target="cm-modal-<?php echo $field_id; ?>" style="color: <?php echo $primary_color; ?>; font-weight: 600; text-decoration: underline; margin-left: 3px;">
                                            <?php echo $terms_link_text; ?>
                                        </a>
                                    <?php endif; ?>
                                    <?php if ($required) : ?><span class="cm-required">*</span><?php endif; ?>
                                </span>
                            </label>
                            <?php if ($help) : ?><small class="cm-field-help"><?php echo $help; ?></small><?php endif; ?>

                            <?php if ($has_terms && !empty($terms_content)) : ?>
                                <!-- Modal Flotante de Términos y Condiciones -->
                                <div id="cm-modal-<?php echo $field_id; ?>" class="cm-terms-modal-backdrop" style="display: none;">
                                    <div class="cm-terms-modal-card">
                                        <div class="cm-terms-modal-header">
                                            <h4>📜 <?php echo $terms_title; ?></h4>
                                            <button type="button" class="cm-close-terms-btn" data-modal-target="cm-modal-<?php echo $field_id; ?>" aria-label="Cerrar">✕</button>
                                        </div>
                                        <div class="cm-terms-modal-body">
                                            <?php echo nl2br(esc_html($terms_content)); ?>
                                        </div>
                                        <div class="cm-terms-modal-footer">
                                            <button type="button" class="cm-terms-btn-close cm-close-terms-btn" data-modal-target="cm-modal-<?php echo $field_id; ?>">Cerrar</button>
                                            <button type="button" class="cm-terms-btn-accept cm-accept-terms-btn" data-checkbox-id="<?php echo $field_id; ?>" data-modal-target="cm-modal-<?php echo $field_id; ?>" style="background: <?php echo $primary_color; ?>; color: <?php echo $btn_text_color; ?>;">✓ Aceptar Términos y Marcar</button>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>

                    <?php elseif ($type === 'radio') : ?>
                        <div class="cm-form-group <?php echo $width_class; ?>">
                            <label class="cm-label" style="color: <?php echo $f_custom_color; ?>;"><?php echo $label; ?> <?php if ($required) : ?><span class="cm-required">*</span><?php endif; ?></label>
                            <div class="cm-radio-group">
                                <?php if (!empty($field['options'])) : ?>
                                    <?php foreach ($field['options'] as $idx => $opt) : 
                                        $opt_val = is_array($opt) ? $opt['nombre'] : $opt;
                                    ?>
                                        <label class="cm-radio-label">
                                            <input type="radio" name="<?php echo $field_id; ?>" value="<?php echo esc_attr($opt_val); ?>" <?php echo ($required && $idx === 0) ? 'required' : ''; ?> />
                                            <span class="cm-radio-box" style="border-color: <?php echo $f_custom_border; ?>; background: <?php echo $f_custom_bg; ?>;"></span>
                                            <span><?php echo esc_html($opt_val); ?></span>
                                        </label>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                            <?php if ($help) : ?><small class="cm-field-help"><?php echo $help; ?></small><?php endif; ?>
                        </div>

                    <?php elseif ($type === 'rating') : ?>
                        <div class="cm-form-group <?php echo $width_class; ?>">
                            <label class="cm-label" style="color: <?php echo $f_custom_color; ?>;"><?php echo $label; ?> <?php if ($required) : ?><span class="cm-required">*</span><?php endif; ?></label>
                            <div class="cm-rating-stars">
                                <?php for ($s = 5; $s >= 1; $s--) : ?>
                                    <input type="radio" id="<?php echo $field_id . '_' . $s; ?>" name="<?php echo $field_id; ?>" value="<?php echo $s; ?>" <?php echo ($required && $s === 1) ? 'required' : ''; ?> />
                                    <label for="<?php echo $field_id . '_' . $s; ?>">★</label>
                                <?php endfor; ?>
                            </div>
                            <?php if ($help) : ?><small class="cm-field-help"><?php echo $help; ?></small><?php endif; ?>
                        </div>

                    <?php else : ?>
                        <div class="cm-form-group <?php echo $width_class; ?>">
                            <label class="cm-label" for="<?php echo $field_id; ?>" style="color: <?php echo $f_custom_color; ?>;">
                                <?php echo $label; ?>
                                <?php if ($required) : ?><span class="cm-required">*</span><?php endif; ?>
                            </label>

                            <div class="cm-input-wrapper">
                                <?php if ($type === 'text') : ?>
                                    <svg class="cm-input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                                    <input type="text" id="<?php echo $field_id; ?>" name="<?php echo $field_id; ?>" class="cm-input" placeholder="<?php echo $placeholder; ?>" style="border-color: <?php echo $f_custom_border; ?>; border-radius: <?php echo $border_radius; ?>px; background: <?php echo $f_custom_bg; ?>;" <?php echo $required ? 'required' : ''; ?> />

                                <?php elseif ($type === 'email') : ?>
                                    <svg class="cm-input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                                    <input type="email" id="<?php echo $field_id; ?>" name="<?php echo $field_id; ?>" class="cm-input" placeholder="<?php echo $placeholder; ?>" style="border-color: <?php echo $f_custom_border; ?>; border-radius: <?php echo $border_radius; ?>px; background: <?php echo $f_custom_bg; ?>;" <?php echo $required ? 'required' : ''; ?> />

                                <?php elseif ($type === 'phone') : ?>
                                    <svg class="cm-input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                                    <input type="tel" id="<?php echo $field_id; ?>" name="<?php echo $field_id; ?>" class="cm-input" placeholder="<?php echo $placeholder; ?>" style="border-color: <?php echo $f_custom_border; ?>; border-radius: <?php echo $border_radius; ?>px; background: <?php echo $f_custom_bg; ?>;" <?php echo $required ? 'required' : ''; ?> />

                                <?php elseif ($type === 'number') : ?>
                                    <input type="number" id="<?php echo $field_id; ?>" name="<?php echo $field_id; ?>" class="cm-input cm-no-icon" placeholder="<?php echo $placeholder; ?>" style="border-color: <?php echo $f_custom_border; ?>; border-radius: <?php echo $border_radius; ?>px; background: <?php echo $f_custom_bg; ?>;" <?php echo $required ? 'required' : ''; ?> />

                                <?php elseif ($type === 'url') : ?>
                                    <input type="url" id="<?php echo $field_id; ?>" name="<?php echo $field_id; ?>" class="cm-input cm-no-icon" placeholder="<?php echo $placeholder; ?>" style="border-color: <?php echo $f_custom_border; ?>; border-radius: <?php echo $border_radius; ?>px; background: <?php echo $f_custom_bg; ?>;" <?php echo $required ? 'required' : ''; ?> />

                                <?php elseif ($type === 'date') : ?>
                                    <input type="date" id="<?php echo $field_id; ?>" name="<?php echo $field_id; ?>" class="cm-input cm-no-icon" style="border-color: <?php echo $f_custom_border; ?>; border-radius: <?php echo $border_radius; ?>px; background: <?php echo $f_custom_bg; ?>;" <?php echo $required ? 'required' : ''; ?> />

                                <?php elseif ($type === 'department' || $type === 'select') : ?>
                                    <svg class="cm-input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                                    <select id="<?php echo $field_id; ?>" name="<?php echo $field_id; ?>" class="cm-select" style="border-color: <?php echo $f_custom_border; ?>; border-radius: <?php echo $border_radius; ?>px; background: <?php echo $f_custom_bg; ?>;" <?php echo $required ? 'required' : ''; ?>>
                                        <option value="">— Selecciona el destinatario —</option>
                                        <?php if (!empty($field['options'])) : ?>
                                            <?php foreach ($field['options'] as $idx => $opt) : ?>
                                                <?php $opt_name = is_array($opt) ? $opt['nombre'] : $opt; ?>
                                                <option value="<?php echo $idx; ?>"><?php echo esc_html($opt_name); ?></option>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </select>

                                <?php elseif ($type === 'textarea') : ?>
                                    <textarea id="<?php echo $field_id; ?>" name="<?php echo $field_id; ?>" class="cm-textarea" rows="4" placeholder="<?php echo $placeholder; ?>" style="border-color: <?php echo $f_custom_border; ?>; border-radius: <?php echo $border_radius; ?>px; background: <?php echo $f_custom_bg; ?>;" <?php echo $required ? 'required' : ''; ?>></textarea>

                                <?php elseif ($type === 'file') : ?>
                                    <div class="cm-file-dropzone" style="border-color: <?php echo $f_custom_border; ?>; border-radius: <?php echo $border_radius; ?>px; background: <?php echo $f_custom_bg; ?>;">
                                        <input type="file" id="<?php echo $field_id; ?>" name="<?php echo $field_id; ?>" class="cm-file-input" accept=".jpg,.jpeg,.png,.pdf,.doc,.docx,.xls,.xlsx,.zip,.txt" <?php echo $required ? 'required' : ''; ?> />
                                        <div class="cm-file-content">
                                            <svg class="cm-file-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                                            <span class="cm-file-text">Arrastra o haz clic para subir tu archivo</span>
                                            <small class="cm-field-help"><?php echo $help ? $help : sprintf('PDF, DOCX, XLSX, JPG, PNG, ZIP. Máx %d MB.', $max_file_size); ?></small>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <?php if ($help && $type !== 'file' && $type !== 'heading' && $type !== 'divider') : ?>
                                <small class="cm-field-help"><?php echo $help; ?></small>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <?php if ($in_pos) : ?></div><?php endif; ?>
                <?php endforeach; ?>
            </div>

            <!-- Botón de Envío -->
            <?php
            $btn_align = isset($settings['btn_align']) ? $settings['btn_align'] : 'left';
            $btn_size  = isset($settings['btn_size']) ? $settings['btn_size'] : 'md';
            $btn_full  = !empty($settings['btn_fullwidth']);
            $align_css = in_array($btn_align, array('left', 'center', 'right'), true) ? "text-align: {$btn_align};" : '';
            $width_css = $btn_full ? 'display: block; width: 100%;' : '';
            $size_map  = array(
                'sm' => 'padding: 8px 18px; font-size: 13px;',
                'md' => 'padding: 12px 26px; font-size: 15px;',
                'lg' => 'padding: 16px 34px; font-size: 17px;',
            );
            $size_css  = isset($size_map[$btn_size]) ? $size_map[$btn_size] : $size_map['md'];
            ?>
            <div class="cm-submit-container" style="margin-top: 20px; <?php echo esc_attr($align_css); ?>">
                <button type="submit" id="cm-submit-btn" class="cm-submit-button" style="<?php echo $btn_style_css; ?> border-radius: <?php echo ($button_style === 'rounded') ? '50px' : $border_radius . 'px'; ?> <?php echo $size_css . ' ' . $width_css; ?>">
                    <span class="cm-btn-spinner" style="display: none;"></span>
                    <span class="cm-btn-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                    </span>
                    <span class="cm-btn-text"><?php echo esc_html($button_text); ?></span>
                </button>
            </div>

            <?php if ($show_credit) : ?>
                <div class="cm-ingecodex-credit" style="text-align: right; margin-top: 14px; font-size: 11px; color: #94a3b8; letter-spacing: 0.02em;">
                    Diseñado por <a href="https://ingecodex.com" target="_blank" rel="noopener" style="color: <?php echo $primary_color; ?>; font-weight: 600; text-decoration: none;">Ingecodex.com</a>
                </div>
            <?php endif; ?>
        </form>
    </div>
    <?php
    return ob_get_clean();
}
