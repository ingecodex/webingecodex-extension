<?php
/**
 * Ingecodex Form — Bandeja de Entradas y Gestión de Casos (Estilo Apple / Office Pro)
 * Panel de administración para revisar envíos de formularios, derivar entre áreas, gestionar encargados, habilitar/deshabilitar departamentos y suspender usuarios.
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Renderiza la página principal de la Bandeja de Casos y Envíos en WP-Admin.
 */
function cm_render_admin_submissions_page() {
    if (!current_user_can('edit_posts') && !current_user_can('manage_options')) {
        wp_die(__('No tienes permisos suficientes para acceder a esta página.', 'contacto-multidestino'));
    }

    $is_superadmin       = current_user_can('manage_options');
    $is_director         = function_exists('cm_is_director') && cm_is_director();
    $can_view_dashboard  = $is_superadmin || $is_director;
    $user_assigned_dept  = function_exists('cm_get_current_user_assigned_department') ? cm_get_current_user_assigned_department() : '';

    // ══════════════════════════════════════════════════════════════════
    // VISTA DE CASO EN PÁGINA COMPLETA ESTILO APPLE PRO (SI VIENE case_id)
    // ══════════════════════════════════════════════════════════════════
    $view_case_id = isset($_GET['case_id']) ? absint($_GET['case_id']) : (isset($_GET['view_case']) ? absint($_GET['view_case']) : 0);
    if ($view_case_id > 0) {
        $payload = cm_build_case_inspector_payload($view_case_id);
        if (!is_wp_error($payload)) {
            cm_render_fullpage_case_view($payload);
            return;
        }
    }
    
    $default_tab  = $can_view_dashboard ? 'dashboard' : 'inbox';
    $active_tab   = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : $default_tab;
    if (!$can_view_dashboard && ($active_tab === 'dashboard' || $active_tab === 'departments' || $active_tab === 'trash')) {
        $active_tab = 'inbox';
    }
    if (!$is_superadmin && ($active_tab === 'departments' || $active_tab === 'trash')) {
        $active_tab = 'inbox';
    }

    $current_page = isset($_GET['paged']) ? max(1, absint($_GET['paged'])) : 1;
    $per_page     = 20;
    $offset       = ($current_page - 1) * $per_page;

    $filter_form   = isset($_GET['form_filter']) ? sanitize_text_field($_GET['form_filter']) : '';
    $filter_status = isset($_GET['status_filter']) ? sanitize_text_field($_GET['status_filter']) : '';
    $filter_dept   = !empty($user_assigned_dept) ? $user_assigned_dept : (isset($_GET['dept_filter']) ? sanitize_text_field($_GET['dept_filter']) : '');
    $search_query  = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';

    $trash_count = function_exists('cm_get_trash_count') ? cm_get_trash_count() : 0;

    if ($active_tab === 'trash') {
        $results = cm_get_submissions(array(
            'trash_only' => true,
            'search'     => $search_query,
            'limit'      => $per_page,
            'offset'     => $offset,
            'orderby'    => 'deleted_at',
            'order'      => 'DESC',
        ));
    } else {
        $results = cm_get_submissions(array(
            'form_id'    => $filter_form,
            'status'     => $filter_status,
            'department' => $filter_dept,
            'search'     => $search_query,
            'limit'      => $per_page,
            'offset'     => $offset,
        ));
    }

    $submissions = $results['items'];
    $total_items = $results['total'];
    $total_pages = ceil($total_items / $per_page);

    $stats       = cm_get_submission_stats($filter_dept);
    $statuses    = cm_get_case_statuses();
    $forms       = cm_get_all_forms();
    $departments = cm_get_available_departments(false);
    $wp_users    = get_users(array('fields' => array('ID', 'display_name', 'user_email', 'user_login')));

    // Datos del Dashboard Analítico para Superadmin y Directores
    $analytics = function_exists('cm_get_dashboard_analytics') ? cm_get_dashboard_analytics() : array();
    $kanban    = function_exists('cm_get_kanban_columns_data') ? cm_get_kanban_columns_data() : array();

    // Enqueue nonce y datos para AJAX
    wp_localize_script('jquery', 'cmSubmissionsVars', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('cm_contacto_nonce'),
    ));
    ?>
    <div class="wrap cm-apple-wrap">
        <!-- Barra Superior Compacta Estilo macOS / Office -->
        <div class="cm-apple-header">
            <div class="cm-apple-header-left">
                <div class="cm-apple-logo-badge">
                    <span class="dashicons dashicons-portfolio"></span>
                </div>
                <div>
                    <h1 class="cm-apple-title">
                        <?php if ($is_superadmin) : ?>
                            <?php _e('Centro de Casos y Solicitudes', 'contacto-multidestino'); ?>
                        <?php elseif ($is_director) : ?>
                            <?php _e('👑 Panel Directivo • Monitoreo Institucional', 'contacto-multidestino'); ?>
                        <?php else : ?>
                            <?php printf(__('Bandeja de Casos • %s', 'contacto-multidestino'), esc_html($user_assigned_dept ? $user_assigned_dept : 'Mi Área')); ?>
                        <?php endif; ?>
                        <span class="cm-apple-version">v<?php echo CM_VERSION; ?> Pro</span>
                    </h1>
                    <p class="cm-apple-desc">
                        <?php if ($is_superadmin) : ?>
                            <?php _e('Monitoreo en tiempo real, gestión ejecutiva, derivación entre áreas y seguimiento.', 'contacto-multidestino'); ?>
                        <?php elseif ($is_director) : ?>
                            <?php _e('Supervisión en tiempo real de todos los casos, flujo de atención y auditoría institucional.', 'contacto-multidestino'); ?>
                        <?php else : ?>
                            <?php printf(__('Expedientes y solicitudes dirigidas al departamento de %s.', 'contacto-multidestino'), esc_html($user_assigned_dept ? $user_assigned_dept : 'tu área')); ?>
                        <?php endif; ?>
                    </p>
                </div>
            </div>

            <!-- Segmented Control (Pestañas estilo macOS) -->
            <?php if ($can_view_dashboard) : ?>
                <div class="cm-segmented-control">
                    <a href="<?php echo admin_url('admin.php?page=cm-form-submissions&tab=dashboard'); ?>" class="cm-segment-btn <?php echo $active_tab === 'dashboard' ? 'active' : ''; ?>">
                        📊 <?php _e('Dashboard en Vivo', 'contacto-multidestino'); ?>
                    </a>
                    <a href="<?php echo admin_url('admin.php?page=cm-form-submissions&tab=inbox'); ?>" class="cm-segment-btn <?php echo $active_tab === 'inbox' ? 'active' : ''; ?>">
                        📥 <?php _e('Todos los Casos', 'contacto-multidestino'); ?> (<?php echo esc_html($stats['total']); ?>)
                    </a>
                    <?php if ($is_superadmin) : ?>
                        <a href="<?php echo admin_url('admin.php?page=cm-form-submissions&tab=departments'); ?>" class="cm-segment-btn <?php echo $active_tab === 'departments' ? 'active' : ''; ?>">
                            👥 <?php _e('Áreas y Encargados', 'contacto-multidestino'); ?>
                        </a>
                        <a href="<?php echo admin_url('admin.php?page=cm-form-submissions&tab=trash'); ?>" class="cm-segment-btn <?php echo $active_tab === 'trash' ? 'active' : ''; ?>" style="<?php echo $trash_count > 0 ? 'color:#dc2626; font-weight:700;' : ''; ?>">
                            🗑️ <?php _e('Papelera', 'contacto-multidestino'); ?> (<?php echo esc_html($trash_count); ?>)
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="cm-apple-header-actions">
                <a href="https://link.mercadopago.cl/ingecodex" target="_blank" rel="noopener noreferrer" class="cm-apple-btn-secondary" style="background: linear-gradient(135deg, #009ee3 0%, #007eb5 100%); color: #ffffff !important; border: none; font-weight: 700; display: inline-flex; align-items: center; gap: 5px; box-shadow: 0 2px 6px rgba(0, 158, 227, 0.28);" title="Apoyar el desarrollo con Mercado Pago">
                    ☕ <span>Donar</span>
                </a>
                <?php if ($is_superadmin) : ?>
                    <a href="<?php echo admin_url('admin.php?page=cm-form-studio'); ?>" class="cm-apple-btn-secondary">
                        🛠️ <?php _e('Editor', 'contacto-multidestino'); ?>
                    </a>
                    <a href="<?php echo admin_url('admin.php?page=cm-form-smtp'); ?>" class="cm-apple-btn-secondary">
                        ⚙️ <?php _e('SMTP', 'contacto-multidestino'); ?>
                    </a>
                <?php else : ?>
                    <a href="<?php echo esc_url(wp_logout_url(home_url())); ?>" class="cm-apple-btn-secondary" style="color:#ef4444 !important; border-color:#fca5a5;">
                        🚪 <?php _e('Cerrar Sesión', 'contacto-multidestino'); ?>
                    </a>
                <?php endif; ?>
            </div>
        </div>

        <?php 
        $cm_curr_uid = get_current_user_id();
        $cm_has_2fa  = function_exists('cm_is_2fa_enabled') && cm_is_2fa_enabled($cm_curr_uid);
        ?>
        <?php if (!$cm_has_2fa) : ?>
            <!-- BANNER DE SUGERENCIA DE SEGURIDAD 2FA ESTILO APPLE PRO -->
            <div id="cm-2fa-suggestion-banner" class="cm-apple-card-sm" style="background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%); border: 1.5px solid #bae6fd; border-radius: 12px; padding: 14px 18px; margin-bottom: 18px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px; box-shadow: 0 2px 8px rgba(2, 132, 199, 0.08);">
                <div style="display: flex; align-items: center; gap: 12px;">
                    <div style="font-size: 26px; background: #ffffff; width: 42px; height: 42px; border-radius: 10px; display: flex; align-items: center; justify-content: center; box-shadow: 0 1px 3px rgba(0,0,0,0.06);">
                        🛡️
                    </div>
                    <div>
                        <strong style="font-size: 13.5px; color: #0369a1; display: block;">
                            <?php _e('Seguridad Recomendada: Activa la Autenticación de Dos Factores (2FA)', 'contacto-multidestino'); ?>
                        </strong>
                        <p style="font-size: 12px; color: #0284c7; margin: 2px 0 0 0;">
                            <?php _e('Protege tu cuenta con Google Authenticator, Microsoft Authenticator o Apple Passwords para asegurar el acceso a tus solicitudes.', 'contacto-multidestino'); ?>
                        </p>
                    </div>
                </div>
                <div style="display: flex; align-items: center; gap: 8px;">
                    <button type="button" class="cm-apple-btn-primary" style="background: #0284c7; border-color: #0369a1; font-weight: 700; font-size: 12.5px; height: 32px; padding: 0 14px; display: inline-flex; align-items: center; gap: 5px; border-radius: 8px; box-shadow: 0 2px 6px rgba(2, 132, 199, 0.3); cursor: pointer;" onclick="cmOpen2FASetupModal()">
                        🔐 <?php _e('Activar 2FA Ahora', 'contacto-multidestino'); ?>
                    </button>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($active_tab === 'dashboard' && $can_view_dashboard) : ?>
            <!-- ══════════════════════════════════════════════════════════
                 PESTAÑA 1: DASHBOARD ANALYTICS EN TIEMPO REAL (SUPERADMIN)
                 ══════════════════════════════════════════════════════════ -->
            
            <!-- 4 Hero KPIs -->
            <div class="cm-dashboard-hero-grid">
                <div class="cm-kpi-apple-card cm-kpi-iniciados">
                    <div>
                        <div class="cm-kpi-num"><?php echo esc_html($analytics['iniciados']); ?></div>
                        <div class="cm-kpi-title">📥 <?php _e('Iniciados (Nuevos)', 'contacto-multidestino'); ?></div>
                    </div>
                    <div class="cm-kpi-icon-wrap" style="background:#eff6ff; color:#0071e3;">📥</div>
                </div>

                <div class="cm-kpi-apple-card cm-kpi-continuidad">
                    <div>
                        <div class="cm-kpi-num"><?php echo esc_html($analytics['continuidad']); ?></div>
                        <div class="cm-kpi-title">⚡ <?php _e('En Continuidad (Gestión)', 'contacto-multidestino'); ?></div>
                    </div>
                    <div class="cm-kpi-icon-wrap" style="background:#f5f3ff; color:#5856d6;">⚡</div>
                </div>

                <div class="cm-kpi-apple-card cm-kpi-pendientes">
                    <div>
                        <div class="cm-kpi-num"><?php echo esc_html($analytics['pendientes']); ?></div>
                        <div class="cm-kpi-title">⚠️ <?php _e('Requiere Presencia / Acción', 'contacto-multidestino'); ?></div>
                    </div>
                    <div class="cm-kpi-icon-wrap" style="background:#fffbeb; color:#ff9500;">⚠️</div>
                </div>

                <div class="cm-kpi-apple-card cm-kpi-finalizados">
                    <div>
                        <div style="display:flex; align-items:baseline; gap:8px;">
                            <div class="cm-kpi-num"><?php echo esc_html($analytics['finalizados']); ?></div>
                            <span style="font-size:11px; font-weight:800; color:#16a34a; background:#dcfce7; padding:2px 6px; border-radius:10px;">
                                <?php echo esc_html($analytics['tasa_cierre']); ?>% <?php _e('Cierre', 'contacto-multidestino'); ?>
                            </span>
                        </div>
                        <div class="cm-kpi-title">✅ <?php _e('Finalizados / Resueltos', 'contacto-multidestino'); ?></div>
                    </div>
                    <div class="cm-kpi-icon-wrap" style="background:#f0fdf4; color:#34c759;">✅</div>
                </div>
            </div>

            <!-- Tablero Kanban de Casos en Tiempo Real -->
            <div class="cm-apple-card-panel cm-kanban-section">
                <div class="cm-panel-header" style="margin-bottom:14px; padding-bottom:12px;">
                    <div>
                        <h2 class="cm-panel-title">📋 <?php _e('Tablero Visual de Flujo de Casos', 'contacto-multidestino'); ?></h2>
                        <p class="cm-panel-sub"><?php _e('Visualiza en tiempo real en qué etapa se encuentra cada solicitud institucional. Haz clic en cualquier tarjeta para abrir su expediente.', 'contacto-multidestino'); ?></p>
                    </div>
                    <div>
                        <button type="button" class="cm-btn-view" style="font-size:12px;" onclick="location.reload()">
                            🔄 <?php _e('Actualizar Tablero', 'contacto-multidestino'); ?>
                        </button>
                    </div>
                </div>

                <div class="cm-kanban-board">
                    <!-- Columna 1: Iniciados -->
                    <div class="cm-kanban-column" style="border-top:3px solid #0071e3;">
                        <div class="cm-kanban-header">
                            <span class="cm-kanban-col-title">
                                📥 <?php _e('Iniciados', 'contacto-multidestino'); ?>
                            </span>
                            <span class="cm-kanban-count-pill" style="background:#dbeafe; color:#1e40af;"><?php echo count($kanban['iniciados']); ?></span>
                        </div>
                        <div class="cm-kanban-cards-list">
                            <?php if (empty($kanban['iniciados'])) : ?>
                                <small style="color:#94a3b8; text-align:center; padding:15px;"><?php _e('Sin casos pendientes de inicio', 'contacto-multidestino'); ?></small>
                            <?php else : ?>
                                <?php foreach ($kanban['iniciados'] as $c) : ?>
                                    <div class="cm-kanban-card" onclick="cmOpenCaseModal(<?php echo esc_attr($c->id); ?>, '<?php echo esc_attr($c->ticket_code); ?>')">
                                        <div class="cm-kanban-card-top">
                                            <span class="cm-kanban-ticket"><?php echo esc_html($c->ticket_code); ?></span>
                                            <span class="cm-badge-mini" style="background:#e0f2fe; color:#0369a1;">NUEVO</span>
                                        </div>
                                        <div class="cm-kanban-card-user"><?php echo esc_html($c->sender_name ? $c->sender_name : 'Solicitante'); ?></div>
                                        <div class="cm-kanban-card-dept">🏢 <?php echo esc_html($c->department); ?></div>
                                        <div class="cm-kanban-card-footer">
                                            <span>📅 <?php echo date_i18n('d/m H:i', strtotime($c->created_at)); ?></span>
                                            <span style="color:#0071e3; font-weight:700;">👁️ Ver &rarr;</span>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Columna 2: En Continuidad -->
                    <div class="cm-kanban-column" style="border-top:3px solid #5856d6;">
                        <div class="cm-kanban-header">
                            <span class="cm-kanban-col-title">
                                ⚡ <?php _e('En Continuidad', 'contacto-multidestino'); ?>
                            </span>
                            <span class="cm-kanban-count-pill" style="background:#ede9fe; color:#5b21b6;"><?php echo count($kanban['continuidad']); ?></span>
                        </div>
                        <div class="cm-kanban-cards-list">
                            <?php if (empty($kanban['continuidad'])) : ?>
                                <small style="color:#94a3b8; text-align:center; padding:15px;"><?php _e('Sin casos en revisión activa', 'contacto-multidestino'); ?></small>
                            <?php else : ?>
                                <?php foreach ($kanban['continuidad'] as $c) : ?>
                                    <div class="cm-kanban-card" onclick="cmOpenCaseModal(<?php echo esc_attr($c->id); ?>, '<?php echo esc_attr($c->ticket_code); ?>')">
                                        <div class="cm-kanban-card-top">
                                            <span class="cm-kanban-ticket" style="color:#5856d6;"><?php echo esc_html($c->ticket_code); ?></span>
                                            <span class="cm-badge-mini" style="background:#ede9fe; color:#5b21b6;"><?php echo strtoupper($c->status); ?></span>
                                        </div>
                                        <div class="cm-kanban-card-user"><?php echo esc_html($c->sender_name ? $c->sender_name : 'Solicitante'); ?></div>
                                        <div class="cm-kanban-card-dept">🏢 <?php echo esc_html($c->department); ?></div>
                                        <div class="cm-kanban-card-footer">
                                            <span>📅 <?php echo date_i18n('d/m H:i', strtotime($c->updated_at)); ?></span>
                                            <span style="color:#5856d6; font-weight:700;">👁️ Ver &rarr;</span>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Columna 3: Requiere Presencia / Acción -->
                    <div class="cm-kanban-column" style="border-top:3px solid #ff9500;">
                        <div class="cm-kanban-header">
                            <span class="cm-kanban-col-title">
                                ⚠️ <?php _e('Requiere Presencia', 'contacto-multidestino'); ?>
                            </span>
                            <span class="cm-kanban-count-pill" style="background:#fef3c7; color:#92400e;"><?php echo count($kanban['pendientes']); ?></span>
                        </div>
                        <div class="cm-kanban-cards-list">
                            <?php if (empty($kanban['pendientes'])) : ?>
                                <small style="color:#94a3b8; text-align:center; padding:15px;"><?php _e('Sin casos pendientes de usuario', 'contacto-multidestino'); ?></small>
                            <?php else : ?>
                                <?php foreach ($kanban['pendientes'] as $c) : ?>
                                    <div class="cm-kanban-card" style="border-left:3px solid #ff9500;" onclick="cmOpenCaseModal(<?php echo esc_attr($c->id); ?>, '<?php echo esc_attr($c->ticket_code); ?>')">
                                        <div class="cm-kanban-card-top">
                                            <span class="cm-kanban-ticket" style="color:#d97706;"><?php echo esc_html($c->ticket_code); ?></span>
                                            <span class="cm-badge-mini" style="background:#fef3c7; color:#92400e;">ACCIÓN</span>
                                        </div>
                                        <div class="cm-kanban-card-user"><?php echo esc_html($c->sender_name ? $c->sender_name : 'Solicitante'); ?></div>
                                        <div class="cm-kanban-card-dept">🏢 <?php echo esc_html($c->department); ?></div>
                                        <div class="cm-kanban-card-footer">
                                            <span>📅 <?php echo date_i18n('d/m H:i', strtotime($c->updated_at)); ?></span>
                                            <span style="color:#d97706; font-weight:700;">👁️ Ver &rarr;</span>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Columna 4: Finalizados -->
                    <div class="cm-kanban-column" style="border-top:3px solid #34c759;">
                        <div class="cm-kanban-header">
                            <span class="cm-kanban-col-title">
                                ✅ <?php _e('Finalizados', 'contacto-multidestino'); ?>
                            </span>
                            <span class="cm-kanban-count-pill" style="background:#dcfce7; color:#166534;"><?php echo count($kanban['finalizados']); ?></span>
                        </div>
                        <div class="cm-kanban-cards-list">
                            <?php if (empty($kanban['finalizados'])) : ?>
                                <small style="color:#94a3b8; text-align:center; padding:15px;"><?php _e('Sin casos cerrados aún', 'contacto-multidestino'); ?></small>
                            <?php else : ?>
                                <?php foreach ($kanban['finalizados'] as $c) : ?>
                                    <div class="cm-kanban-card" onclick="cmOpenCaseModal(<?php echo esc_attr($c->id); ?>, '<?php echo esc_attr($c->ticket_code); ?>')">
                                        <div class="cm-kanban-card-top">
                                            <span class="cm-kanban-ticket" style="color:#16a34a;"><?php echo esc_html($c->ticket_code); ?></span>
                                            <span class="cm-badge-mini" style="background:#dcfce7; color:#166534;">CERRADO</span>
                                        </div>
                                        <div class="cm-kanban-card-user"><?php echo esc_html($c->sender_name ? $c->sender_name : 'Solicitante'); ?></div>
                                        <div class="cm-kanban-card-dept">🏢 <?php echo esc_html($c->department); ?></div>
                                        <div class="cm-kanban-card-footer">
                                            <span>📅 <?php echo date_i18n('d/m H:i', strtotime($c->updated_at)); ?></span>
                                            <span style="color:#16a34a; font-weight:700;">👁️ Ver &rarr;</span>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Fila Inferior 2 Columnas: Desglose por Áreas + Feed de Actividad en Vivo -->
            <div class="cm-dashboard-2col">
                <!-- Columna Izquierda: Rendimiento por Áreas -->
                <div class="cm-apple-card-panel" style="margin-bottom:0;">
                    <div class="cm-panel-header" style="margin-bottom:12px; padding-bottom:10px;">
                        <div>
                            <h3 style="font-size:14.5px; font-weight:700; color:#1d1d1f; margin:0;">🏢 <?php _e('Rendimiento por Departamento / Área', 'contacto-multidestino'); ?></h3>
                            <p class="cm-panel-sub"><?php _e('Distribución de carga de trabajo y tasa de resolución por cada área.', 'contacto-multidestino'); ?></p>
                        </div>
                    </div>

                    <?php if (empty($analytics['departments'])) : ?>
                        <p style="color:#94a3b8; font-size:13px; text-align:center; padding:20px;"><?php _e('No hay registros de casos aún.', 'contacto-multidestino'); ?></p>
                    <?php else : ?>
                        <div style="overflow-x:auto;">
                            <table class="cm-table-apple" style="font-size:12.5px;">
                                <thead>
                                    <tr>
                                        <th><?php _e('Área', 'contacto-multidestino'); ?></th>
                                        <th style="text-align:center;"><?php _e('Iniciados', 'contacto-multidestino'); ?></th>
                                        <th style="text-align:center;"><?php _e('Gestión', 'contacto-multidestino'); ?></th>
                                        <th style="text-align:center;"><?php _e('Cerrados', 'contacto-multidestino'); ?></th>
                                        <th style="text-align:center;"><?php _e('Total', 'contacto-multidestino'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($analytics['departments'] as $dr) : 
                                        $d_tot  = (int)$dr->total_cases;
                                        $d_ini  = (int)$dr->count_iniciados;
                                        $d_con  = (int)$dr->count_continuidad + (int)$dr->count_pendientes;
                                        $d_fin  = (int)$dr->count_finalizados;
                                        $p_ini  = $d_tot > 0 ? round(($d_ini / $d_tot) * 100) : 0;
                                        $p_con  = $d_tot > 0 ? round(($d_con / $d_tot) * 100) : 0;
                                        $p_fin  = $d_tot > 0 ? round(($d_fin / $d_tot) * 100) : 0;
                                    ?>
                                        <tr>
                                            <td>
                                                <strong style="color:#1d1d1f;">🏢 <?php echo esc_html($dr->department ? $dr->department : 'General'); ?></strong>
                                                <div class="cm-progress-stacked" title="Iniciados: <?php echo $p_ini; ?>% | Gestión: <?php echo $p_con; ?>% | Finalizados: <?php echo $p_fin; ?>%">
                                                    <div class="cm-prog-seg" style="width:<?php echo $p_ini; ?>%; background:#0071e3;"></div>
                                                    <div class="cm-prog-seg" style="width:<?php echo $p_con; ?>%; background:#5856d6;"></div>
                                                    <div class="cm-prog-seg" style="width:<?php echo $p_fin; ?>%; background:#34c759;"></div>
                                                </div>
                                            </td>
                                            <td style="text-align:center;"><span style="color:#0071e3; font-weight:700;"><?php echo $d_ini; ?></span></td>
                                            <td style="text-align:center;"><span style="color:#5856d6; font-weight:700;"><?php echo $d_con; ?></span></td>
                                            <td style="text-align:center;"><span style="color:#34c759; font-weight:700;"><?php echo $d_fin; ?></span></td>
                                            <td style="text-align:center;"><strong><?php echo $d_tot; ?></strong></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Columna Derecha: Feed de Auditoría y Actividad en Vivo -->
                <div class="cm-apple-card-panel" style="margin-bottom:0;">
                    <div class="cm-panel-header" style="margin-bottom:12px; padding-bottom:10px;">
                        <div>
                            <h3 style="font-size:14.5px; font-weight:700; color:#1d1d1f; margin:0;">⚡ <?php _e('Línea de Tiempo y Auditoría en Vivo', 'contacto-multidestino'); ?></h3>
                            <p class="cm-panel-sub"><?php _e('Últimas acciones realizadas por los encargados de todas las áreas.', 'contacto-multidestino'); ?></p>
                        </div>
                    </div>

                    <?php if (empty($analytics['recent_activity'])) : ?>
                        <p style="color:#94a3b8; font-size:13px; text-align:center; padding:20px;"><?php _e('Sin actividad reciente registrada.', 'contacto-multidestino'); ?></p>
                    <?php else : ?>
                        <div style="max-height:380px; overflow-y:auto; padding-right:4px;">
                            <?php foreach ($analytics['recent_activity'] as $act) : 
                                $icon = '📢';
                                if ($act->action_type === 'created') $icon = '📥';
                                elseif ($act->action_type === 'transfer') $icon = '🔄';
                                elseif ($act->status === 'resuelto' || $act->status === 'cerrado') $icon = '✅';
                                elseif ($act->status === 'pendiente_usuario') $icon = '⚠️';
                                elseif ($act->status === 'en_revision' || $act->status === 'en_proceso') $icon = '⚡';
                            ?>
                                <div class="cm-feed-item">
                                    <span class="cm-feed-icon"><?php echo $icon; ?></span>
                                    <div style="flex:1;">
                                        <div class="cm-feed-title">
                                            <strong><code><?php echo esc_html($act->ticket_code); ?></code></strong> • <?php echo esc_html($act->author_name); ?>
                                        </div>
                                        <div style="color:#475569; font-size:12px; margin-top:2px;">
                                            <?php echo esc_html(wp_strip_all_tags($act->note)); ?>
                                        </div>
                                        <div class="cm-feed-time">
                                            🕒 <?php echo date_i18n('d/m/Y H:i', strtotime($act->created_at)); ?> hrs
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        <?php elseif ($active_tab === 'inbox') : ?>
            <!-- Métricas Compactas (KPIs estilo Apple) -->
            <div class="cm-apple-metrics">
                <div class="cm-metric-pill cm-metric-total">
                    <span class="cm-metric-dot"></span>
                    <span class="cm-metric-val"><?php echo esc_html($stats['total']); ?></span>
                    <span class="cm-metric-name"><?php _e('Total Casos', 'contacto-multidestino'); ?></span>
                </div>
                <div class="cm-metric-pill cm-metric-recibido">
                    <span class="cm-metric-dot" style="background:#0071e3;"></span>
                    <span class="cm-metric-val"><?php echo esc_html($stats['recibido']); ?></span>
                    <span class="cm-metric-name"><?php _e('Recibidos', 'contacto-multidestino'); ?></span>
                </div>
                <div class="cm-metric-pill cm-metric-proceso">
                    <span class="cm-metric-dot" style="background:#5856d6;"></span>
                    <span class="cm-metric-val"><?php echo esc_html($stats['en_revision'] + $stats['en_proceso']); ?></span>
                    <span class="cm-metric-name"><?php _e('En Gestión', 'contacto-multidestino'); ?></span>
                </div>
                <div class="cm-metric-pill cm-metric-alerta">
                    <span class="cm-metric-dot" style="background:#ff9500;"></span>
                    <span class="cm-metric-val"><?php echo esc_html($stats['pendiente_usuario']); ?></span>
                    <span class="cm-metric-name"><?php _e('Requiere Presencia / Acción', 'contacto-multidestino'); ?></span>
                </div>
                <div class="cm-metric-pill cm-metric-resuelto">
                    <span class="cm-metric-dot" style="background:#34c759;"></span>
                    <span class="cm-metric-val"><?php echo esc_html($stats['resuelto']); ?></span>
                    <span class="cm-metric-name"><?php _e('Finalizados', 'contacto-multidestino'); ?></span>
                </div>
            </div>

            <!-- Tarjeta Informativa del Portal de Consulta para Solicitantes -->
            <?php 
            $general_tracker_url = function_exists('cm_get_case_tracker_url') ? cm_get_case_tracker_url('') : home_url('/');
            ?>
            <div class="cm-apple-shortcode-bar" style="margin: 0 0 14px 0; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 10px; padding: 10px 16px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px; box-shadow: 0 1px 3px rgba(0,0,0,0.03);">
                <div style="display: flex; align-items: center; gap: 10px;">
                    <span style="font-size: 20px;">🌐</span>
                    <div>
                        <div style="font-size: 12.5px; font-weight: 700; color: #0f172a;">
                            <?php _e('Portal de Consulta para Solicitantes / Clientes:', 'contacto-multidestino'); ?>
                        </div>
                        <div style="font-size: 11.5px; color: #64748b;">
                            <?php _e('Página donde los usuarios consultan su caso con el código:', 'contacto-multidestino'); ?> 
                            <a href="<?php echo esc_url($general_tracker_url); ?>" target="_blank" style="color: #0284c7; font-weight: 700; text-decoration: underline;">
                                <?php echo esc_html($general_tracker_url); ?> ↗
                            </a>
                        </div>
                    </div>
                </div>
                <div style="display: flex; align-items: center; gap: 8px;">
                    <button type="button" class="cm-btn-copy-sm" style="background:#f0f9ff; color:#0369a1; border-color:#bae6fd; font-weight:700; padding:5px 12px;" onclick="navigator.clipboard.writeText('<?php echo esc_js($general_tracker_url); ?>'); alert('¡Enlace del Portal copiado al portapapeles!');">
                        📋 <?php _e('Copiar URL del Portal', 'contacto-multidestino'); ?>
                    </button>
                    <a href="<?php echo esc_url($general_tracker_url); ?>" target="_blank" class="cm-btn-copy-sm" style="background:#0284c7; color:#ffffff; border-color:#0284c7; font-weight:700; text-decoration:none; padding:5px 12px; display:inline-flex; align-items:center; gap:4px;">
                        🌐 <?php _e('Abrir Portal', 'contacto-multidestino'); ?> ↗
                    </a>
                </div>
            </div>

            <!-- Barra de Filtros Compacta estilo Barra de Herramientas -->
            <div class="cm-apple-toolbar">
                <form method="GET" action="<?php echo admin_url('admin.php'); ?>" class="cm-toolbar-form">
                    <input type="hidden" name="page" value="cm-form-submissions" />
                    <input type="hidden" name="tab" value="inbox" />

                    <!-- Filtro Formulario -->
                    <div class="cm-tool-item">
                        <select name="form_filter" onchange="this.form.submit()" class="cm-apple-select">
                            <option value=""><?php _e('Formularios (Todos)', 'contacto-multidestino'); ?></option>
                            <?php foreach ($forms as $fid => $f) : ?>
                                <option value="<?php echo esc_attr($fid); ?>" <?php selected($filter_form, $fid); ?>>
                                    <?php echo esc_html($f['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- Filtro Estado -->
                    <div class="cm-tool-item">
                        <select name="status_filter" onchange="this.form.submit()" class="cm-apple-select">
                            <option value=""><?php _e('Estados (Todos)', 'contacto-multidestino'); ?></option>
                            <?php foreach ($statuses as $skey => $sinfo) : ?>
                                <option value="<?php echo esc_attr($skey); ?>" <?php selected($filter_status, $skey); ?>>
                                    <?php echo $sinfo['icon'] . ' ' . esc_html($sinfo['label']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- Filtro Departamento (Visible para Superadmin) -->
                    <?php if ($is_superadmin) : ?>
                        <div class="cm-tool-item">
                            <select name="dept_filter" onchange="this.form.submit()" class="cm-apple-select">
                                <option value=""><?php _e('Áreas (Todas)', 'contacto-multidestino'); ?></option>
                                <?php foreach ($departments as $dkey => $dinfo) : 
                                    $dname = is_array($dinfo) ? ($dinfo['name'] ?? $dkey) : $dinfo;
                                ?>
                                    <option value="<?php echo esc_attr($dname); ?>" <?php selected($filter_dept, $dname); ?>>
                                        🏢 <?php echo esc_html($dname); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    <?php else : ?>
                        <div class="cm-tool-item">
                            <span class="cm-tag-dept" style="padding:5px 10px; font-size:12.5px;">
                                🏢 <?php printf(__('Área: %s', 'contacto-multidestino'), esc_html($user_assigned_dept ? $user_assigned_dept : 'General')); ?>
                            </span>
                        </div>
                    <?php endif; ?>

                    <!-- Buscador Apple Minimalista -->
                    <div class="cm-tool-item cm-tool-search">
                        <div class="cm-search-wrap">
                            <span class="dashicons dashicons-search cm-search-icon"></span>
                            <input 
                                type="search" 
                                name="s" 
                                value="<?php echo esc_attr($search_query); ?>" 
                                placeholder="<?php esc_attr_e('Buscar por código, solicitante, correo...', 'contacto-multidestino'); ?>" 
                                class="cm-apple-search-input"
                            />
                        </div>
                        <?php if ($filter_form || $filter_status || ($filter_dept && $is_superadmin) || $search_query) : ?>
                            <a href="<?php echo admin_url('admin.php?page=cm-form-submissions'); ?>" class="cm-btn-clear-filter" title="<?php esc_attr_e('Limpiar filtros', 'contacto-multidestino'); ?>">
                                ✕ <?php _e('Limpiar', 'contacto-multidestino'); ?>
                            </a>
                        <?php endif; ?>
                        
                        <button type="button" class="cm-btn-view" style="font-size:11.5px; padding:4px 10px; margin-left:6px; display:inline-flex; align-items:center; gap:4px; height:32px;" onclick="cmPlayNotificationSound(true)" title="<?php esc_attr_e('Probar sonido de notificación de nuevos casos', 'contacto-multidestino'); ?>">
                            🔔 <span class="hide-if-small"><?php _e('Probar Sonido', 'contacto-multidestino'); ?></span>
                        </button>
                    </div>
                </form>
            </div>

            <!-- Contenedor Flotante de Avisos en Vivo -->
            <div id="cm-live-toast-wrap" style="position:fixed; top:40px; right:25px; z-index:99999; display:flex; flex-direction:column; gap:10px; pointer-events:none;"></div>

            <!-- Tabla de Casos Compacta y Elegante -->
            <div class="cm-apple-table-card">
                <table class="cm-table-apple">
                    <thead>
                        <tr>
                            <th style="width: 140px;"><?php _e('Código / Portal', 'contacto-multidestino'); ?></th>
                            <th style="width: 190px;"><?php _e('Solicitante', 'contacto-multidestino'); ?></th>
                            <th style="width: 160px;"><?php _e('Área Asignada', 'contacto-multidestino'); ?></th>
                            <th><?php _e('Formulario / Asunto', 'contacto-multidestino'); ?></th>
                            <th style="width: 130px;"><?php _e('Fecha', 'contacto-multidestino'); ?></th>
                            <th style="width: 160px;"><?php _e('Estado Actual', 'contacto-multidestino'); ?></th>
                            <th style="width: 110px; text-align: center;"><?php _e('Acción', 'contacto-multidestino'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($submissions)) : ?>
                            <?php foreach ($submissions as $sub) : 
                                $status_key  = $sub->status;
                                $status_info = isset($statuses[$status_key]) ? $statuses[$status_key] : array(
                                    'label'    => ucfirst($status_key),
                                    'color'    => '#475569',
                                    'bg_color' => '#f1f5f9',
                                    'icon'     => '📌'
                                );
                                $date_short = date_i18n('d/m/y H:i', strtotime($sub->created_at));
                                $tracker_url = function_exists('cm_get_case_tracker_url') ? cm_get_case_tracker_url($sub->ticket_code) : home_url('/?codigo=' . $sub->ticket_code);
                            ?>
                                <tr id="cm-row-<?php echo esc_attr($sub->id); ?>" class="cm-table-row">
                                    <td>
                                        <code class="cm-tag-code"><?php echo esc_html($sub->ticket_code); ?></code>
                                        <div style="margin-top:4px;">
                                            <a href="<?php echo esc_url($tracker_url); ?>" target="_blank" class="cm-portal-link-btn" title="<?php esc_attr_e('Abrir portal donde el solicitante ve este caso', 'contacto-multidestino'); ?>" style="font-size:10.5px; font-weight:700; color:#0284c7; text-decoration:none; display:inline-flex; align-items:center; gap:3px; background:#e0f2fe; padding:2px 7px; border-radius:5px; border:1px solid #bae6fd;">
                                                🌐 <?php _e('Ir al Caso Web', 'contacto-multidestino'); ?> ↗
                                            </a>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="cm-cell-name"><?php echo esc_html($sub->sender_name ? $sub->sender_name : 'Anónimo'); ?></div>
                                        <?php if ($sub->sender_email) : ?>
                                            <div class="cm-cell-sub">✉️ <?php echo esc_html($sub->sender_email); ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="cm-tag-dept" id="cm-row-dept-<?php echo esc_attr($sub->id); ?>">
                                            🏢 <?php echo esc_html($sub->department ? $sub->department : 'General'); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="cm-cell-form"><?php echo esc_html($sub->form_name ? $sub->form_name : $sub->form_id); ?></div>
                                    </td>
                                    <td>
                                        <span class="cm-cell-date"><?php echo esc_html($date_short); ?></span>
                                    </td>
                                    <td>
                                        <span class="cm-badge-status" id="cm-status-pill-<?php echo esc_attr($sub->id); ?>" style="background-color: <?php echo esc_attr($status_info['bg_color']); ?>; color: <?php echo esc_attr($status_info['color']); ?>; border-color: <?php echo esc_attr($status_info['border'] ?? $status_info['color']); ?>;">
                                            <?php echo $status_info['icon'] . ' ' . esc_html($status_info['label']); ?>
                                        </span>
                                    </td>
                                    <td style="text-align: center;">
                                        <div class="cm-action-group">
                                            <button 
                                                type="button" 
                                                class="cm-btn-view" 
                                                onclick="cmOpenCaseModal(<?php echo esc_attr($sub->id); ?>)" 
                                                title="<?php esc_attr_e('Abrir en Modal Flotante', 'contacto-multidestino'); ?>"
                                            >
                                                👁️ <?php _e('Modal', 'contacto-multidestino'); ?>
                                            </button>
                                            <a 
                                                href="<?php echo admin_url('admin.php?page=cm-form-submissions&case_id=' . $sub->id); ?>" 
                                                class="cm-apple-btn-secondary" 
                                                style="font-size:11px; padding:3px 8px; height:26px; display:inline-flex; align-items:center; gap:3px; text-decoration:none; font-weight:700; color:#0f172a; background:#f8fafc; border-color:#cbd5e1;" 
                                                title="<?php esc_attr_e('Ver en Página Completa', 'contacto-multidestino'); ?>"
                                            >
                                                🖥️ <?php _e('Página', 'contacto-multidestino'); ?>
                                            </a>
                                            <button 
                                                type="button" 
                                                class="cm-btn-del" 
                                                onclick="cmDeleteCase(<?php echo esc_attr($sub->id); ?>)" 
                                                title="<?php esc_attr_e('Eliminar', 'contacto-multidestino'); ?>"
                                            >
                                                🗑️
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="7" class="cm-empty-cell">
                                    <div class="cm-empty-wrap">
                                        <span class="dashicons dashicons-inbox cm-empty-icon"></span>
                                        <h4><?php _e('No hay casos registrados', 'contacto-multidestino'); ?></h4>
                                        <p><?php _e('Los mensajes enviados desde tus formularios aparecerán ordenados aquí en tiempo real.', 'contacto-multidestino'); ?></p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Paginación Compacta -->
            <?php if ($total_pages > 1) : ?>
                <div class="cm-pagination-bar">
                    <span><?php printf(__('Total: %d casos', 'contacto-multidestino'), $total_items); ?></span>
                    <div class="cm-page-links">
                        <?php
                        echo paginate_links(array(
                            'base'      => add_query_arg('paged', '%#%'),
                            'format'    => '',
                            'prev_text' => '&lsaquo;',
                            'next_text' => '&rsaquo;',
                            'total'     => $total_pages,
                            'current'   => $current_page,
                        ));
                        ?>
                    </div>
                </div>
            <?php endif; ?>

        <?php elseif ($active_tab === 'departments') : ?>
            <!-- PESTAÑA: GESTIÓN DE ÁREAS Y ENCARGADOS (SUPERADMIN) -->
            <div class="cm-apple-card-panel">
                <div class="cm-panel-header">
                    <div>
                        <h2 class="cm-panel-title">🏢 <?php _e('Departamentos y Áreas de Atención', 'contacto-multidestino'); ?></h2>
                        <p class="cm-panel-sub"><?php _e('Habilita, deshabilita, edita o asigna encargados responsables a cada área. Las áreas deshabilitadas no aceptarán solicitudes.', 'contacto-multidestino'); ?></p>
                    </div>
                    <div style="display:flex; gap:8px;">
                        <button type="button" class="cm-btn-apple-primary" onclick="cmOpenNewDeptModal()">
                            ➕ <?php _e('Nueva Área', 'contacto-multidestino'); ?>
                        </button>
                        <button type="button" class="cm-apple-btn-secondary" onclick="cmOpenNewUserModal()">
                            👤 <?php _e('Crear Usuario / Encargado', 'contacto-multidestino'); ?>
                        </button>
                    </div>
                </div>

                <!-- Banner Informativo con URL de Acceso para Encargados -->
                <div style="background:#f0f9ff; border:1px solid #bae6fd; border-radius:12px; padding:12px 18px; margin-bottom:20px; display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:12px;">
                    <div style="display:flex; align-items:center; gap:10px;">
                        <span style="font-size:22px;">🔗</span>
                        <div>
                            <strong style="color:#0369a1; font-size:13px;"><?php _e('Enlace de Acceso Directo para Encargados de Área:', 'contacto-multidestino'); ?></strong>
                            <div style="font-size:12px; color:#475569; margin-top:2px;">
                                <?php _e('Comparte esta URL con los encargados para que ingresen directo a su bandeja de casos:', 'contacto-multidestino'); ?>
                            </div>
                        </div>
                    </div>
                    <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
                        <code style="font-size:12px; font-weight:700; color:#0369a1; background:#ffffff; border:1px solid #e0f2fe; padding:5px 10px; border-radius:8px;">
                            <?php echo esc_url(admin_url('admin.php?page=cm-form-submissions')); ?>
                        </code>
                        <button type="button" class="cm-btn-copy-sm" style="background:#0284c7; color:#ffffff; font-weight:700;" onclick="navigator.clipboard.writeText('<?php echo esc_url(admin_url('admin.php?page=cm-form-submissions')); ?>'); alert('✓ ¡Enlace copiado al portapapeles! Puedes enviarlo por correo.');">
                            📋 <?php _e('Copiar Enlace', 'contacto-multidestino'); ?>
                        </button>
                    </div>
                </div>

                <!-- Tabla de Departamentos -->
                <div class="cm-departments-table-wrap">
                    <table class="cm-table-apple">
                        <thead>
                            <tr>
                                <th><?php _e('Área / Departamento', 'contacto-multidestino'); ?></th>
                                <th><?php _e('Correos de Notificación', 'contacto-multidestino'); ?></th>
                                <th><?php _e('Encargado Responsable', 'contacto-multidestino'); ?></th>
                                <th style="width: 140px; text-align:center;"><?php _e('Estado', 'contacto-multidestino'); ?></th>
                                <th style="width: 160px; text-align:center;"><?php _e('Acciones', 'contacto-multidestino'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($departments as $dkey => $ddata) : 
                                $dname    = is_array($ddata) ? ($ddata['name'] ?? $dkey) : $ddata;
                                $demails  = is_array($ddata) ? ($ddata['emails'] ?? '') : '';
                                $duser    = is_array($ddata) ? ($ddata['user'] ?? '') : '';
                                $duser_id = is_array($ddata) ? ($ddata['user_id'] ?? 0) : 0;
                                $denabled = is_array($ddata) ? (!empty($ddata['enabled'])) : true;
                            ?>
                                <tr id="cm-dept-row-<?php echo esc_attr(sanitize_title($dname)); ?>">
                                    <td>
                                        <strong style="color:#1d1d1f; font-size:13.5px;">🏢 <?php echo esc_html($dname); ?></strong>
                                    </td>
                                    <td>
                                        <code style="font-size:12px; color:#475569; background:#f5f5f7; padding:3px 8px; border-radius:6px;"><?php echo esc_html($demails ? $demails : get_option('admin_email')); ?></code>
                                    </td>
                                    <td>
                                        <div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap;">
                                            <span class="cm-tag-user">👤 <?php echo esc_html($duser ? $duser : 'Administrador General'); ?></span>
                                            <?php if ($duser_id > 0) : ?>
                                                <button 
                                                    type="button" 
                                                    class="cm-btn-copy-sm" 
                                                    style="font-size:11px; padding:2px 7px; background:#eff6ff; color:#0071e3; border:1px solid #bfdbfe; cursor:pointer;" 
                                                    onclick="cmOpenResetPasswordModal(<?php echo esc_attr($duser_id); ?>, '<?php echo esc_attr(addslashes($duser)); ?>')" 
                                                    title="<?php esc_attr_e('Restablecer o cambiar la contraseña de este encargado', 'contacto-multidestino'); ?>"
                                                >
                                                    🔑 <?php _e('Clave', 'contacto-multidestino'); ?>
                                                </button>
                                                <a 
                                                    href="<?php echo esc_url(admin_url('user-edit.php?user_id=' . $duser_id)); ?>" 
                                                    target="_blank" 
                                                    class="cm-btn-copy-sm" 
                                                    style="font-size:11px; padding:2px 7px; text-decoration:none; background:#f8fafc; color:#475569; border:1px solid #e2e8f0;" 
                                                    title="<?php esc_attr_e('Editar perfil, correo y datos del usuario en WordPress', 'contacto-multidestino'); ?>"
                                                >
                                                    ✏️ <?php _e('Editar', 'contacto-multidestino'); ?>
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td style="text-align:center;">
                                        <?php if ($denabled) : ?>
                                            <span class="cm-badge-active">🟢 <?php _e('Habilitada', 'contacto-multidestino'); ?></span>
                                        <?php else : ?>
                                            <span class="cm-badge-mini" style="background:#ffe5e5; color:#c53030; font-weight:700; padding:3px 8px; border-radius:10px;">🔴 <?php _e('Deshabilitada', 'contacto-multidestino'); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="text-align:center;">
                                        <div class="cm-action-group">
                                            <button 
                                                type="button" 
                                                class="cm-btn-view" 
                                                onclick="cmOpenEditDeptModal('<?php echo esc_attr(addslashes($dname)); ?>', '<?php echo esc_attr(addslashes($demails)); ?>', '<?php echo esc_attr($duser_id); ?>', '<?php echo esc_attr($denabled ? 1 : 0); ?>')"
                                                title="<?php esc_attr_e('Editar Área y Reasignar Encargado', 'contacto-multidestino'); ?>"
                                            >
                                                ✏️ <?php _e('Editar', 'contacto-multidestino'); ?>
                                            </button>
                                            <button 
                                                type="button" 
                                                class="cm-btn-del" 
                                                style="color:<?php echo $denabled ? '#e06c00' : '#10b981'; ?> !important;" 
                                                onclick="cmToggleDeptStatus('<?php echo esc_attr(addslashes($dname)); ?>')" 
                                                title="<?php echo $denabled ? esc_attr__('Deshabilitar área', 'contacto-multidestino') : esc_attr__('Habilitar área', 'contacto-multidestino'); ?>"
                                            >
                                                <?php echo $denabled ? '⏸️' : '▶️'; ?>
                                            </button>
                                            <button 
                                                type="button" 
                                                class="cm-btn-del" 
                                                onclick="cmDeleteDept('<?php echo esc_attr(addslashes($dname)); ?>')" 
                                                title="<?php esc_attr_e('Eliminar Área', 'contacto-multidestino'); ?>"
                                            >
                                                🗑️
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Sección de Usuarios del Sistema y Suspensión -->
                <div style="margin-top: 32px; padding-top: 20px; border-top: 1px solid #e5e5ea;">
                    <div class="cm-panel-header" style="border-bottom:none; margin-bottom:12px;">
                        <div>
                            <h3 style="font-size:15px; font-weight:700; margin:0; color:#1d1d1f;">👥 <?php _e('Usuarios del Sistema y Control de Cuentas', 'contacto-multidestino'); ?></h3>
                            <p class="cm-panel-sub"><?php _e('Gestiona las credenciales, cambia contraseñas al instante o suspende el acceso de cualquier usuario.', 'contacto-multidestino'); ?></p>
                        </div>
                    </div>

                    <div class="cm-table-wrap" style="overflow-x:auto; -webkit-overflow-scrolling:touch; width:100%; border-radius:12px; border:1px solid #e2e8f0;">
                        <table class="cm-table-apple" style="margin:0; width:100%; min-width:960px;">
                            <thead>
                                <tr>
                                    <th style="white-space:nowrap; width:110px;"><?php _e('Usuario (Login)', 'contacto-multidestino'); ?></th>
                                    <th style="min-width:150px;"><?php _e('Correo Electrónico', 'contacto-multidestino'); ?></th>
                                    <th style="white-space:nowrap; min-width:130px;"><?php _e('Nombre Público', 'contacto-multidestino'); ?></th>
                                    <th style="white-space:nowrap; width:140px;"><?php _e('Perfil / Nivel', 'contacto-multidestino'); ?></th>
                                    <th style="min-width:160px;"><?php _e('Área Asignada', 'contacto-multidestino'); ?></th>
                                    <th style="white-space:nowrap; width:130px; text-align:center;"><?php _e('Seguridad 2FA', 'contacto-multidestino'); ?></th>
                                    <th style="white-space:nowrap; width:90px; text-align:center;"><?php _e('Estado', 'contacto-multidestino'); ?></th>
                                    <th style="white-space:nowrap; min-width:280px; text-align:center;"><?php _e('Acciones y Seguridad', 'contacto-multidestino'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($wp_users as $u) : 
                                    $is_suspended     = get_user_meta($u->ID, 'cm_user_suspended', true);
                                    $user_2fa_enabled = function_exists('cm_is_2fa_enabled') && cm_is_2fa_enabled($u->ID);
                                    $user_2fa_date    = function_exists('cm_get_2fa_activated_at') ? cm_get_2fa_activated_at($u->ID) : '';
                                    $user_obj         = new WP_User($u->ID);
                                    $is_admin         = in_array('administrator', (array)$user_obj->roles);
                                    
                                    // Buscar áreas asignadas a este usuario
                                    $user_deps = array();
                                    foreach ($departments as $dk => $dv) {
                                        $d_uid = is_array($dv) ? ($dv['user_id'] ?? 0) : 0;
                                        if ((int)$d_uid === (int)$u->ID) {
                                            $user_deps[] = is_array($dv) ? ($dv['name'] ?? $dk) : $dv;
                                        }
                                    }
                                ?>
                                    <tr id="cm-user-row-<?php echo esc_attr($u->ID); ?>">
                                        <td style="white-space:nowrap;">
                                            <strong><code><?php echo esc_html($u->user_login); ?></code></strong>
                                        </td>
                                        <td>
                                            <a href="mailto:<?php echo esc_attr($u->user_email); ?>" style="color:#0284c7; text-decoration:none; font-size:12.5px;">
                                                <?php echo esc_html($u->user_email); ?>
                                            </a>
                                        </td>
                                        <td style="white-space:nowrap;">
                                            <span style="font-weight:600; color:#1e293b;">👤 <?php echo esc_html($u->display_name); ?></span>
                                        </td>
                                        <td style="white-space:nowrap;">
                                            <?php 
                                            $is_wp_superadmin = in_array('administrator', (array)$user_obj->roles);
                                            $is_dir_profile   = get_user_meta($u->ID, 'cm_user_profile', true) === 'director';
                                            
                                            if ($is_wp_superadmin) : ?>
                                                <span class="cm-tag-dept" style="background:#fee2e2; color:#991b1b; border:1px solid #fca5a5; font-weight:800; font-size:11px; padding:2px 8px;">
                                                    ⚡ <?php _e('Superadmin WP', 'contacto-multidestino'); ?>
                                                </span>
                                            <?php elseif ($is_dir_profile) : ?>
                                                <span class="cm-tag-dept" style="background:#fef3c7; color:#92400e; border:1px solid #fde68a; font-weight:800; font-size:11px; padding:2px 8px;">
                                                    👑 <?php _e('Director / Auditor', 'contacto-multidestino'); ?>
                                                </span>
                                            <?php else : ?>
                                                <span class="cm-tag-dept" style="background:#eff6ff; color:#1e40af; border:1px solid #bfdbfe; font-size:11px; padding:2px 8px;">
                                                    🏢 <?php _e('Encargado Área', 'contacto-multidestino'); ?>
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($is_wp_superadmin || $is_dir_profile) : ?>
                                                <small style="color:#059669; font-weight:700; display:inline-flex; align-items:center; gap:4px; font-size:11px;">
                                                    🌐 <?php _e('Acceso Global (Dashboard y Todas las Áreas)', 'contacto-multidestino'); ?>
                                                </small>
                                            <?php elseif (!empty($user_deps)) : ?>
                                                <span class="cm-tag-dept" style="font-size:11px; padding:2px 8px;">
                                                    🏢 <?php echo esc_html(implode(', ', $user_deps)); ?>
                                                </span>
                                            <?php else : ?>
                                                <small style="color:#94a3b8; font-size:11px;"><?php _e('Sin área asignada', 'contacto-multidestino'); ?></small>
                                            <?php endif; ?>
                                        </td>
                                        <td style="text-align:center; white-space:nowrap;">
                                            <?php if ($user_2fa_enabled) : ?>
                                                <div id="cm-2fa-status-cell-<?php echo esc_attr($u->ID); ?>">
                                                    <span class="cm-badge-active" style="background:#dcfce7; color:#15803d; border:1px solid #bbf7d0; font-weight:700; padding:2px 8px; border-radius:10px; font-size:10.5px; display:inline-block;">
                                                        🛡️ <?php _e('Activo', 'contacto-multidestino'); ?>
                                                    </span>
                                                    <?php if ($user_2fa_date) : ?>
                                                        <div style="font-size:10px; color:#64748b; margin-top:2px;">
                                                            🕒 <?php echo date_i18n('d/m/y H:i', strtotime($user_2fa_date)); ?>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            <?php else : ?>
                                                <div id="cm-2fa-status-cell-<?php echo esc_attr($u->ID); ?>">
                                                    <span style="font-size:11px; color:#94a3b8; background:#f1f5f9; padding:2px 7px; border-radius:8px; display:inline-block;">
                                                        ⚪ <?php _e('No activado', 'contacto-multidestino'); ?>
                                                    </span>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                        <td style="text-align:center; white-space:nowrap;">
                                            <?php if ($is_suspended) : ?>
                                                <span class="cm-badge-mini" style="background:#fee2e2; color:#b91c1c; font-weight:700; padding:2px 8px; border-radius:10px; font-size:10.5px;">⛔ <?php _e('Suspendido', 'contacto-multidestino'); ?></span>
                                            <?php else : ?>
                                                <span class="cm-badge-active" style="font-size:10.5px; padding:2px 8px;">🟢 <?php _e('Activo', 'contacto-multidestino'); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td style="text-align:center; white-space:nowrap;">
                                            <div class="cm-action-group" style="justify-content:center; gap:4px; display:inline-flex; flex-wrap:nowrap; align-items:center; white-space:nowrap;">
                                                <button 
                                                    type="button" 
                                                    class="cm-btn-view" 
                                                    style="font-size:11px; padding:2px 8px; height:26px; line-height:22px; display:inline-flex; align-items:center; gap:3px; border-radius:6px; cursor:pointer;"
                                                    onclick="cmOpenResetPasswordModal(<?php echo esc_attr($u->ID); ?>, '<?php echo esc_attr(addslashes($u->user_login)); ?>')"
                                                    title="<?php esc_attr_e('Restablecer o cambiar la contraseña inmediatamente', 'contacto-multidestino'); ?>"
                                                >
                                                    🔑 <?php _e('Clave', 'contacto-multidestino'); ?>
                                                </button>
                                                <a 
                                                    href="<?php echo esc_url(admin_url('user-edit.php?user_id=' . $u->ID)); ?>" 
                                                    target="_blank" 
                                                    class="cm-btn-view" 
                                                    style="font-size:11px; padding:2px 8px; height:26px; line-height:22px; display:inline-flex; align-items:center; gap:3px; text-decoration:none; border-radius:6px;"
                                                    title="<?php esc_attr_e('Modificar datos, correo y rol en WordPress', 'contacto-multidestino'); ?>"
                                                >
                                                    ✏️ <?php _e('Datos', 'contacto-multidestino'); ?>
                                                </a>
                                                <?php if ($user_2fa_enabled) : ?>
                                                    <button 
                                                        type="button" 
                                                        id="cm-btn-2fa-user-<?php echo esc_attr($u->ID); ?>"
                                                        class="cm-btn-view" 
                                                        style="font-size:11px; padding:2px 8px; height:26px; line-height:22px; display:inline-flex; align-items:center; gap:3px; background:#0284c7; border:none; border-radius:6px; cursor:pointer;"
                                                        onclick="cmOpenAdminUser2FAModal(<?php echo esc_attr($u->ID); ?>, '<?php echo esc_attr(addslashes($u->user_login)); ?>', '<?php echo esc_attr(addslashes($u->display_name)); ?>', 1, '<?php echo esc_attr($user_2fa_date ? date_i18n('d/m/Y H:i', strtotime($user_2fa_date)) : ''); ?>')"
                                                        title="<?php esc_attr_e('Ver detalles de 2FA, quitar o restablecer la seguridad', 'contacto-multidestino'); ?>"
                                                    >
                                                        🛡️ <?php _e('Ver 2FA', 'contacto-multidestino'); ?>
                                                    </button>
                                                <?php else : ?>
                                                    <button 
                                                        type="button" 
                                                        id="cm-btn-2fa-user-<?php echo esc_attr($u->ID); ?>"
                                                        class="cm-btn-view" 
                                                        style="font-size:11px; padding:2px 8px; height:26px; line-height:22px; display:inline-flex; align-items:center; gap:3px; background:#f1f5f9; color:#94a3b8 !important; border:1px solid #e2e8f0; border-radius:6px; cursor:pointer;"
                                                        onclick="cmOpenAdminUser2FAModal(<?php echo esc_attr($u->ID); ?>, '<?php echo esc_attr(addslashes($u->user_login)); ?>', '<?php echo esc_attr(addslashes($u->display_name)); ?>', 0, '')"
                                                        title="<?php esc_attr_e('2FA no activado por este usuario', 'contacto-multidestino'); ?>"
                                                    >
                                                        🛡️ <?php _e('2FA', 'contacto-multidestino'); ?>
                                                    </button>
                                                <?php endif; ?>
                                                <?php if ($u->ID !== get_current_user_id()) : ?>
                                                    <button 
                                                        type="button" 
                                                        class="<?php echo $is_suspended ? 'cm-btn-view' : 'cm-btn-del'; ?>" 
                                                        style="font-size:11px; padding:2px 8px; height:26px; line-height:22px; display:inline-flex; align-items:center; gap:3px; border-radius:6px; cursor:pointer;"
                                                        onclick="cmToggleUserSuspension(<?php echo esc_attr($u->ID); ?>)"
                                                        title="<?php echo $is_suspended ? esc_attr__('Reactivar acceso a la plataforma', 'contacto-multidestino') : esc_attr__('Suspender acceso a la plataforma', 'contacto-multidestino'); ?>"
                                                    >
                                                        <?php echo $is_suspended ? '✓ Activar' : '⛔ Suspender'; ?>
                                                    </button>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <?php elseif ($active_tab === 'trash' && $is_superadmin) : ?>
            <!-- ══════════════════════════════════════════════════════════
                 PESTAÑA: PAPELERA Y RECUPERACIÓN DE CASOS (SOLO SUPERADMIN)
                 ══════════════════════════════════════════════════════════ -->
            <div class="cm-apple-card-panel">
                <div class="cm-panel-header">
                    <div>
                        <h2 class="cm-panel-title" style="color:#b91c1c;">🗑️ <?php _e('Papelera de Casos Eliminados', 'contacto-multidestino'); ?></h2>
                        <p class="cm-panel-sub">
                            <?php _e('Los casos nunca se eliminan definitivamente del sistema. Como Super Administrador, puedes consultar el historial de cuándo fue eliminado, por quién, y recuperarlo en cualquier momento a su estado activo.', 'contacto-multidestino'); ?>
                        </p>
                    </div>
                    <div>
                        <span class="cm-badge-mini" style="background:#fee2e2; color:#b91c1c; font-size:12px; font-weight:700; padding:6px 12px; border-radius:12px; border:1px solid #fecaca;">
                            <?php printf(_n('%s caso en papelera', '%s casos en papelera', $total_items, 'contacto-multidestino'), number_format_i18n($total_items)); ?>
                        </span>
                    </div>
                </div>

                <!-- Buscador en Papelera -->
                <div class="cm-filters-bar" style="margin-bottom: 16px;">
                    <form method="get" action="<?php echo esc_url(admin_url('admin.php')); ?>" style="display:flex; gap:10px; width:100%; align-items:center; flex-wrap:wrap;">
                        <input type="hidden" name="page" value="cm-form-submissions" />
                        <input type="hidden" name="tab" value="trash" />
                        <div class="cm-search-wrap" style="flex:1; min-width:260px;">
                            <span class="cm-search-icon">🔍</span>
                            <input 
                                type="text" 
                                name="s" 
                                class="cm-search-input" 
                                value="<?php echo esc_attr($search_query); ?>" 
                                placeholder="<?php esc_attr_e('Buscar por código, solicitante, correo o departamento...', 'contacto-multidestino'); ?>" 
                            />
                        </div>
                        <button type="submit" class="cm-btn-apple-primary" style="height:36px; padding:0 16px;">
                            <?php _e('Buscar', 'contacto-multidestino'); ?>
                        </button>
                        <?php if (!empty($search_query)) : ?>
                            <a href="<?php echo admin_url('admin.php?page=cm-form-submissions&tab=trash'); ?>" class="cm-apple-btn-secondary" style="height:36px; line-height:34px; padding:0 12px; text-decoration:none;">
                                ✕ <?php _e('Limpiar', 'contacto-multidestino'); ?>
                            </a>
                        <?php endif; ?>
                    </form>
                </div>

                <!-- Tabla de Casos en Papelera -->
                <div class="cm-table-wrap">
                    <table class="cm-table-apple">
                        <thead>
                            <tr>
                                <th style="width: 140px;"><?php _e('Código / Ticket', 'contacto-multidestino'); ?></th>
                                <th><?php _e('Solicitante', 'contacto-multidestino'); ?></th>
                                <th style="width: 160px;"><?php _e('Área Asignada', 'contacto-multidestino'); ?></th>
                                <th style="width: 160px;"><?php _e('Fecha Eliminación', 'contacto-multidestino'); ?></th>
                                <th style="width: 150px;"><?php _e('Eliminado Por', 'contacto-multidestino'); ?></th>
                                <th style="width: 130px; text-align:center;"><?php _e('Último Estado', 'contacto-multidestino'); ?></th>
                                <th style="width: 190px; text-align: center;"><?php _e('Acciones', 'contacto-multidestino'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($submissions)) : ?>
                                <?php foreach ($submissions as $sub) : 
                                    $st_info = isset($statuses[$sub->status]) ? $statuses[$sub->status] : array('label' => ucfirst($sub->status), 'color' => '#475569', 'bg_color' => '#f1f5f9', 'icon' => '📌');
                                    $del_date = !empty($sub->deleted_at) ? date_i18n('d/m/Y H:i', strtotime($sub->deleted_at)) . ' hrs' : '—';
                                    $del_by = !empty($sub->deleted_by) ? esc_html($sub->deleted_by) : 'Administrador';
                                ?>
                                    <tr id="cm-trash-row-<?php echo esc_attr($sub->id); ?>">
                                        <td>
                                            <span class="cm-ticket-badge" style="font-family: monospace; font-size:12.5px; font-weight: 800; color: #0284c7; background: #e0f2fe; padding: 3px 8px; border-radius: 6px; display:inline-block;">
                                                <?php echo esc_html($sub->ticket_code); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="cm-sender-name" style="font-weight:700; color:#0f172a; font-size:13px;">
                                                <?php echo esc_html($sub->sender_name ? $sub->sender_name : __('Anónimo', 'contacto-multidestino')); ?>
                                            </div>
                                            <div class="cm-sender-meta" style="font-size:11.5px; margin-top:2px;">
                                                <a href="mailto:<?php echo esc_attr($sub->sender_email); ?>" style="color:#64748b; text-decoration:none;">
                                                    <?php echo esc_html($sub->sender_email); ?>
                                                </a>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="cm-tag-dept" style="background:#f1f5f9; color:#334155; font-weight:600; font-size:11.5px; padding:3px 9px; border-radius:6px; display:inline-block;">
                                                🏢 <?php echo esc_html($sub->department ? $sub->department : 'General'); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div style="display:inline-flex; align-items:center; gap:4px; font-size:11.5px; color:#b91c1c; font-weight:600; background:#fef2f2; border:1px solid #fecaca; padding:2px 8px; border-radius:6px;">
                                                🗑️ <?php echo esc_html($del_date); ?>
                                            </div>
                                        </td>
                                        <td>
                                            <div style="font-size: 12px; color: #334155; font-weight: 600;">
                                                👤 <?php echo $del_by; ?>
                                            </div>
                                        </td>
                                        <td style="text-align:center;">
                                            <span class="cm-badge-mini" style="background-color: <?php echo esc_attr($st_info['bg_color']); ?>; color: <?php echo esc_attr($st_info['color']); ?>; font-weight:700; padding:3px 8px; border-radius:10px; display:inline-block;">
                                                <?php echo $st_info['icon'] . ' ' . esc_html($st_info['label']); ?>
                                            </span>
                                        </td>
                                        <td style="text-align: center;">
                                            <div class="cm-action-group" style="justify-content:center; gap:6px; flex-wrap:nowrap;">
                                                <button 
                                                    type="button" 
                                                    class="cm-apple-btn-primary" 
                                                    style="font-size:11.5px; font-weight:700; height:28px; padding:0 12px; background:#16a34a; border-color:#15803d; color:#ffffff; display:inline-flex; align-items:center; gap:4px; border-radius:6px; box-shadow:0 1px 3px rgba(22,163,74,0.25); cursor:pointer;"
                                                    onclick="cmRestoreCase(<?php echo esc_attr($sub->id); ?>)" 
                                                    title="<?php esc_attr_e('Restaurar este caso a la bandeja de casos activos', 'contacto-multidestino'); ?>"
                                                >
                                                    ♻️ <?php _e('Recuperar', 'contacto-multidestino'); ?>
                                                </button>
                                                <button 
                                                    type="button" 
                                                    class="cm-btn-view" 
                                                    style="font-size:11.5px; font-weight:700; height:28px; padding:0 10px; display:inline-flex; align-items:center; gap:4px; cursor:pointer;"
                                                    onclick="cmOpenCaseModal(<?php echo esc_attr($sub->id); ?>)" 
                                                    title="<?php esc_attr_e('Abrir expediente en ventana flotante', 'contacto-multidestino'); ?>"
                                                >
                                                    👁️ <?php _e('Modal', 'contacto-multidestino'); ?>
                                                </button>
                                                <a 
                                                    href="<?php echo esc_url(admin_url('admin.php?page=cm-form-submissions&case_id=' . $sub->id)); ?>" 
                                                    class="cm-apple-btn-secondary" 
                                                    style="font-size:11.5px; font-weight:700; height:28px; padding:0 10px; text-decoration:none; display:inline-flex; align-items:center; gap:4px; color:#0f172a; background:#ffffff; border-color:#cbd5e1; border-radius:6px;"
                                                    title="<?php esc_attr_e('Ver en página completa estilo Apple', 'contacto-multidestino'); ?>"
                                                >
                                                    🖥️ <?php _e('Página', 'contacto-multidestino'); ?>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <tr>
                                    <td colspan="7" style="text-align: center; padding: 40px 20px;">
                                        <div style="font-size: 32px; margin-bottom: 8px;">🎉</div>
                                        <h3 style="font-size: 15px; font-weight: 700; color: #0f172a; margin: 0 0 4px 0;">
                                            <?php _e('La papelera está vacía', 'contacto-multidestino'); ?>
                                        </h3>
                                        <p style="color: #64748b; font-size: 12.5px; margin: 0;">
                                            <?php _e('No hay casos eliminados en este momento. Todos los casos activos se encuentran en la bandeja principal.', 'contacto-multidestino'); ?>
                                        </p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Paginación en Papelera -->
                <?php if ($total_pages > 1) : ?>
                    <div class="cm-pagination-wrap" style="display:flex; justify-content:space-between; align-items:center; margin-top:16px; padding-top:12px; border-top:1px solid #e2e8f0;">
                        <div style="font-size: 12px; color: #64748b;">
                            <?php printf(__('Página %s de %s (%s casos)', 'contacto-multidestino'), $current_page, $total_pages, $total_items); ?>
                        </div>
                        <div style="display: flex; gap: 6px;">
                            <?php for ($i = 1; $i <= $total_pages; $i++) : ?>
                                <a 
                                    href="<?php echo esc_url(add_query_arg(array('page' => 'cm-form-submissions', 'tab' => 'trash', 'paged' => $i, 's' => $search_query), admin_url('admin.php'))); ?>" 
                                    class="cm-page-btn <?php echo $i === $current_page ? 'active' : ''; ?>"
                                    style="padding: 4px 10px; border-radius: 6px; font-size: 12px; font-weight: 600; text-decoration: none; border: 1px solid #cbd5e1; background: <?php echo $i === $current_page ? '#0284c7' : '#ffffff'; ?>; color: <?php echo $i === $current_page ? '#ffffff' : '#334155'; ?>;"
                                >
                                    <?php echo $i; ?>
                                </a>
                            <?php endfor; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <!-- Tarjeta Informativa Compacta de Shortcodes -->
        <div class="cm-apple-shortcode-bar">
            <div class="cm-shortcode-icon">🔗</div>
            <div class="cm-shortcode-text">
                <strong><?php _e('Portal Público de Consulta:', 'contacto-multidestino'); ?></strong>
                <span><?php _e('Inserta el shortcode en una página para que los usuarios vean el estado y las solicitudes de su caso:', 'contacto-multidestino'); ?></span>
            </div>
            <div class="cm-shortcode-copy-group">
                <code>[seguimiento_caso]</code>
                <button type="button" class="cm-btn-copy-sm" onclick="navigator.clipboard.writeText('[seguimiento_caso]'); alert('¡Shortcode [seguimiento_caso] copiado!');">
                    📋 <?php _e('Copiar', 'contacto-multidestino'); ?>
                </button>
                <a href="https://link.mercadopago.cl/ingecodex" target="_blank" rel="noopener noreferrer" class="cm-btn-copy-sm" style="background: #009ee3; color: #ffffff; border-color: #0088c6; font-weight: 700; text-decoration: none; display: inline-flex; align-items: center; gap: 4px;" title="Apoyar el desarrollo con Mercado Pago">
                    ☕ <?php _e('Donar', 'contacto-multidestino'); ?>
                </a>
            </div>
        </div>
    </div>

    <!-- MODAL EDITAR / CREAR ÁREA -->
    <div id="cm-dept-modal-overlay" class="cm-apple-modal-overlay" style="display:none;">
        <div class="cm-apple-modal-box" style="max-width: 520px;">
            <div class="cm-apple-modal-head">
                <div class="cm-modal-head-left">
                    <span class="cm-modal-badge-app">CONFIGURACIÓN</span>
                    <strong id="cm-dept-modal-title" style="font-size:14px;"><?php _e('Área / Departamento', 'contacto-multidestino'); ?></strong>
                </div>
                <button type="button" class="cm-apple-modal-close" onclick="jQuery('#cm-dept-modal-overlay').fadeOut(100)">✕</button>
            </div>
            <div class="cm-apple-modal-body" style="padding:18px;">
                <div class="cm-form-row-compact">
                    <label><strong><?php _e('Nombre del Área / Departamento:', 'contacto-multidestino'); ?></strong></label>
                    <input type="text" id="cm-input-dept-name" class="cm-apple-input-sm" style="height:34px !important;" placeholder="Ej: Inspectoría General, Finanzas..." />
                </div>
                <div class="cm-form-row-compact" style="margin-top:12px;">
                    <label><strong><?php _e('Correos de Notificación (Separados por coma):', 'contacto-multidestino'); ?></strong></label>
                    <input type="text" id="cm-input-dept-emails" class="cm-apple-input-sm" style="height:34px !important;" placeholder="encargado@colegio.cl, direccion@colegio.cl" />
                </div>
                <div class="cm-form-row-compact" style="margin-top:12px;">
                    <label><strong><?php _e('Usuario Encargado Asignado:', 'contacto-multidestino'); ?></strong></label>
                    <select id="cm-select-dept-user" class="cm-apple-select-lg">
                        <option value="0"><?php _e('— Sin Asignar / Administrador General —', 'contacto-multidestino'); ?></option>
                        <?php foreach ($wp_users as $wu) : ?>
                            <option value="<?php echo esc_attr($wu->ID); ?>">
                                👤 <?php echo esc_html($wu->display_name . ' (' . $wu->user_login . ')'); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="cm-form-row-compact" style="margin-top:12px;">
                    <label style="display:flex; align-items:center; gap:8px; cursor:pointer;">
                        <input type="checkbox" id="cm-checkbox-dept-enabled" value="1" checked />
                        <span>🟢 <strong><?php _e('Área Habilitada para recibir formularios y derivaciones', 'contacto-multidestino'); ?></strong></span>
                    </label>
                </div>
                <div style="margin-top:16px; text-align:right;">
                    <button type="button" class="cm-btn-apple-primary" onclick="cmSaveDeptModal()">
                        💾 <?php _e('Guardar Área', 'contacto-multidestino'); ?>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL CREAR NUEVO USUARIO / ENCARGADO -->
    <div id="cm-user-modal-overlay" class="cm-apple-modal-overlay" style="display:none;">
        <div class="cm-apple-modal-box" style="max-width: 500px;">
            <div class="cm-apple-modal-head">
                <div class="cm-modal-head-left">
                    <span class="cm-modal-badge-app">SUPERADMIN</span>
                    <strong style="font-size:14px;"><?php _e('Crear Nuevo Encargado de Área', 'contacto-multidestino'); ?></strong>
                </div>
                <button type="button" class="cm-apple-modal-close" onclick="jQuery('#cm-user-modal-overlay').fadeOut(100)">✕</button>
            </div>
            <div class="cm-apple-modal-body" style="padding:18px;">
                <div style="background:#eff6ff; border:1px solid #bfdbfe; border-radius:10px; padding:10px 12px; margin-bottom:12px;">
                    <div style="font-size:11px; font-weight:700; color:#1e40af; text-transform:uppercase; margin-bottom:4px;">
                        🔗 <?php _e('URL de Acceso para el Encargado:', 'contacto-multidestino'); ?>
                    </div>
                    <div style="display:flex; align-items:center; gap:6px;">
                        <code style="font-size:11px; color:#1e293b; background:#ffffff; padding:4px 8px; border-radius:6px; flex:1; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;"><?php echo esc_url(admin_url('admin.php?page=cm-form-submissions')); ?></code>
                        <button type="button" class="cm-btn-copy-sm" onclick="navigator.clipboard.writeText('<?php echo esc_url(admin_url('admin.php?page=cm-form-submissions')); ?>'); alert('✓ ¡Enlace copiado al portapapeles!');">
                            📋 <?php _e('Copiar', 'contacto-multidestino'); ?>
                        </button>
                    </div>
                    <div style="font-size:11px; color:#3b82f6; margin-top:4px;">
                        💡 <?php _e('Al crear la cuenta, el sistema le enviará un correo automático de bienvenida con su clave y este enlace.', 'contacto-multidestino'); ?>
                    </div>
                </div>

                <div class="cm-form-row-compact">
                    <label><strong><?php _e('Perfil / Nivel de Acceso:', 'contacto-multidestino'); ?></strong></label>
                    <select id="cm-newuser-role" class="cm-apple-select-lg" onchange="cmOnNewUserRoleChange(this.value)">
                        <option value="editor">🏢 <?php _e('Encargado de Área (Acceso exclusivo a su propio departamento)', 'contacto-multidestino'); ?></option>
                        <option value="administrator">👑 <?php _e('Director / Administrador (Acceso Total a Dashboard y Todos los Casos)', 'contacto-multidestino'); ?></option>
                    </select>
                    <div id="cm-newuser-role-tip" style="font-size:11px; color:#0369a1; background:#f0f9ff; border:1px solid #e0f2fe; padding:6px 10px; border-radius:6px; margin-top:5px;">
                        🏢 <?php _e('El encargado solo podrá ver y gestionar las solicitudes de su departamento asignado.', 'contacto-multidestino'); ?>
                    </div>
                </div>

                <div class="cm-form-row-compact" style="margin-top:10px;">
                    <label><strong><?php _e('Nombre de Usuario (Login):', 'contacto-multidestino'); ?></strong></label>
                    <input type="text" id="cm-newuser-login" class="cm-apple-input-sm" style="height:32px !important;" placeholder="ej: direccion_academica" />
                </div>
                <div class="cm-form-row-compact" style="margin-top:10px;">
                    <label><strong><?php _e('Nombre y Apellido Público:', 'contacto-multidestino'); ?></strong></label>
                    <input type="text" id="cm-newuser-name" class="cm-apple-input-sm" style="height:32px !important;" placeholder="ej: Director Claudio Morales" />
                </div>
                <div class="cm-form-row-compact" style="margin-top:10px;">
                    <label><strong><?php _e('Correo Electrónico:', 'contacto-multidestino'); ?></strong></label>
                    <input type="email" id="cm-newuser-email" class="cm-apple-input-sm" style="height:32px !important;" placeholder="direccion@colegio.cl" />
                </div>
                <div class="cm-form-row-compact" style="margin-top:10px;">
                    <label><strong><?php _e('Contraseña de Acceso:', 'contacto-multidestino'); ?></strong></label>
                    <input type="password" id="cm-newuser-pass" class="cm-apple-input-sm" style="height:32px !important;" placeholder="Contraseña segura..." />
                </div>
                <div id="cm-newuser-dept-wrap" class="cm-form-row-compact" style="margin-top:10px;">
                    <label><strong><?php _e('Asignar al Área de Atención:', 'contacto-multidestino'); ?></strong></label>
                    <select id="cm-newuser-dept" class="cm-apple-select-lg">
                        <option value=""><?php _e('— Seleccionar Área —', 'contacto-multidestino'); ?></option>
                        <?php foreach ($departments as $dkey => $dinfo) : 
                            $dname = is_array($dinfo) ? ($dinfo['name'] ?? $dkey) : $dinfo;
                        ?>
                            <option value="<?php echo esc_attr($dname); ?>">🏢 <?php echo esc_html($dname); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div style="margin-top:16px; text-align:right;">
                    <button type="button" class="cm-btn-apple-primary" onclick="cmSaveNewUserModal()">
                        👤 <?php _e('Crear y Guardar Usuario', 'contacto-multidestino'); ?>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL RESTABLECER / CAMBIAR CONTRASEÑA DE USUARIO -->
    <div id="cm-resetpass-modal-overlay" class="cm-apple-modal-overlay" style="display:none;">
        <div class="cm-apple-modal-box" style="max-width: 460px;">
            <div class="cm-apple-modal-head">
                <div class="cm-modal-head-left">
                    <span class="cm-modal-badge-app" style="background:#eff6ff; color:#0071e3; border:1px solid #bfdbfe;">SEGURIDAD</span>
                    <strong style="font-size:14px;"><?php _e('Cambiar / Restablecer Clave', 'contacto-multidestino'); ?></strong>
                </div>
                <button type="button" class="cm-apple-modal-close" onclick="jQuery('#cm-resetpass-modal-overlay').fadeOut(100)">✕</button>
            </div>
            <div class="cm-apple-modal-body" style="padding:18px;">
                <input type="hidden" id="cm-resetpass-userid" value="" />
                
                <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:10px 14px; margin-bottom:14px; display:flex; align-items:center; gap:8px;">
                    <span style="font-size:18px;">👤</span>
                    <div>
                        <div style="font-size:11px; font-weight:700; color:#64748b; text-transform:uppercase;"><?php _e('Usuario a Modificar:', 'contacto-multidestino'); ?></div>
                        <strong id="cm-resetpass-username" style="font-size:14px; color:#0f172a;">—</strong>
                    </div>
                </div>

                <div class="cm-form-row-compact">
                    <label><strong><?php _e('Nueva Contraseña:', 'contacto-multidestino'); ?></strong></label>
                    <div style="display:flex; gap:6px; margin-top:4px;">
                        <input type="text" id="cm-resetpass-new" class="cm-apple-input-sm" style="height:34px !important; flex:1; font-family:monospace; font-size:13.5px;" placeholder="Escribe la nueva contraseña..." />
                        <button type="button" class="cm-btn-view" style="font-size:11.5px; padding:0 10px; height:34px;" onclick="cmGenerateRandomPass()" title="Generar una contraseña aleatoria segura">
                            🎲 <?php _e('Generar', 'contacto-multidestino'); ?>
                        </button>
                    </div>
                    <small style="color:#64748b; font-size:11px; margin-top:4px; display:block;">
                        <?php _e('Mínimo 6 caracteres. El usuario podrá iniciar sesión inmediatamente con esta clave.', 'contacto-multidestino'); ?>
                    </small>
                </div>

                <div style="margin-top:18px; text-align:right; display:flex; justify-content:flex-end; gap:8px;">
                    <button type="button" class="cm-apple-btn-secondary" onclick="jQuery('#cm-resetpass-modal-overlay').fadeOut(100)">
                        <?php _e('Cancelar', 'contacto-multidestino'); ?>
                    </button>
                    <button type="button" class="cm-btn-apple-primary" id="cm-btn-submit-resetpass" onclick="cmSubmitResetPasswordModal()">
                        💾 <?php _e('Guardar Nueva Clave', 'contacto-multidestino'); ?>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL ACTIVAR AUTENTICACIÓN DE DOS FACTORES (2FA) -->
    <div id="cm-2fa-setup-modal-overlay" class="cm-apple-modal-overlay" style="display:none;">
        <div class="cm-apple-modal-box" style="max-width: 480px;">
            <div class="cm-apple-modal-head">
                <div class="cm-modal-head-left">
                    <span class="cm-modal-badge-app" style="background:#eff6ff; color:#0284c7; border:1px solid #bae6fd;">SEGURIDAD 2FA</span>
                    <strong style="font-size:14px;"><?php _e('Activar Autenticación 2FA', 'contacto-multidestino'); ?></strong>
                </div>
                <button type="button" class="cm-apple-modal-close" onclick="cmClose2FAModal()">✕</button>
            </div>
            <div class="cm-apple-modal-body" style="padding:18px;">
                <p style="font-size:12.5px; color:#475569; margin:0 0 14px 0; line-height:1.4;">
                    <?php _e('Escanea este código QR con tu aplicación móvil preferida (<strong>Google Authenticator</strong>, <strong>Microsoft Authenticator</strong> o <strong>Apple Passwords</strong>):', 'contacto-multidestino'); ?>
                </p>

                <div style="text-align:center; margin-bottom:14px;">
                    <div style="display:inline-block; padding:8px; background:#ffffff; border:1.5px solid #e2e8f0; border-radius:12px; box-shadow:0 2px 8px rgba(0,0,0,0.06);">
                        <img id="cm-2fa-qr-img" src="" alt="QR 2FA" style="width:180px; height:180px; display:block; margin:0 auto;" />
                    </div>
                </div>

                <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:8px 12px; margin-bottom:14px;">
                    <label style="font-size:10.5px; font-weight:700; color:#64748b; text-transform:uppercase; display:block; margin-bottom:2px;">
                        🔑 <?php _e('Clave de Configuración Manual:', 'contacto-multidestino'); ?>
                    </label>
                    <div style="display:flex; align-items:center; justify-content:space-between; gap:8px;">
                        <code id="cm-2fa-secret-text" style="font-size:13px; font-weight:800; color:#0f172a; letter-spacing:1.5px;">—</code>
                        <button type="button" class="cm-btn-view" style="font-size:11px; padding:2px 8px; height:24px;" onclick="cmCopy2FASecret()">
                            📋 <?php _e('Copiar', 'contacto-multidestino'); ?>
                        </button>
                    </div>
                </div>

                <div class="cm-form-row-compact">
                    <label><strong><?php _e('Ingresa el código de 6 dígitos que muestra tu app:', 'contacto-multidestino'); ?></strong></label>
                    <input 
                        type="text" 
                        id="cm-2fa-code-input" 
                        class="cm-apple-input-sm" 
                        maxlength="6" 
                        placeholder="123456" 
                        inputmode="numeric" 
                        pattern="[0-9]*" 
                        style="font-family:monospace; font-size:20px; letter-spacing:6px; text-align:center; font-weight:800; height:44px !important; width:100%; box-sizing:border-box; margin-top:4px;" 
                    />
                </div>

                <div style="margin-top:16px; text-align:right; display:flex; justify-content:flex-end; gap:8px;">
                    <button type="button" class="cm-apple-btn-secondary" onclick="cmClose2FAModal()">
                        <?php _e('Cancelar', 'contacto-multidestino'); ?>
                    </button>
                    <button type="button" class="cm-apple-btn-primary" id="cm-btn-submit-2fa" style="background:#0284c7; border-color:#0369a1; font-weight:700;" onclick="cmVerifyAndEnable2FA()">
                        ✓ <?php _e('Confirmar y Activar 2FA', 'contacto-multidestino'); ?>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL SUPERADMIN: GESTIÓN DE SEGURIDAD 2FA DE USUARIOS -->
    <div id="cm-admin-manage-2fa-modal-overlay" class="cm-apple-modal-overlay" style="display:none;">
        <div class="cm-apple-modal-box" style="max-width: 480px;">
            <div class="cm-apple-modal-head">
                <div class="cm-modal-head-left">
                    <span class="cm-modal-badge-app" style="background:#eff6ff; color:#0284c7; border:1px solid #bae6fd;">SEGURIDAD 2FA</span>
                    <strong style="font-size:14px;"><?php _e('Control de Seguridad 2FA', 'contacto-multidestino'); ?></strong>
                </div>
                <button type="button" class="cm-apple-modal-close" onclick="cmCloseAdminUser2FAModal()">✕</button>
            </div>
            <div class="cm-apple-modal-body" style="padding:18px;">
                <input type="hidden" id="cm-m2fa-userid" value="" />
                <input type="hidden" id="cm-m2fa-userlogin" value="" />

                <!-- Datos de la Cuenta -->
                <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:12px 14px; margin-bottom:14px; display:flex; align-items:center; gap:10px;">
                    <div style="font-size:24px; background:#ffffff; width:40px; height:40px; border-radius:8px; display:flex; align-items:center; justify-content:center; box-shadow:0 1px 3px rgba(0,0,0,0.06);">
                        👤
                    </div>
                    <div>
                        <div style="font-size:11px; font-weight:700; color:#64748b; text-transform:uppercase;"><?php _e('Usuario Seleccionado:', 'contacto-multidestino'); ?></div>
                        <div style="font-size:14px; font-weight:700; color:#0f172a;">
                            <code id="cm-m2fa-username">—</code> <span id="cm-m2fa-displayname" style="font-size:12px; color:#64748b; font-weight:normal;"></span>
                        </div>
                    </div>
                </div>

                <!-- Estado del 2FA -->
                <div id="cm-m2fa-status-box" style="border-radius:10px; padding:14px; margin-bottom:16px;">
                    <!-- Rellenado dinámicamente con JS -->
                </div>

                <!-- Opciones de Gestión -->
                <div id="cm-m2fa-actions-wrap" style="display:flex; flex-direction:column; gap:10px;">
                    <!-- Botón para desplegar Generación y Asignación de 2FA -->
                    <button 
                        type="button" 
                        class="cm-apple-btn-primary" 
                        id="cm-btn-show-generate-2fa"
                        style="background:#0284c7; border-color:#0369a1; font-weight:700; height:38px; display:flex; align-items:center; justify-content:center; gap:6px; cursor:pointer;"
                        onclick="cmAdminToggleGenerateUser2FA()"
                    >
                        📲 <?php _e('Asignar / Generar Nueva Clave y QR', 'contacto-multidestino'); ?>
                    </button>

                    <!-- Panel con QR y Clave para el Usuario Seleccionado (inicialmente oculto) -->
                    <div id="cm-m2fa-generate-panel" style="display:none; background:#f8fafc; border:1.5px solid #bae6fd; border-radius:10px; padding:14px; margin-top:4px;">
                        <div style="font-size:12px; color:#0369a1; font-weight:700; margin-bottom:10px;">
                            📲 <?php _e('Escanea este QR con la app del usuario (Google Authenticator / Apple):', 'contacto-multidestino'); ?>
                        </div>

                        <div style="text-align:center; margin-bottom:12px;">
                            <div style="display:inline-block; padding:6px; background:#ffffff; border:1px solid #e2e8f0; border-radius:10px; box-shadow:0 2px 6px rgba(0,0,0,0.05);">
                                <img id="cm-m2fa-qr-img" src="" alt="QR 2FA" style="width:160px; height:160px; display:block; margin:0 auto;" />
                            </div>
                        </div>

                        <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:8px; padding:8px 10px; margin-bottom:12px;">
                            <label style="font-size:10px; font-weight:700; color:#64748b; text-transform:uppercase; display:block; margin-bottom:2px;">
                                🔑 <?php _e('Clave de Configuración Manual:', 'contacto-multidestino'); ?>
                            </label>
                            <div style="display:flex; align-items:center; justify-content:space-between; gap:6px;">
                                <code id="cm-m2fa-secret-text" style="font-size:12.5px; font-weight:800; color:#0f172a; letter-spacing:1px;">—</code>
                                <button type="button" class="cm-btn-view" style="font-size:10.5px; padding:2px 7px; height:24px;" onclick="cmCopyAdminGenerated2FASecret()">
                                    📋 <?php _e('Copiar', 'contacto-multidestino'); ?>
                                </button>
                            </div>
                        </div>

                        <div class="cm-form-row-compact">
                            <label style="font-size:11.5px;"><strong><?php _e('Código de 6 dígitos de prueba (Opcional):', 'contacto-multidestino'); ?></strong></label>
                            <input 
                                type="text" 
                                id="cm-m2fa-verify-code-input" 
                                class="cm-apple-input-sm" 
                                maxlength="6" 
                                placeholder="123456" 
                                inputmode="numeric" 
                                pattern="[0-9]*" 
                                style="font-family:monospace; font-size:16px; letter-spacing:4px; text-align:center; font-weight:800; height:36px !important; width:100%; box-sizing:border-box; margin-top:3px;" 
                            />
                        </div>

                        <div style="margin-top:12px; display:flex; justify-content:flex-end; gap:6px;">
                            <button 
                                type="button" 
                                class="cm-apple-btn-primary" 
                                id="cm-btn-confirm-assign-2fa"
                                style="background:#059669; border-color:#047857; font-weight:700; height:34px; font-size:12px; width:100%;"
                                onclick="cmAdminConfirmAssignUser2FA()"
                            >
                                ✓ <?php _e('Activar y Asignar este 2FA al Usuario', 'contacto-multidestino'); ?>
                            </button>
                        </div>
                    </div>

                    <div id="cm-m2fa-active-actions" style="display:flex; flex-direction:column; gap:10px;">
                        <button 
                            type="button" 
                            class="cm-apple-btn-secondary" 
                            style="background:#fff1f2; border:1px solid #fecdd3; color:#e11d48 !important; font-weight:700; height:38px; display:flex; align-items:center; justify-content:center; gap:6px; cursor:pointer;"
                            onclick="cmAdminModalDisable2FA()"
                        >
                            🔓 <?php _e('Quitar 2FA a este Usuario', 'contacto-multidestino'); ?>
                        </button>
                        <button 
                            type="button" 
                            class="cm-apple-btn-secondary" 
                            style="background:#f0f9ff; border:1px solid #bae6fd; color:#0284c7 !important; font-weight:700; height:38px; display:flex; align-items:center; justify-content:center; gap:6px; cursor:pointer;"
                            onclick="cmAdminModalReset2FA()"
                        >
                            🔄 <?php _e('Restablecer 2FA (Re-vincular App)', 'contacto-multidestino'); ?>
                        </button>
                    </div>
                </div>

                <div style="margin-top:18px; text-align:right; border-top:1px solid #e2e8f0; padding-top:12px;">
                    <button type="button" class="cm-apple-btn-secondary" onclick="cmCloseAdminUser2FAModal()">
                        <?php _e('Cerrar', 'contacto-multidestino'); ?>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL APPLE PRO DE DETALLE Y GESTIÓN DEL CASO -->
    <div id="cm-case-modal-overlay" class="cm-apple-modal-overlay" style="display:none;">
        <div class="cm-apple-modal-box">
            <div class="cm-apple-modal-head">
                <div class="cm-modal-head-left">
                    <span class="cm-modal-badge-app">EXPEDIENTE</span>
                    <span id="cm-modal-ticket-title" class="cm-modal-ticket-code">CL000000</span>
                    <a id="cm-modal-public-link" href="#" target="_blank" class="cm-portal-link-btn" style="display:none; font-size:11px; font-weight:700; color:#0284c7; background:#e0f2fe; border:1px solid #bae6fd; border-radius:6px; padding:3px 9px; text-decoration:none; align-items:center; gap:4px; margin-left:6px;" title="<?php esc_attr_e('Abrir página pública donde el solicitante ve su caso', 'contacto-multidestino'); ?>">
                        🌐 <?php _e('Ir al Caso en la Web', 'contacto-multidestino'); ?> ↗
                    </a>
                </div>
                <div style="display:flex; align-items:center; gap:8px;">
                    <a id="cm-modal-fullpage-link" href="#" class="cm-apple-btn-secondary" style="display:none; font-size:12px; font-weight:700; align-items:center; gap:5px; padding:5px 12px; background:#f8fafc; border-color:#cbd5e1; text-decoration:none;" title="<?php esc_attr_e('Abrir este caso en página completa', 'contacto-multidestino'); ?>">
                        🖥️ <?php _e('Página Completa', 'contacto-multidestino'); ?>
                    </a>
                    <button type="button" class="cm-apple-btn-secondary" id="cm-btn-modal-print" onclick="cmOpenPrintPreview()" style="font-size:12px; font-weight:700; display:inline-flex; align-items:center; gap:5px; padding:5px 12px; background:#f8fafc; border-color:#cbd5e1;" title="<?php esc_attr_e('Vista Previa e Impresión Oficial en Tamaño Carta', 'contacto-multidestino'); ?>">
                        🖨️ <?php _e('Imprimir Informe (Carta)', 'contacto-multidestino'); ?>
                    </button>
                    <button type="button" class="cm-apple-modal-close" onclick="cmCloseCaseModal()">✕</button>
                </div>
            </div>
            <div class="cm-apple-modal-body" id="cm-modal-body-content">
                <div class="cm-modal-loading">
                    <span class="spinner is-active"></span>
                    <p><?php _e('Cargando expediente...', 'contacto-multidestino'); ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL LIGHTBOX DE VISUALIZACIÓN DE DOCUMENTOS/IMÁGENES -->
    <div id="cm-lightbox-modal" class="cm-lightbox-overlay" style="display:none;" onclick="cmCloseDocumentPreview(event)">
        <div class="cm-lightbox-box" onclick="event.stopPropagation();">
            <div class="cm-lightbox-head">
                <span id="cm-lightbox-filename" class="cm-lightbox-title">Documento</span>
                <div class="cm-lightbox-actions">
                    <a id="cm-lightbox-download" href="#" target="_blank" class="cm-apple-btn-secondary" style="font-size:12px; font-weight:700;">
                        ⬇️ <?php _e('Descargar Original', 'contacto-multidestino'); ?>
                    </a>
                    <button type="button" class="cm-apple-modal-close" onclick="cmCloseDocumentPreview()">✕</button>
                </div>
            </div>
            <div class="cm-lightbox-body" id="cm-lightbox-content"></div>
        </div>
    </div>

    <!-- Scripts AJAX Apple Pro -->
    <script>
    var cmCurrentCasePrintHtml = '';

    function cmOpenCaseModal(submissionId) {
        var $overlay = jQuery('#cm-case-modal-overlay');
        var $body    = jQuery('#cm-modal-body-content');
        
        $overlay.fadeIn(120).css('display', 'flex');
        $body.html('<div class="cm-modal-loading"><span class="spinner is-active"></span><p>Cargando información del caso...</p></div>');
        jQuery('#cm-modal-public-link').hide();
        jQuery('#cm-modal-fullpage-link').attr('href', '<?php echo admin_url("admin.php?page=cm-form-submissions&case_id="); ?>' + submissionId).css('display', 'inline-flex');
        
        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_get_case_detail',
                id: submissionId,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                if (res.success) {
                    $body.html(res.data.html);
                    if (res.data.ticket_code) {
                        jQuery('#cm-modal-ticket-title').text(res.data.ticket_code);
                    }
                    if (res.data.tracker_url) {
                        jQuery('#cm-modal-public-link').attr('href', res.data.tracker_url).css('display', 'inline-flex');
                    }
                    if (res.data.print_html) {
                        cmCurrentCasePrintHtml = res.data.print_html;
                    }
                } else {
                    $body.html('<div class="cm-modal-error">' + (res.data.message || 'Error al cargar el caso.') + '</div>');
                }
            },
            error: function() {
                $body.html('<div class="cm-modal-error">Error de conexión con el servidor.</div>');
            }
        });
    }

    window.cmOpenPrintPreview = function() {
        if (!cmCurrentCasePrintHtml) {
            alert('Cargando datos del expediente para imprimir...');
            return;
        }
        
        var ticketCode = jQuery('#cm-modal-ticket-title').text() || 'EXPEDIENTE';
        var printWindow = window.open('', '_blank');
        if (!printWindow) {
            alert('Por favor habilita las ventanas emergentes en tu navegador para abrir el expediente en una página aparte.');
            return;
        }

        var doc = printWindow.document;
        doc.open();
        doc.write('<!DOCTYPE html>' +
            '<html lang="es"><head>' +
            '<meta charset="UTF-8">' +
            '<meta name="viewport" content="width=device-width, initial-scale=1.0">' +
            '<title>Expediente Oficial - ' + ticketCode + '</title>' +
            '<style>' +
            '@page { size: letter portrait; margin: 12mm 15mm; }' +
            '* { box-sizing: border-box; }' +
            'body { margin: 0; padding: 0; background: #525659; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; color: #111827; }' +
            '.cm-print-topbar { position: sticky; top: 0; z-index: 9999; background: #ffffff; padding: 12px 24px; display: flex; align-items: center; justify-content: space-between; box-shadow: 0 2px 10px rgba(0,0,0,0.18); border-bottom: 1px solid #e2e8f0; }' +
            '.cm-print-action-btn { background: #0071e3; color: #ffffff; border: none; border-radius: 8px; padding: 9px 22px; font-size: 14px; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 6px; box-shadow: 0 2px 8px rgba(0,113,227,0.35); transition: background 0.15s ease; }' +
            '.cm-print-action-btn:hover { background: #0077ed; }' +
            '.cm-print-close-btn { background: #f1f5f9; color: #475569; border: 1px solid #cbd5e1; border-radius: 8px; padding: 8px 16px; font-size: 13px; font-weight: 600; cursor: pointer; }' +
            '.cm-print-close-btn:hover { background: #e2e8f0; }' +
            '.cm-dossier-wrap { display: flex; justify-content: center; padding: 28px 16px 60px; }' +
            '.cm-dossier-sheet { width: 100%; max-width: 816px; background: #ffffff; padding: 48px 56px; box-shadow: 0 12px 36px rgba(0,0,0,0.3); border-radius: 4px; min-height: 1056px; }' +
            'table { width: 100%; border-collapse: collapse; }' +
            '@media print {' +
            '  body { background: #ffffff !important; padding: 0 !important; }' +
            '  .cm-print-topbar { display: none !important; }' +
            '  .cm-dossier-wrap { padding: 0 !important; display: block !important; }' +
            '  .cm-dossier-sheet { box-shadow: none !important; padding: 0 !important; border-radius: 0 !important; max-width: 100% !important; min-height: auto !important; }' +
            '}' +
            '</style>' +
            '</head><body>' +
            '<div class="cm-print-topbar">' +
            '  <div style="display:flex; align-items:center; gap:8px;">' +
            '    <span style="font-size:14.5px; font-weight:700; color:#1e293b;">📄 Expediente Oficial • Formato Carta (8.5" x 11")</span>' +
            '    <span style="font-size:11px; background:#e2e8f0; color:#475569; padding:2px 8px; border-radius:10px; font-weight:700;">' + ticketCode + '</span>' +
            '  </div>' +
            '  <div style="display:flex; align-items:center; gap:10px;">' +
            '    <button class="cm-print-action-btn" onclick="window.print()">🖨️ Imprimir Caso Ahora</button>' +
            '    <button class="cm-print-close-btn" onclick="window.close()">✕ Cerrar Pestaña</button>' +
            '  </div>' +
            '</div>' +
            '<div class="cm-dossier-wrap">' +
            '  <div class="cm-dossier-sheet">' +
            cmCurrentCasePrintHtml +
            '  </div>' +
            '</div>' +
            '</body></html>'
        );
        doc.close();
    };

    window.cmOpenDocumentPreview = function(fileUrl, fileName, isImage) {
        if (isImage) {
            jQuery('#cm-lightbox-filename').text(fileName);
            jQuery('#cm-lightbox-download').attr('href', fileUrl);
            jQuery('#cm-lightbox-content').html('<img src="' + fileUrl + '" class="cm-lightbox-img" alt="' + fileName + '" />');
            jQuery('#cm-lightbox-modal').fadeIn(150).css('display', 'flex');
        } else {
            window.open(fileUrl, '_blank');
        }
    };

    window.cmCloseDocumentPreview = function(e) {
        jQuery('#cm-lightbox-modal').fadeOut(120);
    };

    function cmCloseCaseModal() {
        jQuery('#cm-case-modal-overlay').fadeOut(100);
    }

    function cmSwitchModalTab(tabId) {
        jQuery('.cm-tab-pane').hide();
        jQuery('.cm-modal-tab-btn').removeClass('active');
        jQuery('#cm-pane-' + tabId).fadeIn(120);
        jQuery('#cm-tab-btn-' + tabId).addClass('active');
    }

    function cmToggleDocRequestTitle(chk) {
        if (chk.checked) {
            jQuery('#cm-wrap-doc-title').slideDown(120);
            jQuery('#cm-select-new-status').val('pendiente_usuario');
            if (!jQuery('#cm-input-doc-title').val()) {
                jQuery('#cm-input-doc-title').val('Adjuntar documentación solicitada para dar curso al requerimiento');
            }
        } else {
            jQuery('#cm-wrap-doc-title').slideUp(120);
        }
    }

    function cmApplyQuickResponse(text, statusKey, isDocReq) {
        jQuery('#cm-update-note').val(text).focus();
        if (statusKey) {
            jQuery('#cm-select-new-status').val(statusKey);
        }
        if (isDocReq) {
            jQuery('#cm-check-req-doc').prop('checked', true);
            jQuery('#cm-wrap-doc-title').slideDown(120);
            if (!jQuery('#cm-input-doc-title').val()) {
                jQuery('#cm-input-doc-title').val('Adjuntar documentación solicitada para dar curso al requerimiento');
            }
        }
    }

    function cmSaveCaseUpdate(submissionId) {
        var $btn       = jQuery('#cm-btn-save-update');
        var newStatus  = jQuery('#cm-select-new-status').val();
        var note       = jQuery('#cm-update-note').val().trim();
        var notifyUser = jQuery('#cm-checkbox-notify-user').is(':checked') ? 1 : 0;
        var authorName = jQuery('#cm-input-author-name').val() || 'Área Responsable';
        var fileInput  = document.getElementById('cm-admin-attach-file');
        var reqDoc     = jQuery('#cm-check-req-doc').is(':checked') ? 1 : 0;
        var docTitle   = jQuery('#cm-input-doc-title').val().trim();
        var reqPres    = jQuery('#cm-check-req-presence').is(':checked') ? 1 : 0;

        if (!note && !newStatus && (!fileInput || !fileInput.files.length) && !reqDoc) {
            alert('Por favor selecciona un estado o ingresa una nota/requerimiento.');
            return;
        }

        var formData = new FormData();
        formData.append('action', 'cm_admin_update_case');
        formData.append('id', submissionId);
        formData.append('status', newStatus);
        formData.append('note', note);
        formData.append('notify_user', notifyUser);
        formData.append('author_name', authorName);
        formData.append('req_doc', reqDoc);
        formData.append('doc_title', docTitle);
        formData.append('req_presence', reqPres);
        formData.append('nonce', '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>');

        if (fileInput && fileInput.files && fileInput.files[0]) {
            if (fileInput.files[0].size > 4 * 1024 * 1024) {
                alert('El archivo adjunto supera los 4 Megabytes.');
                return;
            }
            formData.append('admin_attachment', fileInput.files[0]);
        }

        $btn.prop('disabled', true).text('Guardando...');

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            success: function(res) {
                $btn.prop('disabled', false).text('💾 Guardar y Actualizar Estado');
                if (res.success) {
                    cmOpenCaseModal(submissionId);
                    if (res.data.status_label) {
                        var $pill = jQuery('#cm-status-pill-' + submissionId);
                        $pill.css({
                            'background-color': res.data.status_bg,
                            'color': res.data.status_color
                        }).html(res.data.status_icon + ' ' + res.data.status_label);
                    }
                } else {
                    alert(res.data.message || 'Error al actualizar el caso.');
                }
            },
            error: function() {
                $btn.prop('disabled', false).text('💾 Guardar y Actualizar Estado');
                alert('Error de conexión al guardar.');
            }
        });
    }

    function cmReassignCase(submissionId) {
        var $btn          = jQuery('#cm-btn-reassign-area');
        var targetDept    = jQuery('#cm-select-target-dept').val();
        var reason        = jQuery('#cm-reassign-reason').val().trim();
        var notifyNewArea = jQuery('#cm-checkbox-notify-area').is(':checked') ? 1 : 0;
        var notifyUser    = jQuery('#cm-checkbox-notify-user-transfer').is(':checked') ? 1 : 0;
        var authorName    = jQuery('#cm-reassign-author').val() || 'Área Responsable';

        if (!targetDept) {
            alert('Por favor selecciona el área o departamento de destino.');
            return;
        }

        $btn.prop('disabled', true).text('Derivando...');

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_reassign_case',
                id: submissionId,
                target_department: targetDept,
                reason: reason,
                notify_new_area: notifyNewArea,
                notify_user: notifyUser,
                author_name: authorName,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                $btn.prop('disabled', false).text('🔄 Derivar Caso a Esta Área');
                if (res.success) {
                    alert('✓ ' + res.data.message);
                    cmOpenCaseModal(submissionId);
                    jQuery('#cm-row-dept-' + submissionId).html('🏢 ' + res.data.new_department);
                } else {
                    alert(res.data.message || 'Error al derivar el caso.');
                }
            },
            error: function() {
                $btn.prop('disabled', false).text('🔄 Derivar Caso a Esta Área');
                alert('Error de conexión al derivar el caso.');
            }
        });
    }

    function cmDeleteCase(submissionId) {
        if (!confirm('¿Mover este caso a la papelera? (Podrá ser recuperado en cualquier momento por el Administrador)')) return;

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_delete_case',
                id: submissionId,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                if (res.success) {
                    jQuery('#cm-row-' + submissionId).fadeOut(150, function() {
                        jQuery(this).remove();
                    });
                } else {
                    alert(res.data.message || 'Error al enviar el caso a la papelera.');
                }
            },
            error: function() {
                alert('Error de conexión al eliminar el caso.');
            }
        });
    }

    function cmRestoreCase(submissionId) {
        if (!confirm('¿Confirmas que deseas restaurar este caso y reincorporarlo a la bandeja de casos activos?')) return;

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_restore_case',
                id: submissionId,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                if (res.success) {
                    alert('✓ ' + (res.data.message || 'Caso recuperado y restaurado exitosamente.'));
                    jQuery('#cm-trash-row-' + submissionId).fadeOut(150, function() {
                        jQuery(this).remove();
                    });
                } else {
                    alert(res.data.message || 'Error al restaurar el caso.');
                }
            },
            error: function() {
                alert('Error de conexión al restaurar el caso.');
            }
        });
    }

    // Modal de Departamentos
    function cmOpenNewDeptModal() {
        jQuery('#cm-dept-modal-title').text('Nueva Área de Atención');
        jQuery('#cm-input-dept-name').val('').prop('readonly', false);
        jQuery('#cm-input-dept-emails').val('');
        jQuery('#cm-select-dept-user').val('0');
        jQuery('#cm-checkbox-dept-enabled').prop('checked', true);
        jQuery('#cm-dept-modal-overlay').fadeIn(120).css('display', 'flex');
    }

    function cmOpenEditDeptModal(name, emails, userId, enabled) {
        jQuery('#cm-dept-modal-title').text('Editar: ' + name);
        jQuery('#cm-input-dept-name').val(name);
        jQuery('#cm-input-dept-emails').val(emails);
        jQuery('#cm-select-dept-user').val(userId || '0');
        jQuery('#cm-checkbox-dept-enabled').prop('checked', enabled == 1);
        jQuery('#cm-dept-modal-overlay').fadeIn(120).css('display', 'flex');
    }

    function cmSaveDeptModal() {
        var name    = jQuery('#cm-input-dept-name').val().trim();
        var emails  = jQuery('#cm-input-dept-emails').val().trim();
        var userId  = jQuery('#cm-select-dept-user').val();
        var enabled = jQuery('#cm-checkbox-dept-enabled').is(':checked') ? 1 : 0;

        if (!name) {
            alert('El nombre del área es obligatorio.');
            return;
        }

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_save_dept',
                name: name,
                emails: emails,
                user_id: userId,
                enabled: enabled,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                if (res.success) {
                    location.reload();
                } else {
                    alert(res.data.message || 'Error al guardar el área.');
                }
            }
        });
    }

    function cmToggleDeptStatus(name) {
        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_toggle_dept',
                name: name,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                if (res.success) {
                    location.reload();
                } else {
                    alert(res.data.message || 'Error al cambiar estado.');
                }
            }
        });
    }

    function cmDeleteDept(name) {
        if (!confirm('¿Eliminar el área "' + name + '" del registro?')) return;

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_delete_dept',
                name: name,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                if (res.success) {
                    location.reload();
                } else {
                    alert(res.data.message || 'Error al eliminar área.');
                }
            }
        });
    }

    // Modal de Crear Nuevo Usuario
    function cmOpenNewUserModal() {
        jQuery('#cm-newuser-login').val('');
        jQuery('#cm-newuser-name').val('');
        jQuery('#cm-newuser-email').val('');
        jQuery('#cm-newuser-pass').val('');
        jQuery('#cm-newuser-dept').val('');
        jQuery('#cm-newuser-role').val('editor');
        cmOnNewUserRoleChange('editor');
        jQuery('#cm-user-modal-overlay').fadeIn(120).css('display', 'flex');
    }

    function cmOnNewUserRoleChange(role) {
        if (role === 'administrator') {
            jQuery('#cm-newuser-role-tip').html('👑 <strong>Perfil Director / Administrador:</strong> Tendrá acceso global al <strong>Dashboard en Vivo</strong>, al <strong>Tablero Kanban</strong> y a todos los casos de todas las áreas.').css({'background':'#fffbeb', 'border-color':'#fde68a', 'color':'#92400e'});
            jQuery('#cm-newuser-dept-wrap').slideUp(150);
        } else {
            jQuery('#cm-newuser-role-tip').html('🏢 <strong>Perfil Encargado de Área:</strong> Solo podrá ver y gestionar las solicitudes dirigidas a su departamento asignado.').css({'background':'#f0f9ff', 'border-color':'#e0f2fe', 'color':'#0369a1'});
            jQuery('#cm-newuser-dept-wrap').slideDown(150);
        }
    }

    function cmSaveNewUserModal() {
        var login = jQuery('#cm-newuser-login').val().trim();
        var name  = jQuery('#cm-newuser-name').val().trim();
        var email = jQuery('#cm-newuser-email').val().trim();
        var pass  = jQuery('#cm-newuser-pass').val();
        var role  = jQuery('#cm-newuser-role').val();
        var dept  = jQuery('#cm-newuser-dept').val();

        if (!login || !email || !pass) {
            alert('Por favor ingresa usuario, email y contraseña.');
            return;
        }

        if (role === 'editor' && !dept) {
            if (!confirm('No seleccionaste ningún área para este encargado. ¿Deseas crearlo igualmente?')) {
                return;
            }
        }

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_create_area_user',
                login: login,
                name: name,
                email: email,
                pass: pass,
                role: role,
                department: dept,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                if (res.success) {
                    alert('✓ Usuario creado exitosamente con el perfil asignado.');
                    location.reload();
                } else {
                    alert(res.data.message || 'Error al crear el usuario.');
                }
            }
        });
    }

    function cmToggleUserSuspension(userId) {
        if (!confirm('¿Deseas cambiar el estado de acceso de este usuario?')) return;

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_toggle_user_suspension',
                user_id: userId,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                if (res.success) {
                    location.reload();
                } else {
                    alert(res.data.message || 'Error al modificar estado del usuario.');
                }
            }
        });
    }

    function cmOpenResetPasswordModal(userId, userName) {
        jQuery('#cm-resetpass-userid').val(userId);
        jQuery('#cm-resetpass-username').text(userName);
        jQuery('#cm-resetpass-new').val('');
        jQuery('#cm-resetpass-modal-overlay').fadeIn(150);
        setTimeout(function() { jQuery('#cm-resetpass-new').focus(); }, 200);
    }

    function cmGenerateRandomPass() {
        var chars = 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789!@#$%&*';
        var pass = '';
        for (var i = 0; i < 12; i++) {
            pass += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        jQuery('#cm-resetpass-new').val(pass);
    }

    function cmSubmitResetPasswordModal() {
        var userId = jQuery('#cm-resetpass-userid').val();
        var newPass = jQuery('#cm-resetpass-new').val().trim();

        if (!userId) {
            alert('Usuario no válido.');
            return;
        }

        if (!newPass || newPass.length < 6) {
            alert('La nueva contraseña debe tener al menos 6 caracteres.');
            jQuery('#cm-resetpass-new').focus();
            return;
        }

        var btn = jQuery('#cm-btn-submit-resetpass');
        btn.prop('disabled', true).text('Guardando...');

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_reset_user_password',
                user_id: userId,
                new_password: newPass,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                btn.prop('disabled', false).text('💾 Guardar Nueva Clave');
                if (res.success) {
                    alert('✓ ' + (res.data.message || 'Contraseña actualizada exitosamente.'));
                    jQuery('#cm-resetpass-modal-overlay').fadeOut(100);
                } else {
                    alert(res.data.message || 'Error al actualizar contraseña.');
                }
            },
            error: function() {
                btn.prop('disabled', false).text('💾 Guardar Nueva Clave');
                alert('Error de conexión.');
            }
        });
    }

    // ═════════════════════════════════════════════════════════════════
    // FUNCIONES JAVASCRIPT DE AUTENTICACIÓN DE DOS FACTORES (2FA)
    // ═════════════════════════════════════════════════════════════════

    var cmCurrent2FASecret = '';

    function cmOpen2FASetupModal() {
        jQuery('#cm-2fa-code-input').val('');
        jQuery('#cm-2fa-secret-text').text('Cargando...');
        jQuery('#cm-2fa-qr-img').attr('src', '');
        jQuery('#cm-btn-submit-2fa').prop('disabled', true).text('Cargando...');
        jQuery('#cm-2fa-setup-modal-overlay').fadeIn(120).css('display', 'flex');

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_2fa_setup_init',
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                jQuery('#cm-btn-submit-2fa').prop('disabled', false).text('✓ Confirmar y Activar 2FA');
                if (res.success && res.data) {
                    cmCurrent2FASecret = res.data.secret;
                    jQuery('#cm-2fa-secret-text').text(res.data.secret);
                    jQuery('#cm-2fa-qr-img').attr('src', res.data.qr_url);
                    setTimeout(function() {
                        jQuery('#cm-2fa-code-input').focus();
                    }, 200);
                } else {
                    alert(res.data.message || 'Error al inicializar 2FA.');
                    cmClose2FAModal();
                }
            },
            error: function() {
                alert('Error de conexión al generar clave 2FA.');
                cmClose2FAModal();
            }
        });
    }

    function cmClose2FAModal() {
        jQuery('#cm-2fa-setup-modal-overlay').fadeOut(100);
    }

    function cmCopy2FASecret() {
        if (!cmCurrent2FASecret) return;
        navigator.clipboard.writeText(cmCurrent2FASecret);
        alert('✓ Clave secreta copiada al portapapeles: ' + cmCurrent2FASecret);
    }

    function cmVerifyAndEnable2FA() {
        var code = jQuery('#cm-2fa-code-input').val().trim();
        if (!code || code.length !== 6) {
            alert('Por favor ingresa el código de 6 dígitos de tu app.');
            jQuery('#cm-2fa-code-input').focus();
            return;
        }

        var btn = jQuery('#cm-btn-submit-2fa');
        btn.prop('disabled', true).text('Verificando...');

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_2fa_verify_and_enable',
                code: code,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                btn.prop('disabled', false).text('✓ Confirmar y Activar 2FA');
                if (res.success) {
                    alert('✓ ' + (res.data.message || '2FA activado exitosamente.'));
                    cmClose2FAModal();
                    jQuery('#cm-2fa-suggestion-banner').slideUp(200);
                    location.reload();
                } else {
                    alert(res.data.message || 'Código incorrecto. Verifica la hora y código de tu app.');
                    jQuery('#cm-2fa-code-input').val('').focus();
                }
            },
            error: function() {
                btn.prop('disabled', false).text('✓ Confirmar y Activar 2FA');
                alert('Error de conexión.');
            }
        });
    }

    function cmAdminDisable2FA(userId, userLogin) {
        if (!confirm('¿Confirmas que deseas desactivar la seguridad 2FA para el usuario "' + userLogin + '"?\nEl usuario podrá ingresar con su contraseña habitual y volver a configurar 2FA si lo desea.')) {
            return;
        }

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_disable_2fa',
                user_id: userId,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                if (res.success) {
                    alert('✓ ' + (res.data.message || '2FA desactivado exitosamente.'));
                    location.reload();
                } else {
                    alert(res.data.message || 'Error al desactivar 2FA.');
                }
            },
            error: function() {
                alert('Error de conexión al desactivar 2FA.');
            }
        });
    }

    var cmCurrentAdminGenerated2FASecret = '';

    // Modal de Gestión 2FA de Usuario (Superadmin)
    function cmOpenAdminUser2FAModal(userId, userLogin, displayName, isEnabled, dateStr) {
        jQuery('#cm-m2fa-userid').val(userId);
        jQuery('#cm-m2fa-userlogin').val(userLogin);
        jQuery('#cm-m2fa-username').text(userLogin);
        jQuery('#cm-m2fa-displayname').text(displayName ? '(' + displayName + ')' : '');

        // Reiniciar panel de generación
        jQuery('#cm-m2fa-generate-panel').hide();
        jQuery('#cm-m2fa-verify-code-input').val('');
        jQuery('#cm-btn-show-generate-2fa').show().text(isEnabled ? '📲 Cambiar / Generar Nueva Clave y QR' : '📲 Asignar / Generar Nueva Clave y QR');

        var statusBox = jQuery('#cm-m2fa-status-box');
        var activeActions = jQuery('#cm-m2fa-active-actions');

        if (isEnabled) {
            statusBox.css({
                'background': '#f0fdf4',
                'border': '1px solid #bbf7d0',
                'color': '#166534'
            }).html(
                '<div style="display:flex; align-items:center; gap:8px; margin-bottom:4px;">' +
                    '<span style="font-size:18px;">🟢</span>' +
                    '<strong style="font-size:13.5px; color:#15803d;">Autenticación de 2 Factores Activa</strong>' +
                '</div>' +
                '<div style="font-size:12px; color:#166534; line-height:1.4;">' +
                    'Este usuario tiene protegida su cuenta con Google Authenticator / Apple. Cada vez que inicie sesión, se le exigirá el código de 6 dígitos.' +
                '</div>' +
                (dateStr ? '<div style="font-size:11.5px; color:#15803d; font-weight:700; margin-top:6px;">🕒 Activado el: ' + dateStr + ' hrs</div>' : '')
            );
            activeActions.show();
        } else {
            statusBox.css({
                'background': '#f8fafc',
                'border': '1px solid #e2e8f0',
                'color': '#64748b'
            }).html(
                '<div style="display:flex; align-items:center; gap:8px; margin-bottom:4px;">' +
                    '<span style="font-size:18px;">⚪</span>' +
                    '<strong style="font-size:13.5px; color:#475569;">2FA No Activado</strong>' +
                '</div>' +
                '<div style="font-size:12px; color:#64748b; line-height:1.4;">' +
                    'Este usuario aún no tiene 2FA configurado. Puedes asignarle y generarle uno ahora mismo pulsando el botón de abajo.' +
                '</div>'
            );
            activeActions.hide();
        }

        jQuery('#cm-admin-manage-2fa-modal-overlay').fadeIn(120).css('display', 'flex');
    }

    function cmCloseAdminUser2FAModal() {
        jQuery('#cm-admin-manage-2fa-modal-overlay').fadeOut(100);
    }

    function cmAdminToggleGenerateUser2FA() {
        var userId = jQuery('#cm-m2fa-userid').val();
        if (!userId) return;

        var panel = jQuery('#cm-m2fa-generate-panel');
        if (panel.is(':visible')) {
            panel.slideUp(150);
            return;
        }

        jQuery('#cm-m2fa-secret-text').text('Generando...');
        jQuery('#cm-m2fa-qr-img').attr('src', '');
        jQuery('#cm-btn-confirm-assign-2fa').prop('disabled', true).text('Generando QR...');

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_generate_user_2fa',
                user_id: userId,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                jQuery('#cm-btn-confirm-assign-2fa').prop('disabled', false).text('✓ Activar y Asignar este 2FA al Usuario');
                if (res.success && res.data) {
                    cmCurrentAdminGenerated2FASecret = res.data.secret;
                    jQuery('#cm-m2fa-secret-text').text(res.data.secret);
                    jQuery('#cm-m2fa-qr-img').attr('src', res.data.qr_url);
                    panel.slideDown(200);
                } else {
                    alert(res.data.message || 'Error al generar 2FA.');
                }
            },
            error: function() {
                alert('Error de conexión al generar 2FA.');
            }
        });
    }

    function cmCopyAdminGenerated2FASecret() {
        if (!cmCurrentAdminGenerated2FASecret) return;
        navigator.clipboard.writeText(cmCurrentAdminGenerated2FASecret);
        alert('✓ Clave de configuración copiada: ' + cmCurrentAdminGenerated2FASecret);
    }

    function cmAdminConfirmAssignUser2FA() {
        var userId = jQuery('#cm-m2fa-userid').val();
        var code   = jQuery('#cm-m2fa-verify-code-input').val().trim();
        if (!userId) return;

        var btn = jQuery('#cm-btn-confirm-assign-2fa');
        btn.prop('disabled', true).text('Guardando y Activando...');

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_assign_user_2fa',
                user_id: userId,
                code: code,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                btn.prop('disabled', false).text('✓ Activar y Asignar este 2FA al Usuario');
                if (res.success) {
                    alert('✓ ' + (res.data.message || '2FA asignado exitosamente al usuario.'));
                    cmCloseAdminUser2FAModal();
                    location.reload();
                } else {
                    alert(res.data.message || 'Error al asignar 2FA.');
                }
            },
            error: function() {
                btn.prop('disabled', false).text('✓ Activar y Asignar este 2FA al Usuario');
                alert('Error de conexión al asignar 2FA.');
            }
        });
    }

    function cmAdminModalDisable2FA() {
        var userId = jQuery('#cm-m2fa-userid').val();
        var userLogin = jQuery('#cm-m2fa-userlogin').val();
        if (!userId) return;

        if (!confirm('¿Confirmas que deseas desactivar la seguridad 2FA para el usuario "' + userLogin + '"?\nEl usuario podrá ingresar con su contraseña habitual inmediatamente.')) {
            return;
        }

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_disable_2fa',
                user_id: userId,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                if (res.success) {
                    alert('✓ ' + (res.data.message || '2FA desactivado exitosamente.'));
                    cmCloseAdminUser2FAModal();
                    location.reload();
                } else {
                    alert(res.data.message || 'Error al desactivar 2FA.');
                }
            },
            error: function() {
                alert('Error de conexión al desactivar 2FA.');
            }
        });
    }

    function cmAdminModalReset2FA() {
        var userId = jQuery('#cm-m2fa-userid').val();
        var userLogin = jQuery('#cm-m2fa-userlogin').val();
        if (!userId) return;

        if (!confirm('¿Deseas restablecer la seguridad 2FA de "' + userLogin + '"?\nSe borrará la vinculación actual y el usuario podrá registrar una nueva app de autenticación en su cuenta.')) {
            return;
        }

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_reset_user_2fa',
                user_id: userId,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                if (res.success) {
                    alert('✓ ' + (res.data.message || '2FA restablecido exitosamente.'));
                    cmCloseAdminUser2FAModal();
                    location.reload();
                } else {
                    alert(res.data.message || 'Error al restablecer 2FA.');
                }
            },
            error: function() {
                alert('Error de conexión al restablecer 2FA.');
            }
        });
    }

    // 🔔 SINTETIZADOR DE AUDIO PROFESIONAL (Web Audio API - Cero dependencias externas)
    function cmPlayNotificationSound(isTest) {
        try {
            var AudioCtx = window.AudioContext || window.webkitAudioContext;
            if (!AudioCtx) return;
            var ctx = new AudioCtx();

            // Tono 1: Campana armónica inicial (587 Hz - Re)
            var osc1 = ctx.createOscillator();
            var gain1 = ctx.createGain();
            osc1.type = 'sine';
            osc1.frequency.setValueAtTime(587.33, ctx.currentTime);
            gain1.gain.setValueAtTime(0.25, ctx.currentTime);
            gain1.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
            osc1.connect(gain1);
            gain1.connect(ctx.destination);
            osc1.start(ctx.currentTime);
            osc1.stop(ctx.currentTime + 0.35);

            // Tono 2: Timbre de confirmación cristalino (880 Hz - La)
            setTimeout(function() {
                var osc2 = ctx.createOscillator();
                var gain2 = ctx.createGain();
                osc2.type = 'sine';
                osc2.frequency.setValueAtTime(880, ctx.currentTime);
                gain2.gain.setValueAtTime(0.30, ctx.currentTime);
                gain2.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.50);
                osc2.connect(gain2);
                gain2.connect(ctx.destination);
                osc2.start(ctx.currentTime);
                osc2.stop(ctx.currentTime + 0.50);
            }, 110);

            if (isTest) {
                cmShowLiveToast('TEST-AUDIO', 'Demostración de Notificación Sonora', 'Área de Prueba');
            }
        } catch(e) {
            console.log('Audio notification:', e);
        }
    }

    // Muestra alerta visual flotante (Toast estilo Apple)
    function cmShowLiveToast(ticketCode, senderName, department) {
        var toastHtml = jQuery(
            '<div class="cm-apple-toast" style="background:#ffffff; border:1px solid #e2e8f0; border-left:4px solid #0071e3; border-radius:12px; padding:14px 18px; box-shadow:0 10px 30px rgba(0,0,0,0.12); display:flex; align-items:center; justify-content:space-between; gap:14px; min-width:320px; pointer-events:auto; animation:cmFadeIn 0.3s ease;">' +
                '<div style="display:flex; align-items:center; gap:10px;">' +
                    '<span style="font-size:24px;">🔔</span>' +
                    '<div>' +
                        '<div style="font-size:11px; font-weight:800; color:#0071e3; letter-spacing:0.05em; text-transform:uppercase;">¡NUEVO CASO RECIBIDO!</div>' +
                        '<div style="font-size:13.5px; font-weight:700; color:#0f172a; margin-top:2px;">' + ticketCode + ' — ' + senderName + '</div>' +
                        '<div style="font-size:11.5px; color:#64748b;">🏢 ' + (department || 'Tu Área') + '</div>' +
                    '</div>' +
                '</div>' +
                '<button type="button" class="cm-btn-view" style="font-size:11.5px; padding:6px 12px; background:#0071e3; color:#fff;" onclick="location.reload()">' +
                    '🔄 Actualizar' +
                '</button>' +
            '</div>'
        );

        jQuery('#cm-live-toast-wrap').prepend(toastHtml);
        setTimeout(function() {
            toastHtml.fadeOut(300, function() { jQuery(this).remove(); });
        }, 12000);
    }

    // Poller de nuevos casos en tiempo real (cada 20 segundos)
    var cmLatestCaseId = <?php echo !empty($submissions[0]->id) ? (int)$submissions[0]->id : 0; ?>;
    setInterval(function() {
        if (cmLatestCaseId <= 0) return;
        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_check_new_submissions',
                last_id: cmLatestCaseId,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                if (res.success && res.data && res.data.has_new) {
                    cmLatestCaseId = res.data.latest_id;
                    cmPlayNotificationSound(false);
                    cmShowLiveToast(res.data.ticket_code, res.data.sender_name, res.data.department);
                }
            }
        });
    }, 20000);
    </script>
    <?php
}

/**
 * AJAX: Guarda o edita un departamento.
 */
function cm_ajax_admin_save_dept() {
    check_ajax_referer('cm_contacto_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Permiso denegado.', 'contacto-multidestino')));
    }

    $name    = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : '';
    $emails  = isset($_POST['emails']) ? sanitize_text_field($_POST['emails']) : '';
    $user_id = isset($_POST['user_id']) ? absint($_POST['user_id']) : 0;
    $enabled = !empty($_POST['enabled']) ? 1 : 0;

    if (!$name) {
        wp_send_json_error(array('message' => __('Nombre no válido.', 'contacto-multidestino')));
    }

    $saved = cm_save_department_entry(array(
        'name'    => $name,
        'emails'  => $emails,
        'user_id' => $user_id,
        'enabled' => $enabled,
    ));

    if ($saved) {
        wp_send_json_success(array('message' => __('Área guardada exitosamente.', 'contacto-multidestino')));
    } else {
        wp_send_json_error(array('message' => __('No se pudo guardar el área.', 'contacto-multidestino')));
    }
}
add_action('wp_ajax_cm_admin_save_dept', 'cm_ajax_admin_save_dept');

/**
 * AJAX: Habilita o deshabilita un departamento.
 */
function cm_ajax_admin_toggle_dept() {
    check_ajax_referer('cm_contacto_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Permiso denegado.', 'contacto-multidestino')));
    }

    $name = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : '';
    $res  = cm_toggle_department_status($name);

    if ($res !== false) {
        wp_send_json_success(array('status' => $res));
    } else {
        wp_send_json_error(array('message' => __('Área no encontrada.', 'contacto-multidestino')));
    }
}
add_action('wp_ajax_cm_admin_toggle_dept', 'cm_ajax_admin_toggle_dept');

/**
 * AJAX: Elimina un departamento.
 */
function cm_ajax_admin_delete_dept() {
    check_ajax_referer('cm_contacto_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Permiso denegado.', 'contacto-multidestino')));
    }

    $name = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : '';
    $res  = cm_delete_department_entry($name);

    if ($res) {
        wp_send_json_success();
    } else {
        wp_send_json_error(array('message' => __('No se pudo eliminar.', 'contacto-multidestino')));
    }
}
add_action('wp_ajax_cm_admin_delete_dept', 'cm_ajax_admin_delete_dept');

/**
 * AJAX: Crea un nuevo usuario y lo asigna a un área.
 */
function cm_ajax_admin_create_area_user() {
    check_ajax_referer('cm_contacto_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Permiso denegado.', 'contacto-multidestino')));
    }

    $login = isset($_POST['login']) ? sanitize_user($_POST['login']) : '';
    $name  = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : '';
    $email = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
    $pass  = isset($_POST['pass']) ? $_POST['pass'] : '';
    $role  = isset($_POST['role']) && in_array($_POST['role'], array('administrator', 'editor')) ? $_POST['role'] : 'editor';
    $dept  = isset($_POST['department']) ? sanitize_text_field($_POST['department']) : '';

    if (!$login || !is_email($email) || empty($pass)) {
        wp_send_json_error(array('message' => __('Datos inválidos o incompletos.', 'contacto-multidestino')));
    }

    if (username_exists($login) || email_exists($email)) {
        wp_send_json_error(array('message' => __('El nombre de usuario o correo ya está registrado.', 'contacto-multidestino')));
    }

    $user_id = wp_create_user($login, $pass, $email);
    if (is_wp_error($user_id)) {
        wp_send_json_error(array('message' => $user_id->get_error_message()));
    }

    if ($name) {
        wp_update_user(array('ID' => $user_id, 'display_name' => $name));
    }

    // Asignar rol base editor en WordPress (mantiene bloqueado WordPress nativo)
    $user = new WP_User($user_id);
    $user->set_role('editor');

    // Registrar perfil institucional en metadatos de usuario
    $is_director_account = ($role === 'administrator' || $role === 'director');
    if ($is_director_account) {
        update_user_meta($user_id, 'cm_user_profile', 'director');
    } else {
        update_user_meta($user_id, 'cm_user_profile', 'area_manager');
    }

    // Asignar al área si se seleccionó
    if ($dept) {
        $deps = cm_get_available_departments(false);
        if (isset($deps[$dept])) {
            $deps[$dept]['user_id'] = $user_id;
            $deps[$dept]['user']    = $name ? $name : $login;
            cm_save_department_entry($deps[$dept]);
        }
    }

    // Enviar correo de bienvenida con credenciales y nivel de acceso
    $site_name = get_bloginfo('name');
    $site_url  = home_url();
    $login_url = admin_url('admin.php?page=cm-form-submissions');

    $is_admin_role = $is_director_account;

    if ($is_admin_role) {
        $welcome_subject = sprintf('[%s] Cuenta de Director / Administrador Habilitada (Acceso Total)', $site_name);
        $role_badge_text = '👑 DIRECTOR / ADMINISTRADOR (ACCESO TOTAL)';
        $welcome_heading = '¡Bienvenido al Panel de Dirección de ' . esc_html($site_name) . '!';
        $welcome_desc    = 'Tu cuenta de administrador y control directivo ha sido configurada con acceso total.';
        $area_label      = '🌐 Acceso Global (Dashboard y Todas las Áreas)';
        $btn_text        = '📊 Ingresar al Dashboard y Control de Casos &rarr;';
        $perm_note       = 'Como Director/Administrador, podrás ver el <strong>Dashboard en Tiempo Real</strong>, el <strong>Tablero Kanban</strong> con todas las etapas de casos y monitorear el rendimiento de cada área.';
    } else {
        $welcome_subject = sprintf('[%s] Tu cuenta de Encargado de Área ha sido creada', $site_name);
        $role_badge_text = '🏢 ENCARGADO DE ÁREA';
        $welcome_heading = '¡Bienvenido al Panel de ' . esc_html($site_name) . '!';
        $welcome_desc    = 'Tu cuenta de encargado de área ha sido creada exitosamente.';
        $area_label      = '🏢 ' . esc_html($dept ? $dept : 'General');
        $btn_text        = '📥 Ingresar a la Bandeja de Casos de mi Área &rarr;';
        $perm_note       = 'Podrás atender, dar continuidad, derivar o solicitar la presencia del solicitante para los casos dirigidos a tu departamento.';
    }

    $welcome_body = '
    <!DOCTYPE html>
    <html lang="es">
    <head><meta charset="UTF-8"></head>
    <body style="font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, sans-serif; background-color: #f1f5f9; padding: 30px 15px; margin: 0;">
        <div style="max-width: 580px; margin: 0 auto; background: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.06); border: 1px solid #e2e8f0;">
            <div style="background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%); padding: 28px 32px; color: #ffffff;">
                <div style="display:inline-block; background:rgba(255,255,255,0.15); padding:4px 12px; border-radius:20px; font-size:11px; font-weight:800; color:#c7d2fe; text-transform:uppercase; letter-spacing:0.05em;">
                    ' . $role_badge_text . '
                </div>
                <h2 style="margin: 10px 0 0 0; font-size: 21px; font-weight: 800; color: #ffffff;">' . $welcome_heading . '</h2>
                <p style="margin: 4px 0 0 0; font-size: 13.5px; color: #cbd5e1;">' . $welcome_desc . '</p>
            </div>
            <div style="padding: 26px 32px;">
                <p style="margin: 0 0 16px 0; font-size: 14.5px; color: #334155;">Hola <strong>' . esc_html($name ? $name : $login) . '</strong>, te compartimos tus credenciales de acceso institucional:</p>
                
                <table style="width: 100%; border-collapse: collapse; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; overflow: hidden; margin-bottom: 20px;">
                    <tr>
                        <td style="padding: 11px 14px; font-weight: 600; color: #475569; border-bottom: 1px solid #e2e8f0; width: 40%;">Perfil / Nivel:</td>
                        <td style="padding: 11px 14px; font-weight: 700; color: #0f172a; border-bottom: 1px solid #e2e8f0;">' . ($is_admin_role ? '👑 Director / Administrador' : '🏢 Encargado de Área') . '</td>
                    </tr>
                    <tr>
                        <td style="padding: 11px 14px; font-weight: 600; color: #475569; border-bottom: 1px solid #e2e8f0;">Ámbito / Área:</td>
                        <td style="padding: 11px 14px; font-weight: 700; color: #4f46e5; border-bottom: 1px solid #e2e8f0;">' . $area_label . '</td>
                    </tr>
                    <tr>
                        <td style="padding: 11px 14px; font-weight: 600; color: #475569; border-bottom: 1px solid #e2e8f0;">Usuario (Login):</td>
                        <td style="padding: 11px 14px; font-family: monospace; font-weight: 700; color: #0f172a; border-bottom: 1px solid #e2e8f0;">' . esc_html($login) . '</td>
                    </tr>
                    <tr>
                        <td style="padding: 11px 14px; font-weight: 600; color: #475569;">Contraseña de Acceso:</td>
                        <td style="padding: 11px 14px; font-family: monospace; font-weight: 700; color: #0f172a;">' . esc_html($pass) . '</td>
                    </tr>
                </table>

                <div style="background:#f1f5f9; border-left:3px solid #6366f1; padding:10px 14px; border-radius:0 8px 8px 0; font-size:12.5px; color:#475569; line-height:1.45; margin-bottom:20px;">
                    ' . $perm_note . '
                </div>

                <div style="text-align: center; margin: 22px 0 18px 0;">
                    <a href="' . esc_url($login_url) . '" target="_blank" style="display: inline-block; background: #0071e3; color: #ffffff; text-decoration: none; padding: 13px 28px; border-radius: 10px; font-size: 14px; font-weight: 700;">
                        ' . $btn_text . '
                    </a>
                </div>

                <div style="background:#eff6ff; border:1px solid #bfdbfe; border-radius:8px; padding:10px 14px; font-size:12px; color:#1e40af; line-height:1.5;">
                    🔗 <strong>Enlace directo para ingresar:</strong><br>
                    <a href="' . esc_url($login_url) . '" style="color:#0284c7; word-break:break-all;">' . esc_url($login_url) . '</a>
                </div>
            </div>
            <div style="background: #f8fafc; padding: 16px 32px; border-top: 1px solid #e2e8f0; text-align: center; font-size: 12px; color: #94a3b8;">
                Ingecodex Form • ' . esc_html($site_name) . '
            </div>
        </div>
    </body>
    </html>';

    $from_email = get_option('cm_smtp_from', get_option('admin_email'));
    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . esc_html($site_name) . ' <' . $from_email . '>'
    );
    wp_mail($email, $welcome_subject, $welcome_body, $headers);

    wp_send_json_success(array('user_id' => $user_id, 'access_url' => $login_url, 'role' => $role));
}
add_action('wp_ajax_cm_admin_create_area_user', 'cm_ajax_admin_create_area_user');

/**
 * AJAX: Comprueba periódicamente si hay casos nuevos para emitir alerta sonora y visual.
 */
function cm_ajax_admin_check_new_submissions() {
    check_ajax_referer('cm_contacto_nonce', 'nonce');

    if (!current_user_can('edit_posts') && !current_user_can('manage_options')) {
        wp_send_json_error();
    }

    $last_id = isset($_POST['last_id']) ? absint($_POST['last_id']) : 0;
    $user_assigned_dept = function_exists('cm_get_current_user_assigned_department') ? cm_get_current_user_assigned_department() : '';

    $args = array(
        'limit' => 1,
        'order' => 'DESC',
    );
    if (!empty($user_assigned_dept)) {
        $args['department'] = $user_assigned_dept;
    }

    $res = cm_get_submissions($args);
    $latest = !empty($res['items']) ? $res['items'][0] : null;

    if ($latest && (int)$latest->id > $last_id && $last_id > 0) {
        wp_send_json_success(array(
            'has_new'     => true,
            'latest_id'   => (int)$latest->id,
            'ticket_code' => $latest->ticket_code,
            'sender_name' => $latest->sender_name,
            'department'  => $latest->department,
        ));
    } else {
        wp_send_json_success(array(
            'has_new'   => false,
            'latest_id' => $latest ? (int)$latest->id : 0,
        ));
    }
}
add_action('wp_ajax_cm_admin_check_new_submissions', 'cm_ajax_admin_check_new_submissions');

/**
 * Construye el payload HTML completo del Expediente Oficial (reutilizable en modal y página completa).
 */
function cm_build_case_inspector_payload($id) {
    if (!current_user_can('edit_posts') && !current_user_can('manage_options')) {
        return new WP_Error('forbidden', __('Permiso denegado.', 'contacto-multidestino'));
    }

    $case = cm_get_submission_by_id($id);
    if (!$case) {
        return new WP_Error('not_found', __('Caso no encontrado.', 'contacto-multidestino'));
    }

    // Si es encargado de área (no Director ni Superadmin), verificar que el caso pertenezca a su área
    if (function_exists('cm_can_view_global_dashboard') && !cm_can_view_global_dashboard()) {
        $user_assigned_dept = function_exists('cm_get_current_user_assigned_department') ? cm_get_current_user_assigned_department() : '';
        if (!empty($user_assigned_dept) && $case->department !== $user_assigned_dept) {
            return new WP_Error('forbidden_dept', __('No tienes permiso para acceder a casos de otra área.', 'contacto-multidestino'));
        }
    }

    $history     = cm_get_case_updates($case->id, false);
    $statuses    = cm_get_case_statuses();
    $departments = cm_get_available_departments(true); // Solo activas para derivar

    $submitted_data = array();
    if (!empty($case->submitted_data)) {
        $decoded = json_decode($case->submitted_data, true);
        if (is_array($decoded)) $submitted_data = $decoded;
    }

    $current_user = wp_get_current_user();
    $current_user_name = $current_user && $current_user->display_name ? $current_user->display_name : ($case->department ? 'Área ' . $case->department : 'Administración');

    ob_start();
    ?>
    <div class="cm-apple-inspector-grid">
        <!-- Columna Izquierda: Datos del Formulario y Solicitante -->
        <div class="cm-inspector-sidebar">
            <div class="cm-apple-card-sm">
                <div class="cm-card-sm-title"><?php _e('Información del Solicitante', 'contacto-multidestino'); ?></div>
                <div class="cm-kv-list">
                    <div class="cm-kv-item">
                        <span class="cm-kv-k">👤 <?php _e('Nombre:', 'contacto-multidestino'); ?></span>
                        <span class="cm-kv-v"><strong><?php echo esc_html($case->sender_name ? $case->sender_name : 'No especificado'); ?></strong></span>
                    </div>
                    <div class="cm-kv-item">
                        <span class="cm-kv-k">✉️ <?php _e('Correo:', 'contacto-multidestino'); ?></span>
                        <span class="cm-kv-v"><a href="mailto:<?php echo esc_attr($case->sender_email); ?>"><?php echo esc_html($case->sender_email); ?></a></span>
                    </div>
                    <?php if ($case->sender_phone) : ?>
                    <div class="cm-kv-item">
                        <span class="cm-kv-k">📞 <?php _e('Teléfono:', 'contacto-multidestino'); ?></span>
                        <span class="cm-kv-v"><?php echo esc_html($case->sender_phone); ?></span>
                    </div>
                    <?php endif; ?>
                    <div class="cm-kv-item">
                        <span class="cm-kv-k">🏢 <?php _e('Área Actual:', 'contacto-multidestino'); ?></span>
                        <span class="cm-kv-v"><span class="cm-tag-dept-sm"><?php echo esc_html($case->department ? $case->department : 'General'); ?></span></span>
                    </div>
                    <div class="cm-kv-item">
                        <span class="cm-kv-k">📋 <?php _e('Formulario de Origen:', 'contacto-multidestino'); ?></span>
                        <span class="cm-kv-v"><strong><?php echo esc_html($case->form_name ? $case->form_name : $case->form_id); ?></strong></span>
                    </div>
                    <div class="cm-kv-item">
                        <span class="cm-kv-k">📅 <?php _e('Fecha de Ingreso:', 'contacto-multidestino'); ?></span>
                        <span class="cm-kv-v"><?php echo date_i18n('d/m/Y - H:i \h\r\s', strtotime($case->created_at)); ?></span>
                    </div>
                    <?php if (!empty($case->updated_at) && $case->updated_at !== $case->created_at) : ?>
                    <div class="cm-kv-item">
                        <span class="cm-kv-k">🔄 <?php _e('Última Actualización:', 'contacto-multidestino'); ?></span>
                        <span class="cm-kv-v"><?php echo date_i18n('d/m/Y - H:i \h\r\s', strtotime($case->updated_at)); ?></span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Campos Completados del Formulario -->
            <div class="cm-apple-card-sm" style="margin-top: 12px;">
                <div class="cm-card-sm-title"><?php _e('Detalle del Formulario', 'contacto-multidestino'); ?></div>
                <div class="cm-fields-compact-list">
                    <?php if (!empty($submitted_data)) : ?>
                        <?php foreach ($submitted_data as $label => $val) : ?>
                            <div class="cm-fitem">
                                <div class="cm-flabel"><?php echo esc_html($label); ?>:</div>
                                <div class="cm-fval"><?php echo nl2br(esc_html($val)); ?></div>
                            </div>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <p style="color:#86868b;font-size:12px;margin:0;"><?php _e('Sin datos adicionales.', 'contacto-multidestino'); ?></p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Documentos y Archivos Adjuntos (Lista Compacta con Scroll) -->
            <?php
            $attached_items = function_exists('cm_extract_case_attachments') ? cm_extract_case_attachments($history, $submitted_data) : array();
            ?>
            <div class="cm-apple-card-sm" style="margin-top: 12px;">
                <div class="cm-card-sm-title" style="display:flex; justify-content:space-between; align-items:center;">
                    <span>📁 <?php _e('Documentos y Archivos del Caso', 'contacto-multidestino'); ?></span>
                    <span style="font-size:11px; background:<?php echo !empty($attached_items) ? '#e0f2fe' : '#f1f5f9'; ?>; color:<?php echo !empty($attached_items) ? '#0369a1' : '#64748b'; ?>; padding:2px 8px; border-radius:12px; font-weight:700;">
                        <?php echo count($attached_items); ?>
                    </span>
                </div>
                <div style="margin-top:6px;">
                    <?php if (!empty($attached_items)) : ?>
                        <div class="cm-doc-list-scroll">
                            <?php foreach ($attached_items as $att) : 
                                $is_img = !empty($att['is_image']);
                                $url = esc_url($att['url']);
                                $name = esc_html($att['name'] ? $att['name'] : basename($att['url']));
                                $ext = strtoupper($att['ext']);
                                $author = esc_html($att['author'] ? $att['author'] : 'Adjunto');
                                $date = esc_html($att['date'] ? $att['date'] : '');
                            ?>
                                <div class="cm-doc-mini-row">
                                    <div style="display:flex; align-items:center; gap:8px; min-width:0; flex:1;">
                                        <?php if ($is_img) : ?>
                                            <div style="width:30px; height:30px; border-radius:6px; overflow:hidden; background:#f1f5f9; flex-shrink:0; border:1px solid #e2e8f0; cursor:pointer;" onclick="cmOpenDocumentPreview('<?php echo esc_js($url); ?>', '<?php echo esc_js($name); ?>', true)" title="<?php esc_attr_e('Ver imagen', 'contacto-multidestino'); ?>">
                                                <img src="<?php echo $url; ?>" style="width:100%; height:100%; object-fit:cover;" alt="<?php echo $name; ?>" />
                                            </div>
                                        <?php else : ?>
                                            <div style="width:30px; height:30px; border-radius:6px; background:#fee2e2; color:#dc2626; display:flex; align-items:center; justify-content:center; font-size:10.5px; font-weight:800; flex-shrink:0; border:1px solid #fecaca;">
                                                <?php echo $ext ? substr($ext, 0, 3) : 'DOC'; ?>
                                            </div>
                                        <?php endif; ?>
                                        <div style="min-width:0; flex:1;">
                                            <div style="font-size:11.5px; font-weight:700; color:#0f172a; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="<?php echo $name; ?>">
                                                <?php echo $name; ?>
                                            </div>
                                            <div style="font-size:10px; color:#64748b; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                                                👤 <?php echo $author; ?><?php if ($date) : ?> • <?php echo $date; ?><?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div style="display:flex; align-items:center; gap:4px; flex-shrink:0;">
                                        <button type="button" class="cm-btn-view" style="font-size:10.5px; padding:2px 7px; height:24px; display:inline-flex; align-items:center; gap:2px;" onclick="cmOpenDocumentPreview('<?php echo esc_js($url); ?>', '<?php echo esc_js($name); ?>', <?php echo $is_img ? 'true' : 'false'; ?>)" title="<?php esc_attr_e('Ver documento', 'contacto-multidestino'); ?>">
                                            👁️ <?php _e('Ver', 'contacto-multidestino'); ?>
                                        </button>
                                        <a href="<?php echo $url; ?>" target="_blank" download class="cm-apple-btn-secondary" style="font-size:10.5px; padding:2px 6px; height:24px; display:inline-flex; align-items:center; text-decoration:none;" title="<?php esc_attr_e('Descargar original', 'contacto-multidestino'); ?>">
                                            ⬇️
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else : ?>
                        <p style="color:#94a3b8; font-size:11.5px; margin:0; line-height:1.4;">
                            💡 <?php _e('No hay documentos adjuntos aún. Puedes solicitarle al usuario que adjunte antecedentes usando la casilla de solicitud.', 'contacto-multidestino'); ?>
                        </p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Columna Derecha: Acciones, Derivación y Línea de Tiempo -->
        <div class="cm-inspector-main">
            <?php if (!empty($case->is_deleted)) : ?>
                <!-- AVISO DE MODO SOLO LECTURA EN CASO EN PAPELERA -->
                <div class="cm-apple-card-sm" style="background:#fef2f2; border:1.5px solid #fecaca; border-radius:12px; padding:16px 18px; margin-bottom:14px;">
                    <div style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:12px;">
                        <div style="display:flex; align-items:center; gap:12px;">
                            <span style="font-size:28px;">🗑️</span>
                            <div>
                                <strong style="font-size:14px; color:#991b1b; display:block;">
                                    <?php _e('Expediente en Papelera (Modo Solo Lectura)', 'contacto-multidestino'); ?>
                                </strong>
                                <p style="font-size:12px; color:#7f1d1d; margin:3px 0 0 0; line-height:1.4;">
                                    <?php 
                                    $del_by_str = !empty($case->deleted_by) ? esc_html($case->deleted_by) : __('Administración', 'contacto-multidestino');
                                    $del_at_str = !empty($case->deleted_at) ? date_i18n('d/m/Y - H:i \h\r\s', strtotime($case->deleted_at)) : '';
                                    printf(__('Este caso fue enviado a la papelera por <strong>%s</strong>%s. No se pueden realizar modificaciones ni cambiar su estado mientras permanezca en la papelera.', 'contacto-multidestino'), $del_by_str, $del_at_str ? ' el ' . $del_at_str : ''); 
                                    ?>
                                </p>
                            </div>
                        </div>
                        <?php if (current_user_can('manage_options')) : ?>
                            <button 
                                type="button" 
                                class="cm-apple-btn-primary" 
                                style="background:#16a34a; border-color:#15803d; color:#ffffff; font-weight:700; font-size:12.5px; height:32px; padding:0 14px; display:inline-flex; align-items:center; gap:5px; border-radius:8px; box-shadow:0 2px 6px rgba(22,163,74,0.3); cursor:pointer;" 
                                onclick="cmRestoreCase(<?php echo esc_attr($case->id); ?>)"
                            >
                                ♻️ <?php _e('Recuperar este Caso Ahora', 'contacto-multidestino'); ?>
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            <?php else : ?>
                <!-- Barra de Pestañas en el Modal / Página -->
                <div class="cm-modal-subnav">
                    <button type="button" id="cm-tab-btn-manage" class="cm-modal-tab-btn active" onclick="cmSwitchModalTab('manage')">
                        ⚙️ <?php _e('Gestión y Solicitudes', 'contacto-multidestino'); ?>
                    </button>
                    <button type="button" id="cm-tab-btn-transfer" class="cm-modal-tab-btn" onclick="cmSwitchModalTab('transfer')">
                        🔄 <?php _e('Derivar a Otra Área', 'contacto-multidestino'); ?>
                    </button>
                </div>

                <!-- PANEL 1: GESTIÓN DE ESTADO Y RESPUESTAS -->
                <div id="cm-pane-manage" class="cm-tab-pane" style="display:block;">
                    <div class="cm-apple-card-sm">
                        <div class="cm-form-row-compact">
                            <label><strong><?php _e('Estado del Caso:', 'contacto-multidestino'); ?></strong></label>
                            <select id="cm-select-new-status" class="cm-apple-select-lg">
                                <?php foreach ($statuses as $st_key => $st_info) : ?>
                                    <option value="<?php echo esc_attr($st_key); ?>" <?php selected($case->status, $st_key); ?>>
                                        <?php echo $st_info['icon'] . ' ' . esc_html($st_info['label']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- Casillas de Requerimiento Especial al Solicitante -->
                        <div style="margin-top: 12px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 10px 12px;">
                            <label style="font-size: 12px; font-weight: 800; color: #1e293b; display: block; margin-bottom: 6px;">
                                📋 <?php _e('Requerimientos Especiales al Solicitante:', 'contacto-multidestino'); ?>
                            </label>
                            <div style="display: flex; flex-direction: column; gap: 8px;">
                                <!-- Checkbox Documentos -->
                                <div>
                                    <label style="display: inline-flex; align-items: center; gap: 6px; font-size: 12px; font-weight: 600; color: #0369a1; cursor: pointer;">
                                        <input type="checkbox" id="cm-check-req-doc" value="1" onchange="cmToggleDocTitleInput(this)" style="border-radius: 4px; accent-color: #0284c7;" />
                                        <span>📁 <?php _e('Solicitar Documentos / Archivos Web (Activa subida en portal)', 'contacto-multidestino'); ?></span>
                                    </label>
                                    <!-- Campo de Título de Documentos (Oculto por defecto) -->
                                    <div id="cm-wrap-doc-title" style="display: none; margin-top: 6px; padding-left: 22px;">
                                        <input 
                                            type="text" 
                                            id="cm-input-doc-title" 
                                            class="cm-apple-input-sm" 
                                            style="height: 32px !important; font-size: 12px; width: 100%; box-sizing: border-box;" 
                                            placeholder="<?php esc_attr_e('Ej: Adjuntar certificado de notas timbrado para continuar con el caso', 'contacto-multidestino'); ?>" 
                                        />
                                        <small style="color: #64748b; font-size: 10.5px; display: block; margin-top: 2px;">
                                            💡 <?php _e('Este título se mostrará en grande en la caja de carga del portal de seguimiento.', 'contacto-multidestino'); ?>
                                        </small>
                                    </div>
                                </div>

                                <!-- Checkbox Presencia -->
                                <label style="display: inline-flex; align-items: center; gap: 6px; font-size: 12px; font-weight: 600; color: #b45309; cursor: pointer;">
                                    <input type="checkbox" id="cm-check-req-presence" value="1" style="border-radius: 4px; accent-color: #f59e0b;" />
                                    <span>🏛️ <?php _e('Solicitar Presencia Física en el Establecimiento', 'contacto-multidestino'); ?></span>
                                </label>
                            </div>
                        </div>

                        <!-- Plantillas Rápidas -->
                        <div style="margin-top: 10px;">
                            <label style="font-size: 11px; color: #64748b; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; display: block; margin-bottom: 5px;">
                                ⚡ <?php _e('Plantillas Rápidas de Solicitud:', 'contacto-multidestino'); ?>
                            </label>
                            <div class="cm-quick-replies-wrap" style="display: flex; gap: 6px; flex-wrap: wrap;">
                                <button type="button" class="cm-btn-pill" onclick="cmApplyQuickResponse('Hemos recibido su solicitud y se encuentra en proceso de revisión por el equipo encargado.', 'en_revision')">
                                    Confirmar Recepción
                                </button>
                                <button type="button" class="cm-btn-pill" style="background:#fffbeb; color:#b45309; border:1px solid #fde68a; font-weight:700;" onclick="cmApplyQuickResponse('Se solicita la presencia de la persona que generó el caso en nuestras dependencias u oficinas de atención para validar antecedentes y continuar con la gestión del trámite.', 'pendiente_usuario', false, true)">
                                    🏛️ Solicitar Presencia
                                </button>
                                <button type="button" class="cm-btn-pill" style="background:#eff6ff; color:#0284c7; border:1px solid #bfdbfe; font-weight:700;" onclick="cmApplyQuickResponse('Se solicita adjuntar o remitir documentación complementaria (imágenes JPG/PNG/SVG/BMP o archivo PDF hasta 4 MB) a través de este portal de seguimiento para dar curso a su requerimiento.', 'pendiente_usuario', true)">
                                    📁 Solicitar Documentos
                                </button>
                                <button type="button" class="cm-btn-pill" style="background:#f0fdf4; color:#15803d; border:1px solid #bbf7d0; font-weight:700;" onclick="cmApplyQuickResponse('Su requerimiento ha sido resuelto y procesado exitosamente por nuestra área.', 'resuelto')">
                                    ✅ Finalizar Caso
                                </button>
                            </div>
                        </div>

                        <div class="cm-form-row-compact" style="margin-top: 10px;">
                            <label>
                                <strong><?php _e('Mensaje o Requerimiento Oficial (Visible para el usuario en el portal):', 'contacto-multidestino'); ?></strong>
                            </label>
                            <textarea id="cm-input-case-note" class="cm-apple-textarea" rows="3" placeholder="<?php esc_attr_e('Escribe un comentario, respuesta o instrucción clara...', 'contacto-multidestino'); ?>"></textarea>
                        </div>

                        <div style="margin-top: 10px;">
                            <label for="cm-admin-attach-file" style="font-size:12px;font-weight:600;color:#1d1d1f;display:block;margin-bottom:4px;">
                                📎 <?php _e('Adjuntar Documento o Certificado Oficial (Opcional, máx 4MB):', 'contacto-multidestino'); ?>
                            </label>
                            <input type="file" id="cm-admin-attach-file" name="admin_attachment" accept=".jpg,.jpeg,.png,.svg,.bmp,.pdf" class="cm-apple-input-sm" style="width:100%; box-sizing:border-box; background:#ffffff;" />
                        </div>

                        <div style="margin-top: 10px; display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
                            <div style="flex:1; min-width:180px;">
                                <input type="text" id="cm-input-author-name" class="cm-apple-input-sm" value="<?php echo esc_attr($current_user_name); ?>" placeholder="Firma / Funcionario Responsable" />
                            </div>
                            <label class="cm-check-notify" style="display:inline-flex; align-items:center; gap:6px; cursor:pointer; font-size:12px; font-weight:600;">
                                <input type="checkbox" id="cm-check-notify-user" value="1" <?php echo !empty($case->sender_email) ? 'checked' : 'disabled'; ?> />
                                <span>📧 <?php _e('Notificar por email al solicitante', 'contacto-multidestino'); ?></span>
                            </label>
                        </div>

                        <div style="margin-top: 12px; display:flex; justify-content:flex-end;">
                            <button type="button" class="cm-apple-btn-primary" onclick="cmSaveCaseUpdate(<?php echo esc_attr($case->id); ?>)">
                                💾 <?php _e('Guardar y Actualizar Estado', 'contacto-multidestino'); ?>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- PANEL 2: DERIVACIÓN A OTRA ÁREA -->
                <div id="cm-pane-transfer" class="cm-tab-pane" style="display:none;">
                    <div class="cm-apple-card-sm" style="background: #fdfdfd; border-color: #fcd34d;">
                        <div style="display:flex; align-items:center; gap:8px; margin-bottom:10px;">
                            <span style="font-size:18px;">🔄</span>
                            <div>
                                <strong style="font-size:13px; color:#92400e;"><?php _e('Derivar caso a otro Departamento / Área', 'contacto-multidestino'); ?></strong>
                                <p style="font-size:11.5px; color:#78350f; margin:2px 0 0 0;">
                                    <?php _e('El caso cambiará de área responsable y se notificará automáticamente a los encargados del nuevo departamento.', 'contacto-multidestino'); ?>
                                </p>
                            </div>
                        </div>

                        <div class="cm-form-row-compact">
                            <label><strong><?php _e('Selecciona Área de Destino:', 'contacto-multidestino'); ?></strong></label>
                            <select id="cm-select-transfer-dept" class="cm-apple-select-lg">
                                <option value=""><?php _e('— Seleccionar Área / Departamento —', 'contacto-multidestino'); ?></option>
                                <?php foreach ($departments as $dkey => $dinfo) : 
                                    $dname = is_array($dinfo) ? ($dinfo['name'] ?? $dkey) : $dinfo;
                                    if ($dname === $case->department) continue;
                                ?>
                                    <option value="<?php echo esc_attr($dname); ?>">
                                        🏢 <?php echo esc_html($dname); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="cm-form-row-compact" style="margin-top:10px;">
                            <label><strong><?php _e('Motivo de la Derivación (Quedará registrado en el historial):', 'contacto-multidestino'); ?></strong></label>
                            <textarea id="cm-input-transfer-note" class="cm-apple-textarea" rows="2" placeholder="<?php esc_attr_e('Ej: Corresponde gestionar por inspectoría general según el tipo de solicitud...', 'contacto-multidestino'); ?>"></textarea>
                        </div>

                        <div class="cm-form-footer-compact" style="margin-top:12px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px;">
                            <label class="cm-check-notify" style="display:inline-flex; align-items:center; gap:6px; cursor:pointer; font-size:12px; font-weight:600;">
                                <input type="checkbox" id="cm-check-notify-transfer" value="1" checked />
                                <span>📧 <?php _e('Notificar a los nuevos encargados por correo', 'contacto-multidestino'); ?></span>
                            </label>
                            <button type="button" class="cm-apple-btn-secondary" style="background:#fef3c7; color:#92400e; border-color:#fde68a; font-weight:700;" onclick="cmExecuteTransferCase(<?php echo esc_attr($case->id); ?>)">
                                🔄 <?php _e('Ejecutar Derivación', 'contacto-multidestino'); ?>
                            </button>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Línea de Tiempo Apple Pro -->
            <div class="cm-apple-card-sm" style="margin-top: 14px;">
                <div class="cm-card-sm-title" style="display:flex; justify-content:space-between; align-items:center;">
                    <span>📜 <?php _e('Historial y Trazabilidad del Caso', 'contacto-multidestino'); ?></span>
                    <span style="font-size:11px; font-weight:700; color:#64748b; background:#f1f5f9; padding:2px 8px; border-radius:10px;">
                        <?php echo count($history); ?> <?php _e('eventos', 'contacto-multidestino'); ?>
                    </span>
                </div>
                <div class="cm-timeline-apple">
                    <?php if (!empty($history)) : ?>
                        <?php foreach ($history as $h) : 
                            $h_status = isset($statuses[$h->status]) ? $statuses[$h->status] : null;
                            $action_type = !empty($h->action_type) ? $h->action_type : 'update';
                            $is_applicant = (stripos($h->author_name, 'solicitante') !== false);
                            $is_system = (stripos($h->author_name, 'sistema') !== false);
                            $author_icon = $is_system ? '⚙️' : ($is_applicant ? '👤' : '🏛️');
                        ?>
                            <div class="cm-tl-row">
                                <div class="cm-tl-node <?php echo $is_applicant ? 'cm-node-user' : ($action_type === 'transfer' ? 'cm-node-transfer' : ($action_type === 'deleted' ? 'cm-node-deleted' : ($action_type === 'restored' ? 'cm-node-restored' : ''))); ?>"></div>
                                <div class="cm-tl-box <?php echo $action_type === 'transfer' ? 'cm-box-transfer' : ($action_type === 'deleted' ? 'cm-box-deleted' : ($action_type === 'restored' ? 'cm-box-restored' : ($is_applicant ? 'cm-box-user' : ($action_type === 'doc_request' ? 'cm-box-doc-req' : '')))); ?>">
                                    <div class="cm-tl-top">
                                        <div class="cm-tl-author-wrap">
                                            <span class="cm-tl-author-icon"><?php echo ($action_type === 'deleted' ? '🗑️' : ($action_type === 'restored' ? '♻️' : $author_icon)); ?></span>
                                            <strong class="cm-tl-author-name"><?php echo esc_html($h->author_name); ?></strong>
                                        </div>
                                        <div class="cm-tl-badges-wrap">
                                            <?php if ($action_type === 'deleted') : ?>
                                                <span class="cm-badge-mini" style="background:#fee2e2; color:#b91c1c; border:1px solid #fecaca;">
                                                    🗑️ <?php _e('Enviado a Papelera', 'contacto-multidestino'); ?>
                                                </span>
                                            <?php elseif ($action_type === 'restored') : ?>
                                                <span class="cm-badge-mini" style="background:#dcfce7; color:#15803d; border:1px solid #bbf7d0;">
                                                    ♻️ <?php _e('Caso Recuperado', 'contacto-multidestino'); ?>
                                                </span>
                                            <?php elseif ($action_type === 'transfer') : ?>
                                                <span class="cm-badge-mini" style="background:#fef3c7; color:#92400e; border:1px solid #fde68a;">
                                                    🔄 <?php _e('Derivación de Área', 'contacto-multidestino'); ?>
                                                </span>
                                            <?php elseif ($action_type === 'doc_request') : ?>
                                                <span class="cm-badge-mini" style="background:#e0f2fe; color:#0369a1; border:1px solid #bae6fd;">
                                                    📁 <?php _e('Solicitud de Documentos', 'contacto-multidestino'); ?>
                                                </span>
                                            <?php elseif ($action_type === 'applicant_attachment') : ?>
                                                <span class="cm-badge-mini" style="background:#e0f2fe; color:#0369a1; border:1px solid #bae6fd;">
                                                    📎 <?php _e('Documento Aportado', 'contacto-multidestino'); ?>
                                                </span>
                                            <?php elseif ($h_status) : ?>
                                                <span class="cm-badge-mini" style="background:<?php echo esc_attr($h_status['bg_color']); ?>; color:<?php echo esc_attr($h_status['color']); ?>; border:1px solid <?php echo esc_attr($h_status['border'] ?? '#cbd5e1'); ?>;">
                                                    <?php echo $h_status['icon'] . ' ' . esc_html($h_status['label']); ?>
                                                </span>
                                            <?php endif; ?>
                                            <span class="cm-tl-time">🕒 <?php echo date_i18n('d/m/y H:i', strtotime($h->created_at)); ?></span>
                                        </div>
                                    </div>
                                    <?php 
                                        $clean_h_note = trim(preg_replace('/\[REQ_DOC:\s*.*?\]/i', '', $h->note));
                                    ?>
                                    <div class="cm-tl-desc"><?php echo nl2br(wp_kses_post($clean_h_note)); ?></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <p style="color:#86868b;font-size:12px;margin:0;"><?php _e('Sin eventos registrados.', 'contacto-multidestino'); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php
    $html = ob_get_clean();

    // ══════════════════════════════════════════════════════════════════
    // GENERAR INFORME OFICIAL EN TAMAÑO CARTA (PRINT_HTML)
    // ══════════════════════════════════════════════════════════════════
    $public_case_url = function_exists('cm_get_case_tracker_url') ? cm_get_case_tracker_url($case->ticket_code) : home_url('/?codigo=' . $case->ticket_code);

    ob_start();
    ?>
    <div class="cm-letter-print-dossier">
        <div style="border-bottom:2px solid #0f172a; padding-bottom:12px; margin-bottom:18px; display:flex; justify-content:space-between; align-items:flex-start;">
            <div>
                <div style="font-size:10px; font-weight:800; text-transform:uppercase; letter-spacing:0.08em; color:#64748b;">EXPEDIENTE OFICIAL DE TRAZABILIDAD Y GESTIÓN</div>
                <h1 style="font-size:20px; font-weight:800; color:#0f172a; margin:4px 0 2px 0; text-transform:uppercase;"><?php echo esc_html(get_bloginfo('name')); ?></h1>
                <div style="font-size:12px; color:#475569;">Área Asignada: <strong><?php echo esc_html($case->department ? $case->department : 'General'); ?></strong></div>
            </div>
            <div style="text-align:right;">
                <div style="display:flex; align-items:center; justify-content:flex-end; gap:8px;">
                    <span style="font-family:monospace; font-size:20px; font-weight:800; color:#0284c7;"><?php echo esc_html($case->ticket_code); ?></span>
                    <a href="<?php echo esc_url($public_case_url); ?>" target="_blank" class="cm-print-screen-only" style="font-size:11px; font-weight:700; color:#ffffff; background:#0284c7; padding:3px 9px; border-radius:6px; text-decoration:none; display:inline-flex; align-items:center; gap:4px;" title="<?php esc_attr_e('Ir a la página donde el cliente ve su caso', 'contacto-multidestino'); ?>">
                        🌐 <?php _e('Ir al Caso en la Web', 'contacto-multidestino'); ?> ↗
                    </a>
                </div>
                <div style="font-size:11px; color:#64748b; margin-top:3px;">Emisión: <?php echo date_i18n('d/m/Y - H:i \h\r\s'); ?></div>
                <div style="font-size:11px; font-weight:700; color:#059669; margin-top:2px;">Estado: <?php echo esc_html($statuses[$case->status]['label'] ?? ucfirst($case->status)); ?></div>
            </div>
        </div>

        <!-- 1. Datos del Solicitante -->
        <div style="margin-bottom:16px;">
            <h2 style="font-size:13px; font-weight:800; text-transform:uppercase; border-bottom:1px solid #e2e8f0; padding-bottom:4px; margin-bottom:8px; color:#1e293b;">
                1. INFORMACIÓN DEL SOLICITANTE
            </h2>
            <table style="width:100%; border-collapse:collapse; font-size:12px;">
                <tr>
                    <td style="width:25%; padding:4px 0; color:#64748b; font-weight:600;">Nombre Completo:</td>
                    <td style="width:75%; padding:4px 0; font-weight:700; color:#0f172a;"><?php echo esc_html($case->sender_name ? $case->sender_name : 'No especificado'); ?></td>
                </tr>
                <tr>
                    <td style="padding:4px 0; color:#64748b; font-weight:600;">Correo Electrónico:</td>
                    <td style="padding:4px 0; color:#0f172a;"><?php echo esc_html($case->sender_email); ?></td>
                </tr>
                <?php if ($case->sender_phone) : ?>
                <tr>
                    <td style="padding:4px 0; color:#64748b; font-weight:600;">Teléfono de Contacto:</td>
                    <td style="padding:4px 0; color:#0f172a;"><?php echo esc_html($case->sender_phone); ?></td>
                </tr>
                <?php endif; ?>
                <tr>
                    <td style="padding:4px 0; color:#64748b; font-weight:600;">Fecha de Ingreso:</td>
                    <td style="padding:4px 0; color:#0f172a;"><?php echo date_i18n('d \d\e F, Y - H:i \h\r\s', strtotime($case->created_at)); ?></td>
                </tr>
            </table>
        </div>

        <!-- 2. Detalle de la Solicitud Inicial -->
        <?php if (!empty($submitted_data)) : ?>
        <div style="margin-bottom:16px;">
            <h2 style="font-size:13px; font-weight:800; text-transform:uppercase; border-bottom:1px solid #e2e8f0; padding-bottom:4px; margin-bottom:8px; color:#1e293b;">
                2. ANTECEDENTES Y REQUERIMIENTO DEL FORMULARIO
            </h2>
            <table style="width:100%; border-collapse:collapse; font-size:11.5px; border:1px solid #e2e8f0;">
                <?php foreach ($submitted_data as $lbl => $val) : ?>
                    <tr style="border-bottom:1px solid #f1f5f9;">
                        <td style="width:35%; padding:6px 8px; background:#f8fafc; font-weight:600; color:#475569; border-right:1px solid #e2e8f0;"><?php echo esc_html($lbl); ?></td>
                        <td style="width:65%; padding:6px 8px; color:#0f172a;"><?php echo nl2br(esc_html($val)); ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
        <?php endif; ?>

        <!-- 3. Trazabilidad Cronológica y Derivaciones -->
        <div style="margin-bottom:16px;">
            <h2 style="font-size:13px; font-weight:800; text-transform:uppercase; border-bottom:1px solid #e2e8f0; padding-bottom:4px; margin-bottom:8px; color:#1e293b;">
                3. HISTORIAL DE GESTIÓN, DERIVACIONES Y RESOLUCIÓN
            </h2>
            <?php if (!empty($history)) : ?>
                <table style="width:100%; border-collapse:collapse; font-size:11px; border:1px solid #cbd5e1;">
                    <thead>
                        <tr style="background:#f1f5f9; border-bottom:1.5px solid #cbd5e1;">
                            <th style="padding:6px 8px; text-align:left; width:22%;">Fecha / Hora</th>
                            <th style="padding:6px 8px; text-align:left; width:22%;">Responsable</th>
                            <th style="padding:6px 8px; text-align:left; width:18%;">Estado / Acción</th>
                            <th style="padding:6px 8px; text-align:left; width:38%;">Detalle / Motivo</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($history as $hitem) : 
                            $st_lbl = isset($statuses[$hitem->status]) ? $statuses[$hitem->status]['label'] : ucfirst($hitem->status);
                        ?>
                            <tr style="border-bottom:1px solid #e2e8f0;">
                                <td style="padding:5px 8px; color:#64748b;"><?php echo date_i18n('d/m/Y H:i', strtotime($hitem->created_at)); ?></td>
                                <td style="padding:5px 8px; font-weight:700; color:#0f172a;"><?php echo esc_html($hitem->author_name); ?></td>
                                <td style="padding:5px 8px; color:#0284c7; font-weight:600;"><?php echo esc_html($st_lbl); ?></td>
                                <td style="padding:5px 8px; color:#334155;"><?php echo nl2br(strip_tags($hitem->note, '<a><b><strong><br>')); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else : ?>
                <p style="font-size:11px; color:#94a3b8; margin:0;">Sin eventos registrados.</p>
            <?php endif; ?>
        </div>

        <!-- 4. Registro de Documentos y Anexos -->
        <?php if (!empty($attached_items)) : ?>
        <div style="margin-bottom:16px;">
            <h2 style="font-size:13px; font-weight:800; text-transform:uppercase; border-bottom:1px solid #e2e8f0; padding-bottom:4px; margin-bottom:8px; color:#1e293b;">
                4. DOCUMENTOS Y ANEXOS APORTADOS (<?php echo count($attached_items); ?>)
            </h2>
            <table style="width:100%; border-collapse:collapse; font-size:11px; border:1px solid #e2e8f0;">
                <tr style="background:#f8fafc; font-weight:700; color:#475569; border-bottom:1px solid #e2e8f0;">
                    <td style="padding:5px 8px; width:45%;">Nombre del Documento</td>
                    <td style="padding:5px 8px; width:15%;">Formato</td>
                    <td style="padding:5px 8px; width:20%;">Emisor / Autor</td>
                    <td style="padding:5px 8px; width:20%;">Fecha</td>
                </tr>
                <?php foreach ($attached_items as $a_item) : ?>
                    <tr style="border-bottom:1px solid #f1f5f9;">
                        <td style="padding:5px 8px; font-weight:600; color:#0f172a;">📄 <?php echo esc_html($a_item['name']); ?></td>
                        <td style="padding:5px 8px; color:#0284c7; font-weight:700;"><?php echo strtoupper($a_item['ext']); ?></td>
                        <td style="padding:5px 8px; color:#475569;"><?php echo esc_html($a_item['author']); ?></td>
                        <td style="padding:5px 8px; color:#64748b;"><?php echo esc_html($a_item['date']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
        <?php endif; ?>

        <!-- 5. Firmas y Timbres Oficiales -->
        <div style="margin-top:35px; padding-top:15px; page-break-inside:avoid; display:flex; justify-content:space-between; text-align:center;">
            <div style="width:42%; border-top:1.5px solid #0f172a; padding-top:6px;">
                <div style="font-weight:700; font-size:12px; color:#0f172a;">Firma y Timbre</div>
                <div style="font-size:11px; color:#64748b;"><?php echo esc_html($case->department ? 'Encargado ' . $case->department : 'Funcionario Responsable'); ?></div>
            </div>
            <div style="width:42%; border-top:1.5px solid #0f172a; padding-top:6px;">
                <div style="font-weight:700; font-size:12px; color:#0f172a;">V° B° y Timbre Oficial</div>
                <div style="font-size:11px; color:#64748b;">Dirección / Auditoría Institucional</div>
            </div>
        </div>
    </div>
    <?php
    $print_html = ob_get_clean();

    return array(
        'case'        => $case,
        'ticket_code' => $case->ticket_code,
        'tracker_url' => $public_case_url,
        'html'        => $html,
        'print_html'  => $print_html
    );
}

/**
 * AJAX: Retorna el contenido del Modal Apple Inspector con pestañas de Gestión y Derivación.
 */
function cm_ajax_admin_get_case_detail() {
    check_ajax_referer('cm_contacto_nonce', 'nonce');
    $id = isset($_POST['id']) ? absint($_POST['id']) : 0;
    $res = cm_build_case_inspector_payload($id);
    if (is_wp_error($res)) {
        wp_send_json_error(array('message' => $res->get_error_message()));
    }
    wp_send_json_success($res);
}
add_action('wp_ajax_cm_admin_get_case_detail', 'cm_ajax_admin_get_case_detail');

/**
 * Renderiza la Vista de Pantalla Completa / Página de un Caso en WordPress Admin.
 */
function cm_render_fullpage_case_view($payload) {
    $case = $payload['case'];
    $ticket_code = $payload['ticket_code'];
    $tracker_url = $payload['tracker_url'];
    $statuses = cm_get_case_statuses();
    $status_info = isset($statuses[$case->status]) ? $statuses[$case->status] : array(
        'label'    => ucfirst($case->status),
        'color'    => '#475569',
        'bg_color' => '#f1f5f9',
        'icon'     => '📌'
    );
    ?>
    <div class="wrap cm-apple-wrap cm-full-case-wrap" style="max-width: 1350px; margin: 20px auto;">
        <!-- Cabecera de Navegación Apple Pro -->
        <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px; margin-bottom:18px; padding-bottom:14px; border-bottom:1px solid #e2e8f0;">
            <div style="display:flex; align-items:center; gap:12px; flex-wrap:wrap;">
                <a href="<?php echo admin_url('admin.php?page=cm-form-submissions&tab=inbox'); ?>" class="cm-apple-btn-secondary" style="font-weight:700; display:inline-flex; align-items:center; gap:6px; height:34px; padding:0 14px; text-decoration:none; color:#0f172a; background:#ffffff;">
                    ← <?php _e('Volver a la Bandeja de Casos', 'contacto-multidestino'); ?>
                </a>
                <span class="cm-modal-badge-app" style="font-size:11px;">EXPEDIENTE OFICIAL</span>
                <span id="cm-modal-ticket-title" class="cm-modal-ticket-code" style="font-size:20px; font-weight:800; font-family:monospace; color:#0284c7; background:#e0f2fe; padding:3px 12px; border-radius:6px;">
                    <?php echo esc_html($ticket_code); ?>
                </span>
                <span class="cm-badge-status" id="cm-status-pill-<?php echo esc_attr($case->id); ?>" style="background-color: <?php echo esc_attr($status_info['bg_color']); ?>; color: <?php echo esc_attr($status_info['color']); ?>; border-color: <?php echo esc_attr($status_info['border'] ?? $status_info['color']); ?>;">
                    <?php echo $status_info['icon'] . ' ' . esc_html($status_info['label']); ?>
                </span>
                <a href="<?php echo esc_url($tracker_url); ?>" target="_blank" class="cm-portal-link-btn" style="font-size:12px; font-weight:700; color:#0284c7; background:#e0f2fe; border:1px solid #bae6fd; border-radius:6px; padding:4px 10px; text-decoration:none; display:inline-flex; align-items:center; gap:4px;" title="<?php esc_attr_e('Abrir página pública donde el solicitante ve su caso', 'contacto-multidestino'); ?>">
                    🌐 <?php _e('Ir al Caso en la Web', 'contacto-multidestino'); ?> ↗
                </a>
            </div>
            <div style="display:flex; align-items:center; gap:8px;">
                <button type="button" class="cm-apple-btn-secondary" onclick="cmOpenPrintPreview()" style="font-size:12.5px; font-weight:700; display:inline-flex; align-items:center; gap:5px; padding:6px 14px; background:#ffffff; border-color:#cbd5e1; height:34px;" title="<?php esc_attr_e('Vista Previa e Impresión Oficial en Tamaño Carta', 'contacto-multidestino'); ?>">
                    🖨️ <?php _e('Imprimir Informe (Carta)', 'contacto-multidestino'); ?>
                </button>
            </div>
        </div>

        <!-- Contenedor del Expediente -->
        <div class="cm-full-case-container" style="background:#ffffff; border:1px solid #e2e8f0; border-radius:14px; padding:22px; box-shadow:0 2px 10px rgba(0,0,0,0.03);">
            <?php echo $payload['html']; ?>
        </div>
    </div>

    <!-- MODAL LIGHTBOX DE VISUALIZACIÓN DE DOCUMENTOS/IMÁGENES -->
    <div id="cm-lightbox-modal" class="cm-lightbox-overlay" style="display:none;" onclick="cmCloseDocumentPreview(event)">
        <div class="cm-lightbox-box" onclick="event.stopPropagation();">
            <div class="cm-lightbox-head">
                <span id="cm-lightbox-filename" class="cm-lightbox-title">Documento</span>
                <div class="cm-lightbox-actions">
                    <a id="cm-lightbox-download" href="#" target="_blank" class="cm-apple-btn-secondary" style="font-size:12px; font-weight:700;">
                        ⬇️ <?php _e('Descargar Original', 'contacto-multidestino'); ?>
                    </a>
                    <button type="button" class="cm-apple-modal-close" onclick="cmCloseDocumentPreview()">✕</button>
                </div>
            </div>
            <div class="cm-lightbox-body" id="cm-lightbox-content"></div>
        </div>
    </div>

    <script>
    var cmCurrentCasePrintHtml = <?php echo json_encode($payload['print_html']); ?>;

    window.cmOpenPrintPreview = function() {
        if (!cmCurrentCasePrintHtml) {
            alert('Cargando datos del expediente para imprimir...');
            return;
        }
        
        var ticketCode = '<?php echo esc_js($ticket_code); ?>';
        var printWindow = window.open('', '_blank');
        if (!printWindow) {
            alert('Por favor habilita las ventanas emergentes en tu navegador para abrir el expediente en una página aparte.');
            return;
        }

        var doc = printWindow.document;
        doc.open();
        doc.write('<!DOCTYPE html>' +
            '<html lang="es"><head>' +
            '<meta charset="UTF-8">' +
            '<meta name="viewport" content="width=device-width, initial-scale=1.0">' +
            '<title>Expediente Oficial - ' + ticketCode + '</title>' +
            '<style>' +
            '@page { size: letter portrait; margin: 12mm 15mm; }' +
            '* { box-sizing: border-box; }' +
            'body { margin: 0; padding: 0; background: #525659; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; color: #111827; }' +
            '.cm-print-topbar { position: sticky; top: 0; z-index: 9999; background: #ffffff; padding: 12px 24px; display: flex; align-items: center; justify-content: space-between; box-shadow: 0 2px 10px rgba(0,0,0,0.18); border-bottom: 1px solid #e2e8f0; }' +
            '.cm-print-action-btn { background: #0071e3; color: #ffffff; border: none; border-radius: 8px; padding: 9px 22px; font-size: 14px; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 6px; box-shadow: 0 2px 8px rgba(0,113,227,0.35); transition: background 0.15s ease; }' +
            '.cm-print-action-btn:hover { background: #0077ed; }' +
            '.cm-print-close-btn { background: #f1f5f9; color: #475569; border: 1px solid #cbd5e1; border-radius: 8px; padding: 8px 16px; font-size: 13px; font-weight: 600; cursor: pointer; }' +
            '.cm-print-close-btn:hover { background: #e2e8f0; }' +
            '.cm-dossier-wrap { display: flex; justify-content: center; padding: 28px 16px 60px; }' +
            '.cm-dossier-sheet { width: 100%; max-width: 816px; background: #ffffff; padding: 48px 56px; box-shadow: 0 12px 36px rgba(0,0,0,0.3); border-radius: 4px; min-height: 1056px; }' +
            'table { width: 100%; border-collapse: collapse; }' +
            '@media print {' +
            '  body { background: #ffffff !important; padding: 0 !important; }' +
            '  .cm-print-topbar { display: none !important; }' +
            '  .cm-dossier-wrap { padding: 0 !important; display: block !important; }' +
            '  .cm-dossier-sheet { box-shadow: none !important; padding: 0 !important; border-radius: 0 !important; max-width: 100% !important; min-height: auto !important; }' +
            '}' +
            '</style>' +
            '</head><body>' +
            '<div class="cm-print-topbar">' +
            '  <div style="font-weight:700; font-size:14px; color:#111827;">📄 EXPEDIENTE OFICIAL • ' + ticketCode + '</div>' +
            '  <div style="display:flex; gap:10px; align-items:center;">' +
            '    <button type="button" class="cm-print-action-btn" onclick="window.print()">🖨️ Imprimir Caso Ahora</button>' +
            '    <button type="button" class="cm-print-close-btn" onclick="window.close()">✕ Cerrar Pestaña</button>' +
            '  </div>' +
            '</div>' +
            '<div class="cm-dossier-wrap">' +
            '  <div class="cm-dossier-sheet">' +
            cmCurrentCasePrintHtml +
            '  </div>' +
            '</div>' +
            '</body></html>');
        doc.close();
    };

    window.cmOpenDocumentPreview = function(fileUrl, fileName, isImage) {
        if (isImage) {
            jQuery('#cm-lightbox-filename').text(fileName);
            jQuery('#cm-lightbox-download').attr('href', fileUrl);
            jQuery('#cm-lightbox-content').html('<img src="' + fileUrl + '" class="cm-lightbox-img" alt="' + fileName + '" />');
            jQuery('#cm-lightbox-modal').fadeIn(150).css('display', 'flex');
        } else {
            window.open(fileUrl, '_blank');
        }
    };

    window.cmCloseDocumentPreview = function(e) {
        jQuery('#cm-lightbox-modal').fadeOut(120);
    };

    window.cmSwitchModalTab = function(tab) {
        jQuery('.cm-modal-tab-btn').removeClass('active');
        jQuery('.cm-tab-pane').hide();
        if (tab === 'manage') {
            jQuery('#cm-tab-btn-manage').addClass('active');
            jQuery('#cm-pane-manage').fadeIn(100);
        } else if (tab === 'transfer') {
            jQuery('#cm-tab-btn-transfer').addClass('active');
            jQuery('#cm-pane-transfer').fadeIn(100);
        }
    };

    window.cmToggleDocTitleInput = function(checkbox) {
        if (checkbox.checked) {
            jQuery('#cm-wrap-doc-title').slideDown(120);
            jQuery('#cm-input-doc-title').focus();
        } else {
            jQuery('#cm-wrap-doc-title').slideUp(100);
        }
    };

    window.cmApplyQuickResponse = function(text, status, reqDoc, reqPresence) {
        jQuery('#cm-input-case-note').val(text);
        if (status) {
            jQuery('#cm-select-new-status').val(status);
        }
        if (reqDoc) {
            jQuery('#cm-check-req-doc').prop('checked', true);
            jQuery('#cm-wrap-doc-title').show();
            if (!jQuery('#cm-input-doc-title').val()) {
                jQuery('#cm-input-doc-title').val('Adjuntar documentación solicitada para continuar con el caso');
            }
        }
        if (reqPresence) {
            jQuery('#cm-check-req-presence').prop('checked', true);
        }
    };

    window.cmSaveCaseUpdate = function(submissionId) {
        var newStatus   = jQuery('#cm-select-new-status').val();
        var note        = jQuery('#cm-input-case-note').val();
        var notifyUser  = jQuery('#cm-check-notify-user').is(':checked') ? 1 : 0;
        var reqDoc      = jQuery('#cm-check-req-doc').is(':checked') ? 1 : 0;
        var docTitle    = jQuery('#cm-input-doc-title').val();
        var reqPresence = jQuery('#cm-check-req-presence').is(':checked') ? 1 : 0;
        var authorName  = jQuery('#cm-input-author-name').val();
        var fileInput   = document.getElementById('cm-admin-attach-file');
        
        if (!note && !newStatus && !reqDoc && !reqPresence && (!fileInput || !fileInput.files.length)) {
            alert('Por favor escribe un mensaje o selecciona un estado.');
            return;
        }

        var $btn = jQuery('.cm-apple-btn-primary').prop('disabled', true).text('Guardando...');

        var formData = new FormData();
        formData.append('action', 'cm_admin_update_case');
        formData.append('id', submissionId);
        formData.append('status', newStatus);
        formData.append('note', note);
        formData.append('notify_user', notifyUser);
        formData.append('req_doc', reqDoc);
        formData.append('doc_title', docTitle);
        formData.append('req_presence', reqPresence);
        formData.append('author_name', authorName);
        formData.append('nonce', '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>');

        if (fileInput && fileInput.files.length > 0) {
            formData.append('admin_attachment', fileInput.files[0]);
        }

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(res) {
                $btn.prop('disabled', false).text('💾 Guardar y Actualizar Estado');
                if (res.success) {
                    alert('✓ Expediente actualizado exitosamente.');
                    location.reload();
                } else {
                    alert('Error: ' + (res.data.message || 'No se pudo actualizar el estado.'));
                }
            },
            error: function() {
                $btn.prop('disabled', false).text('💾 Guardar y Actualizar Estado');
                alert('Error de conexión con el servidor.');
            }
        });
    };

    window.cmExecuteTransferCase = function(submissionId) {
        var newDept = jQuery('#cm-select-transfer-dept').val();
        var note    = jQuery('#cm-input-transfer-note').val();
        var notify  = jQuery('#cm-check-notify-transfer').is(':checked') ? 1 : 0;
        var author  = jQuery('#cm-input-author-name').val() || 'Área Responsable';

        if (!newDept) {
            alert('Por favor selecciona el área de destino.');
            return;
        }

        if (!confirm('¿Confirmas que deseas derivar este caso al departamento "' + newDept + '"?')) {
            return;
        }

        var $btn = jQuery('.cm-apple-btn-secondary').prop('disabled', true).text('Derivando...');

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_reassign_case',
                id: submissionId,
                target_department: newDept,
                reason: note,
                author_name: author,
                notify_new_area: notify,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                if (res.success) {
                    alert('✓ Caso derivado exitosamente a ' + newDept);
                    location.reload();
                } else {
                    $btn.prop('disabled', false).text('🔄 Ejecutar Derivación');
                    alert('Error: ' + (res.data.message || 'No se pudo derivar el caso.'));
                }
            },
            error: function() {
                $btn.prop('disabled', false).text('🔄 Ejecutar Derivación');
                alert('Error de conexión con el servidor.');
            }
        });
    };
    </script>
    <?php
}

/**
 * AJAX: Suspende o reactiva un usuario.
 */
function cm_ajax_admin_toggle_user_suspension() {
    check_ajax_referer('cm_contacto_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Permiso denegado.', 'contacto-multidestino')));
    }

    $user_id = isset($_POST['user_id']) ? absint($_POST['user_id']) : 0;
    if (!$user_id || $user_id === get_current_user_id()) {
        wp_send_json_error(array('message' => __('Acción no permitida sobre este usuario.', 'contacto-multidestino')));
    }

    $new_status = cm_toggle_user_suspension($user_id);
    wp_send_json_success(array('status' => $new_status));
}
add_action('wp_ajax_cm_admin_toggle_user_suspension', 'cm_ajax_admin_toggle_user_suspension');



/**
 * AJAX: Deriva un caso a otra área.
 */
function cm_ajax_admin_reassign_case() {
    check_ajax_referer('cm_contacto_nonce', 'nonce');
    if (!current_user_can('edit_posts') && !current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Permiso denegado.', 'contacto-multidestino')));
    }

    $id              = isset($_POST['id']) ? absint($_POST['id']) : 0;
    $target_dept     = isset($_POST['target_department']) ? sanitize_text_field($_POST['target_department']) : '';
    $reason          = isset($_POST['reason']) ? sanitize_textarea_field($_POST['reason']) : '';
    $author_name     = isset($_POST['author_name']) ? sanitize_text_field($_POST['author_name']) : 'Área Responsable';
    $notify_new_area = !empty($_POST['notify_new_area']);
    $notify_user     = !empty($_POST['notify_user']);

    if (!$id || !$target_dept) {
        wp_send_json_error(array('message' => __('Datos incompletos para derivar el caso.', 'contacto-multidestino')));
    }

    $case = cm_get_submission_by_id($id);
    if (!$case) {
        wp_send_json_error(array('message' => __('No se encontró el caso.', 'contacto-multidestino')));
    }

    if (!empty($case->is_deleted)) {
        wp_send_json_error(array('message' => __('Este caso está en la papelera y no puede derivarse. Debes recuperarlo primero.', 'contacto-multidestino')));
    }

    // Verificar permiso si es encargado de área
    if (function_exists('cm_can_view_global_dashboard') && !cm_can_view_global_dashboard()) {
        $user_assigned_dept = function_exists('cm_get_current_user_assigned_department') ? cm_get_current_user_assigned_department() : '';
        if (!empty($user_assigned_dept) && $case->department !== $user_assigned_dept) {
            wp_send_json_error(array('message' => __('No tienes permiso para derivar casos de otra área.', 'contacto-multidestino')));
        }
    }

    $result = cm_reassign_case_department($id, $target_dept, $reason, $author_name, $notify_new_area, $notify_user);

    if ($result) {
        wp_send_json_success(array(
            'message'        => sprintf(__('Caso derivado exitosamente al área de "%s".', 'contacto-multidestino'), $target_dept),
            'new_department' => $target_dept,
        ));
    } else {
        wp_send_json_error(array('message' => __('No se pudo derivar el caso.', 'contacto-multidestino')));
    }
}
add_action('wp_ajax_cm_admin_reassign_case', 'cm_ajax_admin_reassign_case');

/**
 * AJAX: Guarda una actualización de estado / solicitud oficial y envía correo si aplica.
 */
function cm_ajax_admin_update_case() {
    check_ajax_referer('cm_contacto_nonce', 'nonce');
    if (!current_user_can('edit_posts') && !current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Permiso denegado.', 'contacto-multidestino')));
    }

    $id          = isset($_POST['id']) ? absint($_POST['id']) : 0;
    $status      = isset($_POST['status']) ? sanitize_key($_POST['status']) : '';
    $note        = isset($_POST['note']) ? sanitize_textarea_field($_POST['note']) : '';
    $author_name = isset($_POST['author_name']) ? sanitize_text_field($_POST['author_name']) : 'Administración';
    $notify_user = !empty($_POST['notify_user']) ? 1 : 0;
    $req_doc      = !empty($_POST['req_doc']);
    $doc_title    = isset($_POST['doc_title']) ? sanitize_text_field($_POST['doc_title']) : '';
    $req_presence = !empty($_POST['req_presence']);

    $case = cm_get_submission_by_id($id);
    if (!$case) {
        wp_send_json_error(array('message' => __('No se encontró el caso.', 'contacto-multidestino')));
    }

    if (!empty($case->is_deleted)) {
        wp_send_json_error(array('message' => __('Este caso está en la papelera y no puede modificarse. Debes recuperarlo primero.', 'contacto-multidestino')));
    }

    // Verificar permiso si es encargado de área
    if (function_exists('cm_can_view_global_dashboard') && !cm_can_view_global_dashboard()) {
        $user_assigned_dept = function_exists('cm_get_current_user_assigned_department') ? cm_get_current_user_assigned_department() : '';
        if (!empty($user_assigned_dept) && $case->department !== $user_assigned_dept) {
            wp_send_json_error(array('message' => __('No tienes permiso para actualizar casos de otra área.', 'contacto-multidestino')));
        }
    }

    $statuses = cm_get_case_statuses();
    $status_info = isset($statuses[$status]) ? $statuses[$status] : null;

    // Si el encargado solicitó subir documentos
    $action_type = 'admin_update';
    if ($req_doc) {
        $action_type = 'doc_request';
        if ($doc_title) {
            $note = '[REQ_DOC: ' . $doc_title . "]\n" . $note;
        }
    }

    // Procesar archivo adjunto si fue subido por el encargado / administración
    if (!empty($_FILES['admin_attachment']['name'])) {
        $file = $_FILES['admin_attachment'];
        $max_size = 4 * 1024 * 1024;
        $allowed_extensions = array('jpg', 'jpeg', 'png', 'svg', 'bmp', 'pdf');
        $file_info = pathinfo($file['name']);
        $ext = isset($file_info['extension']) ? strtolower($file_info['extension']) : '';

        if ($file['size'] <= $max_size && in_array($ext, $allowed_extensions, true)) {
            if (!function_exists('wp_handle_upload')) {
                require_once(ABSPATH . 'wp-admin/includes/file.php');
            }
            $upload_overrides = array('test_form' => false);
            $movefile = wp_handle_upload($file, $upload_overrides);
            if ($movefile && !isset($movefile['error'])) {
                $file_url = $movefile['url'];
                $orig_name = sanitize_file_name($file['name']);
                $is_image = in_array($ext, array('jpg', 'jpeg', 'png', 'svg', 'bmp'), true);

                $attach_html = sprintf(
                    '<div class="cm-attachment-pill" style="margin-top:6px; display:inline-flex; align-items:center; gap:6px; background:#eff6ff; border:1px solid #bfdbfe; padding:4px 10px; border-radius:8px; font-size:12px;">' .
                        '<span>%s</span>' .
                        '<a href="%s" target="_blank" style="color:#0284c7; font-weight:700; text-decoration:none;">📄 %s</a>' .
                    '</div>',
                    $is_image ? '🖼️' : '📑',
                    esc_url($file_url),
                    esc_html($orig_name)
                );

                $note = ($note ? $note . "\n" : '') . $attach_html;
            }
        }
    }

    if (!$note && $status) {
        $note = sprintf(__('Actualización de estado a: %s', 'contacto-multidestino'), $status_info ? $status_info['label'] : $status);
    }

    // Registrar actualización en base de datos
    $update_id = cm_add_case_update(array(
        'submission_id' => $case->id,
        'ticket_code'   => $case->ticket_code,
        'author_name'   => $author_name,
        'status'        => $status ? $status : $case->status,
        'action_type'   => $action_type,
        'note'          => $note,
        'is_public'     => 1,
        'notified_user' => $notify_user,
    ));

    if (!$update_id) {
        wp_send_json_error(array('message' => __('Error al registrar la actualización en la base de datos.', 'contacto-multidestino')));
    }

    // Enviar notificación por correo si fue seleccionada
    if ($notify_user && !empty($case->sender_email) && is_email($case->sender_email)) {
        $site_name = get_bloginfo('name');
        $site_url  = home_url();
        $status_label = $status_info ? $status_info['label'] : ucfirst($case->status);

        $email_subject = sprintf('[%s] Actualización de su Caso — %s (%s)', $case->ticket_code, $site_name, $status_label);

        // Construir cuerpo del correo de actualización
        $email_body = cm_build_case_update_email_html(array(
            'ticket_code'         => $case->ticket_code,
            'site_name'           => $site_name,
            'site_url'            => $site_url,
            'sender_name'         => $case->sender_name,
            'nombre_departamento' => $case->department,
            'status_label'        => $status_label,
            'status_color'        => $status_info ? $status_info['color'] : '#2563eb',
            'status_icon'         => $status_info ? $status_info['icon'] : '📌',
            'note'                => $note,
            'author_name'         => $author_name,
        ));

        $from_email = get_option('cm_smtp_from', '');
        if (!is_email($from_email)) $from_email = get_option('cm_smtp_user', '');
        if (!is_email($from_email)) $from_email = get_option('admin_email');

        $headers   = array();
        $headers[] = 'Content-Type: text/html; charset=UTF-8';
        $headers[] = 'From: ' . esc_html($site_name) . ' <' . $from_email . '>';

        wp_mail($case->sender_email, $email_subject, $email_body, $headers);
    }

    wp_send_json_success(array(
        'message'      => __('Caso actualizado exitosamente.', 'contacto-multidestino'),
        'status'       => $status,
        'status_label' => $status_info ? $status_info['label'] : $status,
        'status_color' => $status_info ? $status_info['color'] : '#475569',
        'status_bg'    => $status_info ? $status_info['bg_color'] : '#f1f5f9',
        'status_icon'  => $status_info ? $status_info['icon'] : '📌',
    ));
}
add_action('wp_ajax_cm_admin_update_case', 'cm_ajax_admin_update_case');

/**
 * AJAX: Elimina un caso del sistema.
 */
function cm_ajax_admin_delete_case() {
    check_ajax_referer('cm_contacto_nonce', 'nonce');
    if (!current_user_can('edit_posts') && !current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Permiso denegado.', 'contacto-multidestino')));
    }

    $id = isset($_POST['id']) ? absint($_POST['id']) : 0;
    if (!$id) {
        wp_send_json_error(array('message' => __('ID no válido.', 'contacto-multidestino')));
    }

    $current_user = wp_get_current_user();
    $author_name = ($current_user && $current_user->display_name) ? $current_user->display_name : 'Administrador';

    $deleted = cm_delete_submission($id, $author_name);
    if ($deleted) {
        wp_send_json_success(array('message' => __('Caso enviado a la papelera exitosamente.', 'contacto-multidestino')));
    } else {
        wp_send_json_error(array('message' => __('No se pudo mover el caso a la papelera.', 'contacto-multidestino')));
    }
}
add_action('wp_ajax_cm_admin_delete_case', 'cm_ajax_admin_delete_case');

/**
 * AJAX: Restaura un caso desde la papelera (Exclusivo Super Admin).
 */
function cm_ajax_admin_restore_case() {
    check_ajax_referer('cm_contacto_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Permiso denegado. Solo el Administrador puede recuperar casos de la papelera.', 'contacto-multidestino')));
    }

    $id = isset($_POST['id']) ? absint($_POST['id']) : 0;
    if (!$id) {
        wp_send_json_error(array('message' => __('ID no válido.', 'contacto-multidestino')));
    }

    $current_user = wp_get_current_user();
    $author_name = ($current_user && $current_user->display_name) ? $current_user->display_name : 'Super Admin';

    $restored = cm_restore_submission($id, $author_name);
    if ($restored) {
        wp_send_json_success(array('message' => __('Caso recuperado y restaurado a la bandeja activa exitosamente.', 'contacto-multidestino')));
    } else {
        wp_send_json_error(array('message' => __('No se pudo recuperar el caso.', 'contacto-multidestino')));
    }
}
add_action('wp_ajax_cm_admin_restore_case', 'cm_ajax_admin_restore_case');

/**
 * Construye el correo HTML para notificaciones de actualización de casos al usuario.
 */
function cm_build_case_update_email_html($args) {
    $ticket_code         = esc_html($args['ticket_code'] ?? 'CL000000');
    $site_name           = esc_html($args['site_name'] ?? get_bloginfo('name'));
    $site_url            = esc_url($args['site_url'] ?? home_url());
    $sender_name         = esc_html($args['sender_name'] ?? 'Usuario');
    $nombre_departamento = esc_html($args['nombre_departamento'] ?? 'General');
    $status_label        = esc_html($args['status_label'] ?? 'Actualizado');
    $status_color        = esc_attr($args['status_color'] ?? '#2563eb');
    $status_icon         = esc_html($args['status_icon'] ?? '📌');
    $note                = nl2br(esc_html($args['note'] ?? ''));
    $author_name         = esc_html($args['author_name'] ?? 'Área Responsable');
    $date_time           = current_time('d/m/Y H:i') . ' hrs';

    ob_start();
    ?>
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <title><?php echo esc_html($site_name); ?> — Actualización de Caso</title>
    </head>
    <body style="margin:0;padding:0;background-color:#f1f5f9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;color:#1e293b;">
        <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%" style="background-color:#f1f5f9;padding:30px 15px;">
            <tr>
                <td align="center">
                    <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:640px;background-color:#ffffff;border-radius:18px;overflow:hidden;box-shadow:0 10px 30px rgba(15,23,42,0.08);border:1px solid #e2e8f0;">
                        
                        <!-- Encabezado -->
                        <tr>
                            <td style="background:linear-gradient(135deg,#0f172a 0%,#1e1b4b 60%,#312e81 100%);padding:30px 36px;">
                                <div style="display:inline-block;background:rgba(255,255,255,0.15);padding:4px 12px;border-radius:20px;font-size:11px;font-weight:700;color:#c7d2fe;letter-spacing:0.08em;text-transform:uppercase;margin-bottom:10px;">
                                    🔔 ACTUALIZACIÓN OFICIAL DE CASO
                                </div>
                                <h1 style="margin:0;font-size:22px;font-weight:800;color:#ffffff;line-height:1.3;">
                                    <?php echo $site_name; ?>
                                </h1>
                                <p style="margin:6px 0 0 0;font-size:13.5px;color:#e2e8f0;">
                                    El área de <strong><?php echo $nombre_departamento; ?></strong> ha emitido una actualización sobre tu requerimiento.
                                </p>
                            </td>
                        </tr>

                        <!-- Tarjeta del Código y Estado -->
                        <tr>
                            <td style="padding:26px 36px 10px 36px;">
                                <div style="background:#f8faff;border:2px dashed #818cf8;border-radius:14px;padding:18px 20px;text-align:center;">
                                    <div style="font-size:11px;font-weight:700;color:#4338ca;text-transform:uppercase;letter-spacing:0.1em;">
                                        CÓDIGO DE SEGUIMIENTO:
                                    </div>
                                    <div style="font-family:'Courier New',Courier,monospace;font-size:26px;font-weight:900;color:#1e1b4b;letter-spacing:3px;margin:4px 0;">
                                        <?php echo $ticket_code; ?>
                                    </div>
                                    <div style="margin-top:8px;">
                                        <span style="display:inline-block;background-color:<?php echo $status_color; ?>;color:#ffffff;padding:5px 14px;border-radius:20px;font-size:12px;font-weight:700;">
                                            <?php echo $status_icon . ' Estado: ' . $status_label; ?>
                                        </span>
                                    </div>
                                </div>
                            </td>
                        </tr>

                        <!-- Saludo y Mensaje/Solicitud Oficial -->
                        <tr>
                            <td style="padding:15px 36px;">
                                <p style="margin:0 0 14px 0;font-size:14.5px;color:#334155;">
                                    Estimado(a) <strong><?php echo $sender_name; ?></strong>, te informamos las novedades respecto a tu trámite:
                                </p>

                                <!-- Tarjeta del Mensaje Oficial -->
                                <div style="background:#f8fafc;border-left:4px solid <?php echo $status_color; ?>;padding:16px 18px;border-radius:0 10px 10px 0;margin-bottom:16px;">
                                    <div style="font-size:11.5px;font-weight:700;color:#64748b;text-transform:uppercase;margin-bottom:6px;">
                                        📢 Mensaje / Requerimiento del Área (Firmado por <?php echo $author_name; ?> - <?php echo $date_time; ?>):
                                    </div>
                                    <div style="font-size:14px;line-height:1.6;color:#0f172a;">
                                        <?php echo $note; ?>
                                    </div>
                                </div>

                                <?php 
                                $tracking_url = function_exists('cm_get_case_tracker_url') ? esc_url(cm_get_case_tracker_url($ticket_code)) : $site_url;
                                ?>
                                <div style="text-align:center;margin:20px 0 10px 0;">
                                    <a href="<?php echo $tracking_url; ?>" target="_blank" style="display:inline-block;background:#4f46e5;color:#ffffff;text-decoration:none;padding:11px 24px;border-radius:8px;font-size:13.5px;font-weight:700;letter-spacing:0.02em;">
                                        🔍 Ver Estado Completo del Caso en Línea &rarr;
                                    </a>
                                </div>
                            </td>
                        </tr>

                        <!-- Pie del Correo -->
                        <tr>
                            <td style="background-color:#f8fafc;padding:20px 36px;border-top:1px solid #e2e8f0;text-align:center;">
                                <p style="margin:0;font-size:12px;color:#64748b;line-height:1.5;">
                                    Puedes consultar el historial completo ingresando tu código <strong><?php echo $ticket_code; ?></strong> en el portal de seguimiento de nuestro sitio web.
                                </p>
                                <div style="margin-top:10px;font-size:11px;color:#94a3b8;">
                                    Desarrollado con Ingecodex Form • <a href="<?php echo $site_url; ?>" style="color:#4f46e5;text-decoration:none;"><?php echo $site_name; ?></a>
                                </div>
                            </td>
                        </tr>

                    </table>
                </td>
            </tr>
        </table>
    </body>
    </html>
    <?php
    return ob_get_clean();
}
