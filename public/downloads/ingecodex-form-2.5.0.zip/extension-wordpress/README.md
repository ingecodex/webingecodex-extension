# Ingecodex Form — Formulario Multidestino & Centro de Casos

[![WordPress Plugin](https://img.shields.io/badge/WordPress-5.8%2B%20Compatible-blue.svg)](https://wordpress.org)
[![PHP Version](https://img.shields.io/badge/PHP-7.4%20--%208.3-777bb4.svg)](https://php.net)
[![License](https://img.shields.io/badge/License-GPLv2-green.svg)](https://www.gnu.org/licenses/gpl-2.0.html)
[![Security](https://img.shields.io/badge/2FA-TOTP%20RFC%206238-brightgreen.svg)](https://ingecodex.com)

**Ingecodex Form** es una suite profesional para WordPress y Elementor que transforma un formulario de contacto tradicional en un **Centro Integral de Casos, Requerimientos y Seguimiento Institucional**.

Diseñado con estándares de interfaz **Apple Pro (macOS inspired)**, incorpora constructor visual en tiempo real, seguridad avanzada con 2FA TOTP, bandeja de expedientes con derivación por departamentos, papelera con auditoría inmutable, y portal público de consulta de estado por código de ticket.

---

## 📚 Historial Completo de Versiones (Changelog)

### 🛡️ Versión 2.5.0 — *Seguridad 2FA TOTP y Control Avanzado de Cuentas*
- **Motor Criptográfico TOTP RFC 6238:** Generación y validación nativa de códigos dinámicos de 6 dígitos en PHP puro (cero dependencias externas). Compatible con **Google Authenticator, Microsoft Authenticator y Apple Passwords**.
- **Hook de Login en WordPress:** Exigencia obligatoria del código 2FA en `wp-login.php` para cuentas protegidas.
- **Sugerencia Automática de 2FA:** Banner de bienvenida y recomendación de seguridad para nuevos usuarios y encargados.
- **Panel de Gestión y Asignación Directa para Super Admin:**
  - Nueva columna `🛡️ Seguridad 2FA` en la tabla de usuarios con fecha y hora exacta de activación.
  - Botón **`🔓 Quitar 2FA`** para desbloqueo instantáneo en caso de extravío de teléfono.
  - Botón **`📲 Asignar / Generar Nueva Clave y QR`** para que el Administrador configure y muestre el QR directamente al Director o usuario.
  - Botón **`🔄 Restablecer 2FA`** para forzar una nueva vinculación.
- **Tabla Adaptable:** Diseño responsive fluido con scroll horizontal y alineación en una sola fila de todos los controles (`🔑 Clave`, `✏️ Datos`, `🛡️ 2FA`, `⛔ Suspender`).

---

### 🗑️ Versión 2.4.9 — *Papelera, Auditoría Inmutable y Vista en Página Completa*
- **Papelera de Casos (`tab=trash`):** Protección contra borrado accidental; los casos eliminados se trasladan a la papelera.
- **Filtro en Portal Público:** Los casos en papelera quedan ocultos del portal de seguimiento web (`is_deleted = 0`).
- **Restauración en 1 Clic (`♻️ Recuperar`):** Función exclusiva para el Super Administrador.
- **Auditoría Inmutable:** Registro cronológico detallado de qué usuario envió el caso a la papelera y quién lo recuperó con timestamp.
- **Modo Solo Lectura en Papelera:** Bloqueo de cambios de estado y derivaciones en casos eliminados.
- **Vista en Página Completa (`&view_case=ID`):** Visualización de expedientes en página web dedicada además del visor modal flotante.
- **Impresión Oficial Formato Carta:** Estilos CSS de impresión optimizados para exportar fichas oficiales limpias en PDF/Carta.
- **Limpieza de Marcadores Internos:** Ocultamiento automático de etiquetas técnicas como `[REQ_DOC: ...]` en las notas públicas y del panel.

---

### 📥 Versión 2.4.8 — *Bandeja de Casos, Estados y Portal Público de Seguimiento*
- **Bandeja de Entradas Administrativa (`tab=inbox`):** Panel interactivo para visualizar y gestionar todos los envíos.
- **Portal Público de Seguimiento (`[seguimiento_caso]`):** Página de consulta pública donde el solicitante ingresa su código (ej: `CL849201`) para ver el avance de su solicitud en tiempo real.
- **Flujo de Atención por Estados:** *Recibido, En Revisión, En Proceso, Requiere Presencia / Documentación, Resuelto*.
- **Derivación entre Áreas:** Reasignación de casos entre departamentos con motivo justificado.
- **Notificaciones Automáticas por Email:** Envío de correo al solicitante ante cada cambio de estado o solicitud de antecedentes.
- **Base de Datos Relacional:** Creación de tablas MySQL `cm_submissions` y `cm_case_events` para trazabilidad completa.

---

### 🔔 Versión 2.4.7 — *Estabilidad y Compatibilidad Multidestino*
- Optimización en el enrutamiento de correos a múltiples destinatarios separados por coma.
- Ajustes de compatibilidad en widgets dinámicos de Elementor.

---

### 🚀 Versión 2.4.6 — *Envío AJAX Asíncrono y Subida de Archivos*
- Envío inteligente de formularios vía AJAX con spinner animado y validación de campos sin recargar la página.
- Soporte para subida de adjuntos con Dropzone interactivo (drag & drop), validación estricta de extensiones y límite de peso.

---

### 🔊 Versión 2.4.5 — *Alertas Sonoras Profesionales (Web Audio API)*
- Notificaciones acústicas en tiempo real ante la llegada de nuevos casos mediante tonos armónicos sintetizados con Web Audio API (cero archivos de audio externos).
- Alertas visuales flotantes (Toasts estilo Apple).

---

### 👥 Versión 2.4.4 — *Gestor de Roles y Perfiles de Acceso*
- Separación de perfiles: Encargados de Área (acceso exclusivo a sus solicitudes) vs. Directores / Super Administradores (acceso global a todas las áreas y dashboard analítico).
- Módulo de restablecimiento inmediato de contraseñas de usuarios.

---

### 🎨 Versión 2.4.2 — *Modos de Diseño del Contenedor*
- Estilos visuales para el formulario: Vidrio Glassmorphism con desenfoque de fondo, Plano (Flat), Sombra Moderna y 100% Transparente (para integrarse en fondos de Elementor).
- Personalización de bordes y fondos por campo.

---

### ⚙️ Versión 2.4.1 — *Diagnóstico y Avisos SMTP*
- Panel de alerta exclusivo para administradores con acceso directo a la configuración de correo SMTP.
- Verificación de estado de envío de correos salientes.

---

### 🛠️ Versión 2.4.0 — *Constructor Visual Form Studio y Enrutamiento*
- Lanzamiento del Constructor Visual interactivo **Form Studio** con función de arrastrar y soltar (drag & drop) y previsualización responsive en vivo.
- Enrutamiento dinámico de correos por departamento.
- Modal emergente de Términos y Condiciones con aceptación automática.
- Widget oficial para Elementor.

---

## 🛠️ Shortcodes Disponibles

| Shortcode | Descripción |
| :--- | :--- |
| `[Formulario_Ingecodex]` | Inserta el formulario de contacto principal (Recomendado) |
| `[seguimiento_caso]` | Inserta el portal público de consulta de estado por código de ticket |
| `[formulario_ingecodex]` | Alias alternativo del formulario |
| `[consultar_caso]` | Alias alternativo del portal de seguimiento |

---

## 📦 Instalación

1. Descarga el paquete ZIP de la versión deseada (`ingecodex-form-2.5.0.zip`).
2. En tu WordPress, ve a **Plugins > Añadir nuevo plugin > Subir plugin**.
3. Selecciona el archivo ZIP, pulsa **Instalar ahora** y luego **Activar plugin**.
4. Accede a **Ingecodex Form** en la barra lateral para gestionar la bandeja de casos o configurar formularios.

---

## 📄 Licencia

Este proyecto está bajo la licencia **GPLv2 o posterior**.

Desarrollado por **[Ingecodex](https://ingecodex.com)**.
