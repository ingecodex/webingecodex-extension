<?php
if (!defined('ABSPATH')) {
    exit;
}

function cm_add_admin_menu() {
    add_options_page(
        'Formulario de Contacto Multidestino',
        'Formulario Contacto',
        'manage_options',
        'contacto-multidestino',
        'cm_render_admin_page'
    );
}
add_action('admin_menu', 'cm_add_admin_menu');

function cm_save_admin_settings() {
    if (!isset($_POST['cm_settings_nonce']) || !wp_verify_nonce($_POST['cm_settings_nonce'], 'cm_save_settings_action')) {
        return;
    }

    if (!current_user_can('manage_options')) {
        return;
    }

    
    if (isset($_POST['cm_default_email'])) {
        update_option('cm_default_email', sanitize_email($_POST['cm_default_email']));
    }

    if (isset($_POST['cm_max_file_size'])) {
        update_option('cm_max_file_size', absint($_POST['cm_max_file_size']));
    }

    update_option('cm_send_user_confirmation', !empty($_POST['cm_send_user_confirmation']) ? '1' : '0');

    $departamentos = array();
    if (isset($_POST['dep_nombre']) && isset($_POST['dep_email']) && is_array($_POST['dep_nombre'])) {
        for ($i = 0; $i < count($_POST['dep_nombre']); $i++) {
            $nombre = sanitize_text_field($_POST['dep_nombre'][$i]);
            $email  = sanitize_email($_POST['dep_email'][$i]);

            if (!empty($nombre) && !empty($email) && is_email($email)) {
                $departamentos[] = array(
                    'nombre' => $nombre,
                    'email'  => $email
                );
            }
        }
    }
    update_option('cm_departamentos', $departamentos);

    echo '<div class="notice notice-success is-dismissible"><p><strong>' . __('Ajustes guardados correctamente.', 'contacto-multidestino') . '</strong></p></div>';
}

function cm_render_admin_page() {
    if (!current_user_can('manage_options')) {
        return;
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        cm_save_admin_settings();
    }

    $default_email           = get_option('cm_default_email', get_option('admin_email'));
    $max_file_size           = get_option('cm_max_file_size', 5);
    $send_user_confirmation  = get_option('cm_send_user_confirmation', '1');
    $departamentos           = get_option('cm_departamentos', array());
    ?>
    <div class="wrap">
        <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;margin-bottom:12px;">
            <h1 style="margin:0;"><?php _e('Ajustes del Formulario Universal', 'contacto-multidestino'); ?></h1>
            <a href="<?php echo esc_url(admin_url('admin.php?page=cm-universal-installer')); ?>" style="background: linear-gradient(135deg, #0071e3 0%, #0066cc 100%); color: #ffffff !important; font-weight: 700; font-size: 12.5px; padding: 6px 14px; border-radius: 8px; text-decoration: none; display: inline-flex; align-items: center; gap: 6px; box-shadow: 0 2px 6px rgba(0, 113, 227, 0.28);">
                ⚡ Configurar API Universal
            </a>
        </div>
        <p><?php _e('Para insertar el formulario en cualquier página o entrada, utiliza el Shortcode:', 'contacto-multidestino'); ?> <code>[formulario_contacto]</code></p>

        <form method="post" action="">
            <?php wp_nonce_field('cm_save_settings_action', 'cm_settings_nonce'); ?>

            <table class="form-table">
                <tr>
                    <th scope="row"><label for="cm_default_email"><?php _e('Correo Principal / Predeterminado', 'contacto-multidestino'); ?></label></th>
                    <td>
                        <input name="cm_default_email" type="email" id="cm_default_email" value="<?php echo esc_attr($default_email); ?>" class="regular-text" required />
                        <p class="description"><?php _e('Correo donde se enviará el mensaje si no se selecciona ningún departamento específico.', 'contacto-multidestino'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="cm_max_file_size"><?php _e('Tamaño Máximo de Adjuntos (MB)', 'contacto-multidestino'); ?></label></th>
                    <td>
                        <input name="cm_max_file_size" type="number" id="cm_max_file_size" value="<?php echo esc_attr($max_file_size); ?>" min="1" max="50" class="small-text" /> MB
                        <p class="description"><?php _e('Tamaño máximo permitido para los archivos adjuntos en el formulario.', 'contacto-multidestino'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php _e('Envío de Confirmación al Solicitante', 'contacto-multidestino'); ?></th>
                    <td>
                        <label style="font-weight:600; cursor:pointer;">
                            <input name="cm_send_user_confirmation" type="checkbox" value="1" <?php checked($send_user_confirmation, '1'); ?> />
                            <?php _e('Enviar comprobante por correo electrónico al usuario que completó el formulario', 'contacto-multidestino'); ?>
                        </label>
                        <p class="description"><?php _e('Si está desmarcado, no se enviará correo al usuario; en su lugar, se mostrará el código de seguimiento directamente en pantalla para que la persona lo anote.', 'contacto-multidestino'); ?></p>
                    </td>
                </tr>
            </table>

            <h2><?php _e('Departamentos y Correos Asignados', 'contacto-multidestino'); ?></h2>
            <p><?php _e('Configura las personas o áreas de destino (ej. Convivencia, PIE, Dirección) a las cuales el remitente podrá dirigir su consulta.', 'contacto-multidestino'); ?></p>

            <table class="widefat fixed striped" id="cm-departamentos-table" style="max-width: 800px; margin-bottom: 20px;">
                <thead>
                    <tr>
                        <th style="width: 45%;"><?php _e('Nombre del Departamento / Área', 'contacto-multidestino'); ?></th>
                        <th style="width: 45%;"><?php _e('Correo Electrónico Destino', 'contacto-multidestino'); ?></th>
                        <th style="width: 10%;"><?php _e('Acción', 'contacto-multidestino'); ?></th>
                    </tr>
                </thead>
                <tbody id="cm-departamentos-body">
                    <?php if (!empty($departamentos)) : ?>
                        <?php foreach ($departamentos as $dep) : ?>
                            <tr>
                                <td><input type="text" name="dep_nombre[]" value="<?php echo esc_attr($dep['nombre']); ?>" class="widefat" required /></td>
                                <td><input type="email" name="dep_email[]" value="<?php echo esc_attr($dep['email']); ?>" class="widefat" required /></td>
                                <td><button type="button" class="button button-link-delete cm-remove-dep">Eliminar</button></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <tr>
                            <td><input type="text" name="dep_nombre[]" value="General" class="widefat" required /></td>
                            <td><input type="email" name="dep_email[]" value="<?php echo esc_attr($default_email); ?>" class="widefat" required /></td>
                            <td><button type="button" class="button button-link-delete cm-remove-dep">Eliminar</button></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <p>
                <button type="button" class="button button-secondary" id="cm-add-dep-btn"><?php _e('+ Añadir Nuevo Departamento', 'contacto-multidestino'); ?></button>
            </p>

            <?php submit_button(__('Guardar Cambios', 'contacto-multidestino')); ?>
        </form>
    </div>

    <script>
    jQuery(document).ready(function($) {
        $('#cm-add-dep-btn').on('click', function() {
            var newRow = '<tr>' +
                '<td><input type="text" name="dep_nombre[]" placeholder="Ej. Convivencia Escolar" class="widefat" required /></td>' +
                '<td><input type="email" name="dep_email[]" placeholder="ejemplo@colegio.cl" class="widefat" required /></td>' +
                '<td><button type="button" class="button button-link-delete cm-remove-dep">Eliminar</button></td>' +
                '</tr>';
            $('#cm-departamentos-body').append(newRow);
        });

        $(document).on('click', '.cm-remove-dep', function() {
            if ($('#cm-departamentos-body tr').length > 1) {
                $(this).closest('tr').remove();
            } else {
                alert('Debe existir al menos un departamento configurado.');
            }
        });
    });
    </script>
    <?php
}
