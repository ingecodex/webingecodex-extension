<?php
/**
 * Universal Contact Form API — Endpoints REST universales (headless).
 *
 * Expone los endpoints de recepción y seguimiento de casos con CORS habilitado,
 * sin depender de cookies/nonces de WordPress, para que cualquier frontend
 * (React, HTML plano, otro WordPress) pueda consumirlos.
 *
 * Endpoints (namespace configurable, por defecto: universal-form/v1):
 *   POST /wp-json/universal-form/v1/submit       Enviar formulario (FormData o JSON)
 *   GET  /wp-json/universal-form/v1/track        Seguimiento por ?ticket=CM-XXXXXX
 *   POST /wp-json/universal-form/v1/attachment   Adjuntar documento a un caso
 *   GET  /wp-json/universal-form/v1/forms        Esquema público de formularios
 *   GET  /wp-json/universal-form/v1/config       Configuración pública del widget
 *
 * Seguridad:
 *   - Si se configura una clave API (cm_api_key), las mutaciones exigen
 *     el header "X-UF-API-Key" (o ?api_key=). Con clave vacía el modo es
 *     público (mismo comportamiento que AJAX nopriv) con honeypot anti-spam.
 *   - Nunca se exponen correos internos ni datos sensibles de configuración.
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Namespace de la API universal. Dinámico: lo define el dueño del sitio.
 */
function cm_get_api_namespace() {
    $ns = get_option('cm_api_namespace', '');
    if (!empty($ns)) {
        $ns = trim(sanitize_text_field($ns), '/');
    }
    if (empty($ns)) {
        $ns = 'universal-form/v1';
    }
    return $ns;
}

/**
 * Genera un token alfanumérico único de 20 caracteres en mayúsculas (ej: UF9K2P8M4X1W5Z3L0J7Q).
 */
function cm_generate_form_token($length = 20) {
    $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $token = '';
    $max = strlen($chars) - 1;
    for ($i = 0; $i < $length; $i++) {
        $token .= $chars[random_int(0, $max)];
    }
    return $token;
}

/**
 * Obtiene o inicializa el token de 20 caracteres para un formulario.
 */
function cm_get_form_token($form_id = 'principal') {
    $form_id = empty($form_id) ? 'principal' : sanitize_key($form_id);
    $tokens = get_option('cm_form_tokens', array());
    if (empty($tokens[$form_id])) {
        $tokens[$form_id] = cm_generate_form_token(20);
        update_option('cm_form_tokens', $tokens);
    }
    return $tokens[$form_id];
}

/**
 * Retorna todos los tokens registrados indexados por form_id.
 */
function cm_get_all_form_tokens() {
    $tokens = get_option('cm_form_tokens', array());
    if (empty($tokens['principal'])) {
        $tokens['principal'] = cm_get_form_token('principal');
    }
    return $tokens;
}

/**
 * Busca el ID de formulario correspondiente a un token de 20 caracteres.
 */
function cm_get_form_id_by_token($token) {
    $token = strtoupper(trim(sanitize_text_field((string) $token)));
    if (empty($token)) {
        return null;
    }
    $tokens = cm_get_all_form_tokens();
    foreach ($tokens as $fid => $tok) {
        if (strtoupper($tok) === $token) {
            return $fid;
        }
    }
    return null;
}

/**
 * Permite cambiar, rotar o reasignar un token a un formulario (para reconstrucción/persistencia).
 */
function cm_set_form_token($form_id, $token = '') {
    $form_id = empty($form_id) ? 'principal' : sanitize_key($form_id);
    $tokens = get_option('cm_form_tokens', array());
    if (empty($token)) {
        $token = cm_generate_form_token(20);
    } else {
        $token = strtoupper(trim(preg_replace('/[^a-zA-Z0-9]/', '', $token)));
        if (strlen($token) !== 20) {
            $token = substr(str_pad($token, 20, 'X'), 0, 20);
        }
    }
    $tokens[$form_id] = $token;
    update_option('cm_form_tokens', $tokens);
    return $token;
}

/**
 * Headers CORS para todas las respuestas de la API universal.
 */
function cm_api_cors($response, $server, $request) {
    $route = $request->get_route();
    $ns    = cm_get_api_namespace();

    if (is_wp_error($response)) {
        $response = new WP_REST_Response($response, 500);
    }

    if ($route === '/' || strpos($route, '/' . $ns) === 0 || strpos($route, $ns) === 1) {
        $origin = get_option('cm_cors_origin', '*');
        if (empty($origin)) {
            $origin = '*';
        }

        if (is_object($response) && method_exists($response, 'header')) {
            $response->header('Access-Control-Allow-Origin', $origin);
            $response->header('Access-Control-Allow-Credentials', 'false');
            $response->header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
            $response->header('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With, X-WP-Nonce, X-UF-API-Key');
            $response->header('Access-Control-Max-Age', '86400');
            $response->header('X-Universal-Form-API', '1');
        }
    }

    return $response;
}
add_filter('rest_pre_serve_request', 'cm_api_cors', 10, 3);

/**
 * Responde directamente a pre-flight OPTIONS de la API universal.
 */
function cm_api_preflight_router() {
    $ns = cm_get_api_namespace();

    if (isset($_SERVER['REQUEST_METHOD']) && strtoupper($_SERVER['REQUEST_METHOD']) === 'OPTIONS') {
        $path = isset($_SERVER['REQUEST_URI']) ? parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) : '';
        $rest = get_rest_url();
        $rest_path = parse_url(rest_url('/'), PHP_URL_PATH) ?: '/wp-json/';

        // Solo interceptamos peticiones a nuestro namespace
        if (strpos($path, '/' . $ns) !== false) {
            $origin = get_option('cm_cors_origin', '*');
            if (empty($origin)) {
                $origin = '*';
            }

            status_header(200);
            header('Access-Control-Allow-Origin: ' . $origin);
            header('Access-Control-Allow-Credentials: false');
            header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
            header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, X-WP-Nonce, X-UF-API-Key');
            header('Access-Control-Max-Age: 86400');
            header('Content-Type: application/json');
            echo '{}';
            exit;
        }
    }
}
add_action('init', 'cm_api_preflight_router');

/**
 * Acepta peticiones de cualquier origen para la API universal.
 * (Hookeado antes de que WP valide el host de la petición REST.)
 */
function cm_api_allow_any_origin() {
    if (!headers_sent()) {
        @header('X-Robots-Tag: noindex, nofollow');
    }
}

/**
 * Autorización para endpoints de mutación (submit/attachment).
 * - Con clave API configurada: exige X-UF-API-Key correcta o nonce de WP.
 * - Sin clave API: acceso público (honeypot anti-spam protege el envío).
 */
function cm_rest_mutation_permission($request) {
    $api_key = get_option('cm_api_key', '');

    if ($api_key !== '') {
        $provided = $request->get_header('X-UF-API-Key');
        if (!$provided) {
            $provided = $request->get_param('api_key');
        }

        if (is_string($provided) && $provided !== '' && hash_equals($api_key, $provided)) {
            return true;
        }

        $nonce = $request->get_header('X-WP-Nonce');
        if (!$nonce) {
            $nonce = $request->get_param('nonce');
        }

        if ($nonce && wp_verify_nonce($nonce, 'cm_contacto_nonce')) {
            return true;
        }

        return new WP_Error(
            'rest_forbidden',
            __('Falta la clave API o un nonce válido para este envío.', 'contacto-multidestino'),
            array('status' => 403)
        );
    }

    return true;
}

/**
 * Convierte una lista JSON de archivos base64 en estructura $_FILES.
 * Formato del payload JSON: cm_base64_files = [ {"field":"field_adjunto","name":"doc.pdf","data":"<base64>"} ]
 */
function cm_decode_base64_files($payload) {
    $files = array();

    if (empty($payload) || !is_string($payload)) {
        return $files;
    }

    $list = json_decode(stripslashes($payload), true);
    if (!is_array($list)) {
        return $files;
    }

    $tmp_dir = function_exists('wp_tempnam') ? sys_get_temp_dir() : sys_get_temp_dir();

    foreach ($list as $item) {
        if (empty($item['field']) || empty($item['data'])) {
            continue;
        }

        $raw      = preg_replace('/^data:[^;]*;base64,/', '', $item['data']);
        $decoded  = base64_decode($raw, true);

        if ($decoded === false) {
            continue;
        }

        $name = !empty($item['name']) ? sanitize_file_name($item['name']) : ('archivo-' . time() . '.bin');
        $tmp  = tempnam($tmp_dir, 'cmb64_');
        if ($tmp === false) {
            continue;
        }

        file_put_contents($tmp, $decoded);

        $files[$item['field']] = array(
            'name'     => $name,
            'type'     => !empty($item['mime']) ? $item['mime'] : '',
            'tmp_name' => $tmp,
            'error'    => UPLOAD_ERR_OK,
            'size'     => strlen($decoded),
        );
    }

    return $files;
}

/**
 * POST /submit — receptor universal del formulario.
 */
function cm_rest_submit($request) {
    $post_data = $request->get_params();

    // Soporte para token de 20 caracteres del formulario
    $form_token = $request->get_param('form_token') ?: $request->get_param('formToken') ?: $request->get_header('X-UF-Form-Token');
    if (!empty($form_token)) {
        $resolved_form_id = cm_get_form_id_by_token($form_token);
        if ($resolved_form_id) {
            $post_data['form_id'] = $resolved_form_id;
            $post_data['form_token'] = $form_token;
        }
    }

    // Limpiar campos internos/reservados
    unset($post_data['cm_nonce'], $post_data['nonce'], $post_data['api_key'], $post_data['cm_base64_files']);

    $files = (array) $request->get_file_params();
    $files = array_merge($files, cm_decode_base64_files($request->get_param('cm_base64_files')));

    $result = cm_process_submission($post_data, $files);

    // Limpiar temporales de base64 decodificados
    foreach ($files as $f) {
        if (!empty($f['tmp_name']) && strpos($f['tmp_name'], 'cmb64_') !== false && file_exists($f['tmp_name'])) {
            @unlink($f['tmp_name']);
        }
    }

    if (is_wp_error($result)) {
        return new WP_REST_Response(
            array(
                'success' => false,
                'code'    => $result->get_error_code(),
                'message' => $result->get_error_message(),
            ),
            400
        );
    }

    return new WP_REST_Response(array('success' => true, 'data' => $result), 200);
}

/**
 * GET /track — seguimiento de caso por código de ticket y token de formulario.
 */
function cm_rest_track($request) {
    $ticket = $request->get_param('ticket');
    if (!$ticket) {
        $ticket = $request->get_param('codigo');
    }

    $ticket = strtoupper(trim(sanitize_text_field((string) $ticket)));

    if (empty($ticket)) {
        return new WP_REST_Response(
            array('success' => false, 'code' => 'missing_ticket', 'message' => __('Ingresa un código de seguimiento válido.', 'contacto-multidestino')),
            400
        );
    }

    $case = cm_get_submission_by_code($ticket);

    if (!$case) {
        return new WP_REST_Response(
            array('success' => false, 'code' => 'not_found', 'message' => __('No encontramos ningún caso asociado al código ingresado.', 'contacto-multidestino')),
            404
        );
    }

    // Validación de Token del Formulario (si el seguidor se configuró para un formulario específico)
    $form_token = $request->get_param('token') ?: $request->get_param('form_token') ?: $request->get_param('formToken') ?: $request->get_header('X-UF-Form-Token');
    if (!empty($form_token)) {
        $expected_form_id = cm_get_form_id_by_token($form_token);
        if (!$expected_form_id || (!empty($case->form_id) && $case->form_id !== $expected_form_id)) {
            return new WP_REST_Response(
                array(
                    'success' => false,
                    'code'    => 'token_mismatch',
                    'message' => __('El caso consultado no pertenece a este formulario de seguimiento.', 'contacto-multidestino')
                ),
                404
            );
        }
    }

    $history = cm_get_case_updates($case->id, true);

    return new WP_REST_Response(
        array('success' => true, 'data' => cm_get_case_json($case, $history)),
        200
    );
}

/**
 * POST /attachment — el solicitante adjunta documentos a su caso.
 */
function cm_rest_attachment($request) {
    $files = (array) $request->get_file_params();

    $file = array();
    foreach ($files as $f) {
        if ((int)($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
            $file = $f;
            break;
        }
    }

    // Soporte base64 para clientes JSON
    if (empty($file)) {
        $b64 = cm_decode_base64_files($request->get_param('cm_base64_files'));
        if (!empty($b64)) {
            $file = reset($b64);
        }
    }

    $result = cm_handle_public_case_attachment(
        $request->get_param('ticket_code'),
        $request->get_param('comment'),
        $file
    );

    if (!empty($file['tmp_name']) && strpos($file['tmp_name'], 'cmb64_') !== false && file_exists($file['tmp_name'])) {
        @unlink($file['tmp_name']);
    }

    if (is_wp_error($result)) {
        return new WP_REST_Response(array('success' => false, 'code' => $result->get_error_code(), 'message' => $result->get_error_message()), 400);
    }

    return new WP_REST_Response(array('success' => true, 'data' => $result), 200);
}

/**
 * Genera el esquema público (sin correos internos) para el widget.
 */
function cm_build_public_form_schema($schema) {
    if (!is_array($schema) || empty($schema['fields'])) {
        return array('settings' => array(), 'fields' => array());
    }

    $pub_settings = array();
    $settings = isset($schema['settings']) ? $schema['settings'] : array();

    foreach (array(
        'title', 'subtitle', 'primary_color', 'button_text_color', 'bg_color',
        'label_color', 'input_bg_color', 'input_border_color', 'border_radius',
        'shadow', 'card_preset', 'button_text', 'success_msg', 'default_area_name',
        'button_style', 'border_width', 'container_border_color', 'show_header',
    ) as $key) {
        if (isset($settings[$key])) {
            $pub_settings[$key] = $settings[$key];
        }
    }

    $pub_fields = array();
    foreach ($schema['fields'] as $field) {
        $f = array(
            'id'          => isset($field['id']) ? $field['id'] : '',
            'type'        => isset($field['type']) ? $field['type'] : 'text',
            'label'       => isset($field['label']) ? $field['label'] : '',
            'placeholder' => isset($field['placeholder']) ? $field['placeholder'] : '',
            'help'        => isset($field['help']) ? $field['help'] : '',
            'required'    => !empty($field['required']),
            'width'       => isset($field['width']) ? $field['width'] : '100',
        );

        if (in_array($f['type'], array('select', 'department'), true) && !empty($field['options'])) {
            $opts = array();
            foreach ($field['options'] as $opt) {
                if (is_array($opt)) {
                    $nombre = isset($opt['nombre']) ? $opt['nombre'] : (isset($opt['label']) ? $opt['label'] : '');
                    if ($nombre !== '') {
                        $opts[] = array('nombre' => $nombre, 'email' => '');
                    }
                } else {
                    $opts[] = array('nombre' => (string) $opt, 'email' => '');
                }
            }
            $f['options'] = $opts;
        }

        if (in_array($f['type'], array('range'), true) && isset($field['range_unit'])) {
            $f['range_unit'] = $field['range_unit'];
        }

        if (in_array($f['type'], array('terms', 'checkbox'), true)) {
            $f['has_terms'] = !empty($field['has_terms']);
            $f['terms_title'] = !empty($field['terms_title']) ? $field['terms_title'] : '';
            $f['terms_content'] = !empty($field['terms_content']) ? $field['terms_content'] : '';
        }

        $pub_fields[] = $f;
    }

    return array('settings' => $pub_settings, 'fields' => $pub_fields);
}

/**
 * GET /forms — esquema público del formulario activo (para el widget).
 */
function cm_rest_forms($request) {
    $form_id = $request->get_param('form_id');
    $form_token = $request->get_param('token') ?: $request->get_param('form_token') ?: $request->get_param('formToken') ?: $request->get_header('X-UF-Form-Token');

    if (!empty($form_token)) {
        $resolved_id = cm_get_form_id_by_token($form_token);
        if ($resolved_id) {
            $form_id = $resolved_id;
        }
    }

    $schema = null;
    if ($form_id && function_exists('cm_get_form')) {
        $schema = cm_get_form($form_id);
    }
    if (!$schema && function_exists('cm_get_default_form_id')) {
        $schema = cm_get_form(cm_get_default_form_id());
    }

    if (!$schema) {
        $schema = get_option('cm_form_builder_schema', null);
    }
    if (!$schema) {
        $schema = cm_get_default_schema();
    }

    $active_form_id = $form_id ? sanitize_key($form_id) : (function_exists('cm_get_default_form_id') ? cm_get_default_form_id() : 'principal');
    $assigned_token = cm_get_form_token($active_form_id);

    return new WP_REST_Response(
        array(
            'success' => true,
            'data'    => array(
                'form_id'    => $active_form_id,
                'form_token' => $assigned_token,
                'schema'     => cm_build_public_form_schema($schema),
                'namespace'  => cm_get_api_namespace(),
            ),
        ),
        200
    );
}

/**
 * GET /config — configuración pública para el widget embebido.
 */
function cm_rest_config() {
    $config = array(
        'namespace'      => cm_get_api_namespace(),
        'rest_url'       => get_rest_url(null, cm_get_api_namespace() . '/'),
        'default_form_id' => function_exists('cm_get_default_form_id') ? cm_get_default_form_id() : 'principal',
        'tracking_url'   => cm_get_case_tracker_url(),
        'site_name'      => get_bloginfo('name'),
        'site_url'       => home_url(),
        'requires_api_key' => get_option('cm_api_key', '') !== '',
        'cors_origin'    => get_option('cm_cors_origin', '*'),
        'tracker_settings' => function_exists('cm_get_tracker_settings') ? cm_get_tracker_settings() : array(),
    );

    return new WP_REST_Response(array('success' => true, 'data' => $config), 200);
}

/**
 * Registro de rutas REST universales.
 */
function cm_register_universal_routes() {
    $ns = cm_get_api_namespace();

    register_rest_route($ns, '/submit', array(
        'methods'             => 'POST',
        'callback'            => 'cm_rest_submit',
        'permission_callback' => 'cm_rest_mutation_permission',
    ));

    register_rest_route($ns, '/track', array(
        'methods'             => 'GET',
        'callback'            => 'cm_rest_track',
        'permission_callback' => '__return_true',
    ));

    register_rest_route($ns, '/attachment', array(
        'methods'             => 'POST',
        'callback'            => 'cm_rest_attachment',
        'permission_callback' => 'cm_rest_mutation_permission',
    ));

    register_rest_route($ns, '/forms', array(
        'methods'             => 'GET',
        'callback'            => 'cm_rest_forms',
        'permission_callback' => '__return_true',
    ));

    register_rest_route($ns, '/config', array(
        'methods'             => 'GET',
        'callback'            => 'cm_rest_config',
        'permission_callback' => '__return_true',
    ));
}
add_action('rest_api_init', 'cm_register_universal_routes');