<?php
if (!defined('ABSPATH')) {
    exit;
}

class CM_Elementor_Contact_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'formulario_ingecodex';
    }

    public function get_title() {
        return __('Formulario Universal Contact Form', 'contacto-multidestino');
    }

    public function get_icon() {
        return 'eicon-form-horizontal';
    }

    public function get_categories() {
        return array('general', 'basic');
    }

    public function get_keywords() {
        return array(
            'ingecodex',
            'ingecodex.com',
            'formulario ingecodex',
            'contacto ingecodex',
            'formulario',
            'contacto',
            'multidestino',
            'email',
            'pie',
            'convivencia',
            'elementor'
        );
    }

    protected function register_controls() {
        
        $this->start_controls_section(
            'content_section',
            array(
                'label' => __('Configuración del Formulario', 'contacto-multidestino'),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            )
        );

        $this->add_control(
            'form_id',
            array(
                'label'       => __('Formulario a Mostrar', 'contacto-multidestino'),
                'type'        => \Elementor\Controls_Manager::SELECT,
                'default'     => '',
                'options'     => function_exists('cm_get_forms_for_select') ? (array('' => '— Predeterminado ★ —') + cm_get_forms_for_select()) : array('' => '— Predeterminado ★ —'),
                'description' => __('Crea y edita formularios en Universal Contact Form Form (menú WP Admin).', 'contacto-multidestino'),
            )
        );

        $this->add_control(
            'form_title',
            array(
                'label'       => __('Título Personalizado (Opcional)', 'contacto-multidestino'),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => '',
                'placeholder' => __('Dejar vacío para usar el de Universal Contact Form Form', 'contacto-multidestino'),
            )
        );

        $this->add_control(
            'form_subtitle',
            array(
                'label'       => __('Subtítulo Personalizado (Opcional)', 'contacto-multidestino'),
                'type'        => \Elementor\Controls_Manager::TEXTAREA,
                'default'     => '',
                'placeholder' => __('Dejar vacío para usar el de Universal Contact Form Form', 'contacto-multidestino'),
                'rows'        => 3,
            )
        );

        $this->end_controls_section();

        
        $this->start_controls_section(
            'style_section',
            array(
                'label' => __('Estilo Elementor', 'contacto-multidestino'),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'primary_color',
            array(
                'label'     => __('Color Principal de Botón y Enfoque', 'contacto-multidestino'),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#2563eb',
                'selectors' => array(
                    '{{WRAPPER}} .cm-form-container' => '--cm-primary: {{VALUE}};',
                ),
            )
        );

        $this->add_control(
            'card_bg',
            array(
                'label'     => __('Fondo del Formulario', 'contacto-multidestino'),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#ffffff',
                'selectors' => array(
                    '{{WRAPPER}} .cm-form-container' => 'background-color: {{VALUE}};',
                ),
            )
        );

        $this->add_control(
            'border_radius',
            array(
                'label'      => __('Bordes Redondeados (px)', 'contacto-multidestino'),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => array('px'),
                'range'      => array(
                    'px' => array(
                        'min' => 0,
                        'max' => 30,
                    ),
                ),
                'default'    => array(
                    'unit' => 'px',
                    'size' => 16,
                ),
                'selectors'  => array(
                    '{{WRAPPER}} .cm-form-container' => 'border-radius: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .cm-input, {{WRAPPER}} .cm-select, {{WRAPPER}} .cm-textarea, {{WRAPPER}} .cm-submit-button' => 'border-radius: calc({{SIZE}}{{UNIT}} / 1.5);',
                ),
            )
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        
        echo '<div class="cm-elementor-wrapper">';
        if (!empty($settings['form_title'])) {
            echo '<h3 class="cm-elementor-title">' . esc_html($settings['form_title']) . '</h3>';
        }
        if (!empty($settings['form_subtitle'])) {
            echo '<p class="cm-elementor-subtitle">' . esc_html($settings['form_subtitle']) . '</p>';
        }
        
        $shortcode   = '[Formulario_Universal Contact Form';
        $widget_form = !empty($settings['form_id']) ? $settings['form_id'] : (function_exists('cm_get_default_form_id') ? cm_get_default_form_id() : '');
        if ($widget_form) {
            $shortcode .= ' id="' . esc_attr($widget_form) . '"';
        }
        $shortcode .= ']';

        echo do_shortcode($shortcode);
        echo '</div>';
    }
}

class CM_Elementor_Tracker_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'seguimiento_ingecodex';
    }

    public function get_title() {
        return __('Seguimiento de Caso', 'contacto-multidestino');
    }

    public function get_icon() {
        return 'eicon-search';
    }

    public function get_categories() {
        return array('general', 'basic');
    }

    public function get_keywords() {
        return array('ingecodex', 'seguimiento', 'caso', 'tracker', 'ticket');
    }

    protected function register_controls() {
        $this->start_controls_section(
            'content_section',
            array(
                'label' => __('Seguimiento de Caso', 'contacto-multidestino'),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            )
        );
        $this->add_control(
            'notice',
            array(
                'type' => \Elementor\Controls_Manager::RAW_HTML,
                'raw' => __('Este widget mostrará el buscador de casos para los usuarios.', 'contacto-multidestino'),
            )
        );
        $this->end_controls_section();
    }

    protected function render() {
        echo '<div class="cm-tracker-elementor-wrapper">';
        echo do_shortcode('[seguimiento_caso]');
        echo '</div>';
    }
}
