<?php
/**
 * Universal Contact Form API — Instalador / Integración Universal
 * Página de administración que:
 *   1. Verifica la instalación (tablas, endpoints, CORS).
 *   2. Permite configurar namespace, origen CORS y clave API.
 *   3. Administra los Tokens de 20 caracteres por formulario (rotación y reconstrucción).
 *   4. Genera los snippets del widget (formulario y seguidor de procesos) con 1 clic.
 */

if (!defined('ABSPATH')) {
    exit;
}

function cm_get_api_base_url() {
    return get_rest_url(null, cm_get_api_namespace() . '/');
}

function cm_generate_random_key($length = 32) {
    return substr(str_replace(array('+', '/', '='), '', base64_encode(random_bytes($length))), 0, $length);
}

function cm_universal_installer_handle_post() {
    if (!isset($_POST['cm_universal_nonce']) || !wp_verify_nonce($_POST['cm_universal_nonce'], 'cm_universal_save')) {
        return;
    }
    if (!current_user_can('manage_options')) {
        return;
    }

    foreach (array('cm_api_namespace', 'cm_cors_origin', 'cm_footer_credit', 'cm_credit_text', 'cm_credit_url', 'cm_tracking_page_url') as $opt) {
        if (isset($_POST[$opt])) {
            update_option($opt, sanitize_text_field($_POST[$opt]));
        }
    }

    if (isset($_POST['cm_api_key_action'])) {
        update_option('cm_api_key', cm_generate_random_key(32));
    } elseif (isset($_POST['cm_api_key_clear'])) {
        update_option('cm_api_key', '');
    }

    // Rotar o reasignar token de formulario
    if (!empty($_POST['cm_action_rotate_token']) && !empty($_POST['target_form_id'])) {
        $fid = sanitize_key($_POST['target_form_id']);
        $new_tok = cm_set_form_token($fid);
        echo '<div class="notice notice-success is-dismissible"><p><strong>' . sprintf(__('Nuevo token de 20 caracteres generado para "%s": %s', 'contacto-multidestino'), esc_html($fid), '<code>' . esc_html($new_tok) . '</code>') . '</strong></p></div>';
    } elseif (!empty($_POST['cm_action_set_custom_token']) && !empty($_POST['target_form_id']) && !empty($_POST['custom_token_val'])) {
        $fid = sanitize_key($_POST['target_form_id']);
        $custom_tok = cm_set_form_token($fid, $_POST['custom_token_val']);
        echo '<div class="notice notice-success is-dismissible"><p><strong>' . sprintf(__('Token personalizado de 20 caracteres reasignado a "%s": %s', 'contacto-multidestino'), esc_html($fid), '<code>' . esc_html($custom_tok) . '</code>') . '</strong></p></div>';
    } else {
        echo '<div class="notice notice-success is-dismissible"><p><strong>' . __('Ajustes de integración guardados correctamente.', 'contacto-multidestino') . '</strong></p></div>';
    }
}

function cm_render_universal_installer_page() {
    if (!current_user_can('manage_options')) {
        return;
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        cm_universal_installer_handle_post();
    }

    $ns           = cm_get_api_namespace();
    $api_base     = cm_get_api_base_url();
    $cors_origin  = get_option('cm_cors_origin', '*');
    $api_key      = get_option('cm_api_key', '');
    $namespace    = get_option('cm_api_namespace', 'universal-form/v1');
    $credit_text  = get_option('cm_credit_text', get_bloginfo('name'));
    $credit_url   = get_option('cm_credit_url', home_url());
    $footer_credit = get_option('cm_footer_credit', '');
    $tracking_page = get_option('cm_tracking_page_url', '');
    $site_url     = home_url();
    $widget_url   = cm_widget_file_url();

    global $wpdb;
    $tables_ok = ($wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}cm_form_submissions'") === "{$wpdb->prefix}cm_form_submissions")
              && ($wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}cm_case_updates'") === "{$wpdb->prefix}cm_case_updates");

    $dashboard_url = admin_url('admin.php?page=cm-form-submissions');

    // Obtener tokens de formularios
    $form_tokens = cm_get_all_form_tokens();
    $primary_token = cm_get_form_token('principal');

    $form_snippet = '<div id="universal-contact-form"></div>' . "\n" .
        '<script>' . "\n" .
        "window.UF_CONFIG = {\n" .
        "  apiBase: \"" . esc_js($api_base) . "\",\n" .
        "  mode: \"form\",\n" .
        "  formToken: \"" . esc_js($primary_token) . "\"\n" .
        ($api_key !== '' ? "  ,\n  apiKey: \"" . esc_js($api_key) . "\"\n" : "\n") .
        "};\n" .
        '</script>' . "\n" .
        '<script src="' . esc_js($widget_url) . '" defer></script>';

    $tracker_snippet = '<div data-uf-widget="tracker"></div>' . "\n" .
        '<script>' . "\n" .
        "window.UF_CONFIG = {\n" .
        "  apiBase: \"" . esc_js($api_base) . "\",\n" .
        "  mode: \"tracker\",\n" .
        "  formToken: \"" . esc_js($primary_token) . "\"\n" .
        "};\n" .
        '</script>' . "\n" .
        '<script src="' . esc_js($widget_url) . '" defer></script>';
    ?>
    <style>
        #wpbody .uf-code-box,
        #wpcontent .uf-code-box,
        textarea.uf-code-box {
            width: 100% !important;
            max-width: 100% !important;
            font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace !important;
            font-size: 13px !important;
            line-height: 1.6 !important;
            background: #090d16 !important;
            color: #38bdf8 !important;
            border-radius: 0 0 12px 12px !important;
            padding: 16px 18px !important;
            box-sizing: border-box !important;
            border: 1px solid #1e293b !important;
            border-top: none !important;
            resize: vertical !important;
            box-shadow: inset 0 2px 12px rgba(0,0,0,0.6) !important;
            text-shadow: 0 0 1px rgba(56,189,248,0.2) !important;
            display: block !important;
        }
        .uf-terminal-bar {
            background: #1e293b;
            border: 1px solid #334155;
            border-bottom: 1px solid #0f172a;
            border-radius: 12px 12px 0 0;
            padding: 10px 16px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .uf-terminal-dots {
            display: flex;
            gap: 6px;
            align-items: center;
        }
        .uf-dot { width: 10px; height: 10px; border-radius: 50%; display: inline-block; }
        .uf-dot-red { background: #ef4444; }
        .uf-dot-yellow { background: #f59e0b; }
        .uf-dot-green { background: #10b981; }
        .uf-btn-copy {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%);
            color: #ffffff !important;
            border: none;
            border-radius: 8px;
            padding: 8px 16px;
            font-weight: 700;
            cursor: pointer;
            font-size: 13px;
            transition: all 0.2s ease;
            box-shadow: 0 2px 8px rgba(2,132,199,0.3);
        }
        .uf-btn-copy:hover {
            background: linear-gradient(135deg, #0369a1 0%, #075985 100%);
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(2,132,199,0.4);
        }
        .uf-token-badge {
            font-family: ui-monospace, SFMono-Regular, Menlo, monospace !important;
            font-weight: 800 !important;
            background: #090d16 !important;
            color: #38bdf8 !important;
            padding: 6px 14px !important;
            border-radius: 8px !important;
            border: 1.5px solid #0284c7 !important;
            font-size: 14px !important;
            letter-spacing: 0.8px !important;
            display: inline-block;
            box-shadow: 0 2px 6px rgba(2,132,199,0.15);
        }
        .uf-card-section {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 16px;
            padding: 24px 26px;
            margin-bottom: 24px;
            box-shadow: 0 4px 20px rgba(15,23,42,0.04);
        }
    </style>

    <div class="wrap" style="max-width: 960px;">
        <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;margin-bottom:12px;padding-top:10px;">
            <h1 style="margin:0;font-size:24px;font-weight:800;color:#0f172a;">⚡ Generador Universal — Tokens & Scripts</h1>
        </div>
        <p style="color:#475569;font-size:14px;margin-bottom:24px;line-height:1.6;">
            Cada formulario cuenta con su propio <strong>Token alfanumérico único de 20 caracteres</strong>. 
            Puedes inyectar el formulario en cualquier web externa (React, HTML plano u otro WordPress) y enlazar un <strong>Seguidor de Procesos Independiente</strong> simplemente usando el token.
        </p>

        <!-- Bloque 1: Gestión de Tokens por Formulario -->
        <div class="uf-card-section">
            <h2 style="margin:0 0 8px 0;font-size:18px;font-weight:800;color:#0f172a;display:flex;align-items:center;gap:8px;">
                <span>🔑</span> Tokens de 20 Dígitos por Formulario
            </h2>
            <p style="margin:0 0 16px 0;color:#64748b;font-size:13px;">
                El token identifica a cada formulario de forma independiente. Si reconstruyes un formulario borrado, puedes reasignarle su token original para restaurar la continuidad de los envíos a las mismas áreas.
            </p>

            <table class="widefat striped" style="border-radius:10px;overflow:hidden;border:1px solid #e2e8f0;margin-bottom:16px;">
                <thead>
                    <tr style="background:#f8fafc;">
                        <th style="padding:12px 16px;font-weight:700;">Formulario / ID</th>
                        <th style="padding:12px 16px;font-weight:700;">Token Único (20 Dígitos)</th>
                        <th style="padding:12px 16px;font-weight:700;">Acciones Rápidas</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($form_tokens as $fid => $tok) : ?>
                        <tr>
                            <td style="vertical-align:middle;padding:14px 16px;">
                                <strong style="font-size:14px;color:#0f172a;"><?php echo esc_html(ucfirst($fid)); ?></strong>
                                <br><small style="color:#64748b;font-family:monospace;">id: <?php echo esc_html($fid); ?></small>
                            </td>
                            <td style="vertical-align:middle;padding:14px 16px;">
                                <span class="uf-token-badge" id="tok_val_<?php echo esc_attr($fid); ?>"><?php echo esc_html($tok); ?></span>
                                <button type="button" class="button button-small" style="margin-left:8px;font-weight:600;" onclick="ufCopyText('<?php echo esc_js($tok); ?>', this)">📋 Copiar</button>
                            </td>
                            <td style="vertical-align:middle;padding:14px 16px;">
                                <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
                                    <button type="button" class="button button-primary button-small" style="font-weight:700;background:#0071e3;border-color:#0071e3;" onclick="ufLoadFormSnippet('<?php echo esc_js($fid); ?>', '<?php echo esc_js($tok); ?>')">⚡ Ver Script</button>
                                    <button type="button" class="button button-secondary button-small" style="font-weight:600;" onclick="ufLoadTrackerSnippet('<?php echo esc_js($tok); ?>')">🔍 Crear Seguidor</button>
                                    
                                    <form method="post" style="display:inline;" onsubmit="return confirm('¿Rotar el token de este formulario? El script anterior dejará de recibir datos.');">
                                        <?php wp_nonce_field('cm_universal_save', 'cm_universal_nonce'); ?>
                                        <input type="hidden" name="target_form_id" value="<?php echo esc_attr($fid); ?>" />
                                        <button type="submit" name="cm_action_rotate_token" value="1" class="button button-small" title="Genera un token nuevo">🔄 Rotar</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <!-- Reasignar Token Manualmente -->
            <details style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:12px 16px;">
                <summary style="cursor:pointer;font-weight:700;color:#334155;font-size:13px;">✏️ Reasignar o Restaurar un Token Manual de 20 Dígitos</summary>
                <form method="post" style="margin-top:14px;display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
                    <?php wp_nonce_field('cm_universal_save', 'cm_universal_nonce'); ?>
                    <input type="text" name="target_form_id" value="principal" placeholder="ID Formulario (ej: principal)" style="width:160px;" required />
                    <input type="text" name="custom_token_val" maxlength="20" placeholder="Token de 20 dígitos (ej: UF7K9Q2M8P4X1W5Z3L0J)" style="width:280px;font-family:monospace;text-transform:uppercase;font-weight:700;" required />
                    <button type="submit" name="cm_action_set_custom_token" value="1" class="button button-secondary">Guardar Token</button>
                </form>
            </details>
        </div>

        <!-- Bloque 2: Generador de Script del Formulario -->
        <div class="uf-card-section">
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:10px;">
                <div>
                    <h3 style="margin:0;font-size:17px;font-weight:800;color:#0f172a;">📋 Script del Formulario (Listo para Copiar y Pegar)</h3>
                    <p style="margin:4px 0 0 0;color:#64748b;font-size:13px;">Pega este fragmento en tu web (React, HTML plano u otro WordPress).</p>
                </div>
                <button type="button" class="uf-btn-copy" onclick="ufCopyTextarea('uf_form_snippet_box', this)">📋 Copiar Script</button>
            </div>

            <!-- Terminal Window -->
            <div style="margin-top:14px;">
                <div class="uf-terminal-bar">
                    <div class="uf-terminal-dots">
                        <span class="uf-dot uf-dot-red"></span>
                        <span class="uf-dot uf-dot-yellow"></span>
                        <span class="uf-dot uf-dot-green"></span>
                        <span style="font-family:monospace;font-size:11px;color:#94a3b8;margin-left:8px;">formulario-universal.html</span>
                    </div>
                    <span style="font-size:11px;color:#38bdf8;font-weight:700;font-family:monospace;">JavaScript Widget</span>
                </div>
                <textarea id="uf_form_snippet_box" readonly rows="8" class="uf-code-box"><?php echo esc_textarea($form_snippet); ?></textarea>
            </div>
        </div>

        <!-- Bloque 3: Generador de Seguidor de Procesos Independiente -->
        <div class="uf-card-section">
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:10px;">
                <div>
                    <h3 style="margin:0;font-size:17px;font-weight:800;color:#0f172a;">🔍 Seguidor de Procesos Independiente (Tracker de Casos)</h3>
                    <p style="margin:4px 0 0 0;color:#64748b;font-size:13px;">Rastrea exclusivamente los tickets generados por este formulario.</p>
                </div>
                <button type="button" class="uf-btn-copy" onclick="ufCopyTextarea('uf_tracker_snippet_box', this)">📋 Copiar Script del Seguidor</button>
            </div>

            <div style="display:flex;align-items:center;gap:10px;margin:14px 0 16px 0;background:#f8fafc;padding:12px 16px;border-radius:10px;border:1px solid #e2e8f0;flex-wrap:wrap;">
                <label for="uf_tracker_token_input" style="font-weight:800;color:#0f172a;font-size:13px;">Token de 20 dígitos vinculado:</label>
                <input type="text" id="uf_tracker_token_input" value="<?php echo esc_attr($primary_token); ?>" maxlength="20" style="width:240px;font-family:monospace;font-weight:800;letter-spacing:0.8px;text-transform:uppercase;color:#0369a1;background:#fff;border:1.5px solid #0284c7;border-radius:8px;padding:6px 10px;" oninput="ufUpdateTrackerCode()" />
                <span style="font-size:12px;color:#64748b;">(Cambia el código para vincular a otro formulario)</span>
            </div>

            <!-- Terminal Window -->
            <div>
                <div class="uf-terminal-bar">
                    <div class="uf-terminal-dots">
                        <span class="uf-dot uf-dot-red"></span>
                        <span class="uf-dot uf-dot-yellow"></span>
                        <span class="uf-dot uf-dot-green"></span>
                        <span style="font-family:monospace;font-size:11px;color:#94a3b8;margin-left:8px;">seguidor-procesos.html</span>
                    </div>
                    <span style="font-size:11px;color:#38bdf8;font-weight:700;font-family:monospace;">JavaScript Tracker</span>
                </div>
                <textarea id="uf_tracker_snippet_box" readonly rows="8" class="uf-code-box"><?php echo esc_textarea($tracker_snippet); ?></textarea>
            </div>
        </div>

        <!-- Bloque 4: Estado y Ajustes del Servidor -->
        <div style="display:flex;gap:20px;flex-wrap:wrap;margin-bottom:20px;">
            <div style="flex:1;min-width:320px;background:#ffffff;border:1px solid #e2e8f0;border-radius:16px;padding:22px 24px;box-shadow:0 4px 20px rgba(15,23,42,0.04);">
                <h3 style="margin:0 0 12px 0;font-size:16px;font-weight:800;color:#0f172a;">🧪 Estado del Servidor</h3>
                <table class="widefat striped" style="border:1px solid #e2e8f0;border-radius:8px;overflow:hidden;">
                    <tr><td>Tablas de base de datos</td><td><?php echo $tables_ok ? '<span style="color:#16a34a;font-weight:800;">✓ OK</span>' : '<span style="color:#dc2626;font-weight:800;">✗ Error</span>'; ?></td></tr>
                    <tr><td>Endpoint Envíos (POST)</td><td><code style="color:#0284c7;"><?php echo esc_html($api_base . 'submit'); ?></code></td></tr>
                    <tr><td>Endpoint Seguimiento (GET)</td><td><code style="color:#0284c7;"><?php echo esc_html($api_base . 'track'); ?></code></td></tr>
                    <tr><td>CORS</td><td><span style="color:#16a34a;font-weight:800;">Habilitado</span> (<?php echo esc_html($cors_origin); ?>)</td></tr>
                </table>
                <p style="margin:16px 0 0 0;">
                    <a class="button button-primary" style="font-weight:700;background:#0071e3;" href="<?php echo esc_url($dashboard_url); ?>">📥 Abrir Bandeja de Casos</a>
                </p>
            </div>

            <div style="flex:1;min-width:320px;background:#ffffff;border:1px solid #e2e8f0;border-radius:16px;padding:22px 24px;box-shadow:0 4px 20px rgba(15,23,42,0.04);">
                <h3 style="margin:0 0 12px 0;font-size:16px;font-weight:800;color:#0f172a;">🔧 Ajustes Globales</h3>
                <form method="post" action="">
                    <?php wp_nonce_field('cm_universal_save', 'cm_universal_nonce'); ?>
                    <table class="form-table" style="max-width:100%;">
                        <tr>
                            <th scope="row"><label for="cm_cors_origin" style="font-weight:700;">CORS Origin</label></th>
                            <td><input name="cm_cors_origin" id="cm_cors_origin" type="text" value="<?php echo esc_attr($cors_origin); ?>" class="regular-text" /></td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="cm_credit_text" style="font-weight:700;">Texto de Crédito</label></th>
                            <td><input name="cm_credit_text" id="cm_credit_text" type="text" value="<?php echo esc_attr($credit_text); ?>" class="regular-text" /></td>
                        </tr>
                    </table>
                    <?php submit_button(__('Guardar ajustes', 'contacto-multidestino')); ?>
                </form>
            </div>
        </div>
    </div>

    <script>
        var API_BASE = <?php echo json_encode($api_base); ?>;
        var WIDGET_URL = <?php echo json_encode($widget_url); ?>;

        function ufCopyText(text, btn) {
            navigator.clipboard.writeText(text).then(function() {
                var old = btn.textContent;
                btn.textContent = '✓ ¡Copiado!';
                btn.style.color = '#10b981';
                setTimeout(function() { btn.textContent = old; btn.style.color = ''; }, 2000);
            });
        }

        function ufCopyTextarea(id, btn) {
            var el = document.getElementById(id);
            if (!el) return;
            el.select();
            document.execCommand('copy');
            var old = btn.textContent;
            btn.textContent = '✓ ¡Script Copiado!';
            btn.style.background = 'linear-gradient(135deg, #10b981 0%, #059669 100%)';
            setTimeout(function() {
                btn.textContent = old;
                btn.style.background = '';
            }, 2000);
        }

        function ufLoadFormSnippet(formId, token) {
            var code = '<div id="universal-contact-form"></div>\n' +
                '<script>\n' +
                'window.UF_CONFIG = {\n' +
                '  apiBase: ' + JSON.stringify(API_BASE) + ',\n' +
                '  mode: "form",\n' +
                '  formToken: ' + JSON.stringify(token) + '\n' +
                '};\n' +
                '<\/script>\n' +
                '<script src="' + WIDGET_URL + '" defer><\/script>';
            var box = document.getElementById('uf_form_snippet_box');
            if (box) {
                box.value = code;
                box.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        }

        function ufLoadTrackerSnippet(token) {
            var input = document.getElementById('uf_tracker_token_input');
            if (input) {
                input.value = token;
                ufUpdateTrackerCode();
                input.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        }

        function ufUpdateTrackerCode() {
            var input = document.getElementById('uf_tracker_token_input');
            var tok = input ? input.value.trim().toUpperCase() : '';
            var code = '<div data-uf-widget="tracker"></div>\n' +
                '<script>\n' +
                'window.UF_CONFIG = {\n' +
                '  apiBase: ' + JSON.stringify(API_BASE) + ',\n' +
                '  mode: "tracker",\n' +
                '  formToken: ' + JSON.stringify(tok) + '\n' +
                '};\n' +
                '<\/script>\n' +
                '<script src="' + WIDGET_URL + '" defer><\/script>';
            var box = document.getElementById('uf_tracker_snippet_box');
            if (box) box.value = code;
        }
    </script>
    <?php
}