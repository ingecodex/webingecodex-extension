<?php
/**
 * Universal Contact Form API — Esquema de formulario por defecto.
 * Sin marcas hardcodeadas: los correos de destino parten del admin_email del sitio.
 */

if (!defined('ABSPATH')) {
    exit;
}

function cm_get_default_schema() {
    $default_email = get_option('cm_default_email', get_option('admin_email'));

    return array(
        'settings' => array(
            'show_header'            => true,
            'title'                  => 'Formulario de Contacto',
            'subtitle'               => 'Selecciona el departamento al que deseas dirigir tu mensaje.',
            'primary_color'          => '#0071e3',
            'button_text_color'      => '#ffffff',
            'bg_color'               => '#ffffff',
            'label_color'            => '#0f172a',
            'input_bg_color'         => '#f8fafc',
            'input_border_color'     => '#e2e8f0',
            'border_radius'          => '12',
            'shadow'                 => 'md',
            'card_preset'            => 'modern',
            'border_width'           => '1',
            'container_border_color' => '#e2e8f0',
            'button_text'            => 'Enviar Mensaje',
            'button_style'           => 'gradient',
            'success_msg'            => '¡Gracias! Tu mensaje ha sido enviado exitosamente al departamento correspondiente.',
            'destination_emails'     => $default_email,
            'default_area_name'      => 'General / Consultas',
            'enable_autoresponder'   => true,
            'custom_subject'         => '',
            'show_credit'            => true,
        ),
        'fields' => array(
            array(
                'id'          => 'field_nombre',
                'type'        => 'text',
                'label'       => 'Nombre Completo',
                'placeholder' => 'Ej. Juan Pérez',
                'required'    => true,
                'width'       => '50',
                'help'        => '',
            ),
            array(
                'id'          => 'field_email',
                'type'        => 'email',
                'label'       => 'Correo Electrónico',
                'placeholder' => 'ejemplo@correo.com',
                'required'    => true,
                'width'       => '50',
                'help'        => '',
            ),
            array(
                'id'          => 'field_telefono',
                'type'        => 'phone',
                'label'       => 'Teléfono de Contacto',
                'placeholder' => '+56 9 1234 5678',
                'required'    => false,
                'width'       => '50',
                'help'        => '',
            ),
            array(
                'id'          => 'field_departamento',
                'type'        => 'department',
                'label'       => 'Dirigido a / Departamento',
                'required'    => true,
                'width'       => '50',
                'help'        => '',
                'options'     => array(
                    array('nombre' => 'General / Consultas',  'email' => $default_email),
                    array('nombre' => 'Ventas',               'email' => ''),
                    array('nombre' => 'Soporte',              'email' => ''),
                    array('nombre' => 'Dirección',            'email' => ''),
                ),
            ),
            array(
                'id'          => 'field_mensaje',
                'type'        => 'textarea',
                'label'       => 'Mensaje o Comentario',
                'placeholder' => 'Escribe aquí tu consulta...',
                'required'    => true,
                'width'       => '100',
                'help'        => '',
            ),
            array(
                'id'          => 'field_adjunto',
                'type'        => 'file',
                'label'       => 'Adjuntar Archivo (opcional)',
                'placeholder' => '',
                'required'    => false,
                'width'       => '100',
                'help'        => 'PDF, DOCX, XLSX, JPG, PNG, ZIP. Máx 5 MB.',
            ),
            array(
                'id'              => 'field_terminos',
                'type'            => 'terms',
                'label'           => 'He leído y acepto los',
                'required'        => false,
                'width'           => '100',
                'help'            => '',
                'has_terms'       => true,
                'terms_title'     => 'Políticas y Términos de Servicio',
                'terms_content'   => "1. PROTECCIÓN DE DATOS\nLos datos suministrados a través de este formulario serán tratados de forma estrictamente confidencial.\n\n2. FINALIDAD DEL CONTACTO\nLa información proporcionada se utilizará exclusivamente para responder a su requerimiento.\n\n3. SEGURIDAD\nNo compartimos su información con terceros.",
            ),
        ),
    );
}