<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Verifica si la conexión de correo (SMTP) está activada y completa.
 * Se usa para ocultar los formularios del frontend hasta que el admin
 * configure la conexión en "Ajustes de Correo SMTP".
 */
function cm_is_smtp_configured() {
    $enabled = get_option('cm_smtp_enabled', false);
    $host    = get_option('cm_smtp_host', '');
    $user    = get_option('cm_smtp_user', '');
    $pass    = get_option('cm_smtp_pass', '');
    return !empty($enabled) && !empty($host) && !empty($user) && !empty($pass);
}

/**
 * Guarda el último error de envío (PHPMailer) para mostrar el detalle
 * técnico en la pantalla de prueba SMTP.
 */
function cm_store_mail_error( $wp_error ) {
    if ( is_wp_error( $wp_error ) ) {
        update_option( 'cm_last_mail_error', $wp_error->get_error_message(), false );
    }
}
add_action( 'wp_mail_failed', 'cm_store_mail_error' );

/**
 * Devuelve el HTML con el detalle técnico del último error de envío
 * y una pista según su tipo.
 */
function cm_smtp_failure_details_html() {
    $last_err = get_option('cm_last_mail_error', '');
    if ( ! $last_err ) return '';
    $err_lc = strtolower($last_err);
    if ( strpos($err_lc, 'authenticate') !== false || strpos($err_lc, '535') !== false || strpos($err_lc, 'username and password') !== false || strpos($err_lc, 'credentials') !== false ) {
        $hint = '💡 El servidor rechazó las credenciales: verifica el usuario y su contraseña (en Gmail debe ser una <strong>Contraseña de Aplicación</strong> de 16 caracteres).';
    } elseif ( strpos($err_lc, 'conectar') !== false || strpos($err_lc, 'connect') !== false || strpos($err_lc, 'timed out') !== false || strpos($err_lc, 'refused') !== false || strpos($err_lc, 'unreachable') !== false ) {
        $hint = '🔌 <strong>Tu hosting bloquea las conexiones salientes por SMTP</strong> (puertos 25/465/587). Es una restricción antispam del proveedor.<br><br>'
            . '✅ <strong>Solución recomendada:</strong> deja <strong>DESACTIVADO</strong> el interruptor «Activar envío SMTP». Tu servidor envía perfectamente con su sistema interno (PHP mail()) y los formularios funcionarán igual.<br><br>'
            . '📞 Si necesitas SMTP sí o sí, pide a tu proveedor que desactive la restricción «SMTP Restrictions» de tu cuenta.';
    } elseif ( strpos($err_lc, '530') !== false || strpos($err_lc, 'from') !== false && strpos($err_lc, 'does not conform') !== false ) {
        $hint = '💡 El correo remitente (From) debe coincidir con el usuario SMTP autenticado.';
    } else {
        $hint = '';
    }
    return '<div style="margin-top:10px;padding:12px 14px;background:#fff1f2;border-left:4px solid #f43f5e;border-radius:8px;font-size:13px;color:#881337;word-break:break-word;">'
        . '<strong>Detalle técnico:</strong><br>' . esc_html( mb_substr( $last_err, 0, 400 ) )
        . ( $hint ? '<br><br>' . $hint : '' )
        . '</div>';
}

/**
 * Usa siempre el remitente configurado en Universal Contact Form Form,
 * incluso cuando el envío va por PHP mail() (SMTP desactivado).
 */
function cm_custom_mail_from( $orig_email ) {
    $from = get_option('cm_smtp_from', '');
    if ( is_email( $from ) ) return $from;
    $user = get_option('cm_smtp_user', '');
    if ( is_email( $user ) ) return $user;
    return $orig_email;
}
add_filter( 'wp_mail_from', 'cm_custom_mail_from' );

function cm_custom_mail_from_name( $orig_name ) {
    $from_name = get_option('cm_smtp_from_name', '');
    if ( trim( $from_name ) !== '' ) return $from_name;
    return $orig_name;
}
add_filter( 'wp_mail_from_name', 'cm_custom_mail_from_name' );

function cm_configure_smtp( $phpmailer ) {
    $smtp_enabled = get_option('cm_smtp_enabled', false);
    $test_mode    = ! empty( $GLOBALS['cm_smtp_force_test'] );
    if ( ! $smtp_enabled && ! $test_mode ) return;

    $host      = get_option('cm_smtp_host',      'smtp.gmail.com');
    $port      = get_option('cm_smtp_port',      587);
    $user      = get_option('cm_smtp_user',      '');
    $pass      = get_option('cm_smtp_pass',      '');
    $from      = get_option('cm_smtp_from',      $user);
    $from_name = get_option('cm_smtp_from_name', get_bloginfo('name'));

    if ( empty($user) || empty($pass) ) return;

    $phpmailer->isSMTP();
    $phpmailer->Host       = $host;
    $phpmailer->SMTPAuth   = true;
    $phpmailer->Port       = (int) $port;
    $phpmailer->SMTPSecure = ( $port == 465 ) ? 'ssl' : 'tls';
    $phpmailer->Username   = $user;
    $phpmailer->Password   = $pass;
    // Evita fallos de certificado SSL auto-firmado o sin coincidencia de nombre,
    // típicos en servidores cPanel al conectar contra su propio mail.*.
    $phpmailer->SMTPOptions = array(
        'ssl' => array(
            'verify_peer'       => false,
            'verify_peer_name'  => false,
            'allow_self_signed' => true,
        ),
    );
    $phpmailer->From       = $from;
    $phpmailer->FromName   = $from_name;
    $phpmailer->CharSet    = 'UTF-8';
}
add_action( 'phpmailer_init', 'cm_configure_smtp' );

/**
 * Clave de cifrado derivada del secreto 2FA del usuario y las constantes de seguridad de WordPress.
 */
function cm_get_backup_cipher_key($user_id) {
    $secret = function_exists('cm_get_2fa_secret') ? cm_get_2fa_secret($user_id) : '';
    $salt   = defined('AUTH_KEY') ? AUTH_KEY : 'cm_ingecodex_auth_key_2025';
    $salt  .= defined('SECURE_AUTH_SALT') ? SECURE_AUTH_SALT : 'cm_ingecodex_salt_2025';
    return hash('sha256', $secret . $salt, true);
}

/**
 * Cifra el contenido del backup con AES-256-CBC y firma HMAC-SHA256
 */
function cm_encrypt_backup_data($raw_array, $user_id) {
    $raw_json = wp_json_encode($raw_array, JSON_UNESCAPED_UNICODE);
    $key = cm_get_backup_cipher_key($user_id);
    $iv = openssl_random_pseudo_bytes(16);
    $ciphertext = openssl_encrypt($raw_json, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
    $hmac = hash_hmac('sha256', $iv . $ciphertext, $key);

    return array(
        'plugin'      => 'ingecodex-form',
        'encrypted'   => true,
        'cipher'      => 'aes-256-cbc',
        'version'     => defined('CM_VERSION') ? CM_VERSION : '2.5.3',
        'exported_at' => current_time('mysql'),
        'site_url'    => home_url(),
        'site_name'   => get_bloginfo('name'),
        'iv'          => base64_encode($iv),
        'hmac'        => $hmac,
        'payload'     => base64_encode($ciphertext)
    );
}

/**
 * Descifra el contenido de un backup cifrado
 */
function cm_decrypt_backup_data($json_array, $user_id) {
    if (!empty($json_array['encrypted']) && !empty($json_array['payload']) && !empty($json_array['iv']) && !empty($json_array['hmac'])) {
        $key = cm_get_backup_cipher_key($user_id);
        $iv = base64_decode($json_array['iv']);
        $ciphertext = base64_decode($json_array['payload']);
        $expected_hmac = hash_hmac('sha256', $iv . $ciphertext, $key);

        if (!hash_equals($expected_hmac, $json_array['hmac'])) {
            return new WP_Error('invalid_hmac', __('La firma criptográfica no coincide. Verifica que el archivo no haya sido alterado.', 'contacto-multidestino'));
        }

        $decrypted = openssl_decrypt($ciphertext, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
        if ($decrypted === false) {
            return new WP_Error('decrypt_failed', __('Error al descifrar los datos protegidos.', 'contacto-multidestino'));
        }

        $decoded = json_decode($decrypted, true);
        if (!$decoded || !is_array($decoded)) {
            return new WP_Error('json_invalid', __('El archivo descifrado no contiene una estructura de datos válida.', 'contacto-multidestino'));
        }
        return $decoded;
    }

    if (!empty($json_array['plugin']) && $json_array['plugin'] === 'ingecodex-form') {
        return $json_array;
    }

    return new WP_Error('invalid_format', __('Formato de archivo de respaldo no válido.', 'contacto-multidestino'));
}

function cm_register_smtp_settings() {
    register_setting( 'cm_smtp_settings_group', 'cm_smtp_enabled' );
    register_setting( 'cm_smtp_settings_group', 'cm_smtp_host' );
    register_setting( 'cm_smtp_settings_group', 'cm_smtp_port' );
    register_setting( 'cm_smtp_settings_group', 'cm_smtp_user' );
    register_setting( 'cm_smtp_settings_group', 'cm_smtp_pass' );
    register_setting( 'cm_smtp_settings_group', 'cm_smtp_from' );
    register_setting( 'cm_smtp_settings_group', 'cm_smtp_from_name' );

    // Manejador de Descarga / Exportación de Backup Cifrado con 2FA Obligatorio
    if (isset($_POST['cm_export_backup_nonce']) && wp_verify_nonce($_POST['cm_export_backup_nonce'], 'cm_export_backup_action')) {
        if (!current_user_can('manage_options')) {
            wp_die(__('Acceso denegado.', 'contacto-multidestino'));
        }

        $current_user_id = get_current_user_id();
        $is_2fa_active   = function_exists('cm_is_2fa_enabled') && cm_is_2fa_enabled($current_user_id);

        if (!$is_2fa_active) {
            wp_die(__('⚠️ Seguridad 2FA Requerida: Para descargar una copia de seguridad cifrada, debes activar primero la Verificación en 2 Pasos (2FA) en tu perfil de administrador.', 'contacto-multidestino'));
        }

        $otp_code = isset($_POST['cm_export_2fa_code']) ? sanitize_text_field(trim($_POST['cm_export_2fa_code'])) : '';
        $secret   = function_exists('cm_get_2fa_secret') ? cm_get_2fa_secret($current_user_id) : '';

        if (!$otp_code || !class_exists('CM_TOTP_Engine') || !CM_TOTP_Engine::verify_code($secret, $otp_code)) {
            wp_die(__('❌ Código de Verificación 2FA incorrecto o expirado. Por favor ingresa el código actual de 6 dígitos desde Google Authenticator o Apple Passwords.', 'contacto-multidestino'));
        }

        global $wpdb;
        $table_submissions = $wpdb->prefix . 'cm_form_submissions';
        $table_updates     = $wpdb->prefix . 'cm_case_updates';

        // Obtener todos los casos ingresados
        $submissions = array();
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_submissions'") === $table_submissions) {
            $submissions = $wpdb->get_results("SELECT * FROM {$table_submissions}", ARRAY_A);
        }

        // Obtener todas las actualizaciones, mensajes y notas de trazabilidad
        $case_updates = array();
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_updates'") === $table_updates) {
            $case_updates = $wpdb->get_results("SELECT * FROM {$table_updates}", ARRAY_A);
        }

        $raw_backup_data = array(
            'plugin'       => 'ingecodex-form',
            'backup_type'  => 'full_system_and_data',
            'version'      => defined('CM_VERSION') ? CM_VERSION : '2.5.3',
            'exported_at'  => current_time('mysql'),
            'exported_by'  => wp_get_current_user()->user_login,
            'site_url'     => home_url(),
            'site_name'    => get_bloginfo('name'),
            'counts'       => array(
                'submissions'  => count($submissions),
                'case_updates' => count($case_updates),
            ),
            'settings'     => array(
                'cm_smtp_enabled'           => get_option('cm_smtp_enabled', false),
                'cm_smtp_host'              => get_option('cm_smtp_host', 'smtp.gmail.com'),
                'cm_smtp_port'              => get_option('cm_smtp_port', 587),
                'cm_smtp_user'              => get_option('cm_smtp_user', ''),
                'cm_smtp_pass'              => get_option('cm_smtp_pass', ''),
                'cm_smtp_from'              => get_option('cm_smtp_from', ''),
                'cm_smtp_from_name'         => get_option('cm_smtp_from_name', get_bloginfo('name')),
                'cm_forms_visible'          => get_option('cm_forms_visible', 1),
                'cm_send_user_confirmation'  => get_option('cm_send_user_confirmation', 1),
                'cm_internal_mail_mode'     => get_option('cm_internal_mail_mode', 0),
                'cm_2fa_system_enabled'     => get_option('cm_2fa_system_enabled', 0),
                'cm_2fa_required_roles'     => get_option('cm_2fa_required_roles', array()),
            ),
            'departments'  => get_option('cm_departments_registry', array()),
            'quick_notes'  => array(
                'saved'    => get_option('cm_saved_quick_notes', array()),
                'disabled' => get_option('cm_disabled_quick_notes', array()),
            ),
            'forms'        => get_option('cm_forms', array()),
            'submissions'  => $submissions,
            'case_updates' => $case_updates,
        );

        // Cifrado AES-256-CBC con firma HMAC
        $encrypted_payload = cm_encrypt_backup_data($raw_backup_data, $current_user_id);

        $filename = 'ingecodex-backup-cifrado-' . date('Y-m-d-His') . '.json';
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Pragma: no-cache');
        header('Expires: 0');
        echo wp_json_encode($encrypted_payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        exit;
    }
}
add_action( 'admin_init', 'cm_register_smtp_settings' );

function cm_render_smtp_settings_page() {
    if ( ! current_user_can('manage_options') ) return;

    $current_user_id = get_current_user_id();
    $is_2fa_active   = function_exists('cm_is_2fa_enabled') && cm_is_2fa_enabled($current_user_id);

    $notice      = '';
    $notice_type = 'success';

    // Manejador de Subida / Restauración de Backup Cifrado con 2FA
    if ( isset($_POST['cm_backup_import_nonce']) && wp_verify_nonce($_POST['cm_backup_import_nonce'], 'cm_backup_import_action') ) {
        if (!$is_2fa_active) {
            $notice      = '🛡️ Para restaurar una copia de seguridad debes tener activada la Verificación en 2 Pasos (2FA) en tu cuenta.';
            $notice_type = 'warning';
        } else {
            $otp_code = isset($_POST['cm_import_2fa_code']) ? sanitize_text_field(trim($_POST['cm_import_2fa_code'])) : '';
            $secret   = function_exists('cm_get_2fa_secret') ? cm_get_2fa_secret($current_user_id) : '';

            if (!$otp_code || !class_exists('CM_TOTP_Engine') || !CM_TOTP_Engine::verify_code($secret, $otp_code)) {
                $notice      = '❌ Código de 2 Factores (2FA) incorrecto o expirado. Revisa tu aplicación de autenticación.';
                $notice_type = 'error';
            } elseif (!isset($_FILES['cm_backup_file']) || $_FILES['cm_backup_file']['error'] !== UPLOAD_ERR_OK) {
                $notice      = '⚠️ Por favor selecciona un archivo JSON de copia de seguridad válido.';
                $notice_type = 'warning';
            } else {
                $uploaded_content = file_get_contents($_FILES['cm_backup_file']['tmp_name']);
                $raw_json_array   = json_decode($uploaded_content, true);

                if (!$raw_json_array || !is_array($raw_json_array)) {
                    $notice      = '❌ El archivo subido no contiene un formato JSON válido.';
                    $notice_type = 'error';
                } else {
                    // Descifrar payload
                    $decrypted_data = cm_decrypt_backup_data($raw_json_array, $current_user_id);

                    if (is_wp_error($decrypted_data)) {
                        $notice      = '❌ ' . $decrypted_data->get_error_message();
                        $notice_type = 'error';
                    } elseif (empty($decrypted_data['plugin']) || $decrypted_data['plugin'] !== 'ingecodex-form') {
                        $notice      = '❌ El archivo no corresponde a una copia de seguridad de Universal Contact Form Form.';
                        $notice_type = 'error';
                    } else {
                        global $wpdb;
                        $restored_items = array();

                        // Asegurar tablas de base de datos
                        if (function_exists('cm_create_database_tables')) {
                            cm_create_database_tables();
                        }

                        // 1. Restaurar configuraciones de correo / SMTP y sistema
                        if (!empty($decrypted_data['settings']) && is_array($decrypted_data['settings'])) {
                            foreach ($decrypted_data['settings'] as $opt_k => $opt_v) {
                                update_option($opt_k, $opt_v);
                            }
                            $restored_items[] = 'Ajustes y SMTP';
                        }

                        // 2. Restaurar Departamentos / Áreas
                        if (isset($decrypted_data['departments']) && is_array($decrypted_data['departments'])) {
                            update_option('cm_departments_registry', $decrypted_data['departments']);
                            $restored_items[] = count($decrypted_data['departments']) . ' Áreas';
                        }

                        // 3. Restaurar Notas Rápidas
                        if (isset($decrypted_data['quick_notes']) && is_array($decrypted_data['quick_notes'])) {
                            if (isset($decrypted_data['quick_notes']['saved'])) {
                                update_option('cm_saved_quick_notes', $decrypted_data['quick_notes']['saved']);
                            }
                            if (isset($decrypted_data['quick_notes']['disabled'])) {
                                update_option('cm_disabled_quick_notes', $decrypted_data['quick_notes']['disabled']);
                            }
                            $restored_items[] = 'Notas Rápidas';
                        }

                        // 4. Restaurar Formularios
                        if (isset($decrypted_data['forms']) && is_array($decrypted_data['forms'])) {
                            update_option('cm_forms', $decrypted_data['forms']);
                            $restored_items[] = count($decrypted_data['forms']) . ' Formularios';
                        }

                        // 5. Restaurar Casos / Solicitudes ingresadas
                        $sub_count = 0;
                        if (!empty($decrypted_data['submissions']) && is_array($decrypted_data['submissions'])) {
                            $table_subs = $wpdb->prefix . 'cm_form_submissions';
                            foreach ($decrypted_data['submissions'] as $sub) {
                                if (is_array($sub)) {
                                    $wpdb->replace($table_subs, $sub);
                                    $sub_count++;
                                }
                            }
                            $restored_items[] = $sub_count . ' Casos / Solicitudes';
                        }

                        // 6. Restaurar Historial, Actualizaciones y Mensajes
                        $upd_count = 0;
                        if (!empty($decrypted_data['case_updates']) && is_array($decrypted_data['case_updates'])) {
                            $table_upds = $wpdb->prefix . 'cm_case_updates';
                            foreach ($decrypted_data['case_updates'] as $upd) {
                                if (is_array($upd)) {
                                    $wpdb->replace($table_upds, $upd);
                                    $upd_count++;
                                }
                            }
                            $restored_items[] = $upd_count . ' Mensajes e Historial';
                        }

                        $notice = '✅ ¡Copia de seguridad CIFRADA descifrada y restaurada con éxito! (' . implode(' • ', $restored_items) . '). Origen: ' . esc_html($decrypted_data['site_name'] ?? 'Sitio') . ' (' . esc_html($decrypted_data['exported_at'] ?? date('Y-m-d')) . ')';
                        $notice_type = 'success';
                    }
                }
            }
        }
    }
    
    if ( isset($_POST['cm_smtp_save_nonce']) && wp_verify_nonce($_POST['cm_smtp_save_nonce'], 'cm_smtp_save') ) {
        update_option('cm_smtp_enabled',   isset($_POST['cm_smtp_enabled']) ? 1 : 0 );
        update_option('cm_smtp_host',      sanitize_text_field($_POST['cm_smtp_host']      ?? 'smtp.gmail.com') );
        update_option('cm_smtp_port',      absint($_POST['cm_smtp_port']                   ?? 587) );
        update_option('cm_smtp_user',      sanitize_text_field($_POST['cm_smtp_user']      ?? '') );
        update_option('cm_smtp_pass',      sanitize_text_field($_POST['cm_smtp_pass']      ?? '') );
        update_option('cm_smtp_from',      sanitize_email($_POST['cm_smtp_from']           ?? '') );
        update_option('cm_smtp_from_name', sanitize_text_field($_POST['cm_smtp_from_name'] ?? get_bloginfo('name')) );
        update_option('cm_forms_visible',  isset($_POST['cm_forms_visible']) ? 1 : 0 );
        update_option('cm_send_user_confirmation', isset($_POST['cm_send_user_confirmation']) ? 1 : 0 );
        update_option('cm_internal_mail_mode', isset($_POST['cm_internal_mail_mode']) ? 1 : 0 );
        $notice = '✅ Configuración SMTP guardada correctamente.';
    }

    
    if ( isset($_POST['cm_smtp_test_nonce']) && wp_verify_nonce($_POST['cm_smtp_test_nonce'], 'cm_smtp_test') ) {
        $test_to = sanitize_email($_POST['cm_test_email'] ?? '');
        if ( is_email($test_to) ) {
            delete_option('cm_last_mail_error');
            $sent = wp_mail(
                $test_to,
                '✅ Prueba SMTP — Universal Contact Form Form',
                '<html><body style="font-family:Inter,Arial,sans-serif;padding:32px;background:#f0f4f9;">
                    <div style="max-width:520px;margin:0 auto;background:#fff;border-radius:16px;padding:36px;box-shadow:0 4px 24px rgba(0,0,0,0.08);">
                        <div style="background:linear-gradient(135deg,#4f46e5,#7c3aed);border-radius:12px;padding:24px;text-align:center;margin-bottom:24px;">
                            <span style="font-size:40px;">✦</span>
                            <h2 style="color:#fff;margin:12px 0 4px;font-size:20px;">¡Correo de Prueba Exitoso!</h2>
                            <p style="color:rgba(255,255,255,0.8);margin:0;font-size:14px;">Universal Contact Form Form — Configuración de Correo</p>
                        </div>
                        <p style="color:#475569;font-size:15px;line-height:1.6;">Si recibes este correo, el envío funciona correctamente y el formulario de contacto puede enviar mensajes.</p>
                        <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:14px;margin-top:20px;">
                            <p style="color:#166534;margin:0;font-size:13px;">🟢 Enviado desde: <strong>' . esc_html(get_bloginfo('url')) . '</strong></p>
                        </div>
                    </div>
                </body></html>',
                array('Content-Type: text/html; charset=UTF-8')
            );
            if ( $sent ) {
                delete_option('cm_last_mail_error');
                $notice = '📨 Correo de prueba enviado a <strong>' . esc_html($test_to) . '</strong>. Revisa tu bandeja de entrada (y la carpeta spam).';
                $notice_type = 'success';
            } else {
                $notice = '❌ No se pudo enviar el correo de prueba.' . cm_smtp_failure_details_html();
                if ( get_option('cm_smtp_enabled', false) ) {
                    $notice .= '<div style="margin-top:10px;padding:10px 14px;background:#fef9c3;border-left:4px solid #eab308;border-radius:8px;font-size:13px;color:#854d0e;">💡 <strong>Para enviar el mensaje de prueba debes desactivar el SMTP:</strong> baja el interruptor «Activar envío SMTP», guarda y vuelve a probar. Tu servidor puede usar su envío interno sin problemas.</div>';
                }
                $notice_type = 'error';
            }
        } else {
            $notice      = '⚠️ Ingresa un correo electrónico válido para la prueba.';
            $notice_type = 'warning';
        }
    }

    $enabled   = get_option('cm_smtp_enabled', false);
    $forms_visible = get_option('cm_forms_visible', 1);
    $host      = get_option('cm_smtp_host',      'smtp.gmail.com');
    $port      = get_option('cm_smtp_port',      587);
    $user      = get_option('cm_smtp_user',      '');
    $pass      = get_option('cm_smtp_pass',      '');
    $from      = get_option('cm_smtp_from',      '');
    $from_name = get_option('cm_smtp_from_name', get_bloginfo('name'));

    $notice_colors = [
        'success' => ['bg'=>'#f0fdf4','border'=>'#4ade80','text'=>'#166534','icon'=>'✅'],
        'error'   => ['bg'=>'#fef2f2','border'=>'#fca5a5','text'=>'#991b1b','icon'=>'❌'],
        'warning' => ['bg'=>'#fffbeb','border'=>'#fcd34d','text'=>'#92400e','icon'=>'⚠️'],
    ];
    $nc = $notice_colors[$notice_type] ?? $notice_colors['success'];
    ?>

    <style>
    #wpbody-content { background: #f5f5f7 !important; }

    .cm-smtp-page {
        font-family: -apple-system, BlinkMacSystemFont, "SF Pro Text", "Helvetica Neue", "Segoe UI", Roboto, sans-serif;
        margin: 0; padding: 0 0 64px;
        color: #1d1d1f;
        -webkit-font-smoothing: antialiased;
    }

    .cm-smtp-topbar {
        background: rgba(255,255,255,.86);
        backdrop-filter: saturate(180%) blur(20px);
        -webkit-backdrop-filter: saturate(180%) blur(20px);
        border-bottom: 1px solid #e8e8ed;
        margin: -10px -20px 0 -20px;
        padding: 14px 44px;
        display: flex; align-items: center; justify-content: space-between;
    }
    .cm-smtp-brand { display: flex; align-items: center; gap: 13px; }
    .cm-smtp-brand-icon {
        width: 40px; height: 40px;
        border-radius: 10px;
        overflow: hidden; flex-shrink: 0;
        box-shadow: 0 2px 10px rgba(0,0,0,0.12);
    }
    .cm-smtp-brand-icon img { width: 100%; height: 100%; object-fit: cover; display: block; }
    .cm-smtp-brand h1 {
        font-size: 17px; font-weight: 600; letter-spacing: -0.01em; color: #1d1d1f;
        margin: 0; display: flex; align-items: baseline; gap: 10px;
    }
    .cm-smtp-brand h1 small { font-size: 13px; font-weight: 400; color: #6e6e73; }
    .cm-smtp-nav { display: flex; gap: 6px; }
    .cm-smtp-nav a {
        display: inline-flex; align-items: center; gap: 6px;
        padding: 7px 16px; border-radius: 980px; font-size: 13px; font-weight: 500;
        text-decoration: none; transition: all 0.18s ease;
        color: #1d1d1f; background: transparent;
    }
    .cm-smtp-nav a:hover { background: rgba(0,0,0,0.05); }
    .cm-smtp-nav a.active { background: rgba(0,113,227,0.10); color: #0066cc; }

    .cm-smtp-wrap { padding: 30px 44px 0; }

    .cm-smtp-notice {
        padding: 14px 18px; border-radius: 14px; margin-bottom: 24px;
        font-size: 14px; line-height: 1.5; font-weight: 500;
        border: 1px solid transparent;
        display: flex; align-items: flex-start; gap: 12px;
        animation: cm-fadein 0.35s cubic-bezier(0.25,0.1,0.25,1);
    }
    @keyframes cm-fadein { from { opacity:0; transform: translateY(-8px); } to { opacity:1; transform: translateY(0); } }

    .cm-smtp-grid {
        display: grid;
        grid-template-columns: minmax(0, 1fr) 360px;
        gap: 28px;
        align-items: start;
    }
    .cm-col-main { display: flex; flex-direction: column; gap: 20px; min-width: 0; }
    .cm-sidebar-col { display: flex; flex-direction: column; gap: 20px; position: sticky; top: 60px; }

    .cm-smtp-card {
        background: #ffffff;
        border-radius: 18px;
        box-shadow: 0 1px 2px rgba(0,0,0,0.03), 0 8px 28px rgba(0,0,0,0.05);
        padding: 26px 30px;
    }
    .cm-card-head { display: flex; align-items: center; gap: 14px; margin-bottom: 20px; }
    .cm-smtp-card-icon {
        width: 38px; height: 38px; border-radius: 11px;
        display: flex; align-items: center; justify-content: center;
        font-size: 17px; flex-shrink: 0; background: #f5f5f7;
    }
    .cm-card-head h2 { font-size: 17px; font-weight: 600; letter-spacing: -0.01em; color: #1d1d1f; margin: 0; }
    .cm-card-head p  { font-size: 13px; color: #6e6e73; margin: 2px 0 0; }

    .cm-smtp-field { margin-bottom: 18px; }
    .cm-smtp-field:last-child { margin-bottom: 0; }
    .cm-smtp-field label {
        display: block; font-size: 13px; font-weight: 600;
        color: #1d1d1f; margin-bottom: 7px; letter-spacing: -0.005em;
    }
    .cm-smtp-field .cm-smtp-desc {
        font-size: 12px; color: #86868b; margin-top: 6px; line-height: 1.45;
    }
    .cm-smtp-input {
        width: 100%; padding: 11px 14px; font-size: 14px;
        background: #ffffff; border: 1px solid #d2d2d7;
        border-radius: 12px; color: #1d1d1f; box-sizing: border-box;
        transition: border-color 0.15s ease, box-shadow 0.15s ease;
        outline: none; font-family: inherit;
    }
    .cm-smtp-input:focus {
        outline: none; border-color: #0071e3;
        box-shadow: 0 0 0 4px rgba(0,113,227,0.14);
    }
    .cm-smtp-row { display: flex; gap: 16px; }
    .cm-smtp-row > .cm-smtp-field { flex: 1; }
    .cm-smtp-row > .cm-smtp-field.narrow { flex: 0 0 130px; }

    .cm-group-label {
        font-size: 13px; font-weight: 600; color: #1d1d1f;
        margin: 26px 0 14px; padding-top: 22px; border-top: 1px solid #f0f0f2;
    }
    .cm-smtp-toggle-card {
        background: #fafafa; border-radius: 14px;
        border: 1px solid #e8e8ed; padding: 16px 18px;
        display: flex; align-items: center; justify-content: space-between;
        cursor: pointer; transition: all 0.2s ease;
    }
    .cm-smtp-toggle-card:hover { background: #f5f5f7; }
    .cm-smtp-toggle-card.on { border-color: rgba(52,199,89,0.45); background: rgba(52,199,89,0.07); }
    .cm-toggle-label h4 { font-size: 14px; font-weight: 600; color: #1d1d1f; margin: 0 0 3px; }
    .cm-toggle-label p  { font-size: 12px; color: #6e6e73; margin: 0; }

    .cm-toggle-switch { position: relative; width: 51px; height: 31px; flex-shrink: 0; }
    .cm-toggle-switch input { opacity: 0; width: 0; height: 0; }
    .cm-toggle-track {
        position: absolute; inset: 0;
        background: #d1d1d6; border-radius: 980px; cursor: pointer;
        transition: background 0.25s ease;
    }
    .cm-toggle-track::before {
        position: absolute; content: '';
        width: 27px; height: 27px; left: 2px; top: 2px;
        background: #fff; border-radius: 50%; transition: transform 0.25s cubic-bezier(0.25,0.1,0.25,1);
        box-shadow: 0 2px 6px rgba(0,0,0,0.18);
    }
    input:checked ~ .cm-toggle-track { background: #34c759; }
    input:checked ~ .cm-toggle-track::before { transform: translateX(20px); }

    .cm-smtp-status {
        display: inline-flex; align-items: center; gap: 6px;
        padding: 5px 13px; border-radius: 980px;
        font-size: 12px; font-weight: 600;
    }
    .cm-smtp-status.active { background: rgba(52,199,89,0.12); color: #1d7a36; }
    .cm-smtp-status.inactive { background: #f5f5f7; color: #6e6e73; }
    .cm-status-dot { width: 7px; height: 7px; border-radius: 50%; }
    .cm-smtp-status.active .cm-status-dot { background: #34c759; }
    .cm-smtp-status.inactive .cm-status-dot { background: #aeaeb2; }

    .cm-presets {
        border: 1px solid #e8e8ed; border-radius: 14px;
        overflow: hidden; background: #fff;
    }
    .cm-preset-row {
        width: 100%; padding: 13px 16px;
        background: #fff; border: none; border-bottom: 1px solid #f0f0f2;
        text-align: left; cursor: pointer; font-family: inherit;
        display: flex; align-items: center; gap: 14px;
        transition: background 0.15s ease;
    }
    .cm-preset-row:last-child { border-bottom: none; }
    .cm-preset-row:hover { background: #fafafa; }
    .cm-preset-icon { font-size: 19px; width: 26px; text-align: center; }
    .cm-preset-row b { display: block; font-size: 14px; font-weight: 600; color: #1d1d1f; }
    .cm-preset-row small { display: block; font-size: 12px; color: #86868b; margin-top: 1px; }
    .cm-preset-arrow { margin-left: auto; color: #c7c7cc; font-size: 17px; font-weight: 600; }

    .cm-save-row { display: flex; justify-content: flex-end; padding: 4px 2px 0; }

    .cm-smtp-btn {
        display: inline-flex; align-items: center; justify-content: center; gap: 8px;
        padding: 12px 26px; font-size: 14px; font-weight: 500;
        border-radius: 980px; border: none; cursor: pointer;
        transition: all 0.18s ease; font-family: inherit; letter-spacing: -0.005em;
    }
    .cm-smtp-btn:active { transform: scale(0.97); }
    .cm-smtp-btn-primary { background: #0071e3; color: #fff; box-shadow: 0 4px 14px rgba(0,113,227,0.28); }
    .cm-smtp-btn-primary:hover { background: #0077ed; box-shadow: 0 6px 20px rgba(0,113,227,0.34); }
    .cm-smtp-btn-secondary { background: #0071e3; color: #fff; }
    .cm-smtp-btn-secondary:hover { background: #0077ed; }

    .cm-info-header { padding: 2px 2px 18px; border-bottom: 1px solid #f0f0f2; margin-bottom: 18px; }
    .cm-info-header h3 { font-size: 15px; font-weight: 600; color: #1d1d1f; margin: 0 0 3px; letter-spacing: -0.01em; }
    .cm-info-header p  { font-size: 13px; color: #6e6e73; margin: 0; }
    .cm-smtp-step { display: flex; gap: 13px; margin-bottom: 18px; align-items: flex-start; }
    .cm-smtp-step:last-child { margin-bottom: 0; }
    .cm-step-num {
        width: 26px; height: 26px; border-radius: 50%;
        background: rgba(0,113,227,0.10); color: #0066cc;
        font-size: 12px; font-weight: 700;
        display: flex; align-items: center; justify-content: center;
        flex-shrink: 0; margin-top: 1px;
    }
    .cm-step-text h4 { font-size: 13px; font-weight: 600; color: #1d1d1f; margin: 0 0 3px; }
    .cm-step-text p  { font-size: 12px; color: #6e6e73; margin: 0; line-height: 1.5; }
    .cm-step-text a  { color: #0066cc; font-weight: 500; text-decoration: none; }
    .cm-step-text a:hover { text-decoration: underline; }

    .cm-test-email-row { display: flex; gap: 12px; align-items: flex-end; }
    .cm-test-email-row .cm-smtp-field { flex: 1; margin-bottom: 0; }

    .cm-hint-box {
        background: rgba(0,113,227,0.06); border-radius: 12px;
        padding: 14px 16px; margin-top: 16px;
    }
    .cm-hint-box p { margin: 0; font-size: 12px; line-height: 1.5; color: #0066cc; }
    .cm-hint-box p b { display: block; margin-bottom: 3px; }

    @media (max-width: 1200px) {
        .cm-smtp-grid { grid-template-columns: 1fr; }
        .cm-sidebar-col { position: static; }
    }
    @media (max-width: 782px) {
        .cm-smtp-topbar, .cm-smtp-wrap { padding-left: 20px; padding-right: 20px; }
        .cm-smtp-row { flex-direction: column; gap: 0; }
        .cm-test-email-row { flex-direction: column; align-items: stretch; }
    }
    </style>

    <div class="cm-smtp-page">

        <div class="cm-smtp-topbar">
            <div class="cm-smtp-brand">
                <a href="https://example.com" target="_blank" rel="noopener" title="Visitar https://example.com" style="display:flex;align-items:center;gap:13px;text-decoration:none;">
                    <div class="cm-smtp-brand-icon"><img src="<?php echo esc_url(CM_PLUGIN_URL . 'imag/diagrama.gif'); ?>" alt="Universal Contact Form Form" draggable="false" /></div>
                    <h1>Universal Contact Form Form <small>Ajustes de Correo SMTP</small></h1>
                </a>
            </div>
            <nav class="cm-smtp-nav" style="display:flex;align-items:center;gap:8px;">
                <a href="none" target="_blank" rel="noopener noreferrer" style="background: linear-gradient(135deg, #009ee3 0%, #007eb5 100%); color: #ffffff !important; font-weight: 700; font-size: 12.5px; padding: 6px 14px; border-radius: 980px; text-decoration: none; display: inline-flex; align-items: center; gap: 6px; box-shadow: 0 2px 8px rgba(0, 158, 227, 0.28);" title="Apoyar el desarrollo con Mercado Pago">
                    <img src="<?php echo esc_url(CM_PLUGIN_URL . 'assets/images/logo.gif'); ?>" alt="Universal Contact Form" style="width: 18px; height: 18px; border-radius: 50%; object-fit: cover; display: inline-block;" />
                    <span>Donar</span>
                </a>
                <a href="<?php echo admin_url('admin.php?page=cm-form-studio'); ?>">← Editor Visual</a>
                <a href="<?php echo admin_url('admin.php?page=cm-form-smtp'); ?>" class="active">⚙️ Configurar SMTP</a>
            </nav>
        </div>

        <div class="cm-smtp-wrap">

        <?php if ( $notice ) : ?>
        <div class="cm-smtp-notice" style="background:<?php echo $nc['bg']; ?>;border-color:<?php echo $nc['border']; ?>;color:<?php echo $nc['text']; ?>;">
            <span style="font-size:17px;"><?php echo $nc['icon']; ?></span>
            <span><?php echo $notice; ?></span>
        </div>
        <?php endif; ?>

        <div class="cm-smtp-grid">

            <div class="cm-col-main">
                <form method="post" id="cm-smtp-main-form" style="display:flex;flex-direction:column;gap:20px;">
                <?php wp_nonce_field('cm_smtp_save', 'cm_smtp_save_nonce'); ?>

                <!-- Banner Informativo: SMTP No Obligatorio -->
                <div style="background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%); border: 1.5px solid #86efac; border-radius: 16px; padding: 18px 22px; margin-bottom: 22px; display: flex; align-items: flex-start; gap: 14px; box-shadow: 0 4px 16px rgba(22, 163, 74, 0.08);">
                    <span style="font-size: 26px; line-height: 1; flex-shrink: 0; margin-top: 2px;">🛡️</span>
                    <div>
                        <strong style="font-size: 14.5px; color: #166534; display: block; font-weight: 800; margin-bottom: 3px;">
                            <?php _e('Configuración Opcional: El formulario funciona sin cuenta de correo externa', 'contacto-multidestino'); ?>
                        </strong>
                        <p style="font-size: 13px; color: #15803d; margin: 0; line-height: 1.5;">
                            <?php _e('No es obligatorio configurar un servidor SMTP. Con la confirmación interna y la base de datos de expedientes, las solicitudes se reciben, registran y gestionan en la Bandeja de Casos de forma 100% segura sin depender de un proveedor de correo externo.', 'contacto-multidestino'); ?>
                        </p>
                    </div>
                </div>

                <div class="cm-smtp-card">
                    <div class="cm-card-head">
                        <div class="cm-smtp-card-icon">📡</div>
                        <div>
                            <h2>Modo de Envío y Notificaciones</h2>
                            <p>Controla cómo se procesan los correos y la confirmación a los solicitantes</p>
                        </div>
                        <div style="margin-left:auto;">
                            <?php if ($enabled): ?>
                                <span class="cm-smtp-status active"><span class="cm-status-dot"></span> SMTP Activo</span>
                            <?php else: ?>
                                <span class="cm-smtp-status" style="background:#f1f5f9; color:#475569; border-color:#cbd5e1;"><span class="cm-status-dot" style="background:#94a3b8;"></span> Modo Interno (Sin SMTP)</span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- 1. Toggle Modo Interno / Sin SMTP Obligatorio -->
                    <label class="cm-smtp-toggle-card <?php echo !$enabled ? 'on' : ''; ?>" for="cm_internal_mail_toggle">
                        <div class="cm-toggle-label">
                            <h4>✅ Modo Interno Activo (Sin Configuración de Correo Externa)</h4>
                            <p><strong>Recomendado:</strong> El formulario funciona de inmediato. Guarda todas las solicitudes en la Bandeja de Casos, genera códigos de ticket y permite seguimiento web sin riesgo de fallas de conexión SMTP.</p>
                        </div>
                        <div class="cm-toggle-switch">
                            <input type="checkbox" id="cm_internal_mail_toggle" name="cm_internal_mail_mode" value="1" <?php checked(!$enabled, true); ?> onchange="if(this.checked){ document.getElementById('cm_smtp_enabled_toggle').checked = false; }" />
                            <span class="cm-toggle-track"></span>
                        </div>
                    </label>

                    <!-- 2. Toggle SMTP Externo Opcional -->
                    <label class="cm-smtp-toggle-card <?php echo $enabled ? 'on' : ''; ?>" for="cm_smtp_enabled_toggle" style="margin-top:14px;">
                        <div class="cm-toggle-label">
                            <h4>🔌 Activar Servidor SMTP Autenticado (Opcional)</h4>
                            <p>Actívalo únicamente si deseas enviar correos mediante Gmail, Outlook o tu hosting propio. Si no lo configuras, el sistema usa el correo interno de WordPress sin bloquear los formularios.</p>
                        </div>
                        <div class="cm-toggle-switch">
                            <input type="checkbox" id="cm_smtp_enabled_toggle" name="cm_smtp_enabled" value="1" <?php checked($enabled, 1); ?> onchange="if(this.checked){ document.getElementById('cm_internal_mail_toggle').checked = false; }" />
                            <span class="cm-toggle-track"></span>
                        </div>
                    </label>

                    <!-- 3. Toggle Correo de Confirmación al Solicitante -->
                    <?php 
                    $send_user_confirmation = get_option('cm_send_user_confirmation', '1') !== '0';
                    ?>
                    <label class="cm-smtp-toggle-card <?php echo $send_user_confirmation ? 'on' : ''; ?>" for="cm_send_user_conf_toggle" style="margin-top:14px;">
                        <div class="cm-toggle-label">
                            <h4>📨 Enviar Correo de Confirmación al Solicitante</h4>
                            <p>Envía automáticamente un correo al solicitante con su código de ticket y el enlace para consultar el avance de su trámite.</p>
                        </div>
                        <div class="cm-toggle-switch">
                            <input type="checkbox" id="cm_send_user_conf_toggle" name="cm_send_user_confirmation" value="1" <?php checked($send_user_confirmation, true); ?> />
                            <span class="cm-toggle-track"></span>
                        </div>
                    </label>

                    <!-- 4. Toggle Visibilidad de Formularios -->
                    <label class="cm-smtp-toggle-card <?php echo !empty($forms_visible) ? 'on' : ''; ?>" for="cm_forms_visible_toggle" style="margin-top:14px;">
                        <div class="cm-toggle-label">
                            <h4>👁️ Mostrar Formularios en el Sitio Web</h4>
                            <p>Define si los formularios están visibles para los visitantes en las páginas públicas y widgets de Elementor.</p>
                        </div>
                        <div class="cm-toggle-switch">
                            <input type="checkbox" id="cm_forms_visible_toggle" name="cm_forms_visible" value="1" <?php checked(!empty($forms_visible), true); ?> />
                            <span class="cm-toggle-track"></span>
                        </div>
                    </label>
                </div>

                <div class="cm-smtp-card">
                    <div class="cm-card-head">
                        <div class="cm-smtp-card-icon">⚡</div>
                        <div>
                            <h2>Servidores Predefinidos</h2>
                            <p>Toca un proveedor para completar host y puerto automáticamente</p>
                        </div>
                    </div>
                    <div class="cm-presets">
                        <button type="button" class="cm-preset-row" onclick="cmSetPreset('smtp.gmail.com',587)">
                            <span class="cm-preset-icon">📧</span>
                            <span><b>Gmail</b><small>smtp.gmail.com · Puerto 587 · TLS</small></span>
                            <span class="cm-preset-arrow">›</span>
                        </button>
                        <button type="button" class="cm-preset-row" onclick="cmSetPreset('smtp-mail.outlook.com',587)">
                            <span class="cm-preset-icon">📨</span>
                            <span><b>Outlook / Hotmail</b><small>smtp-mail.outlook.com · Puerto 587 · TLS</small></span>
                            <span class="cm-preset-arrow">›</span>
                        </button>
                        <button type="button" class="cm-preset-row" onclick="cmSetPreset('mail.yourdomain.com',587)">
                            <span class="cm-preset-icon">🌐</span>
                            <span><b>Hosting Propio / cPanel</b><small>Configuración personalizada</small></span>
                            <span class="cm-preset-arrow">›</span>
                        </button>
                    </div>
                </div>

                <div class="cm-smtp-card">
                    <div class="cm-card-head">
                        <div class="cm-smtp-card-icon">🖥️</div>
                        <div>
                            <h2>Configuración del Servidor</h2>
                            <p>Datos de conexión saliente de correo</p>
                        </div>
                    </div>
                    <div class="cm-smtp-row">
                        <div class="cm-smtp-field">
                            <label>Servidor SMTP (Host)</label>
                            <input type="text" name="cm_smtp_host" id="cm_smtp_host" class="cm-smtp-input" value="<?php echo esc_attr($host); ?>" placeholder="smtp.gmail.com" />
                        </div>
                        <div class="cm-smtp-field narrow">
                            <label>Puerto</label>
                            <input type="number" name="cm_smtp_port" id="cm_smtp_port" class="cm-smtp-input" value="<?php echo esc_attr($port); ?>" placeholder="587" />
                            <p class="cm-smtp-desc">587 = TLS<br>465 = SSL</p>
                        </div>
                    </div>

                    <p class="cm-group-label">Credenciales</p>
                    <div class="cm-smtp-field">
                        <label>Usuario SMTP (tu correo)</label>
                        <input type="email" name="cm_smtp_user" id="cm_smtp_user" class="cm-smtp-input" value="<?php echo esc_attr($user); ?>" placeholder="tucorreo@gmail.com" />
                    </div>
                    <div class="cm-smtp-field">
                        <label>Contraseña de Aplicación</label>
                        <input type="password" name="cm_smtp_pass" class="cm-smtp-input" value="<?php echo esc_attr($pass); ?>" placeholder="••••••••••••••••" autocomplete="new-password" />
                        <p class="cm-smtp-desc">En Gmail usa una contraseña de aplicación de 16 caracteres, no tu contraseña normal.</p>
                    </div>

                    <p class="cm-group-label">Identidad del Remitente</p>
                    <div class="cm-smtp-row">
                        <div class="cm-smtp-field">
                            <label>Correo Remitente (From)</label>
                            <input type="email" name="cm_smtp_from" class="cm-smtp-input" value="<?php echo esc_attr($from ?: $user); ?>" placeholder="tucorreo@gmail.com" />
                            <p class="cm-smtp-desc">En Gmail debe coincidir con el usuario.</p>
                        </div>
                        <div class="cm-smtp-field">
                            <label>Nombre del Remitente</label>
                            <input type="text" name="cm_smtp_from_name" class="cm-smtp-input" value="<?php echo esc_attr($from_name); ?>" placeholder="Mi Sitio Web" />
                        </div>
                    </div>

                    <div class="cm-save-row">
                        <button type="submit" class="cm-smtp-btn cm-smtp-btn-primary">Guardar Configuración</button>
                    </div>
                </div>

                </form>

                <div class="cm-smtp-card">
                    <div class="cm-card-head">
                        <div class="cm-smtp-card-icon">📨</div>
                        <div>
                            <h2>Enviar Correo de Prueba</h2>
                            <p>Verifica que todo funciona antes de publicar tus formularios</p>
                        </div>
                    </div>
                    <form method="post">
                        <?php wp_nonce_field('cm_smtp_test', 'cm_smtp_test_nonce'); ?>
                        <p style="font-size:13px;color:#6e6e73;margin:0 0 16px;line-height:1.5;">Guarda la configuración primero y luego envía un correo de prueba. <strong>Si tienes activado el SMTP y falla, desactívalo</strong> (interruptor de arriba), guarda y vuelve a probar.</p>
                        <div class="cm-test-email-row">
                            <div class="cm-smtp-field">
                                <label>Correo de Destino para la Prueba</label>
                                <input type="email" name="cm_test_email" class="cm-smtp-input" value="" placeholder="tucorreo@dominio.cl" required />
                            </div>
                            <button type="submit" class="cm-smtp-btn cm-smtp-btn-secondary">Enviar Prueba ✉️</button>
                        </div>
                    </form>
                </div>

                <!-- TARJETA: RESPALDO Y RESTAURACIÓN CIFRADA CON DOBLE FACTOR (2FA) -->
                <div class="cm-smtp-card" style="border: 1.5px solid #e0e7ff; background: #ffffff;">
                    <div class="cm-card-head">
                        <div class="cm-smtp-card-icon" style="background:#eef2ff; color:#4f46e5; font-size:20px;">🛡️</div>
                        <div>
                            <h2>Copia de Seguridad Cifrada y Restauración (Full Backup con 2FA)</h2>
                            <p>Exporta e importa el 100% de expedientes, mensajes, formularios y configuraciones protegidos con cifrado militar AES-256</p>
                        </div>
                        <div style="margin-left:auto;">
                            <?php if ($is_2fa_active) : ?>
                                <span class="cm-smtp-status active" style="font-size:11.5px;"><span class="cm-status-dot"></span> 2FA Activo</span>
                            <?php else : ?>
                                <span class="cm-smtp-status" style="background:#fef2f2; color:#991b1b; border:1px solid #fecaca; font-size:11.5px;"><span class="cm-status-dot" style="background:#ef4444;"></span> 2FA Requerido</span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <?php if (!$is_2fa_active) : ?>
                        <!-- Alerta de 2FA Obligatorio para Backup -->
                        <div style="background:linear-gradient(135deg, #fffbeb 0%, #fef3c7 100%); border:1.5px solid #fcd34d; border-radius:14px; padding:18px 22px; display:flex; align-items:flex-start; gap:14px; margin-top:8px;">
                            <span style="font-size:26px; line-height:1; flex-shrink:0;">🔐</span>
                            <div>
                                <strong style="font-size:14px; color:#92400e; display:block; margin-bottom:4px;">
                                    <?php _e('Autenticación de 2 Factores (2FA) Requerida para Descargar o Restaurar Copias de Seguridad', 'contacto-multidestino'); ?>
                                </strong>
                                <p style="font-size:12.5px; color:#78350f; line-height:1.5; margin:0 0 12px;">
                                    <?php _e('Por motivos de máxima seguridad y confidencialidad de los datos, los respaldos se descargan cifrados con AES-256. Para autorizar la exportación o restauración es obligatorio tener activado el Doble Factor en tu cuenta de administrador.', 'contacto-multidestino'); ?>
                                </p>
                                <a href="<?php echo admin_url('admin.php?page=cm-form-submissions'); ?>" class="cm-smtp-btn cm-smtp-btn-primary" style="font-size:12px; padding:7px 16px; background:#d97706; text-decoration:none;">
                                    🔐 <?php _e('Ir a la Bandeja y Activar 2FA Ahora', 'contacto-multidestino'); ?>
                                </a>
                            </div>
                        </div>
                    <?php else : ?>

                        <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap:18px; margin-top:8px;">
                            
                            <!-- 1. Descargar Backup Cifrado -->
                            <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:14px; padding:18px; display:flex; flex-direction:column; justify-content:space-between;">
                                <div>
                                    <div style="display:flex; align-items:center; gap:8px; margin-bottom:8px;">
                                        <span style="font-size:18px;">📥</span>
                                        <h4 style="margin:0; font-size:14px; font-weight:700; color:#0f172a;">Realizar Backup y Descargar</h4>
                                    </div>
                                    <p style="font-size:12px; color:#64748b; line-height:1.45; margin:0 0 12px;">
                                        Genera un archivo <code>.json</code> cifrado con <strong>todos los casos ingresados, mensajes de trazabilidad, formularios, áreas y credenciales SMTP</strong>.
                                    </p>
                                </div>
                                <form method="post">
                                    <?php wp_nonce_field('cm_export_backup_action', 'cm_export_backup_nonce'); ?>
                                    <div style="margin-bottom:10px;">
                                        <label style="display:block; font-size:11.5px; font-weight:700; color:#334155; margin-bottom:4px;">
                                            🔑 <?php _e('Código 2FA de 6 dígitos:', 'contacto-multidestino'); ?>
                                        </label>
                                        <input type="text" name="cm_export_2fa_code" class="cm-smtp-input" placeholder="Ej: 582914" maxlength="6" inputmode="numeric" autocomplete="one-time-code" required style="font-size:13px; font-weight:700; text-align:center; letter-spacing:2px; height:36px; padding:6px 10px;" />
                                    </div>
                                    <button type="submit" class="cm-smtp-btn cm-smtp-btn-primary" style="width:100%; box-sizing:border-box; background:linear-gradient(135deg, #4f46e5 0%, #4338ca 100%);">
                                        🔒 Descargar Backup Cifrado (.JSON)
                                    </button>
                                </form>
                            </div>

                            <!-- 2. Subir y Restaurar Backup Cifrado -->
                            <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:14px; padding:18px;">
                                <div style="display:flex; align-items:center; gap:8px; margin-bottom:8px;">
                                    <span style="font-size:18px;">📤</span>
                                    <h4 style="margin:0; font-size:14px; font-weight:700; color:#0f172a;">Subir y Restaurar Backup</h4>
                                </div>
                                <p style="font-size:12px; color:#64748b; line-height:1.45; margin:0 0 12px;">
                                    Selecciona el archivo <code>.json</code> cifrado e ingresa tu código 2FA para descifrar e importar todos los datos.
                                </p>
                                <form method="post" enctype="multipart/form-data" onsubmit="return confirm('¿Estás seguro de restaurar este respaldo cifrado? Se importarán todos los casos, mensajes, formularios y configuraciones.');">
                                    <?php wp_nonce_field('cm_backup_import_action', 'cm_backup_import_nonce'); ?>
                                    <div style="margin-bottom:8px;">
                                        <input type="file" name="cm_backup_file" accept=".json,application/json" required style="font-size:11.5px; width:100%; border:1px dashed #cbd5e1; padding:6px; border-radius:8px; background:#ffffff;" />
                                    </div>
                                    <div style="margin-bottom:10px;">
                                        <label style="display:block; font-size:11.5px; font-weight:700; color:#334155; margin-bottom:4px;">
                                            🔑 <?php _e('Código 2FA de 6 dígitos actual:', 'contacto-multidestino'); ?>
                                        </label>
                                        <input type="text" name="cm_import_2fa_code" class="cm-smtp-input" placeholder="Ej: 582914" maxlength="6" inputmode="numeric" autocomplete="one-time-code" required style="font-size:13px; font-weight:700; text-align:center; letter-spacing:2px; height:36px; padding:6px 10px;" />
                                    </div>
                                    <button type="submit" class="cm-smtp-btn cm-smtp-btn-secondary" style="width:100%; box-sizing:border-box; background:#0284c7;">
                                        ⚡ Descifrar y Restaurar Todo
                                    </button>
                                </form>
                            </div>

                        </div>

                    <?php endif; ?>
                </div>
            </div>

            <div class="cm-sidebar-col">
                <div class="cm-smtp-card">
                    <div class="cm-info-header">
                        <h3>📚 Contraseña de Aplicación en Gmail</h3>
                        <p>Cuatro pasos para habilitar el envío</p>
                    </div>
                    <div class="cm-smtp-step">
                        <div class="cm-step-num">1</div>
                        <div class="cm-step-text">
                            <h4>Activa la Verificación en 2 Pasos</h4>
                            <p>Desde <a href="https://myaccount.google.com/security" target="_blank">myaccount.google.com/security</a>.</p>
                        </div>
                    </div>
                    <div class="cm-smtp-step">
                        <div class="cm-step-num">2</div>
                        <div class="cm-step-text">
                            <h4>Crea la Contraseña de Aplicación</h4>
                            <p>En <a href="https://myaccount.google.com/apppasswords" target="_blank">myaccount.google.com/apppasswords</a>, genera una para "Correo".</p>
                        </div>
                    </div>
                    <div class="cm-smtp-step">
                        <div class="cm-step-num">3</div>
                        <div class="cm-step-text">
                            <h4>Copia la clave de 16 caracteres</h4>
                            <p>Pégala en el campo "Contraseña de Aplicación".</p>
                        </div>
                    </div>
                    <div class="cm-smtp-step">
                        <div class="cm-step-num">4</div>
                        <div class="cm-step-text">
                            <h4>Guarda y envía la prueba</h4>
                            <p>Usa el botón "Enviar Prueba" para confirmar.</p>
                        </div>
                    </div>
                </div>

                <div class="cm-smtp-card">
                    <div class="cm-info-header">
                        <h3>💡 ¿Por qué se necesita SMTP?</h3>
                    </div>
                    <p style="font-size:13px;color:#424245;line-height:1.6;margin:0 0 12px;">En servidores locales y muchos hostings compartidos, <strong>PHP mail() está desactivado</strong> por seguridad.</p>
                    <p style="font-size:13px;color:#424245;line-height:1.6;margin:0;">SMTP usa tu propia cuenta como servidor de salida, garantizando la entrega en bandeja de entrada.</p>
                    <div class="cm-hint-box">
                        <p><b>🛡️ Configuración segura</b>Las credenciales se guardan en la base de datos de WordPress y nunca se exponen al frontend.</p>
                    </div>
                </div>
            </div>

        </div>
        </div>

        <div style="display:flex;align-items:center;justify-content:center;gap:12px;margin:18px auto 30px;max-width:980px;flex-wrap:wrap;">
            <a class="cm-credit-bar" href="https://example.com" target="_blank" rel="noopener" title="Visitar https://example.com" style="display:flex;align-items:center;gap:8px;padding:12px 18px;background:#ffffff;border:1px solid #e8e8ed;border-radius:12px;color:#6e6e73;font-size:13px;text-decoration:none;">
                ⚡ Creado por <strong style="color:#1d1d1f;">https://example.com</strong>
            </a>
            <a href="none" target="_blank" rel="noopener noreferrer" style="display:flex;align-items:center;gap:8px;padding:12px 18px;background:#009ee3;color:#ffffff;font-weight:700;border-radius:12px;font-size:13px;text-decoration:none;box-shadow:0 2px 8px rgba(0,158,227,0.25);" title="Apoyar el proyecto con una donación">
                <img src="<?php echo esc_url(CM_PLUGIN_URL . 'assets/images/logo.gif'); ?>" alt="Universal Contact Form" style="width: 20px; height: 20px; border-radius: 50%; object-fit: cover; display: inline-block;" />
                <span>Donar al Desarrollador (Mercado Pago)</span>
            </a>
        </div>
    </div>

    <script>
    function cmSetPreset(host, port) {
        document.getElementById('cm_smtp_host').value = host;
        document.getElementById('cm_smtp_port').value = port;
        document.getElementById('cm_smtp_host').focus();
    }
    // Sincronizar usuario → correo remitente
    document.getElementById('cm_smtp_user').addEventListener('input', function() {
        const fromField = document.querySelector('input[name="cm_smtp_from"]');
        if (!fromField.dataset.edited) fromField.value = this.value;
    });
    document.querySelector('input[name="cm_smtp_from"]').addEventListener('input', function() {
        this.dataset.edited = '1';
    });
    // Toggle visual
    document.getElementById('cm_smtp_enabled_toggle').addEventListener('change', function() {
        this.closest('.cm-smtp-toggle-card').classList.toggle('on', this.checked);
    });
    document.getElementById('cm_forms_visible_toggle').addEventListener('change', function() {
        this.closest('.cm-smtp-toggle-card').classList.toggle('on', this.checked);
    });
    </script>
    <?php
}
