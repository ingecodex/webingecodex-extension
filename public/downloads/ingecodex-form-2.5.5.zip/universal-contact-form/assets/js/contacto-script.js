(function($) {
    'use strict';

    $(document).ready(function() {

        $('.cm-contact-form').each(function() {
        var $form       = $(this);
        var $response   = $form.closest('.cm-form-container').find('.cm-response-msg').first();
        var $submitBtn  = $form.find('.cm-submit-button');
        var $btnText    = $submitBtn.find('.cm-btn-text');
        var $btnSpinner = $submitBtn.find('.cm-btn-spinner');

        if (!$form.length) return;

        $(document).on('click', '.cm-open-terms-link', function(e) {
            e.preventDefault();
            e.stopPropagation();
            var targetModalId = $(this).data('modal-target');
            if (targetModalId) {
                $('#' + targetModalId).fadeIn(200).css('display', 'flex');
                $('body').css('overflow', 'hidden');
            }
        });

        $(document).on('click', '.cm-close-terms-btn', function(e) {
            e.preventDefault();
            e.stopPropagation();
            var targetModalId = $(this).data('modal-target');
            if (targetModalId) {
                $('#' + targetModalId).fadeOut(150);
                $('body').css('overflow', '');
            }
        });

        $(document).on('click', '.cm-terms-modal-backdrop', function(e) {
            if ($(e.target).hasClass('cm-terms-modal-backdrop')) {
                $(this).fadeOut(150);
                $('body').css('overflow', '');
            }
        });

        $(document).on('click', '.cm-accept-terms-btn', function(e) {
            e.preventDefault();
            var targetModalId = $(this).data('modal-target');
            var checkboxId    = $(this).data('checkbox-id');

            if (checkboxId) {
                $('#' + checkboxId).prop('checked', true).trigger('change');
            }
            if (targetModalId) {
                $('#' + targetModalId).fadeOut(150);
                $('body').css('overflow', '');
            }
        });

        $(document).on('change', '.cm-file-input', function() {
            var $input    = $(this);
            var $dropzone = $input.closest('.cm-file-dropzone');
            var $text     = $dropzone.find('.cm-file-text');
            var $help     = $dropzone.find('.cm-field-help');

            if (this.files && this.files.length > 0) {
                var file = this.files[0];
                var sizeStr = (file.size < 1048576)
                    ? (file.size / 1024).toFixed(1) + ' KB'
                    : (file.size / 1048576).toFixed(2) + ' MB';

                $dropzone.addClass('cm-file-selected').css({
                    'border-color': 'var(--cm-primary, #4f46e5)',
                    'background-color': '#eef2ff'
                });

                $text.html('✅ <strong>' + escapeHtml(file.name) + '</strong> (' + sizeStr + ')');
                $help.html('<span style="color: #4f46e5; cursor: pointer; text-decoration: underline;" class="cm-clear-file">Haz clic aquí para cambiar o quitar el archivo</span>');
            } else {
                resetDropzone($dropzone);
            }
        });

        $(document).on('click', '.cm-clear-file', function(e) {
            e.preventDefault();
            e.stopPropagation();
            var $dropzone = $(this).closest('.cm-file-dropzone');
            var $input    = $dropzone.find('.cm-file-input');
            $input.val('');
            resetDropzone($dropzone);
        });

        function resetDropzone($dropzone) {
            $dropzone.removeClass('cm-file-selected').css({
                'border-color': '',
                'background-color': ''
            });
            $dropzone.find('.cm-file-text').text('Arrastra o haz clic para subir tu archivo');
            $dropzone.find('.cm-field-help').text('PDF, DOCX, XLSX, JPG, PNG, ZIP. Máx 5 MB.');
        }

        $(document).on('dragover dragenter', '.cm-file-dropzone', function(e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).css({
                'border-color': 'var(--cm-primary, #4f46e5)',
                'background-color': '#eef2ff',
                'transform': 'scale(1.01)'
            });
        });

        $(document).on('drop', '.cm-file-dropzone', function(e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).removeClass('cm-dragover').css('background-color', '');
            var files = e.originalEvent.dataTransfer.files;
            if (files.length > 0) {
                var $input = $(this).find('.cm-file-input');
                $input[0].files = files;
                $input.trigger('change');
            }
        });

        // Validación en tiempo real para prohibición de enlaces
        $(document).on('input', 'input[data-allow-links="false"], textarea[data-allow-links="false"]', function() {
            var $input = $(this);
            var val = $input.val();
            var hasLinks = /(https?:\/\/|www\.)/i.test(val);
            var $wrapper = $input.closest('.cm-input-wrapper');
            var $alert = $wrapper.find('.cm-link-alert');

            if (hasLinks) {
                if ($alert.length === 0) {
                    $wrapper.append('<div class="cm-link-alert" style="color: #9333ea; font-size: 12px; margin-top: 6px; padding: 6px 10px; background: #faf5ff; border: 1px solid #e9d5ff; border-radius: 6px;">⚠️ No se permiten enlaces (URLs) en este campo. Por favor, elimínalo.</div>');
                }
                $input.css('border-color', '#9333ea');
                $input.addClass('cm-has-error');
            } else {
                if ($alert.length > 0) {
                    $alert.remove();
                    $input.css('border-color', '');
                    $input.removeClass('cm-has-error');
                }
            }
        });

        $(document).on('dragleave drop', '.cm-file-dropzone', function(e) {
            e.preventDefault();
            e.stopPropagation();
            if (!$(this).hasClass('cm-file-selected')) {
                $(this).css({
                    'border-color': '',
                    'background-color': '',
                    'transform': ''
                });
            } else {
                $(this).css({ 'transform': '' });
            }
        });

        $form.on('submit', function(e) {
            e.preventDefault();

            if ($form.find('.cm-has-error').length > 0) {
                $response.show().addClass('cm-error').html('⚠️ Por favor, corrige los campos con errores antes de enviar.');
                return;
            }

            $response.hide().removeClass('cm-success cm-error').html('');

            var formData = new FormData(this);
            formData.append('action', 'cm_submit_form');
            var formId = this.getAttribute('data-form-id');
            if (formId) {
                formData.append('cm_form_id', formId);
            }
            if (typeof cm_ajax_object !== 'undefined' && cm_ajax_object.nonce) {
                formData.append('cm_nonce', cm_ajax_object.nonce);
            }

            $submitBtn.prop('disabled', true);
            var originalBtnText = $btnText.text();
            var sendingText = (typeof cm_ajax_object !== 'undefined' && cm_ajax_object.strings && cm_ajax_object.strings.sending)
                ? cm_ajax_object.strings.sending
                : 'Enviando...';

            $btnText.text(sendingText);
            $btnSpinner.show();

            var ajaxUrl = (typeof cm_ajax_object !== 'undefined' && cm_ajax_object.ajax_url)
                ? cm_ajax_object.ajax_url
                : '/wp-admin/admin-ajax.php';

            $.ajax({
                url: ajaxUrl,
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(res) {
                    $btnSpinner.hide();
                    $submitBtn.prop('disabled', false);
                    $btnText.text(originalBtnText);

                    if (res.success) {
                        var trackingUrl = (res.data && res.data.tracking_url) 
                            ? res.data.tracking_url 
                            : ('/?codigo=' + encodeURIComponent(res.data.ticket_code || ''));

                        var successHtml = '<div style="display:flex;align-items:flex-start;gap:14px;text-align:left;">' +
                            '<div style="font-size:24px;line-height:1;margin-top:2px;">✅</div>' +
                            '<div style="flex:1;">' +
                                '<div style="font-size:16px;font-weight:700;color:#065f46;line-height:1.4;">' + (res.data.message || '¡Tu mensaje ha sido enviado exitosamente!') + '</div>' +
                                (res.data.ticket_code ? '<div style="margin-top:12px;padding:14px 18px;background:#ffffff;border:1.5px dashed #10b981;border-radius:10px;display:block;box-shadow:0 4px 12px rgba(16,185,129,0.08);">' +
                                    '<span style="font-size:11px;font-weight:800;color:#047857;text-transform:uppercase;letter-spacing:0.06em;display:block;">Código de Seguimiento / Comprobante:</span>' +
                                    '<code style="font-family:monospace;font-size:22px;font-weight:900;color:#065f46;letter-spacing:2px;display:inline-block;margin:5px 0 10px 0;">' + res.data.ticket_code + '</code>' +
                                    '<div style="font-size:12px;color:#4b5563;margin-bottom:10px;line-height:1.4;">Guarda este código o haz clic en el botón a continuación para ver en tiempo real el estado y los requerimientos del área:</div>' +
                                    '<div>' +
                                        '<a href="' + trackingUrl + '" target="_blank" style="display:inline-flex;align-items:center;gap:6px;background:linear-gradient(135deg, #059669 0%, #047857 100%);color:#ffffff !important;text-decoration:none;padding:9px 18px;border-radius:8px;font-size:13.5px;font-weight:700;box-shadow:0 3px 10px rgba(5,150,105,0.25);transition:all 0.2s ease;">' +
                                            '🔍 Consultar Estado y Solicitudes de mi Caso &rarr;' +
                                        '</a>' +
                                    '</div>' +
                                '</div>' : '') +
                            '</div>' +
                        '</div>';

                        $response.addClass('cm-success').html(successHtml).slideDown();
                        $form[0].reset();
                        $form.find('.cm-file-dropzone').each(function() {
                            resetDropzone($(this));
                        });

                        $('html, body').animate({
                            scrollTop: $response.offset().top - 80
                        }, 400);
                    } else {
                        var errorMsg = res.data && res.data.message ? res.data.message : 'Ocurrió un error al enviar el formulario.';
                        $response.addClass('cm-error').html(errorMsg).slideDown();
                    }
                },
                error: function() {
                    $btnSpinner.hide();
                    $submitBtn.prop('disabled', false);
                    $btnText.text(originalBtnText);
                    $response.addClass('cm-error').html('Error de conexión al enviar el formulario. Por favor inténtalo de nuevo.').slideDown();
                }
            });
        });

        function escapeHtml(text) {
            var map = {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            };
            return text.replace(/[&<>"']/g, function(m) { return map[m]; });
        }
        });

        // =========================================================================
        // PORTAL PÚBLICO DE SEGUIMIENTO DE CASOS (AJAX LOOKUP)
        // =========================================================================
        $(document).on('submit', '#cm-tracker-search-form', function(e) {
            e.preventDefault();
            var $form = $(this);
            var $input = $('#cm-tracker-code-input');
            var $btn = $('#cm-tracker-submit-btn');
            var $btnText = $btn.find('.cm-btn-text');
            var $btnSpinner = $btn.find('.cm-btn-spinner');
            var $alert = $('#cm-tracker-alert');
            var $result = $('#cm-tracker-result');

            var code = $.trim($input.val());
            if (!code) {
                $input.focus();
                return;
            }

            $alert.hide().html('');
            $btn.prop('disabled', true);
            $btnText.text('Consultando...');
            $btnSpinner.show();

            var ajaxUrl = (typeof cm_ajax_object !== 'undefined' && cm_ajax_object.ajax_url)
                ? cm_ajax_object.ajax_url
                : '/wp-admin/admin-ajax.php';
            var nonce = (typeof cm_ajax_object !== 'undefined' && cm_ajax_object.nonce)
                ? cm_ajax_object.nonce
                : '';

            $.ajax({
                url: ajaxUrl,
                type: 'POST',
                data: {
                    action: 'cm_lookup_case_status',
                    ticket_code: code,
                    nonce: nonce
                },
                dataType: 'json',
                success: function(res) {
                    $btn.prop('disabled', false);
                    $btnText.text('Consultar Estado');
                    $btnSpinner.hide();

                    if (res.success && res.data && res.data.html) {
                        $result.html(res.data.html).slideDown(250);
                        $alert.hide();

                        // Scroll suave al resultado
                        $('html, body').animate({
                            scrollTop: $result.offset().top - 40
                        }, 350);
                    } else {
                        var errMsg = (res.data && res.data.message)
                            ? res.data.message
                            : 'No se encontró ningún caso con el código ingresado. Verifica e inténtalo de nuevo.';
                        $result.hide();
                        $alert.html('<div class="cm-alert-icon">⚠️</div><div class="cm-alert-content"><strong>Atención</strong><p>' + errMsg + '</p></div>').slideDown(200);
                    }
                },
                error: function() {
                    $btn.prop('disabled', false);
                    $btnText.text('Consultar Estado');
                    $btnSpinner.hide();
                    $result.hide();
                    $alert.html('<div class="cm-alert-icon">⚠️</div><div class="cm-alert-content"><strong>Error de conexión</strong><p>No se pudo conectar con el servidor para consultar el estado. Por favor intenta más tarde.</p></div>').slideDown(200);
                }
            });
        });

    });

    // Helper global para copiar el código del ticket
    window.cmCopyTicketCode = function(code) {
        if (!navigator.clipboard) {
            var tempInput = document.createElement('input');
            tempInput.value = code;
            document.body.appendChild(tempInput);
            tempInput.select();
            document.execCommand('copy');
            document.body.removeChild(tempInput);
        } else {
            navigator.clipboard.writeText(code);
        }
        var $btn = jQuery('.cm-copy-btn');
        $btn.find('.cm-copy-text').text('¡Copiado!');
        setTimeout(function() {
            $btn.find('.cm-copy-text').text('Copiar');
        }, 2000);
    };

    // Validación de tamaño de archivo (máx 4MB) en cliente
    window.cmValidateAttachFileSize = function(input) {
        if (input.files && input.files[0]) {
            var file = input.files[0];
            var maxSize = 4 * 1024 * 1024; // 4MB
            if (file.size > maxSize) {
                alert('⚠️ El archivo seleccionado supera el límite de 4 Megabytes. Por favor comprímelo o elige uno más liviano.');
                input.value = '';
                return false;
            }
            var ext = file.name.split('.').pop().toLowerCase();
            var allowed = ['jpg', 'jpeg', 'png', 'svg', 'bmp', 'pdf'];
            if (allowed.indexOf(ext) === -1) {
                alert('⚠️ Formato no permitido. Solo se aceptan archivos JPG, PNG, SVG, BMP o PDF.');
                input.value = '';
                return false;
            }
        }
    };

    // Envío AJAX de adjuntos desde el portal de seguimiento
    window.cmSubmitCaseAttachment = function(e, ticketCode) {
        e.preventDefault();

        var form = document.getElementById('cm-case-attach-form');
        var fileInput = document.getElementById('cm-attach-file');
        var commentInput = document.getElementById('cm-attach-comment');
        var btn = jQuery('#cm-attach-btn');
        var msgBox = jQuery('#cm-attach-msg');

        if (!fileInput.files || !fileInput.files[0]) {
            alert('Por favor selecciona un archivo para adjuntar.');
            return;
        }

        var ajaxObj = (typeof cm_ajax_object !== 'undefined') ? cm_ajax_object : ((typeof cmContactoVars !== 'undefined') ? cmContactoVars : {});
        var nonce = ajaxObj.nonce || jQuery('#cm-attach-nonce').val() || '';
        var ajaxUrl = ajaxObj.ajax_url || (typeof ajaxurl !== 'undefined' ? ajaxurl : '/wp-admin/admin-ajax.php');

        var formData = new FormData(form);
        formData.append('action', 'cm_public_submit_case_attachment');
        formData.append('ticket_code', ticketCode);
        formData.append('nonce', nonce);

        btn.prop('disabled', true).text('⏳ Subiendo documento...');
        msgBox.html('<span style="color:#0284c7;">Subiendo archivo y notificando al área...</span>');

        jQuery.ajax({
            url: ajaxUrl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            success: function(res) {
                btn.prop('disabled', false).text('📤 Enviar Documento al Área');
                if (res.success) {
                    alert('✓ ' + (res.data.message || 'Documento adjuntado exitosamente.'));
                    if (res.data.html) {
                        jQuery('#cm-tracker-result').html(res.data.html);
                    }
                } else {
                    msgBox.html('<span style="color:#ef4444;">❌ ' + (res.data.message || 'Error al subir archivo.') + '</span>');
                    alert('Error: ' + (res.data.message || 'No se pudo subir el archivo.'));
                }
            },
            error: function() {
                btn.prop('disabled', false).text('📤 Enviar Documento al Área');
                msgBox.html('<span style="color:#ef4444;">❌ Error de conexión. Inténtalo de nuevo.</span>');
                alert('Error de conexión.');
            }
        });
    };
    // ══════════════════════════════════════════════════════════════════
    // WIDGET INTERACTIVO: FORMATO Y VALIDACIÓN EN VIVO DE RUT / CÉDULA
    // ══════════════════════════════════════════════════════════════════
    window.cmFormatAndValidateRUT = function(input) {
        if (!input) return;
        var val = input.value.replace(/[^0-9kK]/g, '').toUpperCase();
        if (!val) {
            input.setCustomValidity('');
            input.style.borderColor = '';
            return;
        }

        var cuerpo = val.slice(0, -1);
        var dv = val.slice(-1);

        if (cuerpo.length > 0) {
            // Formatear con puntos
            var formatted = '';
            var count = 0;
            for (var i = cuerpo.length - 1; i >= 0; i--) {
                formatted = cuerpo.charAt(i) + formatted;
                count++;
                if (count === 3 && i > 0) {
                    formatted = '.' + formatted;
                    count = 0;
                }
            }
            input.value = formatted + '-' + dv;
        } else {
            input.value = dv;
        }

        // Validación Módulo 11 (RUT Chileno)
        if (cuerpo.length >= 7) {
            var suma = 0;
            var multiplo = 2;
            for (var j = cuerpo.length - 1; j >= 0; j--) {
                suma += parseInt(cuerpo.charAt(j)) * multiplo;
                multiplo = (multiplo === 7) ? 2 : multiplo + 1;
            }
            var dvEsperado = 11 - (suma % 11);
            var dvFinal = (dvEsperado === 11) ? '0' : ((dvEsperado === 10) ? 'K' : dvEsperado.toString());

            if (dv === dvFinal) {
                input.setCustomValidity('');
                input.style.borderColor = '#10b981';
                input.style.backgroundColor = '#f0fdf4';
            } else {
                input.setCustomValidity('El RUT ingresado no es válido.');
                input.style.borderColor = '#ef4444';
                input.style.backgroundColor = '#fef2f2';
            }
        } else {
            input.setCustomValidity('');
            input.style.borderColor = '';
            input.style.backgroundColor = '';
        }
    };

    // ══════════════════════════════════════════════════════════════════
    // WIDGET INTERACTIVO: FIRMA DIGITAL EN PANTALLA (CANVAS TOUCH/MOUSE)
    // ══════════════════════════════════════════════════════════════════
    window.cmInitSignatures = function() {
        document.querySelectorAll('.cm-signature-canvas').forEach(function(canvas) {
            if (canvas.getAttribute('data-sig-ready')) return;
            canvas.setAttribute('data-sig-ready', '1');

            var ctx = canvas.getContext('2d');
            var fieldId = canvas.getAttribute('data-field-id');
            var hiddenInput = document.getElementById(fieldId);
            var isDrawing = false;
            var hasDrawn = false;

            ctx.lineWidth = 2.5;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
            ctx.strokeStyle = '#0f172a';

            function getPos(e) {
                var rect = canvas.getBoundingClientRect();
                var scaleX = canvas.width / rect.width;
                var scaleY = canvas.height / rect.height;
                var clientX = e.touches ? e.touches[0].clientX : e.clientX;
                var clientY = e.touches ? e.touches[0].clientY : e.clientY;
                return {
                    x: (clientX - rect.left) * scaleX,
                    y: (clientY - rect.top) * scaleY
                };
            }

            function startDraw(e) {
                e.preventDefault();
                isDrawing = true;
                hasDrawn = true;
                var pos = getPos(e);
                ctx.beginPath();
                ctx.moveTo(pos.x, pos.y);
            }

            function draw(e) {
                if (!isDrawing) return;
                e.preventDefault();
                var pos = getPos(e);
                ctx.lineTo(pos.x, pos.y);
                ctx.stroke();
            }

            function endDraw(e) {
                if (!isDrawing) return;
                isDrawing = false;
                if (hasDrawn && hiddenInput) {
                    hiddenInput.value = canvas.toDataURL('image/png');
                }
            }

            canvas.addEventListener('mousedown', startDraw);
            canvas.addEventListener('mousemove', draw);
            canvas.addEventListener('mouseup', endDraw);
            canvas.addEventListener('mouseleave', endDraw);

            canvas.addEventListener('touchstart', startDraw, { passive: false });
            canvas.addEventListener('touchmove', draw, { passive: false });
            canvas.addEventListener('touchend', endDraw, { passive: false });
        });
    };

    window.cmClearSignature = function(fieldId) {
        var canvas = document.getElementById('cm-sig-canvas-' + fieldId);
        var hiddenInput = document.getElementById(fieldId);
        if (canvas) {
            var ctx = canvas.getContext('2d');
            ctx.clearRect(0, 0, canvas.width, canvas.height);
        }
        if (hiddenInput) {
            hiddenInput.value = '';
        }
    };

    // Auto-iniciar firmas al cargar la página
    $(document).ready(function() {
        if (window.cmInitSignatures) {
            window.cmInitSignatures();
        }
    });

})(jQuery);

