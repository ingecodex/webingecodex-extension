/*!
 * Universal Contact Form Widget
 * -----------------------------------------------------------
 * Widget inyectable (Headless / universal). Sin jQuery ni funciones
 * de WordPress: construye el formulario o el seguimiento de caso
 * en CUALQUIER web huésped (React, HTML plano, otro WordPress).
 *
 * Uso:
 *   <div id="universal-contact-form"></div>
 *   <script>
 *     window.UF_CONFIG = {
 *       apiBase: "https://tu-sitio.com/wp-json/universal-form/v1",
 *       mode: "form",            // "form" | "tracker"
 *       formId: "",              // id del formulario (vacío = activo)
 *       apiKey: ""               // solo si la API exige clave (X-UF-API-Key)
 *     };
 *   </script>
 *   <script src=".../universal-widget.js" defer></script>
 *
 * Variantes de contenedor:
 *   - <div data-uf-widget="form" data-uf-api="..."></div>
 *   - <div id="universal-contact-form"></div>
 *   - <div id="universal-form-container"></div>
 *   - <div id="ingecodex-form-container"></div>
 */
(function (window, document) {
  'use strict';

  if (window.UniversalForm && window.UniversalForm._loaded) {
    return;
  }

  var GLOBAL_CFG = window.UF_CONFIG || {};

  var DEFAULT_LABELS = {
    title: 'Formulario de Contacto',
    sending: 'Enviando...',
    success: 'Tu mensaje ha sido enviado con éxito.',
    error: 'Hubo un error al enviar tu mensaje. Intenta nuevamente.',
    required: 'Este campo es obligatorio.',
    emailInvalid: 'Ingresa un correo electrónico válido.',
    urlInvalid: 'Ingresa una URL válida.',
    termsRequired: 'Debes aceptar los términos para continuar.',
    selectFile: 'Seleccionar archivo',
    fileHint: 'Formato permitido según el campo.',
    trackerTitle: 'Consulta y Verificación de Solicitud y Casos',
    trackerSubtitle: 'Ingresa el código de seguimiento recibido por correo.',
    trackerPlaceholder: 'Ejemplo: CL849201',
    trackerButton: 'Consultar',
    notFound: 'No se encontró ningún caso con el código ingresado.',
    copy: 'Copiar',
    copied: '¡Copiado!',
  };

  function merge(base, extra) {
    var out = {};
    var k;
    for (k in base) { if (Object.prototype.hasOwnProperty.call(base, k)) out[k] = base[k]; }
    if (extra && typeof extra === 'object') {
      for (k in extra) { if (Object.prototype.hasOwnProperty.call(extra, k)) out[k] = extra[k]; }
    }
    return out;
  }

  function escapeHtml(str) {
    return String(str == null ? '' : str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function stripTags(html) {
    var tmp = document.createElement('div');
    tmp.innerHTML = html || '';
    return tmp.textContent || tmp.innerText || '';
  }

  function cssInject() {
    var id = 'uf-widget-styles';
    if (document.getElementById(id)) return;

    var style = document.createElement('style');
    style.id = id;
    style.textContent = [
      '.uf-widget{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;line-height:1.5;color:#0f172a;-webkit-font-smoothing:antialiased;box-sizing:border-box}',
      '.uf-widget *,.uf-widget *:before,.uf-widget *:after{box-sizing:border-box}',
      '.uf-card{background:#ffffff;border:1px solid #e2e8f0;border-radius:14px;padding:24px 22px;box-shadow:0 8px 24px rgba(15,23,42,.06)}',
      '.uf-title{margin:0 0 4px 0;font-size:20px;font-weight:800;letter-spacing:-0.02em}',
      '.uf-subtitle{margin:0 0 18px 0;font-size:13px;color:#64748b}',
      '.uf-grid{display:grid;grid-template-columns:repeat(12,1fr);gap:14px}',
      '.uf-field{display:flex;flex-direction:column;grid-column:span 12}',
      '.uf-field.w50{grid-column:span 6}',
      '.uf-field.w33{grid-column:span 4}',
      '.uf-field.w25{grid-column:span 3}',
      '.uf-label{font-size:12.5px;font-weight:700;color:#0f172a;margin-bottom:5px}',
      '.uf-label .uf-req{color:#dc2626}',
      '.uf-input,.uf-select,.uf-textarea{width:100%;font-size:14px;padding:10px 12px;border:1px solid #e2e8f0;border-radius:10px;background:#f8fafc;color:#0f172a;outline:none;transition:border-color .15s ease,box-shadow .15s ease}',
      '.uf-input:focus,.uf-select:focus,.uf-textarea:focus{border-color:var(--uf-primary,#0071e3);box-shadow:0 0 0 3px rgba(0,113,227,.12);background:#fff}',
      '.uf-textarea{min-height:96px;resize:vertical}',
      '.uf-check{display:flex;align-items:flex-start;gap:8px;font-size:13px;color:#334155}',
      '.uf-check input{margin-top:2px}',
      '.uf-file{border:1.5px dashed #cbd5e1;border-radius:10px;padding:12px;background:#f8fafc;font-size:13px;cursor:pointer}',
      '.uf-help{font-size:11px;color:#94a3b8;margin-top:4px}',
      '.uf-error{font-size:12px;color:#dc2626;margin-top:4px;display:none}',
      '.uf-field.has-error .uf-error{display:block}',
      '.uf-field.has-error .uf-input,.uf-field.has-error .uf-select,.uf-field.has-error .uf-textarea{border-color:#dc2626}',
      '.uf-row-range{display:flex;align-items:center;gap:10px}',
      '.uf-row-range output{font-weight:800;color:var(--uf-primary,#0071e3);min-width:44px;text-align:center}',
      '.uf-btn{width:100%;border:none;cursor:pointer;padding:12px 18px;border-radius:10px;font-size:14.5px;font-weight:800;color:#ffffff;background:linear-gradient(135deg,var(--uf-primary,#0071e3) 0%,#0056b3 100%);box-shadow:0 4px 12px rgba(0,113,227,.25);transition:filter .15s ease,transform .15s ease}',
      '.uf-btn:hover{filter:brightness(.94);transform:translateY(-1px)}',
      '.uf-btn:disabled{opacity:.6;cursor:progress;transform:none}',
      '.uf-alert{padding:12px 14px;border-radius:10px;font-size:13.5px;margin:0 0 14px 0;display:none}',
      '.uf-alert-error{background:#fef2f2;color:#b91c1c;border:1px solid #fecaca}',
      '.uf-alert-success{background:#f0fdf4;color:#15803d;border:1px solid #bbf7d0}',
      '.uf-success-ticket{display:inline-block;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-weight:900;letter-spacing:2px;background:#eef2ff;color:#1e1b4b;border:1.5px dashed #818cf8;border-radius:10px;padding:10px 16px;margin:8px 0 4px 0;font-size:20px}',
      '.uf-tracking-link{display:inline-block;margin-top:8px;color:var(--uf-primary,#0071e3);font-weight:800;text-decoration:none;font-size:13px}',
      '.uf-credit{margin-top:16px;text-align:right;font-size:11px;color:#94a3b8}',
      '.uf-credit a{color:var(--uf-primary,#0071e3);font-weight:600;text-decoration:none}',
      /* tracker */
      '.uf-tracker-input-group{display:flex;gap:10px;margin:14px 0}',
      '.uf-tracker-input{flex:1;font-size:14px;padding:12px 14px;border:1px solid #e2e8f0;border-radius:10px;background:#f8fafc;outline:none}',
      '.uf-tracker-btn{padding:12px 20px;border:none;border-radius:10px;font-weight:800;font-size:14px;color:#fff;background:var(--uf-primary,#0071e3);cursor:pointer}',
      '.uf-case{border:1px solid #e2e8f0;border-radius:12px;background:#fff;overflow:hidden;margin-top:16px}',
      '.uf-case-head{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:14px 16px;background:#f8fafc;border-bottom:1px solid #e2e8f0;flex-wrap:wrap}',
      '.uf-case-code{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-weight:900;letter-spacing:1px;font-size:15px}',
      '.uf-status-badge{padding:4px 12px;border-radius:20px;font-size:12px;font-weight:800}',
      '.uf-steps{display:flex;align-items:center;justify-content:space-between;padding:18px 20px;gap:4px}',
      '.uf-step{display:flex;flex-direction:column;align-items:center;gap:4px;font-size:11px;color:#94a3b8;text-align:center;flex:1}',
      '.uf-step-dot{width:26px;height:26px;border-radius:50%;background:#e2e8f0;color:#64748b;font-weight:800;font-size:12px;display:flex;align-items:center;justify-content:center}',
      '.uf-step.active .uf-step-dot{background:var(--uf-primary,#0071e3);color:#fff}',
      '.uf-step.done .uf-step-dot{background:#16a34a;color:#fff}',
      '.uf-step-line{flex:2;height:3px;background:#e2e8f0}',
      '.uf-step-line.active{background:var(--uf-primary,#0071e3)}',
      '.uf-case-body{padding:16px 20px}',
      '.uf-info-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin-bottom:16px}',
      '.uf-info-card{background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:10px 12px}',
      '.uf-info-label{font-size:11px;color:#64748b;font-weight:700}',
      '.uf-info-value{font-size:13px;font-weight:800;color:#0f172a;display:block;margin-top:2px}',
      '.uf-timeline{list-style:none;margin:10px 0 0 0;padding:0;border-left:2px solid #e2e8f0;padding-left:16px}',
      '.uf-timeline li{position:relative;padding:0 0 16px 6px;font-size:13px}',
      '.uf-timeline li:before{content:"";position:absolute;left:-23px;top:4px;width:10px;height:10px;border-radius:50%;background:var(--uf-primary,#0071e3)}',
      '.uf-timeline .author{font-weight:800;color:#0f172a}',
      '.uf-timeline .time{color:#94a3b8;font-size:11px;margin-left:6px}',
      '.uf-timeline .note{color:#475569;margin-top:3px;white-space:pre-line;word-break:break-word}',
      '.uf-summary{background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:12px 14px;margin-top:4px}',
      '.uf-summary-row{display:flex;gap:8px;font-size:13px;padding:4px 0;border-bottom:1px solid #f1f5f9}',
      '.uf-summary-row:last-child{border-bottom:none}',
      '.uf-summary-label{color:#475569;font-weight:700;min-width:40%}',
      '.uf-summary-value{color:#0f172a;word-break:break-word}',
      /* responsive */
      '@media(max-width:640px){.uf-field.w50,.uf-field.w33,.uf-field.w25{grid-column:span 12}.uf-steps{flex-wrap:wrap}.uf-tracker-input-group{flex-direction:column}}',
    ].join('\n');
    document.head.appendChild(style);
  }

  function getContainerConfig(el) {
    var attr = function (name) {
      var v = el.getAttribute(name);
      return v === null ? undefined : v;
    };

    return {
      mode: attr('data-uf-widget') || attr('data-uf-mode') || GLOBAL_CFG.mode || 'form',
      apiBase: attr('data-uf-api') || GLOBAL_CFG.apiBase || '',
      formId: attr('data-uf-form') || GLOBAL_CFG.formId || '',
      formToken: attr('data-uf-token') || GLOBAL_CFG.formToken || '',
      apiKey: attr('data-uf-key') || GLOBAL_CFG.apiKey || '',
      title: attr('data-uf-title') || undefined,
      primary: attr('data-uf-color') || GLOBAL_CFG.primaryColor || undefined,
      labels: GLOBAL_CFG.labels || {},
    };
  }

  function request(url, options) {
    options = options || {};
    var headers = options.headers || {};
    headers['Accept'] = 'application/json';

    if (options.apiKey) {
      headers['X-UF-API-Key'] = options.apiKey;
    }

    return fetch(url, {
      method: options.method || 'GET',
      headers: headers,
      body: options.body,
    }).then(function (res) {
      return res.json().catch(function () {
        return { success: false, message: 'Respuesta inválida del servidor.' };
      }).then(function (json) {
        if (!res.ok && !json.success) {
          throw new Error(json.message || 'Error HTTP ' + res.status);
        }
        return json;
      });
    });
  }

  /* ------------------------------------------------------------------
   * FORM WIDGET
   * ---------------------------------------------------------------- */
  function FormWidget(container, config) {
    this.container = container;
    this.config = config;
    this.schema = null;
  }

  FormWidget.prototype.init = function () {
    var self = this;
    this.renderLoading();

    var url = this.config.apiBase + '/forms';
    var q = [];
    if (this.config.formId) {
      q.push('form_id=' + encodeURIComponent(this.config.formId));
    }
    if (this.config.formToken) {
      q.push('form_token=' + encodeURIComponent(this.config.formToken));
    }
    if (q.length > 0) {
      url += (url.indexOf('?') >= 0 ? '&' : '?') + q.join('&');
    }

    request(url)
      .then(function (json) {
        if (!json.success || !json.data || !json.data.schema) {
          throw new Error('No se pudo obtener el formulario.');
        }
        self.schema = json.data.schema;
        if (json.data.form_token && !self.config.formToken) {
          self.config.formToken = json.data.form_token;
        }
        self.renderForm();
      })
      .catch(function (err) {
        self.renderError(err.message || DEFAULT_LABELS.error);
      });
  };

  FormWidget.prototype.renderLoading = function () {
    this.container.innerHTML = '<div class="uf-widget" style="padding:20px;text-align:center;color:#64748b;">Cargando formulario…</div>';
  };

  FormWidget.prototype.renderError = function (msg) {
    this.container.innerHTML =
      '<div class="uf-widget"><div class="uf-alert uf-alert-error" style="display:block;">' +
      escapeHtml(msg) + '</div></div>';
  };

  FormWidget.prototype.renderForm = function () {
    var self = this;
    var schema = this.schema;
    var settings = schema.settings || {};
    var labels = merge(DEFAULT_LABELS, this.config.labels);
    var primary = this.config.primary || settings.primary_color || '#0071e3';

    var title = this.config.title || settings.title || labels.title;

    this.container.style.setProperty('--uf-primary', primary);
    this.container.innerHTML = '';

    var card = document.createElement('div');
    card.className = 'uf-widget uf-card';
    card.style.setProperty('--uf-primary', primary);

    var html = '<h3 class="uf-title">' + escapeHtml(title) + '</h3>';
    if (settings.subtitle) {
      html += '<p class="uf-subtitle">' + escapeHtml(settings.subtitle) + '</p>';
    }
    html += '<div class="uf-alert uf-alert-error" data-uf-alert></div>';
    html += '<div class="uf-grid">';

    (schema.fields || []).forEach(function (field) {
      html += self.buildField(field, settings, labels);
    });

    // Honeypot anti-spam (invisible para humanos)
    html += '<div style="position:absolute;left:-9999px;opacity:0;" aria-hidden="true">' +
      '<input type="text" name="cm_website" tabindex="-1" autocomplete="off" value="" />' +
      '</div>';

    var buttonText = settings.button_text || 'Enviar Mensaje';
    html += '<div class="uf-field"><button type="submit" class="uf-btn" data-uf-submit>' +
      escapeHtml(buttonText) + '</button></div>';
    html += '</div></div>';

    card.innerHTML = html;

    var form = document.createElement('form');
    form.setAttribute('novalidate', '');
    while (card.firstChild) form.appendChild(card.firstChild);
    this.container.appendChild(form);

    this.form = form;

    // Range outputs
    form.querySelectorAll('input[data-uf-range]').forEach(function (input) {
      var out = form.querySelector('output[for="' + input.id + '"]');
      var update = function () { if (out) out.value = input.value; };
      input.addEventListener('input', update);
    });

    // Términos -> modal simple
    form.querySelectorAll('[data-uf-terms-link]').forEach(function (link) {
      link.addEventListener('click', function (e) {
        e.preventDefault();
        var title2 = link.getAttribute('data-uf-terms-link');
        var content = link.getAttribute('data-uf-terms-content');
        var box = self.buildTermsModal(title2, content);
        document.body.appendChild(box);
      });
    });

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      self.onSubmit();
    });
  };

  FormWidget.prototype.buildTermsModal = function (title, content) {
    var ov = document.createElement('div');
    ov.style.cssText = 'position:fixed;inset:0;background:rgba(15,23,42,.5);z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px;';
    ov.addEventListener('click', function (e) { if (e.target === ov) ov.remove(); });

    var box = document.createElement('div');
    box.style.cssText = 'background:#fff;border-radius:14px;max-width:560px;width:100%;max-height:80vh;overflow:auto;padding:22px 24px;';
    box.innerHTML =
      '<h3 style="margin:0 0 10px 0;font-size:17px;">' + escapeHtml(title) + '</h3>' +
      '<div style="white-space:pre-line;font-size:13px;color:#475569;line-height:1.7;">' +
      escapeHtml(content || '') + '</div>' +
      '<button type="button" style="margin-top:16px;padding:9px 18px;background:#0071e3;color:#fff;border:none;border-radius:8px;font-weight:700;cursor:pointer;">Cerrar</button>';
    box.querySelector('button').addEventListener('click', function () { ov.remove(); });
    ov.appendChild(box);
    return ov;
  };

  FormWidget.prototype.buildField = function (field, settings, labels) {
    var id = field.id;
    var label = field.label;
    var widthClass = field.width === '50' ? ' w50' : (field.width === '33' ? ' w33' : (field.width === '25' ? ' w25' : ''));
    var req = field.required ? ' <span class="uf-req">*</span>' : '';
    var type = field.type;
    var placeholder = field.placeholder || '';
    var help = field.help ? '<div class="uf-help">' + escapeHtml(field.help) + '</div>' : '';
    var out = '';

    if (type === 'heading') {
      return '<div class="uf-field"><h4 style="margin:6px 0 0 0;font-size:16px;color:#0f172a;">' + escapeHtml(label) + '</h4></div>';
    }
    if (type === 'divider') {
      return '<div class="uf-field"><hr style="border:none;border-top:1px solid #e2e8f0;margin:2px 0;"></div>';
    }
    if (type === 'hidden') {
      return '<input type="hidden" name="' + escapeHtml(id) + '" value="' + escapeHtml(field.value || '') + '" />';
    }

    var labelHtml = '<label class="uf-label" for="uf-' + escapeHtml(id) + '">' + escapeHtml(label) + req + '</label>';

    switch (type) {
      case 'textarea':
        out = '<div class="uf-field' + widthClass + '" data-uf-field="' + escapeHtml(id) + '" data-uf-type="textarea">' +
          labelHtml +
          '<textarea id="uf-' + escapeHtml(id) + '" name="' + escapeHtml(id) + '" class="uf-textarea" placeholder="' + escapeHtml(placeholder) + '" data-req="' + (field.required ? '1' : '0') + '"></textarea>' +
          help + '<div class="uf-error">' + labels.required + '</div></div>';
        break;

      case 'select':
      case 'department':
        var opts = (field.options || []).map(function (o, i) {
          var v = typeof o === 'string' ? o : (o.nombre || o.label || '');
          return '<option value="' + escapeHtml(String(i)) + '">' + escapeHtml(v) + '</option>';
        }).join('');
        out = '<div class="uf-field' + widthClass + '" data-uf-field="' + escapeHtml(id) + '" data-uf-type="select">' +
          labelHtml +
          '<select id="uf-' + escapeHtml(id) + '" name="' + escapeHtml(id) + '" class="uf-select" data-req="' + (field.required ? '1' : '0') + '">' +
          '<option value="">' + escapeHtml(field.placeholder || 'Selecciona una opción…') + '</option>' +
          opts + '</select>' +
          help + '<div class="uf-error">' + labels.required + '</div></div>';
        break;

      case 'checkbox':
      case 'terms':
        var isTerms = field.has_terms || field.type === 'terms';
        var termLink = '';
        if (isTerms && field.terms_title) {
          termLink = ' <a href="#" data-uf-terms-link="' + escapeHtml(field.terms_title) + '" data-uf-terms-content="' + escapeHtml(field.terms_content || '') + '" style="color:#0071e3;font-weight:700;">' + escapeHtml(field.terms_title) + '</a>';
        }
        out = '<div class="uf-field' + widthClass + '" data-uf-field="' + escapeHtml(id) + '" data-uf-type="terms">' +
          '<label class="uf-check" style="color:' + escapeHtml(settings.label_color || '#0f172a') + ';">' +
          '<input type="checkbox" name="' + escapeHtml(id) + '" value="1" data-req="' + (field.required ? '1' : '0') + '" />' +
          '<span>' + escapeHtml(label) + termLink + '</span></label>' +
          help + '<div class="uf-error">' + labels.termsRequired + '</div></div>';
        break;

      case 'toggle':
        out = '<div class="uf-field' + widthClass + '" data-uf-field="' + escapeHtml(id) + '" data-uf-type="toggle">' +
          '<label class="uf-check"><input type="checkbox" name="' + escapeHtml(id) + '" value="1" />' +
          '<span>' + escapeHtml(label) + req + '</span></label>' + help + '</div>';
        break;

      case 'range':
        var min = field.min || 0, max = field.max || 100, step = field.step || 1;
        out = '<div class="uf-field' + widthClass + '" data-uf-field="' + escapeHtml(id) + '" data-uf-type="range">' +
          labelHtml +
          '<div class="uf-row-range"><input id="uf-' + escapeHtml(id) + '" type="range" name="' + escapeHtml(id) + '" min="' + escapeHtml(String(min)) + '" max="' + escapeHtml(String(max)) + '" step="' + escapeHtml(String(step)) + '" value="' + escapeHtml(String(min)) + '" data-uf-range="" />' +
          '<output for="uf-' + escapeHtml(id) + '">' + escapeHtml(String(min)) + '</output></div>' +
          help + '</div>';
        break;

      case 'rating':
        var rating = '';
        for (var s = 5; s >= 1; s--) {
          rating += '<label style="cursor:pointer;font-size:22px;color:#e2e8f0;">' +
            '<input type="radio" name="' + escapeHtml(id) + '" value="' + s + '" style="display:none;" /><span data-uf-star data-v="' + s + '">★</span></label>';
        }
        out = '<div class="uf-field' + widthClass + '" data-uf-field="' + escapeHtml(id) + '" data-uf-type="rating">' +
          labelHtml + '<div data-uf-rating style="display:flex;gap:4px;">' + rating + '</div>' + help + '</div>';
        break;

      case 'file':
        out = '<div class="uf-field' + widthClass + '" data-uf-field="' + escapeHtml(id) + '" data-uf-type="file">' +
          labelHtml +
          '<input id="uf-' + escapeHtml(id) + '" type="file" name="' + escapeHtml(id) + '" class="uf-file" data-req="' + (field.required ? '1' : '0') + '" />' +
          help + '<div class="uf-error">' + labels.required + '</div></div>';
        break;

      default: // text, name, email, phone, tel, date, number, url, rut
        var inputType = type;
        if (type === 'phone' || type === 'tel') inputType = 'tel';
        if (type === 'rut') inputType = 'text';
        var emailClass = (type === 'email') ? ' data-email="1"' : '';
        var urlClass = (type === 'url') ? ' data-url="1"' : '';
        out = '<div class="uf-field' + widthClass + '" data-uf-field="' + escapeHtml(id) + '" data-uf-type="text">' +
          labelHtml +
          '<input id="uf-' + escapeHtml(id) + '" type="' + escapeHtml(inputType) + '" name="' + escapeHtml(id) + '" class="uf-input" placeholder="' + escapeHtml(placeholder) + '" data-req="' + (field.required ? '1' : '0') + '"' + emailClass + urlClass + ' />' +
          help + '<div class="uf-error">' + labels.required + '</div></div>';
    }

    return out;
  };

  FormWidget.prototype.collectData = function () {
    var data = {};
    this.form.querySelectorAll('[name]').forEach(function (el) {
      var name = el.getAttribute('name');
      if (!name) return;
      if (el.type === 'checkbox' || el.type === 'radio') {
        if (el.checked) data[name] = el.value;
        return;
      }
      data[name] = el.value;
    });
    return data;
  };

  FormWidget.prototype.validate = function () {
    var ok = true;
    var labels = merge(DEFAULT_LABELS, this.config.labels);

    this.form.querySelectorAll('[data-uf-field]').forEach(function (fieldEl) {
      var field = fieldEl.getAttribute('data-uf-field');
      var input = fieldEl.querySelector('[name="' + field + '"]');
      if (!input) return;
      var req = input.getAttribute('data-req') === '1';
      var value = (input.type === 'checkbox') ? (input.checked ? input.value : '') : input.value;
      var errEl = fieldEl.querySelector('.uf-error');
      var msg = '';

      if (req && (value === '' || value === null || value === undefined)) {
        msg = labels.required;
      } else if (value) {
        if (input.getAttribute('data-email') === '1' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
          msg = labels.emailInvalid;
        }
        if (input.getAttribute('data-url') === '1' && !/^https?:\/\/.+/.test(value)) {
          msg = labels.urlInvalid;
        }
      }

      if (msg) {
        ok = false;
        fieldEl.classList.add('has-error');
        if (errEl) errEl.textContent = msg;
      } else {
        fieldEl.classList.remove('has-error');
      }
    });

    // Términos: validación extra
    var termsMsg = labels.termsRequired;
    if (!ok) {
      // entrada vacía en términos requiere su mensaje específico
    }

    return ok;
  };

  FormWidget.prototype.onSubmit = function () {
    var self = this;
    var labels = merge(DEFAULT_LABELS, this.config.labels);
    var alertEl = this.form.querySelector('[data-uf-alert]');
    var submitBtn = this.form.querySelector('[data-uf-submit]');

    if (!this.validate()) {
      return;
    }

    alertEl.className = 'uf-alert uf-alert-error';
    alertEl.style.display = 'none';
    submitBtn.disabled = true;
    submitBtn.textContent = labels.sending;

    var hasFiles = !!this.form.querySelector('input[type="file"][name]');
    var hasSignature = false;
    var data = this.collectData();
    if (this.config.formToken) {
      data.form_token = this.config.formToken;
    }

    var payload;
    var isFormData = hasFiles || hasSignature;
    if (isFormData) {
      var fd = new FormData();
      Object.keys(data).forEach(function (k) { fd.append(k, data[k]); });
      // campos de archivo
      this.form.querySelectorAll('input[type="file"][name]').forEach(function (input) {
        if (input.files && input.files[0]) {
          fd.append(input.getAttribute('name'), input.files[0], input.files[0].name);
        }
      });
      payload = fd;
    } else {
      payload = JSON.stringify(data);
    }

    request(this.config.apiBase + '/submit', {
      method: 'POST',
      body: payload,
      apiKey: this.config.apiKey,
      headers: isFormData ? {} : { 'Content-Type': 'application/json' },
    })
      .then(function (json) {
        if (!json.success) {
          throw new Error(json.message || labels.error);
        }
        var d = json.data || {};
        self.renderSuccess(d, labels);
      })
      .catch(function (err) {
        alertEl.textContent = err.message || labels.error;
        alertEl.style.display = 'block';
        submitBtn.disabled = false;
        submitBtn.textContent = labels.submit || 'Enviar Mensaje';
      });
  };

  FormWidget.prototype.renderSuccess = function (data, labels) {
    var self = this;
    var alertEl = this.form.querySelector('[data-uf-alert]');

    var card = this.container;
    card.innerHTML = '<div class="uf-widget uf-card" style="text-align:center;padding:32px 24px;">' +
      '<div style="width:56px;height:56px;border-radius:50%;background:#dcfce7;color:#16a34a;font-size:30px;line-height:56px;margin:0 auto 12px auto;">&#10003;</div>' +
      '<h3 style="margin:0 0 8px 0;font-size:17px;color:#0f172a;">' + escapeHtml(data.message || labels.success) + '</h3>';

    if (data.ticket_code) {
      card.innerHTML +=
        '<div style="font-size:12px;color:#64748b;margin-top:6px;">Código de seguimiento</div>' +
        '<div class="uf-success-ticket">' + escapeHtml(data.ticket_code) + '</div>' +
        '<div><button type="button" class="uf-tracking-link" data-uf-copy="' + escapeHtml(data.ticket_code) + '">' +
        escapeHtml(labels.copy) + '</button></div>';
      card.innerHTML +=
        (data.tracking_url
          ? '<div><a class="uf-tracking-link" href="' + escapeHtml(data.tracking_url) + '" target="_blank" rel="noopener">Consultar estado de mi caso →</a></div>'
          : '');

      var btn = card.querySelector('[data-uf-copy]');
      if (btn) {
        btn.addEventListener('click', function () {
          var textarea = document.createElement('textarea');
          textarea.value = btn.getAttribute('data-uf-copy');
          document.body.appendChild(textarea);
          textarea.select();
          try { document.execCommand('copy'); } catch (e) { /* noop */ }
          document.body.removeChild(textarea);
          btn.textContent = labels.copied;
        });
      }
    }

    card.innerHTML += '</div>';
  };

  /* ------------------------------------------------------------------
   * TRACKER WIDGET
   * ---------------------------------------------------------------- */
  function TrackerWidget(container, config) {
    this.container = container;
    this.config = config;
  }

  TrackerWidget.prototype.init = function () {
    var self = this;
    var labels = merge(DEFAULT_LABELS, this.config.labels);
    var primary = this.config.primary || '#0071e3';

    this.container.style.setProperty('--uf-primary', primary);
    this.container.className = 'uf-widget';
    this.container.innerHTML =
      '<div class="uf-card">' +
      '<h3 class="uf-title">' + escapeHtml(labels.trackerTitle) + '</h3>' +
      '<p class="uf-subtitle">' + escapeHtml(labels.trackerSubtitle) + '</p>' +
      '<div class="uf-alert uf-alert-error" data-uf-alert style="display:none;"></div>' +
      '<div class="uf-tracker-input-group">' +
      '<input type="text" class="uf-tracker-input" data-uf-ticket placeholder="' + escapeHtml(labels.trackerPlaceholder) + '" maxlength="32" />' +
      '<button type="button" class="uf-tracker-btn" data-uf-track>' + escapeHtml(labels.trackerButton) + '</button>' +
      '</div>' +
      '<div data-uf-result></div>' +
      '</div>';

    var input = this.container.querySelector('[data-uf-ticket]');
    var btn = this.container.querySelector('[data-uf-track]');
    var alertEl = this.container.querySelector('[data-uf-alert]');

    function search() {
      var code = (input.value || '').trim().toUpperCase();
      alertEl.style.display = 'none';
      if (!code) {
        alertEl.textContent = labels.trackerPlaceholder;
        alertEl.style.display = 'block';
        return;
      }
      btn.disabled = true;
      var trackUrl = self.config.apiBase + '/track?ticket=' + encodeURIComponent(code);
      if (self.config.formToken) {
        trackUrl += '&token=' + encodeURIComponent(self.config.formToken);
      }
      request(trackUrl, {
        apiKey: self.config.apiKey,
      })
        .then(function (json) {
          if (!json.success || !json.data) {
            alertEl.textContent = json.message || labels.notFound;
            alertEl.style.display = 'block';
            return;
          }
          self.renderCase(json.data, labels);
        })
        .catch(function (err) {
          alertEl.textContent = err.message || labels.notFound;
          alertEl.style.display = 'block';
        })
        .finally(function () {
          btn.disabled = false;
        });
    }

    btn.addEventListener('click', search);
    input.addEventListener('keydown', function (e) { if (e.key === 'Enter') search(); });

    // Pre-cargar desde la URL (?codigo= o ?ticket=)
    var params = new URLSearchParams(window.location.search);
    var code = params.get('codigo') || params.get('ticket');
    if (code) {
      input.value = code;
      search();
    }
  };

  TrackerWidget.prototype.renderCase = function (caseData, labels) {
    var result = this.container.querySelector('[data-uf-result]');
    var statusKey = caseData.status || 'recibido';
    var step = (caseData.status_info && caseData.status_info.step) || 1;
    var isResolved = (statusKey === 'resuelto' || statusKey === 'cerrado');

    var steps = [
      { label: 'Recibido', active: step >= 1, done: step > 1 },
      { label: 'En Revisión', active: step >= 2, done: step > 2 },
      { label: statusKey === 'pendiente_usuario' ? 'Acción Requerida' : 'En Gestión', active: step >= 3, done: step > 3 },
      { label: 'Finalizado', active: step >= 4, done: isResolved },
    ];

    var stepsHtml = steps.map(function (s, i) {
      var cls = s.active ? ' active' : '';
      if (s.done) cls = ' done active';
      var dot = s.done ? '&#10003;' : String(i + 1);
      return '<div class="uf-step' + cls + '"><div class="uf-step-dot">' + dot + '</div>' + escapeHtml(s.label) + '</div>' +
        (i < steps.length - 1 ? '<div class="uf-step-line' + (s.active ? ' active' : '') + '"></div>' : '');
    }).join('');

    var info = [
      ['Área / Departamento', caseData.department || 'General'],
      ['Solicitante', caseData.sender_name || '-'],
      ['Fecha de ingreso', caseData.created_at ? caseData.created_at.replace('T', ' ').slice(0, 16) : '-'],
    ];

    var infoHtml = info.map(function (row) {
      return '<div class="uf-info-card"><span class="uf-info-label">' + escapeHtml(row[0]) + '</span>' +
        '<span class="uf-info-value">' + escapeHtml(row[1]) + '</span></div>';
    }).join('');

    var timelineHtml = '';
    if (caseData.history && caseData.history.length) {
      timelineHtml = '<h4 style="margin:14px 0 0 0;font-size:13.5px;color:#0f172a;">Historial y seguimiento</h4>' +
        '<ul class="uf-timeline">' +
        caseData.history.map(function (ev) {
          var time = ev.created_at ? ev.created_at.replace('T', ' ').slice(0, 16) : '';
          return '<li><span class="author">' + escapeHtml(ev.author || 'Sistema') + '</span>' +
            '<span class="time">' + escapeHtml(time) + '</span>' +
            (ev.note ? '<div class="note">' + escapeHtml(stripTags(ev.note)) + '</div>' : '') + '</li>';
        }).join('') + '</ul>';
    }

    var summaryHtml = '';
    if (caseData.submitted_data && Object.keys(caseData.submitted_data).length) {
      var rows = Object.keys(caseData.submitted_data).map(function (k) {
        return '<div class="uf-summary-row"><span class="uf-summary-label">' + escapeHtml(k) + '</span>' +
          '<span class="uf-summary-value">' + escapeHtml(stripTags(caseData.submitted_data[k])) + '</span></div>';
      }).join('');
      summaryHtml = '<div class="uf-summary">' + rows + '</div>';
    }

    var statusColor = (caseData.status_info && caseData.status_info.color) || '#475569';

    result.innerHTML =
      '<div class="uf-case">' +
      '<div class="uf-case-head">' +
      '<div><span style="font-size:11px;color:#64748b;font-weight:800;display:block;">CÓDIGO DE SEGUIMIENTO</span>' +
      '<span class="uf-case-code">' + escapeHtml(caseData.ticket_code) + '</span></div>' +
      '<span class="uf-status-badge" style="background:' + escapeHtml(statusColor) + ';color:#fff;">' +
      escapeHtml((caseData.status_info && caseData.status_info.label) || statusKey) + '</span>' +
      '</div>' +
      '<div class="uf-steps">' + stepsHtml + '</div>' +
      '<div class="uf-case-body">' +
      '<div class="uf-info-grid">' + infoHtml + '</div>' +
      summaryHtml +
      timelineHtml +
      (caseData.tracking_url
        ? '<div style="margin-top:14px;"><a class="uf-tracking-link" href="' + escapeHtml(caseData.tracking_url) + '" target="_blank" rel="noopener">Ver comprobante oficial →</a></div>'
        : '') +
      '</div></div>';
  };

  /* ------------------------------------------------------------------
   * BOOTSTRAP
   * ---------------------------------------------------------------- */
  function discover() {
    var containers = [];

    document.querySelectorAll('[data-uf-widget]').forEach(function (el) {
      containers.push({ el: el, cfg: getContainerConfig(el) });
    });

    if (!containers.length) {
      ['universal-contact-form', 'universal-form-container', 'ingecodex-form-container'].forEach(function (id) {
        var el = document.getElementById(id);
        if (el) {
          containers.push({ el: el, cfg: getContainerConfig(el) });
        }
      });
    }

    return containers;
  }

  function boot() {
    cssInject();

    var list = discover();

    if (!list.length && GLOBAL_CFG.apiBase) {
      var div = document.createElement('div');
      div.id = 'universal-contact-form';
      document.body.appendChild(div);
      var cfg = {
        mode: GLOBAL_CFG.mode || 'form',
        apiBase: GLOBAL_CFG.apiBase,
        formId: GLOBAL_CFG.formId || '',
        apiKey: GLOBAL_CFG.apiKey || '',
        labels: GLOBAL_CFG.labels,
      };
      list.push({ el: div, cfg: cfg });
    }

    list.forEach(function (item) {
      if (!item.cfg.apiBase) {
        item.el.innerHTML = '<div class="uf-widget" style="padding:20px;color:#dc2626;font-size:13px;">' +
          'Universal Contact Form: falta configurar <code>apiBase</code> en window.UF_CONFIG.</div>';
        return;
      }

      try {
        if (item.cfg.mode === 'tracker') {
          new TrackerWidget(item.el, item.cfg).init();
        } else {
          new FormWidget(item.el, item.cfg).init();
        }
      } catch (err) {
        item.el.innerHTML = '<div class="uf-widget" style="padding:20px;color:#dc2626;font-size:13px;">' + escapeHtml(err.message) + '</div>';
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  window.UniversalForm = {
    _loaded: true,
    version: '1.0.0',
    boot: boot,
    Form: FormWidget,
    Tracker: TrackerWidget,
  };
})(window, document);