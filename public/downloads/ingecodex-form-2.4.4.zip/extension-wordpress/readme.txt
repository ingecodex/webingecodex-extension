=== Ingecodex Form — Formulario Multidestino ===
Contributors: ingecodex
Donate link: https://ingecodex.com
Tags: formulario, contacto, multidestino, elementor, ingecodex, email, smtp, terminos y condiciones
Requires at least: 5.8
Tested up to: 6.7
Stable tag: 2.4.4
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Formulario de Contacto Multidestino profesional con constructor visual interactivo, soporte nativo para Elementor, ventana modal de Términos y Condiciones, fondos transparentes y envío por SMTP. Diseñado por Ingecodex (ingecodex.com).

== Descripción ==

Ingecodex Form de Ingecodex es una solución avanzada de formulario de contacto para WordPress y Elementor:

* **Constructor Visual Integrado (Form Studio)**: Diseña formularios arrastrando y soltando campos en vivo con previsualización responsive (Escritorio, Tablet, Móvil).
* **Enrutamiento Multidestino**: Asigna destinatarios específicos (correos individuales o múltiples separados por coma) a cada opción o departamento.
* **Modal Flotante de Términos y Condiciones**: Ventana emergente con desenfoque de fondo y botón "Aceptar Términos y Marcar Casilla" automático.
* **Modos de Diseño del Contenedor**: Soporte para formularios 100% Transparentes (para integrarse en fondos de Elementor), Planos (Flat), Modernos con Sombra o Cristal Glassmorphism.
* **Estilos por Campo**: Personalización de bordes y fondos individuales por cada campo.
* **Integración Nativa con Elementor**: Widget "Formulario Ingecodex" listo para arrastrar y soltar.
* **Subida de Archivos**: Dropzone interactivo con soporte de drag & drop, validación de extensiones y peso.
* **Envío Inteligente por AJAX**: Sin recargas de página, con spinner de carga y mensajes dinámicos.

== Instalación ==

1. Sube o copia la carpeta `extension-wordpress` en el directorio `/wp-content/plugins/` de tu WordPress.
2. Activa el plugin desde **Plugins > Plugins instalados**.
3. Ve a **Form Studio** en el menú de administración para diseñar y personalizar tu formulario.
4. Inserta el formulario usando el widget de Elementor **Formulario Ingecodex** o mediante el shortcode `[Formulario_Ingecodex]`.

== Shortcodes Disponibles ==

* `[Formulario_Ingecodex]` (Shortcode principal recomendado)
* `[formulario_ingecodex]`
* `[ingecodex_form]`
* `[formulario_contacto]` (Retrocompatible)

== Integración con Elementor ==

1. Edita cualquier página con **Elementor**.
2. En el buscador de widgets escribe **Ingecodex** o **Formulario**.
3. Arrastra el widget **Formulario Ingecodex** a tu sección.

== Changelog ==

= 2.4.1 =
* Añadido: los formularios permanecen ocultos para los visitantes si la conexión SMTP no está configurada.
* Añadido aviso exclusivo para administradores con acceso directo a "Ajustes de Correo SMTP".

= 2.7.0 =
* Añadido sistema de correos ejecutivos responsivos con diseño de alta gama.
* Añadido generador automático de código de seguimiento único con formato de 2 letras mayúsculas aleatorias y 6 dígitos (ej. CL123456).
* Añadida configuración de correos de destino por formulario (Ajustes) para formularios sin selector de departamento.
* Añadido auto-responder de confirmación con comprobante al usuario.
* Añadido catálogo de 12 plantillas especializadas en la Galería.
* Optimizado el grid fluido responsivo con Container Queries y proporción espaciosa de inputs.

= 2.6.0 =
* Añadida Galería de Plantillas con 12+ diseños pre-configurados para Educación, Negocios, Salud, Servicios, Tecnología y Marketing.
* Añadido selector de ancho máximo del contenedor (840px, 720px, 960px, 100%).

= 2.5.0 =
* Añadido soporte para ventana modal flotante de Términos y Condiciones con aceptación interactiva.
* Añadido preset de fondo Transparente, Plano (Flat) y Glassmorphism para integración perfecta en Elementor.
* Añadido soporte de personalización de estilo individual por campo.
* Añadido shortcode oficial `[Formulario_Ingecodex]` y widget nativo de Elementor `Formulario Ingecodex`.
* Añadido control total para editar u ocultar título y subtítulo del formulario.
