<?php
/**
 * Plugin Name: Ingecodex Form
 * Plugin URI:  https://ingecodex.com
 * Description: Constructor visual de formularios universales y seguimiento de casos con enrutamiento dinámico de correos por departamento, adjuntos, CRM con Kanban, API REST universal con CORS y portal público de trazabilidad.
 * Version: 2.5.6
 * Author: Ingecodex
 * Author URI: https://ingecodex.com
 * License: GPL2
 * Text Domain: contacto-multidestino
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

define('CM_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('CM_PLUGIN_URL', plugin_dir_url(__FILE__));
define('CM_VERSION', '2.5.6');

// Prevenir optimizaciones agresivas de caché antes de que inicien
if (isset($_GET['cm_portal']) || isset($_GET['print_audit'])) {
    if (!defined('LITESPEED_DISABLE_ALL')) define('LITESPEED_DISABLE_ALL', true);
    if (!defined('DONOTCACHEPAGE')) define('DONOTCACHEPAGE', true);
    if (!defined('DONOTMINIFY')) define('DONOTMINIFY', true);

    add_filter('litespeed_disable_all', '__return_true');
    add_filter('litespeed_optm_js_defer', '__return_false');
    add_filter('litespeed_can_optm', '__return_false');
}

require_once CM_PLUGIN_DIR . 'includes/default-schema.php';
require_once CM_PLUGIN_DIR . 'includes/case-database.php';
require_once CM_PLUGIN_DIR . 'includes/case-tracker-renderer.php';
require_once CM_PLUGIN_DIR . 'includes/admin-tracker-customizer.php';
require_once CM_PLUGIN_DIR . 'includes/auth-2fa.php';
require_once CM_PLUGIN_DIR . 'includes/admin-submissions.php';
require_once CM_PLUGIN_DIR . 'includes/admin-builder.php';
require_once CM_PLUGIN_DIR . 'includes/admin-settings.php';
require_once CM_PLUGIN_DIR . 'includes/form-renderer.php';
require_once CM_PLUGIN_DIR . 'includes/form-handler.php';
require_once CM_PLUGIN_DIR . 'includes/smtp-settings.php';
require_once CM_PLUGIN_DIR . 'includes/standalone-portal.php';
require_once CM_PLUGIN_DIR . 'includes/api-rest.php';
require_once CM_PLUGIN_DIR . 'includes/installer.php';

/* -------------------------------------------------------------------------
 * Gestión de formularios
 * ---------------------------------------------------------------------- */

function cm_get_all_forms() {
    $forms = get_option('cm_forms', array());
    if (!is_array($forms) || empty($forms)) {

        $legacy = get_option('cm_form_builder_schema', null);
        if (!$legacy && function_exists('cm_get_default_schema')) {
            $legacy = cm_get_default_schema();
        }
        $forms = array(
            'principal' => array(
                'id'         => 'principal',
                'name'       => 'Formulario Principal',
                'is_default' => true,
                'schema'     => $legacy ? $legacy : array('settings' => array(), 'fields' => array()),
            ),
        );
        update_option('cm_forms', $forms);
    }
    return $forms;
}

function cm_get_form($form_id = '') {
    $forms = cm_get_all_forms();
    $form_id = sanitize_key($form_id);
    if ($form_id && isset($forms[$form_id])) {
        return $forms[$form_id]['schema'];
    }

    foreach ($forms as $f) {
        if (!empty($f['is_default'])) return $f['schema'];
    }
    $first = reset($forms);
    return $first ? $first['schema'] : null;
}

function cm_get_default_form_id() {
    foreach (cm_get_all_forms() as $id => $f) {
        if (!empty($f['is_default'])) return $id;
    }
    $keys = array_keys(cm_get_all_forms());
    return $keys ? $keys[0] : '';
}

function cm_save_form($form_id, $name, $schema, $is_default = false) {
    $forms   = cm_get_all_forms();
    $form_id = sanitize_key($form_id);
    if (!$form_id) $form_id = 'form-' . substr(md5(uniqid()), 0, 6);

    if ($is_default) {
        foreach ($forms as &$f) $f['is_default'] = false;
        unset($f);
    }

    $forms[$form_id] = array(
        'id'         => $form_id,
        'name'       => sanitize_text_field($name ? $name : ('Formulario ' . count($forms))),
        'is_default' => $is_default || (1 === count($forms)),
        'schema'     => $schema,
    );
    update_option('cm_forms', $forms);

    $def = cm_get_form();
    if ($def) update_option('cm_form_builder_schema', $def);

    return $form_id;
}

function cm_delete_form($form_id) {
    $forms   = cm_get_all_forms();
    $form_id = sanitize_key($form_id);
    if (!$form_id || !isset($forms[$form_id]) || 1 >= count($forms)) return false;
    $was_default = !empty($forms[$form_id]['is_default']);
    unset($forms[$form_id]);
    if ($was_default) {
        $first = reset($forms);
        if ($first) $forms[$first['id']]['is_default'] = true;
    }
    update_option('cm_forms', $forms);
    return true;
}

function cm_get_forms_for_select() {
    $out = array();
    foreach (cm_get_all_forms() as $f) {
        $out[$f['id']] = $f['name'] . (!empty($f['is_default']) ? ' ★' : '');
    }
    return $out;
}

/* -------------------------------------------------------------------------
 * Menús de administración
 * ---------------------------------------------------------------------- */

function cm_register_admin_menus() {
    $menu_cap = current_user_can('manage_options') ? 'manage_options' : 'edit_posts';

    add_menu_page(
        'Formulario Universal',
        'Formulario Universal',
        $menu_cap,
        current_user_can('manage_options') ? 'cm-form-studio' : 'cm-form-submissions',
        current_user_can('manage_options') ? 'cm_render_admin_builder' : 'cm_render_admin_submissions_page',
        'dashicons-portfolio',
        25
    );

    if (current_user_can('manage_options')) {
        add_submenu_page(
            'cm-form-studio',
            'Editor Visual',
            'Editor Visual',
            'manage_options',
            'cm-form-studio',
            'cm_render_admin_builder'
        );
    }

    add_submenu_page(
        current_user_can('manage_options') ? 'cm-form-studio' : 'cm-form-submissions',
        'Bandeja de Casos y Envíos',
        '📥 Bandeja de Casos',
        'edit_posts',
        'cm-form-submissions',
        'cm_render_admin_submissions_page'
    );

    if (current_user_can('manage_options')) {
        add_submenu_page(
            'cm-form-studio',
            'Personalizar Portal de Consulta',
            '🌐 Personalizar Portal',
            'manage_options',
            'cm-tracker-customizer',
            'cm_render_tracker_customizer_page'
        );

        add_submenu_page(
            'cm-form-studio',
            'Ajustes de Envío (SMTP)',
            'Ajustes de Envío',
            'manage_options',
            'cm-form-smtp',
            'cm_render_smtp_settings_page'
        );

        add_submenu_page(
            'cm-form-studio',
            'Integración Universal (API y Widget)',
            '⚡ API Universal',
            'manage_options',
            'cm-universal-installer',
            'cm_render_universal_installer_page'
        );
    }
}
add_action('admin_menu', 'cm_register_admin_menus');

/* -------------------------------------------------------------------------
 * Perfiles de usuario / superadmin
 * ---------------------------------------------------------------------- */

/**
 * Determina si el usuario actual es el Superadministrador de WordPress (Webmaster).
 */
function cm_is_superadmin($user_id = 0) {
    if (!$user_id) $user_id = get_current_user_id();
    if (!$user_id) return false;
    $user = get_userdata($user_id);
    if (!$user) return false;

    $profile = get_user_meta($user_id, 'cm_user_profile', true);
    if ($profile === 'director' || $profile === 'moderator' || $profile === 'subdirector' || $profile === 'area_manager') {
        return false;
    }

    return in_array('administrator', (array)$user->roles) || (int)$user_id === 1;
}

function cm_clean_admin_menus_for_area_users() {
    if (!cm_is_superadmin()) {
        remove_menu_page('index.php');
        remove_menu_page('about.php');
        remove_menu_page('update-core.php');
        remove_menu_page('edit.php');
        remove_menu_page('upload.php');
        remove_menu_page('edit.php?post_type=page');
        remove_menu_page('edit-comments.php');
        remove_menu_page('themes.php');
        remove_menu_page('plugins.php');
        remove_menu_page('users.php');
        remove_menu_page('tools.php');
        remove_menu_page('options-general.php');
        remove_menu_page('edit.php?post_type=elementor_library');
        remove_menu_page('elementor');
        remove_menu_page('site-health.php');
    }
}
add_action('admin_menu', 'cm_clean_admin_menus_for_area_users', 999);

function cm_clean_admin_bar_for_app_users($wp_admin_bar) {
    if (!cm_is_superadmin()) {
        $wp_admin_bar->remove_node('wp-logo');
        $wp_admin_bar->remove_node('site-name');
        $wp_admin_bar->remove_node('comments');
        $wp_admin_bar->remove_node('new-content');
        $wp_admin_bar->remove_node('updates');
        $wp_admin_bar->remove_node('view-site');
        $wp_admin_bar->remove_node('dashboard');
    }
}
add_action('admin_bar_menu', 'cm_clean_admin_bar_for_app_users', 999);

function cm_hide_wp_footer_on_plugin_screens() {
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if ($screen && (strpos($screen->id, 'cm-') !== false || strpos($screen->base, 'cm-') !== false)) {
        echo '<style>#wpfooter { display: none !important; } #wpbody-content { padding-bottom: 20px !important; }</style>';
        echo '<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">';
    }
}
add_action('admin_head', 'cm_hide_wp_footer_on_plugin_screens');

function cm_redirect_area_user_on_login($redirect_to, $request, $user) {
    if (isset($user->ID)) {
        if (!cm_is_superadmin($user->ID)) {
            $is_dir = get_user_meta($user->ID, 'cm_user_profile', true) === 'director';
            if ($is_dir) {
                return admin_url('admin.php?page=cm-form-submissions&tab=dashboard');
            }
            return admin_url('admin.php?page=cm-form-submissions');
        }
    }
    return $redirect_to;
}
add_filter('login_redirect', 'cm_redirect_area_user_on_login', 10, 3);

function cm_enforce_app_user_redirection() {
    if (wp_doing_ajax() || wp_doing_cron()) {
        return;
    }

    $current_user_id = get_current_user_id();
    if (!$current_user_id) return;

    if (cm_is_superadmin($current_user_id)) {
        return;
    }

    $page = isset($_GET['page']) ? sanitize_key($_GET['page']) : '';

    if ($page !== 'cm-form-submissions') {
        $is_dir = function_exists('cm_is_director') && cm_is_director($current_user_id);
        $target = $is_dir
            ? admin_url('admin.php?page=cm-form-submissions&tab=dashboard')
            : admin_url('admin.php?page=cm-form-submissions');

        wp_safe_redirect($target);
        exit;
    }
}
add_action('admin_init', 'cm_enforce_app_user_redirection');

function cm_hide_wp_screen_options_for_app_users() {
    if (!cm_is_superadmin()) {
        echo '<style>
            #screen-meta-links, #contextual-help-link-wrap, #screen-options-link-wrap { display: none !important; }
            #wp-admin-bar-wp-logo, #wp-admin-bar-site-name, #wp-admin-bar-updates, #wp-admin-bar-comments, #wp-admin-bar-new-content { display: none !important; }
        </style>';
    }
}
add_action('admin_head', 'cm_hide_wp_screen_options_for_app_users');

add_filter('admin_footer_text', function ($text) {
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if ($screen && strpos($screen->id, 'cm-form') !== false) {
        return 'Aplicación creada por <a href="' . esc_url(home_url()) . '" target="_blank" rel="noopener">' . esc_html(get_bloginfo('name')) . '</a>';
    }
    return $text;
});

/* -------------------------------------------------------------------------
 * Assets del editor y frontend
 * ---------------------------------------------------------------------- */

function cm_enqueue_admin_studio_assets($hook) {
    if (strpos($hook, 'cm-form') === false && strpos($hook, 'form-studio') === false) {
        return;
    }

    wp_enqueue_style(
        'cm-builder-admin-style',
        CM_PLUGIN_URL . 'assets/css/builder-admin.css',
        array(),
        CM_VERSION
    );

    if (strpos($hook, 'cm-form-studio') !== false || strpos($hook, 'form-studio') !== false) {
        wp_enqueue_script(
            'cm-builder-admin-script',
            CM_PLUGIN_URL . 'assets/js/builder-admin.js',
            array('jquery', 'jquery-ui-sortable'),
            CM_VERSION,
            true
        );

        $active_form_id = isset($_GET['form']) ? sanitize_key($_GET['form']) : get_option('cm_current_form_id', '');

        wp_localize_script('cm-builder-admin-script', 'cmBuilderVars', array(
            'ajax_url'              => admin_url('admin-ajax.php'),
            'nonce'                 => wp_create_nonce('cm_contacto_nonce'),
            'forms'                 => function_exists('cm_get_forms_for_select') ? cm_get_forms_for_select() : array(),
            'shortcodes'            => function_exists('cm_get_form_shortcode_tags') ? cm_get_form_shortcode_tags() : array(),
            'form_id'               => $active_form_id,
            'initial_schema'        => function_exists('cm_get_form') ? cm_get_form($active_form_id) : null,
            'available_departments' => function_exists('cm_get_available_departments') ? cm_get_available_departments(true) : array(),
        ));
    }
}
add_action('admin_enqueue_scripts', 'cm_enqueue_admin_studio_assets');

function cm_register_elementor_widget_compat($widgets_manager = null) {
    static $done = false;
    if ($done) return;
    if (!did_action('elementor/loaded') || !class_exists('\Elementor\Widget_Base')) return;

    require_once CM_PLUGIN_DIR . 'includes/elementor-widget.php';
    $widget = new \CM_Elementor_Contact_Widget();

    if (is_object($widgets_manager) && method_exists($widgets_manager, 'register')) {
        $widgets_manager->register($widget);
    } elseif (is_object($widgets_manager) && method_exists($widgets_manager, 'register_widget_type')) {
        $widgets_manager->register_widget_type($widget);
    } else {
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type($widget);
    }

    if (!class_exists('\CM_Elementor_Contact_Widget_Alias')) {
        eval('class CM_Elementor_Contact_Widget_Alias extends \CM_Elementor_Contact_Widget {
            public function get_name() { return "cm_contacto_multidestino"; }
            public function show_in_panel() { return false; }
        }');
    }
    $alias = new \CM_Elementor_Contact_Widget_Alias();
    $wm   = is_object($widgets_manager) ? $widgets_manager : \Elementor\Plugin::instance()->widgets_manager;
    if (method_exists($wm, 'register')) { $wm->register($alias); }
    elseif (method_exists($wm, 'register_widget_type')) { $wm->register_widget_type($alias); }

    if (class_exists('\CM_Elementor_Tracker_Widget')) {
        $tracker_widget = new \CM_Elementor_Tracker_Widget();
        if (method_exists($wm, 'register')) { $wm->register($tracker_widget); }
        elseif (method_exists($wm, 'register_widget_type')) { $wm->register_widget_type($tracker_widget); }
    }

    $done = true;
}
add_action('elementor/widgets/register', 'cm_register_elementor_widget_compat');
add_action('elementor/widgets/widgets_registered', function () {
    cm_register_elementor_widget_compat(\Elementor\Plugin::instance()->widgets_manager);
});

function cm_enqueue_frontend_scripts() {
    wp_enqueue_style(
        'cm-contacto-style',
        CM_PLUGIN_URL . 'assets/css/contacto-style.css',
        array(),
        CM_VERSION
    );

    wp_enqueue_script(
        'cm-contacto-script',
        CM_PLUGIN_URL . 'assets/js/contacto-script.js',
        array('jquery'),
        CM_VERSION,
        true
    );

    $script_vars = array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('cm_contacto_nonce'),
        'strings'  => array(
            'sending'      => __('Enviando mensaje...', 'contacto-multidestino'),
            'success'      => __('¡Tu mensaje ha sido enviado con éxito! Gracias por contactarnos.', 'contacto-multidestino'),
            'error_generic'=> __('Hubo un error al enviar tu mensaje. Por favor intenta nuevamente.', 'contacto-multidestino'),
        ),
    );

    wp_localize_script('cm-contacto-script', 'cm_ajax_object', $script_vars);
    wp_localize_script('cm-contacto-script', 'cmContactoVars', $script_vars);
}
add_action('wp_enqueue_scripts', 'cm_enqueue_frontend_scripts');

/* -------------------------------------------------------------------------
 * Shortcodes
 * ---------------------------------------------------------------------- */

function cm_render_shortcode($atts = array()) {
    require_once CM_PLUGIN_DIR . 'includes/form-renderer.php';
    return cm_render_dynamic_form($atts);
}

function cm_get_form_shortcode_tags() {
    $tags = array();
    $used = array();
    foreach (cm_get_all_forms() as $fid => $f) {
        $base = str_replace('-', '_', sanitize_title($f['name']));
        if (!$base || is_numeric($base)) $base = $fid;
        $tag = 'formulario_' . $base;
        $n   = 2;
        while (isset($used[$tag])) {
            $tag = 'formulario_' . $base . '_' . $n;
            $n++;
        }
        $used[$tag] = true;
        $tags[$fid] = $tag;
    }
    return $tags;
}

function cm_get_form_shortcode_tag($form_id) {
    $map = cm_get_form_shortcode_tags();
    return isset($map[$form_id]) ? $map[$form_id] : '';
}

add_action('init', function () {
    foreach (cm_get_form_shortcode_tags() as $fid => $tag) {
        if (!shortcode_exists($tag)) {
            add_shortcode($tag, function ($atts = array()) use ($fid) {
                $atts       = is_array($atts) ? $atts : array();
                $atts['id'] = $fid;
                return cm_render_shortcode($atts);
            });
        }
    }
});

// Shortcodes de formularios (compatibilidad + genéricos)
add_shortcode('Formulario_Ingecodex', 'cm_render_shortcode');
add_shortcode('formulario_ingecodex', 'cm_render_shortcode');
add_shortcode('ingecodex_form', 'cm_render_shortcode');
add_shortcode('formulario_contacto', 'cm_render_shortcode');
add_shortcode('formulario_universal', 'cm_render_shortcode');
add_shortcode('universal_form', 'cm_render_shortcode');

// Shortcodes del Portal Público de Seguimiento
add_shortcode('seguimiento_caso', 'cm_render_case_tracker_portal');
add_shortcode('consultar_caso', 'cm_render_case_tracker_portal');
add_shortcode('ingecodex_seguimiento', 'cm_render_case_tracker_portal');
add_shortcode('ingecodex_tracking', 'cm_render_case_tracker_portal');
add_shortcode('seguimiento_universal', 'cm_render_case_tracker_portal');
add_shortcode('tracking_universal', 'cm_render_case_tracker_portal');

/* -------------------------------------------------------------------------
 * Activación y opciones por defecto
 * ---------------------------------------------------------------------- */

function cm_activate_plugin() {
    if (!get_option('cm_form_builder_schema')) {
        update_option('cm_form_builder_schema', cm_get_default_schema());
    }

    if (function_exists('cm_create_database_tables')) {
        cm_create_database_tables();
    }

    // Opciones de la API universal
    if (!get_option('cm_api_namespace')) {
        update_option('cm_api_namespace', 'universal-form/v1');
    }
    if (!get_option('cm_cors_origin')) {
        update_option('cm_cors_origin', '*');
    }
}
register_activation_hook(__FILE__, 'cm_activate_plugin');

// Comprobación de integridad de base de datos en administración
add_action('admin_init', function () {
    if (get_option('cm_db_version') !== '2.4.9' && function_exists('cm_create_database_tables')) {
        cm_create_database_tables();
    }
});

// Exponer la URL estática del widget (para embeber en sitios externos)
add_filter('upload_mimes', function ($mimes) {
    $mimes['js'] = 'application/javascript';
    return $mimes;
});

function cm_widget_file_url() {
    $file = CM_PLUGIN_DIR . 'widget/universal-widget.js';
    if (file_exists($file)) {
        return CM_PLUGIN_URL . 'widget/universal-widget.js';
    }
    return '';
}