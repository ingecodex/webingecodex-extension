<?php
/**
 * Universal Contact Form Form — Portal Público de Consulta y Seguimiento de Casos
 * Permite a los usuarios consultar el estado y solicitudes de su trámite mediante su código de ticket.
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Obtiene los ajustes de personalización del Portal de Seguimiento.
 */
function cm_get_tracker_settings() {
    $defaults = array(
        'badge_text'         => __('🛡️ PORTAL OFICIAL DE VERIFICACIÓN Y SEGUIMIENTO', 'contacto-multidestino'),
        'title'              => __('Consulta y Verificación de Solicitud y Casos', 'contacto-multidestino'),
        'subtitle'           => __('Ingresa tu código de seguimiento recibido por correo para conocer el estado, antecedentes y firma oficial de tu caso.', 'contacto-multidestino'),
        'search_placeholder' => 'Ejemplo: CL849201',
        'search_btn_text'    => __('Consultar y Verificar', 'contacto-multidestino'),
        'primary_color'      => '#0071e3',
        'btn_style'          => 'solid', // 'solid', 'transparent', 'glass', 'gradient'
        'btn_bg_color'       => '#0071e3',
        'btn_text_color'     => '#ffffff',
        'btn_border_color'   => '#0071e3',
        'btn_border_radius'  => '8',
        'card_style'         => 'signature', // 'signature', 'apple', 'glass', 'dark'
        'card_bg_color'      => '#ffffff',
        'show_seal'          => true,
        'seal_text'          => __('VERIFICACIÓN DIGITAL VÁLIDA', 'contacto-multidestino'),
        'show_hint'          => true,
        'hint_text'          => __('El código fue emitido y firmado electrónicamente al momento de completar la solicitud web.', 'contacto-multidestino'),
    );

    $saved = get_option('cm_tracker_settings', array());
    if (is_array($saved)) {
        return wp_parse_args($saved, $defaults);
    }
    return $defaults;
}

/**
 * Renderiza el portal público de seguimiento de casos mediante shortcode.
 * Shortcodes: [seguimiento_caso], [consultar_caso], [ingecodex_seguimiento]
 */
function cm_render_case_tracker_portal($atts = array()) {
    $settings = cm_get_tracker_settings();

    $atts = shortcode_atts(array(
        'title'       => $settings['title'],
        'subtitle'    => $settings['subtitle'],
        'code'        => '',
        'show_search' => 'true',
    ), $atts);

    // Obtener código desde parámetro GET si existe
    $requested_code = !empty($_GET['codigo']) ? sanitize_text_field($_GET['codigo']) : (!empty($_GET['ticket']) ? sanitize_text_field($_GET['ticket']) : $atts['code']);
    $requested_code = strtoupper(trim($requested_code));

    $initial_case = null;
    $initial_history = array();
    $case_not_found = false;

    if (!empty($requested_code)) {
        $initial_case = cm_get_submission_by_code($requested_code);
        if ($initial_case) {
            $initial_history = cm_get_case_updates($initial_case->id, true);
        } else {
            $case_not_found = true;
        }
    }

    $card_style = $settings['card_style'];
    $btn_style  = $settings['btn_style'] ?? 'solid';
    $btn_radius = $settings['btn_border_radius'] ?? '8';
    $container_classes = 'cm-tracker-container cm-style-' . esc_attr($card_style);

    ob_start();
    ?>
    <style>
    :root {
        --cm-tracker-primary: <?php echo esc_attr($settings['primary_color']); ?>;
        --cm-tracker-btn-bg: <?php echo esc_attr($settings['btn_bg_color']); ?>;
        --cm-tracker-btn-color: <?php echo esc_attr($settings['btn_text_color']); ?>;
        --cm-tracker-card-bg: <?php echo esc_attr($settings['card_bg_color']); ?>;
    }
    .cm-tracker-search-btn {
        border-radius: <?php echo esc_attr($btn_radius); ?>px !important;
        font-weight: 800 !important;
        display: inline-flex !important;
        align-items: center !important;
        justify-content: center !important;
        gap: 6px !important;
        cursor: pointer !important;
        transition: all 0.15s ease !important;
        text-decoration: none !important;
        <?php if ($btn_style === 'transparent') : ?>
            background: transparent !important;
            border: 2px solid <?php echo esc_attr($settings['btn_border_color'] ?: $settings['btn_bg_color']); ?> !important;
            color: <?php echo esc_attr($settings['btn_text_color']); ?> !important;
            box-shadow: none !important;
        <?php elseif ($btn_style === 'glass') : ?>
            background: rgba(255, 255, 255, 0.3) !important;
            backdrop-filter: blur(12px) !important;
            -webkit-backdrop-filter: blur(12px) !important;
            border: 1.5px solid <?php echo esc_attr($settings['btn_border_color'] ?: 'rgba(255,255,255,0.6)'); ?> !important;
            color: <?php echo esc_attr($settings['btn_text_color']); ?> !important;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08) !important;
        <?php elseif ($btn_style === 'gradient') : ?>
            background: linear-gradient(135deg, <?php echo esc_attr($settings['btn_bg_color']); ?> 0%, <?php echo esc_attr($settings['primary_color']); ?> 100%) !important;
            color: <?php echo esc_attr($settings['btn_text_color']); ?> !important;
            border: none !important;
            box-shadow: 0 4px 14px rgba(0, 113, 227, 0.3) !important;
        <?php else : ?>
            background: <?php echo esc_attr($settings['btn_bg_color']); ?> !important;
            color: <?php echo esc_attr($settings['btn_text_color']); ?> !important;
            border: none !important;
            box-shadow: 0 3px 10px rgba(0,0,0,0.18) !important;
        <?php endif; ?>
    }
    .cm-tracker-search-btn:hover {
        <?php if ($btn_style === 'transparent') : ?>
            background: <?php echo esc_attr($settings['btn_border_color'] ?: $settings['btn_bg_color']); ?> !important;
            color: #ffffff !important;
        <?php else : ?>
            filter: brightness(0.92) !important;
            transform: translateY(-1px);
        <?php endif; ?>
    }
    .cm-style-signature {
        border: 2px solid <?php echo esc_attr($settings['primary_color']); ?> !important;
        border-top: 6px solid <?php echo esc_attr($settings['primary_color']); ?> !important;
        background: <?php echo esc_attr($settings['card_bg_color']); ?> !important;
        border-radius: 14px !important;
        box-shadow: 0 6px 24px rgba(0, 113, 227, 0.08) !important;
    }
    .cm-style-signature .cm-case-card {
        border: 1.5px solid #e2e8f0 !important;
        background: #ffffff !important;
    }
    .cm-style-glass {
        background: rgba(255, 255, 255, 0.85) !important;
        backdrop-filter: blur(16px) !important;
        -webkit-backdrop-filter: blur(16px) !important;
        border: 1.5px solid rgba(255, 255, 255, 0.9) !important;
        border-radius: 18px !important;
        box-shadow: 0 10px 30px rgba(0,0,0,0.06) !important;
    }
    .cm-style-dark {
        background: #111827 !important;
        color: #f8fafc !important;
        border: 1px solid #1f2937 !important;
        border-radius: 16px !important;
    }
    .cm-style-dark .cm-tracker-title, .cm-style-dark .cm-case-card-title {
        color: #f8fafc !important;
    }
    .cm-style-dark .cm-tracker-subtitle, .cm-style-dark .cm-tracker-search-hint {
        color: #94a3b8 !important;
    }
    .cm-style-dark .cm-tracker-input {
        background: #1f2937 !important;
        color: #f8fafc !important;
        border-color: #374151 !important;
    }
    .cm-style-dark .cm-case-card {
        background: #1f2937 !important;
        border-color: #374151 !important;
        color: #f8fafc !important;
    }
    </style>

    <div class="<?php echo esc_attr($container_classes); ?>" id="cm-tracker-app">
        <!-- Encabezado del Portal de Seguimiento -->
        <div class="cm-tracker-header">
            <?php if (!empty($settings['badge_text'])) : ?>
                <div class="cm-tracker-badge" style="background:#f0f9ff; color:<?php echo esc_attr($settings['primary_color']); ?>; border:1px solid #bae6fd;">
                    <span class="cm-tracker-badge-icon">🛡️</span> <?php echo esc_html($settings['badge_text']); ?>
                </div>
            <?php endif; ?>
            <h2 class="cm-tracker-title"><?php echo esc_html($atts['title']); ?></h2>
            <p class="cm-tracker-subtitle"><?php echo esc_html($atts['subtitle']); ?></p>

            <?php if (!empty($settings['show_seal'])) : ?>
                <div class="cm-tracker-seal-wrap" style="text-align:center; margin-top:10px;">
                    <div class="cm-tracker-seal-badge" style="display:inline-flex; align-items:center; gap:6px; font-size:10.5px; font-weight:800; letter-spacing:0.5px; text-transform:uppercase; padding:3px 10px; border-radius:6px; border:1px dashed <?php echo esc_attr($settings['primary_color']); ?>; background:#f8fafc; color:<?php echo esc_attr($settings['primary_color']); ?>;">
                        <span>🔒</span> <?php echo esc_html($settings['seal_text']); ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <!-- Buscador de Código de Ticket -->
        <?php if ($atts['show_search'] === 'true') : ?>
        <form class="cm-tracker-search-form" id="cm-tracker-search-form" onsubmit="return false;">
            <div class="cm-tracker-input-group">
                <div class="cm-tracker-input-icon">🔍</div>
                <input 
                    type="text" 
                    id="cm-tracker-code-input" 
                    name="ticket_code" 
                    class="cm-tracker-input" 
                    placeholder="<?php echo esc_attr($settings['search_placeholder']); ?>" 
                    value="<?php echo esc_attr($requested_code); ?>" 
                    maxlength="32" 
                    autocomplete="off"
                    required
                />
                <button type="submit" id="cm-tracker-submit-btn" class="cm-tracker-search-btn">
                    <span class="cm-btn-text">🔍 <?php echo esc_html($settings['search_btn_text']); ?></span>
                    <span class="cm-btn-spinner" style="display:none;">⏳</span>
                </button>
            </div>
            <?php if (!empty($settings['show_hint']) && !empty($settings['hint_text'])) : ?>
                <div class="cm-tracker-search-hint">
                    💡 <?php echo esc_html($settings['hint_text']); ?>
                </div>
            <?php endif; ?>
        </form>
        <?php endif; ?>

        <!-- Mensaje de Carga / Error -->
        <div id="cm-tracker-alert" class="cm-tracker-alert" style="<?php echo $case_not_found ? 'display:block;' : 'display:none;'; ?>">
            <?php if ($case_not_found) : ?>
                <div class="cm-alert-icon">⚠️</div>
                <div class="cm-alert-content">
                    <strong><?php _e('No se encontró ningún caso con el código ingresado.', 'contacto-multidestino'); ?></strong>
                    <p><?php _e('Por favor verifica que esté escrito correctamente (ejemplo: CL123456) e inténtalo nuevamente.', 'contacto-multidestino'); ?></p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Vista de Resultados del Caso -->
        <div id="cm-tracker-result" class="cm-tracker-result" style="<?php echo $initial_case ? 'display:block;' : 'display:none;'; ?>">
            <?php if ($initial_case) : 
                echo cm_render_case_detail_html($initial_case, $initial_history);
            endif; ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * Renderiza el detalle completo del caso en formato HTML limpio y estilizado.
 */
function cm_render_case_detail_html($case, $history = array()) {
    $statuses = cm_get_case_statuses();
    $current_status_key = $case->status;
    $status_info = isset($statuses[$current_status_key]) ? $statuses[$current_status_key] : array(
        'label'    => ucfirst($current_status_key),
        'color'    => '#475569',
        'bg_color' => '#f1f5f9',
        'icon'     => '📌',
        'step'     => 1,
    );

    $submitted_data = array();
    if (!empty($case->submitted_data)) {
        $decoded = json_decode($case->submitted_data, true);
        if (is_array($decoded)) {
            $submitted_data = $decoded;
        }
    }

    $created_date = date_i18n('d \d\e F, Y - H:i \h\r\s', strtotime($case->created_at));
    $updated_date = date_i18n('d \d\e F, Y - H:i \h\r\s', strtotime($case->updated_at));

    // Determinar paso de la barra de progreso
    $step_num = isset($status_info['step']) ? $status_info['step'] : 1;
    $is_resolved = in_array($current_status_key, array('resuelto', 'cerrado'));
    $is_pending_user = ($current_status_key === 'pendiente_usuario');

    // Buscar última solicitud o nota importante para el usuario
    $last_public_note = '';
    $last_update_date = '';
    // Buscar última solicitud o nota importante para el usuario
    $last_public_note = '';
    $last_update_date = '';
    if (!empty($history)) {
        $reversed = array_reverse($history);
        foreach ($reversed as $up) {
            if (!empty($up->note)) {
                $cleaned = trim(preg_replace('/\[REQ_DOC:\s*.*?\]/i', '', $up->note));
                if (!empty($cleaned)) {
                    $last_public_note = $cleaned;
                    $last_update_date = date_i18n('d/m/Y H:i', strtotime($up->created_at));
                    break;
                }
            }
        }
    }

    ob_start();
    ?>
    <div class="cm-case-card">
        <!-- Barra de Cabecera del Caso -->
        <div class="cm-case-card-header">
            <div class="cm-case-meta">
                <span class="cm-case-label"><?php _e('CÓDIGO DE SEGUIMIENTO:', 'contacto-multidestino'); ?></span>
                <span class="cm-case-code"><?php echo esc_html($case->ticket_code); ?></span>
                <button type="button" class="cm-copy-btn" onclick="cmCopyTicketCode('<?php echo esc_js($case->ticket_code); ?>')" title="<?php esc_attr_e('Copiar Código', 'contacto-multidestino'); ?>">
                    📋 <span class="cm-copy-text"><?php _e('Copiar', 'contacto-multidestino'); ?></span>
                </button>
            </div>
            <div class="cm-case-status-badge" style="background-color: <?php echo esc_attr($status_info['bg_color']); ?>; color: <?php echo esc_attr($status_info['color']); ?>; border-color: <?php echo esc_attr($status_info['border'] ?? $status_info['color']); ?>;">
                <span class="cm-status-icon"><?php echo $status_info['icon']; ?></span>
                <span class="cm-status-text"><?php echo esc_html($status_info['label']); ?></span>
            </div>
        </div>

        <!-- Indicador de Pasos del Trámite -->
        <div class="cm-case-stepper">
            <div class="cm-step-item <?php echo $step_num >= 1 ? 'cm-step-active' : ''; ?>">
                <div class="cm-step-circle">1</div>
                <div class="cm-step-title"><?php _e('Recibido', 'contacto-multidestino'); ?></div>
            </div>
            <div class="cm-step-line <?php echo $step_num >= 2 ? 'cm-step-line-active' : ''; ?>"></div>
            <div class="cm-step-item <?php echo $step_num >= 2 ? 'cm-step-active' : ''; ?>">
                <div class="cm-step-circle">2</div>
                <div class="cm-step-title"><?php _e('En Revisión', 'contacto-multidestino'); ?></div>
            </div>
            <div class="cm-step-line <?php echo $step_num >= 3 ? 'cm-step-line-active' : ''; ?>"></div>
            <div class="cm-step-item <?php echo $step_num >= 3 ? ($is_pending_user ? 'cm-step-warning' : 'cm-step-active') : ''; ?>">
                <div class="cm-step-circle"><?php echo $is_pending_user ? '⚠️' : '3'; ?></div>
                <div class="cm-step-title"><?php echo $is_pending_user ? __('Acción Requerida', 'contacto-multidestino') : __('En Gestión', 'contacto-multidestino'); ?></div>
            </div>
            <div class="cm-step-line <?php echo $step_num >= 4 ? 'cm-step-line-active' : ''; ?>"></div>
            <div class="cm-step-item <?php echo $step_num >= 4 ? 'cm-step-completed' : ''; ?>">
                <div class="cm-step-circle"><?php echo $is_resolved ? '✓' : '4'; ?></div>
                <div class="cm-step-title"><?php _e('Finalizado', 'contacto-multidestino'); ?></div>
            </div>
        </div>

        <!-- Alerta Destacada si Requiere Acción o Presencia -->
        <?php if ($is_pending_user || !empty($last_public_note)) : ?>
        <div class="cm-case-notification-box <?php echo $is_pending_user ? 'cm-box-alert' : 'cm-box-info'; ?>">
            <div class="cm-box-icon"><?php echo $is_pending_user ? '📢' : '💬'; ?></div>
            <div class="cm-box-content">
                <div class="cm-box-title">
                    <?php if ($is_pending_user) : ?>
                        <?php _e('Requerimiento / Solicitud del Área Responsable', 'contacto-multidestino'); ?>
                    <?php else : ?>
                        <?php _e('Última Actualización del Área', 'contacto-multidestino'); ?>
                    <?php endif; ?>
                    <?php if ($last_update_date) : ?>
                        <span class="cm-box-date">(<?php echo esc_html($last_update_date); ?>)</span>
                    <?php endif; ?>
                </div>
                <div class="cm-box-message">
                    <?php echo nl2br(wp_kses_post($last_public_note)); ?>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Cuadrícula de Datos Generales del Caso -->
        <div class="cm-case-info-grid">
            <div class="cm-info-card">
                <span class="cm-info-label">🏢 <?php _e('Área / Departamento:', 'contacto-multidestino'); ?></span>
                <span class="cm-info-value"><?php echo esc_html($case->department ? $case->department : 'General'); ?></span>
            </div>
            <div class="cm-info-card">
                <span class="cm-info-label">👤 <?php _e('Solicitante:', 'contacto-multidestino'); ?></span>
                <span class="cm-info-value"><?php echo esc_html($case->sender_name ? $case->sender_name : 'No especificado'); ?></span>
            </div>
            <div class="cm-info-card">
                <span class="cm-info-label">📅 <?php _e('Fecha de Ingreso:', 'contacto-multidestino'); ?></span>
                <span class="cm-info-value"><?php echo esc_html($created_date); ?></span>
            </div>
            <div class="cm-info-card">
                <span class="cm-info-label">🔄 <?php _e('Última Modificación:', 'contacto-multidestino'); ?></span>
                <span class="cm-info-value"><?php echo esc_html($updated_date); ?></span>
            </div>
        </div>

        <!-- Línea de Tiempo / Historial de Seguimiento -->
        <div class="cm-case-section">
            <h3 class="cm-section-title">
                <span>📜</span> <?php _e('Historial y Seguimiento del Caso', 'contacto-multidestino'); ?>
            </h3>
            
            <?php if (!empty($history)) : ?>
                <div class="cm-timeline">
                    <?php foreach ($history as $idx => $event) : 
                        $event_status = isset($statuses[$event->status]) ? $statuses[$event->status] : null;
                        $event_date   = date_i18n('d/m/Y - H:i \h\r\s', strtotime($event->created_at));
                        $clean_event_note = trim(preg_replace('/\[REQ_DOC:\s*.*?\]/i', '', $event->note));
                        $is_applicant_event = (stripos($event->author_name, 'solicitante') !== false);
                        $author_icon = $is_applicant_event ? '👤' : '🏛️';
                    ?>
                        <div class="cm-timeline-item">
                            <div class="cm-timeline-marker">
                                <span class="cm-timeline-dot"></span>
                            </div>
                            <div class="cm-timeline-content">
                                <div class="cm-timeline-header">
                                    <span class="cm-timeline-author"><?php echo $author_icon . ' ' . esc_html($event->author_name); ?></span>
                                    <?php if ($event_status) : ?>
                                        <span class="cm-timeline-badge" style="color:<?php echo esc_attr($event_status['color']); ?>; background:<?php echo esc_attr($event_status['bg_color']); ?>;">
                                            <?php echo $event_status['icon'] . ' ' . esc_html($event_status['label']); ?>
                                        </span>
                                    <?php endif; ?>
                                    <span class="cm-timeline-time"><?php echo esc_html($event_date); ?></span>
                                </div>
                                <div class="cm-timeline-body">
                                    <?php echo nl2br(wp_kses_post($clean_event_note)); ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else : ?>
                <p class="cm-empty-text"><?php _e('Aún no se registran actualizaciones públicas adicionales.', 'contacto-multidestino'); ?></p>
            <?php endif; ?>
        </div>

        <!-- Sección para que el Solicitante Adjunte Archivos / Responda Solicitudes -->
        <?php 
        $pending_doc_req = function_exists('cm_get_case_pending_doc_request') ? cm_get_case_pending_doc_request($history, $case->status) : null;
        if (!$is_resolved && $pending_doc_req && !empty($pending_doc_req['active'])) : 
            $doc_req_title = $pending_doc_req['title'];
            $doc_req_note  = $pending_doc_req['note'];
        ?>
        <div class="cm-case-section cm-upload-section" style="background:#ffffff; border:2px solid #0284c7; border-radius:12px; padding:18px 20px; margin-top:20px; box-shadow:0 4px 14px rgba(2, 132, 199, 0.08);">
            <h3 class="cm-section-title" style="margin-top:0; font-size:15px; color:#0369a1; display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:8px;">
                <span>📤 <?php echo esc_html($doc_req_title); ?></span>
                <span style="font-size:11px; font-weight:700; color:#0369a1; background:#e0f2fe; padding:3px 10px; border-radius:20px;">
                    📎 <?php _e('JPG, PNG, SVG, BMP, PDF • Máx. 4 MB', 'contacto-multidestino'); ?>
                </span>
            </h3>
            <p style="font-size:12.5px; color:#475569; margin:4px 0 14px 0;">
                <?php echo esc_html($doc_req_note ? $doc_req_note : __('El área responsable ha solicitado que adjuntes antecedentes para continuar con la gestión de tu caso:', 'contacto-multidestino')); ?>
            </p>

            <form id="cm-case-attach-form" enctype="multipart/form-data" onsubmit="cmSubmitCaseAttachment(event, '<?php echo esc_js($case->ticket_code); ?>')">
                <input type="hidden" id="cm-attach-nonce" name="nonce" value="<?php echo wp_create_nonce('cm_contacto_nonce'); ?>" />
                <div style="display:flex; flex-direction:column; gap:12px;">
                    <div>
                        <label style="font-size:12px; font-weight:700; color:#334155; display:block; margin-bottom:4px;">
                            📁 <?php _e('1. Seleccionar Archivo Adjunto (JPG, PNG, SVG, BMP, PDF):', 'contacto-multidestino'); ?>
                        </label>
                        <input 
                            type="file" 
                            id="cm-attach-file" 
                            name="attachment" 
                            accept=".jpg,.jpeg,.png,.svg,.bmp,.pdf" 
                            class="cm-apple-input-file" 
                            required 
                            style="font-size:12.5px; padding:8px 12px; border:1.5px dashed #0284c7; border-radius:8px; width:100%; box-sizing:border-box; background:#f0f9ff;" 
                            onchange="cmValidateAttachFileSize(this)" 
                        />
                        <small style="color:#64748b; font-size:11px; display:block; margin-top:4px;">
                            💡 <?php _e('Formatos permitidos: Imágenes (JPG, PNG, SVG, BMP) o Documentos PDF. Tamaño máximo permitido: 4 Megabytes.', 'contacto-multidestino'); ?>
                        </small>
                    </div>

                    <div>
                        <label style="font-size:12px; font-weight:700; color:#334155; display:block; margin-bottom:4px;">
                            💬 <?php _e('2. Mensaje o Explicación del Documento:', 'contacto-multidestino'); ?>
                        </label>
                        <textarea 
                            id="cm-attach-comment" 
                            name="comment" 
                            rows="2" 
                            class="cm-input" 
                            style="font-size:13px; padding:8px 12px; border:1px solid #d1d5db; border-radius:8px; width:100%; box-sizing:border-box;" 
                            placeholder="<?php esc_attr_e('Ejemplo: Adjunto comprobante solicitado por el área para continuar con el trámite...', 'contacto-multidestino'); ?>" 
                            required
                        ></textarea>
                    </div>

                    <div style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:10px; margin-top:4px;">
                        <div id="cm-attach-msg" style="font-size:12px;"></div>
                        <button type="submit" id="cm-attach-btn" class="cm-submit-button" style="padding:9px 22px; font-size:13px; font-weight:700; border-radius:8px; width:auto; margin:0;">
                            📤 <?php _e('Enviar Documento al Área', 'contacto-multidestino'); ?>
                        </button>
                    </div>
                </div>
            </form>
        </div>
        <?php endif; ?>

        <!-- Resumen de Datos Enviados en el Formulario -->
        <?php if (!empty($submitted_data)) : ?>
        <div class="cm-case-section cm-summary-section">
            <h3 class="cm-section-title">
                <span>📋</span> <?php _e('Resumen de la Solicitud Inicial', 'contacto-multidestino'); ?>
            </h3>
            <div class="cm-fields-summary-table">
                <?php foreach ($submitted_data as $f_label => $f_val) : ?>
                    <div class="cm-summary-row">
                        <div class="cm-summary-col-label"><?php echo esc_html($f_label); ?>:</div>
                        <div class="cm-summary-col-val"><?php echo nl2br(esc_html($f_val)); ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Acciones del Caso (Impresión Oficial) -->
        <?php if (!empty($settings['show_seal'])) : 
            $cert_hash = strtoupper(substr(sha1($case->ticket_code . $case->created_at . wp_salt('auth')), 0, 16));
        ?>
        <!-- Bloque de Firma Electrónica y Certificación Oficial -->
        <div class="cm-case-section cm-signature-section" style="background:#f8fafc; border:1.5px solid #e2e8f0; border-radius:12px; padding:16px 18px; margin-top:20px;">
            <div style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:12px;">
                <div style="display:flex; align-items:center; gap:10px;">
                    <div style="font-size:28px; background:#ffffff; border:1.5px solid #bae6fd; width:46px; height:46px; border-radius:10px; display:flex; align-items:center; justify-content:center; box-shadow:0 2px 6px rgba(2, 132, 199, 0.1);">
                        🛡️
                    </div>
                    <div>
                        <strong style="font-size:12.5px; color:#0369a1; text-transform:uppercase; letter-spacing:0.5px; display:block;">
                            <?php echo esc_html($settings['seal_text']); ?>
                        </strong>
                        <div style="font-size:11.5px; color:#64748b; margin-top:2px;">
                            <?php printf(__('Expediente emitido y resguardado bajo firma digital institucional el %s hrs.', 'contacto-multidestino'), date_i18n('d/m/Y H:i', strtotime($case->created_at))); ?>
                        </div>
                    </div>
                </div>
                <div style="text-align:right;">
                    <span style="font-size:10px; font-weight:700; color:#64748b; text-transform:uppercase; display:block;"><?php _e('Código Hash de Autenticidad:', 'contacto-multidestino'); ?></span>
                    <code style="font-size:11.5px; font-weight:800; color:#0f172a; background:#ffffff; border:1px solid #cbd5e1; padding:3px 8px; border-radius:6px; letter-spacing:1px;"><?php echo esc_html($cert_hash); ?></code>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Botones de Acción / Imprimir Comprobante -->
        <div class="cm-case-actions" style="margin-top:20px;">
            <button type="button" class="cm-btn-print" onclick="window.print();">
                🖨️ <?php _e('Imprimir Comprobante Oficial', 'contacto-multidestino'); ?>
            </button>
        </div>

        <!-- Modal Lightbox de Documentos para el Portal Público -->
        <div id="cm-public-lightbox-modal" class="cm-lightbox-overlay" style="display:none;" onclick="cmClosePublicDocumentPreview(event)">
            <div class="cm-lightbox-box" onclick="event.stopPropagation();">
                <div class="cm-lightbox-head">
                    <span id="cm-public-lightbox-filename" class="cm-lightbox-title">Documento</span>
                    <div class="cm-lightbox-actions">
                        <a id="cm-public-lightbox-download" href="#" target="_blank" class="cm-btn-print" style="font-size:12px; font-weight:700; text-decoration:none; padding:4px 10px; display:inline-flex; align-items:center; gap:4px;">
                            ⬇️ <?php _e('Descargar Original', 'contacto-multidestino'); ?>
                        </a>
                        <button type="button" style="background:none; border:none; font-size:18px; cursor:pointer; padding:4px 8px; color:#64748b;" onclick="cmClosePublicDocumentPreview()">✕</button>
                    </div>
                </div>
                <div class="cm-lightbox-body" id="cm-public-lightbox-content"></div>
            </div>
        </div>

        <script>
        window.cmOpenDocumentPreview = function(fileUrl, fileName, isImage) {
            if (isImage) {
                jQuery('#cm-public-lightbox-filename').text(fileName);
                jQuery('#cm-public-lightbox-download').attr('href', fileUrl);
                jQuery('#cm-public-lightbox-content').html('<img src="' + fileUrl + '" class="cm-lightbox-img" alt="' + fileName + '" />');
                jQuery('#cm-public-lightbox-modal').fadeIn(150).css('display', 'flex');
            } else {
                window.open(fileUrl, '_blank');
            }
        };

        window.cmClosePublicDocumentPreview = function(e) {
            jQuery('#cm-public-lightbox-modal').fadeOut(120);
        };

        // Interceptar clics en enlaces de documentos dentro del timeline y caja de notificación para abrir modal flotante
        jQuery(document).off('click.cmDocPreview').on('click.cmDocPreview', '.cm-timeline a, .cm-attachment-pill a, .cm-timeline-doc-card a, .cm-case-notification-box a, .cm-box-message a', function(e) {
            var href = jQuery(this).attr('href');
            if (!href) return;
            var cleanUrl = href.split('?')[0].split('#')[0];
            var ext = cleanUrl.split('.').pop().toLowerCase();
            if (['jpg', 'jpeg', 'png', 'svg', 'bmp', 'webp', 'gif'].indexOf(ext) !== -1) {
                e.preventDefault();
                var fileName = jQuery(this).text().replace(/^[📄🖼️📑\s]+/, '') || 'Documento Adjunto';
                cmOpenDocumentPreview(href, fileName, true);
            }
        });
        </script>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * Endpoint AJAX para consultar en tiempo real el estado de un caso por código.
 */
function cm_ajax_lookup_case_status() {
    check_ajax_referer('cm_contacto_nonce', 'nonce');

    $ticket_code = !empty($_POST['ticket_code']) ? sanitize_text_field($_POST['ticket_code']) : '';
    $ticket_code = strtoupper(trim($ticket_code));

    if (empty($ticket_code)) {
        wp_send_json_error(array(
            'message' => __('Por favor ingresa un código de seguimiento válido.', 'contacto-multidestino')
        ));
    }

    $case = cm_get_submission_by_code($ticket_code);

    if (!$case) {
        wp_send_json_error(array(
            'message' => __('No encontramos ningún caso asociado al código "' . esc_html($ticket_code) . '". Por favor verifica el número e inténtalo nuevamente.', 'contacto-multidestino')
        ));
    }

    $history = cm_get_case_updates($case->id, true);
    $html    = cm_render_case_detail_html($case, $history);

    wp_send_json_success(array(
        'ticket_code' => $case->ticket_code,
        'status'      => $case->status,
        'html'        => $html,
    ));
}
add_action('wp_ajax_cm_lookup_case_status', 'cm_ajax_lookup_case_status');
add_action('wp_ajax_nopriv_cm_lookup_case_status', 'cm_ajax_lookup_case_status');

/**
 * Núcleo universal: procesa el adjunto público de un solicitante a su caso.
 * Reutilizado por AJAX y por el endpoint REST /wp-json/<ns>/attachment.
 *
 * @param string $ticket_code Código del caso.
 * @param string $comment     Comentario del solicitante.
 * @param array  $file        Archivo estilo $_FILES (name, type, tmp_name, error, size).
 * @return WP_Error|array
 */
function cm_handle_public_case_attachment($ticket_code, $comment, $file) {
    $ticket_code = !empty($ticket_code) ? sanitize_text_field($ticket_code) : '';
    $ticket_code = strtoupper(trim($ticket_code));
    $comment     = !empty($comment) ? sanitize_textarea_field($comment) : '';

    if (empty($ticket_code) || empty($file) || empty($file['name'])) {
        return new WP_Error('missing_fields', __('Debes seleccionar un archivo y escribir un comentario.', 'contacto-multidestino'));
    }

    $case = cm_get_submission_by_code($ticket_code);
    if (!$case) {
        return new WP_Error('not_found', __('Caso no encontrado.', 'contacto-multidestino'));
    }

    $file = $file;

    // 1. Validar tamaño máximo: 4 Megabytes
    $max_size = 4 * 1024 * 1024;
    if (!isset($file['error']) || (int)$file['error'] !== UPLOAD_ERR_OK) {
        return new WP_Error('upload_error', __('Hubo un problema al recibir el archivo. Intenta nuevamente.', 'contacto-multidestino'));
    }
    if ((int)$file['size'] > $max_size) {
        return new WP_Error('file_too_large', __('El archivo excede el tamaño máximo permitido de 4 Megabytes.', 'contacto-multidestino'));
    }

    // 2. Validar extensiones permitidas
    $allowed_extensions = array('jpg', 'jpeg', 'png', 'svg', 'bmp', 'webp', 'gif', 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'zip', 'txt');
    $file_info = pathinfo($file['name']);
    $ext = isset($file_info['extension']) ? strtolower($file_info['extension']) : '';

    if (!in_array($ext, $allowed_extensions, true)) {
        return new WP_Error('bad_extension', __('Formato de archivo no permitido. Se aceptan PDF, DOC, DOCX, XLS, XLSX, ZIP, TXT, JPG o PNG.', 'contacto-multidestino'));
    }

    // 3. Subir archivo a uploads de WordPress
    if (!function_exists('wp_handle_upload')) {
        require_once(ABSPATH . 'wp-admin/includes/file.php');
    }

    $upload_overrides = array('test_form' => false);
    $movefile = wp_handle_upload($file, $upload_overrides);

    if (!$movefile || isset($movefile['error'])) {
        return new WP_Error('upload_error', __('Error al guardar el archivo adjunto: ', 'contacto-multidestino') . ($movefile['error'] ?? 'desconocido'));
    }

    $file_url  = $movefile['url'];
    $file_name = basename($movefile['file']);
    $orig_name = sanitize_file_name($file['name']);

    // 4. Crear nota estructurada con enlace al archivo
    $is_image = in_array($ext, array('jpg', 'jpeg', 'png', 'svg', 'bmp'), true);
    $attach_html = sprintf(
        '<div class="cm-attachment-pill" style="margin-top:6px; display:inline-flex; align-items:center; gap:6px; background:#eff6ff; border:1px solid #bfdbfe; padding:4px 10px; border-radius:8px; font-size:12px;">' .
            '<span>%s</span>' .
            '<a href="%s" target="_blank" style="color:#0284c7; font-weight:700; text-decoration:none;">&#128196; %s</a>' .
        '</div>',
        $is_image ? '🖼️' : '📑',
        esc_url($file_url),
        esc_html($orig_name)
    );

    $full_note = $comment . "\n" . $attach_html;

    // Cambiar estado a 'en_revision' si estaba en 'pendiente_usuario'
    $new_status = ($case->status === 'pendiente_usuario') ? 'en_revision' : $case->status;

    // 5. Registrar en la base de datos
    cm_add_case_update(array(
        'submission_id' => $case->id,
        'ticket_code'   => $case->ticket_code,
        'author_name'   => $case->sender_name ? $case->sender_name . ' (Solicitante)' : 'Solicitante',
        'status'        => $new_status,
        'action_type'   => 'applicant_attachment',
        'note'          => $full_note,
        'is_public'     => 1,
        'notified_user' => 0,
    ));

    // 6. Notificar por correo al área asignada
    $all_deps = cm_get_available_departments();
    $dept_emails = !empty($all_deps[$case->department]['emails']) ? $all_deps[$case->department]['emails'] : get_option('admin_email');
    $recipient_list = array_values(array_filter(array_map('trim', explode(',', $dept_emails)), 'is_email'));

    if (!empty($all_deps[$case->department]['user_id'])) {
        $u_obj = get_userdata($all_deps[$case->department]['user_id']);
        if ($u_obj && is_email($u_obj->user_email)) {
            $recipient_list = array_unique(array_merge($recipient_list, array($u_obj->user_email)));
        }
    }

    if (!empty($recipient_list)) {
        $site_name = get_bloginfo('name');
        $subject   = sprintf('[%s] Nuevos Documentos Adjuntados por: %s — %s', $case->ticket_code, $case->sender_name, $case->department);
        $case_url  = admin_url('admin.php?page=cm-form-submissions');

        $body = '
        <div style="font-family:sans-serif; background:#f1f5f9; padding:25px 15px;">
            <div style="max-width:550px; margin:0 auto; background:#fff; border-radius:12px; padding:25px 30px; border:1px solid #e2e8f0;">
                <div style="background:#0071e3; color:#fff; padding:6px 12px; border-radius:6px; font-size:12px; font-weight:700; display:inline-block;">NUEVOS DOCUMENTOS</div>
                <h3 style="color:#0f172a; margin:12px 0 6px 0;">El solicitante ha adjuntado archivos a su caso [' . esc_html($case->ticket_code) . ']</h3>
                <p style="color:#475569; font-size:13.5px; margin:0 0 14px 0;"><strong>Solicitante:</strong> ' . esc_html($case->sender_name) . ' (' . esc_html($case->sender_email) . ')</p>
                <div style="background:#f8fafc; border-left:3px solid #0071e3; padding:10px 14px; font-size:13px; color:#334155; margin-bottom:16px;">
                    <strong>Mensaje:</strong><br>' . nl2br(esc_html($comment)) . '<br><br>
                    <strong>Archivo:</strong> <a href="' . esc_url($file_url) . '" target="_blank">📄 Descargar ' . esc_html($orig_name) . '</a>
                </div>
                <div style="text-align:center; margin-top:16px;">
                    <a href="' . esc_url($case_url) . '" target="_blank" style="background:#0071e3; color:#fff; padding:10px 22px; text-decoration:none; border-radius:8px; font-size:13px; font-weight:700; display:inline-block;">
                        📥 Abrir Caso en la Bandeja &rarr;
                    </a>
                </div>
            </div>
        </div>';

        $headers = array('Content-Type: text/html; charset=UTF-8');
        wp_mail($recipient_list, $subject, $body, $headers);
    }

    // 7. Retornar detalle actualizado
    $fresh_case    = cm_get_submission_by_code($ticket_code);
    $fresh_history = cm_get_case_updates($fresh_case->id, true);
    $fresh_html    = cm_render_case_detail_html($fresh_case, $fresh_history);

    return array(
        'message' => __('✓ Documento adjuntado y notificado exitosamente al departamento responsable.', 'contacto-multidestino'),
        'html'    => $fresh_html,
    );
}

/**
 * Endpoint AJAX (same-origin) para que el solicitante adjunte documentos a su caso.
 */
function cm_ajax_public_submit_case_attachment() {
    check_ajax_referer('cm_contacto_nonce', 'nonce');

    $result = cm_handle_public_case_attachment(
        $_POST['ticket_code'] ?? '',
        $_POST['comment'] ?? '',
        $_FILES['attachment'] ?? array()
    );

    if (is_wp_error($result)) {
        wp_send_json_error(array('message' => $result->get_error_message()));
    }
    wp_send_json_success($result);
}
add_action('wp_ajax_cm_public_submit_case_attachment', 'cm_ajax_public_submit_case_attachment');
add_action('wp_ajax_nopriv_cm_public_submit_case_attachment', 'cm_ajax_public_submit_case_attachment');

/**
 * Devuelve la representación JSON de un caso (pública, sin datos internos).
 * Usada por el endpoint REST de seguimiento (API universal / widget).
 */
function cm_get_case_json($case, $history = array()) {
    if (!$case) {
        return null;
    }

    $statuses = cm_get_case_statuses();
    $status_key = $case->status;
    $status_info = isset($statuses[$status_key]) ? $statuses[$status_key] : array(
        'label' => ucfirst($status_key),
        'color' => '#475569',
        'step'  => 1,
    );

    $submitted_data = array();
    if (!empty($case->submitted_data)) {
        $decoded = json_decode($case->submitted_data, true);
        if (is_array($decoded)) {
            $submitted_data = $decoded;
        }
    }

    $events = array();
    foreach ($history as $event) {
        $clean_note = trim(preg_replace('/\[REQ_DOC:\s*.*?\]/i', '', $event->note));
        $events[] = array(
            'id'          => (int)$event->id,
            'author'      => $event->author_name,
            'status'      => $event->status,
            'action_type' => $event->action_type,
            'note'        => $clean_note,
            'is_public'   => (bool)$event->is_public,
            'created_at'  => $event->created_at,
        );
    }

    return array(
        'id'             => (int)$case->id,
        'ticket_code'    => $case->ticket_code,
        'form_name'      => $case->form_name,
        'sender_name'    => $case->sender_name,
        'department'     => $case->department ? $case->department : 'General',
        'status'         => $status_key,
        'status_info'    => array(
            'label' => $status_info['label'],
            'color' => $status_info['color'],
            'step'  => $status_info['step'],
        ),
        'submitted_data' => $submitted_data,
        'created_at'     => $case->created_at,
        'updated_at'     => $case->updated_at,
        'tracking_url'   => cm_get_case_tracker_url($case->ticket_code),
        'history'        => $events,
    );
}
