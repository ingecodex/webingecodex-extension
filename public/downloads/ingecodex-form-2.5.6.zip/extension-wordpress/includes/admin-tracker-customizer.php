<?php
/**
 * Universal Contact Form Form — Editor Visual / Personalizador del Portal de Consulta y Seguimiento (Pro Studio Edition)
 * Permite al administrador personalizar en tiempo real los textos, colores, estilos (Firma Automática / Verificación Digital),
 * insignias, botón de búsqueda (sólido, transparente, cristal, degradado) de la página pública de búsqueda por código.
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Guarda los ajustes del personalizador vía AJAX.
 */
function cm_ajax_save_tracker_settings() {
    check_ajax_referer('cm_contacto_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('No tienes permisos para guardar estos ajustes.', 'contacto-multidestino')));
    }

    $raw = isset($_POST['settings']) ? $_POST['settings'] : array();
    if (!is_array($raw)) {
        wp_send_json_error(array('message' => __('Datos no válidos.', 'contacto-multidestino')));
    }

    $clean = array(
        'badge_text'         => sanitize_text_field($raw['badge_text'] ?? ''),
        'title'              => sanitize_text_field($raw['title'] ?? ''),
        'subtitle'           => sanitize_textarea_field($raw['subtitle'] ?? ''),
        'search_placeholder' => sanitize_text_field($raw['search_placeholder'] ?? ''),
        'search_btn_text'    => sanitize_text_field($raw['search_btn_text'] ?? ''),
        'primary_color'      => sanitize_hex_color($raw['primary_color'] ?? '#0071e3') ?: '#0071e3',
        'btn_style'          => sanitize_key($raw['btn_style'] ?? 'solid'),
        'btn_bg_color'       => sanitize_hex_color($raw['btn_bg_color'] ?? '#0071e3') ?: '#0071e3',
        'btn_text_color'     => sanitize_hex_color($raw['btn_text_color'] ?? '#ffffff') ?: '#ffffff',
        'btn_border_color'   => sanitize_hex_color($raw['btn_border_color'] ?? '#0071e3') ?: '#0071e3',
        'btn_border_radius'  => sanitize_text_field($raw['btn_border_radius'] ?? '8'),
        'card_style'         => sanitize_key($raw['card_style'] ?? 'signature'),
        'card_bg_color'      => sanitize_hex_color($raw['card_bg_color'] ?? '#ffffff') ?: '#ffffff',
        'show_seal'          => !empty($raw['show_seal']) ? 1 : 0,
        'seal_text'          => sanitize_text_field($raw['seal_text'] ?? 'VERIFICACIÓN DIGITAL VÁLIDA'),
        'show_hint'          => !empty($raw['show_hint']) ? 1 : 0,
        'hint_text'          => sanitize_textarea_field($raw['hint_text'] ?? ''),
    );

    update_option('cm_tracker_settings', $clean);

    wp_send_json_success(array(
        'message'  => __('¡Ajustes del Portal de Consulta guardados exitosamente!', 'contacto-multidestino'),
        'settings' => $clean,
    ));
}
add_action('wp_ajax_cm_save_tracker_settings', 'cm_ajax_save_tracker_settings');

/**
 * Renderiza la pantalla del Personalizador del Portal de Consulta (Pro Studio).
 */
function cm_render_tracker_customizer_page() {
    if (!current_user_can('manage_options')) {
        wp_die(__('No tienes permisos para acceder a esta página.', 'contacto-multidestino'));
    }

    $settings = cm_get_tracker_settings();
    $nonce = wp_create_nonce('cm_contacto_nonce');
    ?>
    <div class="wrap cm-studio-customizer-wrap" style="max-width: 1440px; margin: 20px auto; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #1d1d1f;">
        
        <!-- HEADER PRO STUDIO -->
        <div class="cm-studio-customizer-header" style="background: rgba(255, 255, 255, 0.9); backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px); border: 1px solid rgba(0, 0, 0, 0.08); border-radius: 16px; padding: 16px 24px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 16px; box-shadow: 0 4px 20px rgba(0,0,0,0.03); margin-bottom: 24px;">
            <div style="display: flex; align-items: center; gap: 14px;">
                <div style="width: 44px; height: 44px; border-radius: 12px; background: #ffffff; border: 1px solid #e2e8f0; display: flex; align-items: center; justify-content: center; overflow: hidden; box-shadow: 0 4px 12px rgba(0, 113, 227, 0.18);">
                    <img src="<?php echo esc_url(CM_PLUGIN_URL . 'assets/images/logo.gif'); ?>" alt="Universal Contact Form Form" style="width: 100%; height: 100%; object-fit: cover; display: block;" />
                </div>
                <div>
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <h1 style="font-size: 19px; font-weight: 800; margin: 0; color: #0f172a; letter-spacing: -0.02em;">
                            <?php _e('Editor del Portal de Consulta & Verificación', 'contacto-multidestino'); ?>
                        </h1>
                        <span style="background: #e0f2fe; color: #0284c7; font-size: 11px; font-weight: 800; padding: 2px 8px; border-radius: 12px; border: 1px solid #bae6fd;">v2.5.6 Pro Studio</span>
                    </div>
                    <p style="font-size: 12.5px; color: #64748b; margin: 2px 0 0 0;">
                        <?php _e('Personaliza la página pública de búsqueda por código, estilos de botón, transparencia y modo Firma Digital.', 'contacto-multidestino'); ?>
                    </p>
                </div>
            </div>

            <div style="display: flex; align-items: center; gap: 10px;">
                <a href="<?php echo admin_url('admin.php?page=cm-form-submissions'); ?>" class="cm-customizer-nav-btn" style="background: #f1f5f9; color: #334155; text-decoration: none; font-size: 12.5px; font-weight: 700; padding: 8px 14px; border-radius: 10px; border: 1px solid #e2e8f0; display: inline-flex; align-items: center; gap: 6px; transition: all 0.15s ease;">
                    📥 <?php _e('Bandeja de Casos', 'contacto-multidestino'); ?>
                </a>
                <a href="<?php echo admin_url('admin.php?page=cm-form-studio'); ?>" class="cm-customizer-nav-btn" style="background: #f1f5f9; color: #334155; text-decoration: none; font-size: 12.5px; font-weight: 700; padding: 8px 14px; border-radius: 10px; border: 1px solid #e2e8f0; display: inline-flex; align-items: center; gap: 6px; transition: all 0.15s ease;">
                    🛠️ <?php _e('Editor Formularios', 'contacto-multidestino'); ?>
                </a>
                <button type="button" class="cm-customizer-save-btn" id="cm-save-tracker-btn" onclick="cmSaveTrackerCustomizer()" style="background: linear-gradient(135deg, #0071e3 0%, #005bb8 100%); color: #ffffff; border: none; font-size: 13px; font-weight: 700; padding: 9px 20px; border-radius: 10px; cursor: pointer; display: inline-flex; align-items: center; gap: 6px; box-shadow: 0 4px 14px rgba(0, 113, 227, 0.35); transition: all 0.15s ease;">
                    💾 <span><?php _e('Guardar Cambios', 'contacto-multidestino'); ?></span>
                </button>
            </div>
        </div>

        <!-- CUERPO PRINCIPAL: 2 COLUMNAS (INSPECTOR PROFESIONAL + CANVAS EN VIVO) -->
        <div style="display: grid; grid-template-columns: 420px 1fr; gap: 24px; align-items: start;">
            
            <!-- PANEL DE CONTROL LATERAL (INSPECTOR) -->
            <div style="background: #ffffff; border: 1px solid #e5e5ea; border-radius: 18px; box-shadow: 0 4px 20px rgba(0,0,0,0.03); overflow: hidden;">
                
                <!-- Pestañas Superiores del Inspector -->
                <div style="display: flex; background: #f8fafc; border-bottom: 1px solid #e5e5ea; padding: 6px;">
                    <button type="button" class="cm-insp-tab active" onclick="cmSwitchCustomizerTab(this, 'tab-btn-style')" style="flex: 1; padding: 8px 10px; font-size: 12px; font-weight: 800; border: none; border-radius: 8px; cursor: pointer; background: #ffffff; color: #0071e3; box-shadow: 0 1px 4px rgba(0,0,0,0.08);">
                        🔘 Botón y Color
                    </button>
                    <button type="button" class="cm-insp-tab" onclick="cmSwitchCustomizerTab(this, 'tab-visual-mode')" style="flex: 1; padding: 8px 10px; font-size: 12px; font-weight: 700; border: none; border-radius: 8px; cursor: pointer; background: transparent; color: #64748b;">
                        🎨 Plantilla
                    </button>
                    <button type="button" class="cm-insp-tab" onclick="cmSwitchCustomizerTab(this, 'tab-texts-titles')" style="flex: 1; padding: 8px 10px; font-size: 12px; font-weight: 700; border: none; border-radius: 8px; cursor: pointer; background: transparent; color: #64748b;">
                        🔤 Textos
                    </button>
                </div>

                <!-- CONTENIDO PESTAÑA 1: BOTÓN Y COLORES -->
                <div id="tab-btn-style" class="cm-insp-content" style="padding: 22px;">
                    
                    <div style="font-size: 11.5px; font-weight: 800; color: #0071e3; letter-spacing: 0.05em; text-transform: uppercase; margin-bottom: 12px; display: flex; align-items: center; gap: 6px;">
                        <span>🔘</span> <?php _e('Personalización del Botón de Búsqueda', 'contacto-multidestino'); ?>
                    </div>

                    <!-- Estilo del Botón (Sólido, Transparente, Cristal, Degradado) -->
                    <div style="margin-bottom: 18px;">
                        <label style="font-size: 12px; font-weight: 700; color: #1e293b; display: block; margin-bottom: 6px;">
                            <?php _e('Estilo del Botón:', 'contacto-multidestino'); ?>
                        </label>
                        <select id="cm-tset-btn-style" onchange="cmUpdateTrackerPreview()" style="width: 100%; height: 38px; border-radius: 10px; border: 1px solid #d1d5db; font-size: 13px; font-weight: 600; padding: 0 10px; background: #f8fafc;">
                            <option value="solid" <?php selected($settings['btn_style'] ?? 'solid', 'solid'); ?>>🟦 <?php _e('Sólido Clásico (Con Sombra Suave)', 'contacto-multidestino'); ?></option>
                            <option value="transparent" <?php selected($settings['btn_style'] ?? 'solid', 'transparent'); ?>>⚪ <?php _e('Transparente / Outline (Borde Elegante)', 'contacto-multidestino'); ?></option>
                            <option value="glass" <?php selected($settings['btn_style'] ?? 'solid', 'glass'); ?>>🪟 <?php _e('Cristal Glassmorphism (Translúcido con Desenfoque)', 'contacto-multidestino'); ?></option>
                            <option value="gradient" <?php selected($settings['btn_style'] ?? 'solid', 'gradient'); ?>>🌈 <?php _e('Degradado Profesional', 'contacto-multidestino'); ?></option>
                        </select>
                    </div>

                    <!-- Redondez del Botón (Border Radius) -->
                    <div style="margin-bottom: 18px;">
                        <label style="font-size: 12px; font-weight: 700; color: #1e293b; display: block; margin-bottom: 6px;">
                            <?php _e('Forma / Esquinas del Botón:', 'contacto-multidestino'); ?>
                        </label>
                        <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 6px;">
                            <button type="button" class="cm-radius-btn <?php echo ($settings['btn_border_radius'] ?? '8') === '4' ? 'active' : ''; ?>" onclick="cmSetButtonRadius(4, this)" style="padding: 7px; font-size: 11.5px; font-weight: 700; border: 1px solid #cbd5e1; border-radius: 4px; background: #f8fafc; cursor: pointer;">Suave (4px)</button>
                            <button type="button" class="cm-radius-btn <?php echo ($settings['btn_border_radius'] ?? '8') === '8' ? 'active' : ''; ?>" onclick="cmSetButtonRadius(8, this)" style="padding: 7px; font-size: 11.5px; font-weight: 700; border: 1px solid #cbd5e1; border-radius: 8px; background: #f8fafc; cursor: pointer;">Estándar (8px)</button>
                            <button type="button" class="cm-radius-btn <?php echo ($settings['btn_border_radius'] ?? '8') === '12' ? 'active' : ''; ?>" onclick="cmSetButtonRadius(12, this)" style="padding: 7px; font-size: 11.5px; font-weight: 700; border: 1px solid #cbd5e1; border-radius: 12px; background: #f8fafc; cursor: pointer;">Redondo (12px)</button>
                            <button type="button" class="cm-radius-btn <?php echo ($settings['btn_border_radius'] ?? '8') === '24' ? 'active' : ''; ?>" onclick="cmSetButtonRadius(24, this)" style="padding: 7px; font-size: 11.5px; font-weight: 700; border: 1px solid #cbd5e1; border-radius: 24px; background: #f8fafc; cursor: pointer;">Pill (Ovalado)</button>
                        </div>
                        <input type="hidden" id="cm-tset-btn-radius" value="<?php echo esc_attr($settings['btn_border_radius'] ?? '8'); ?>" />
                    </div>

                    <!-- Paleta Rápida de Colores -->
                    <div style="margin-bottom: 18px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 12px;">
                        <label style="font-size: 11.5px; font-weight: 700; color: #475569; display: block; margin-bottom: 8px;">
                            🎨 <?php _e('Paletas Rápidas de Color:', 'contacto-multidestino'); ?>
                        </label>
                        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                            <button type="button" onclick="cmApplyColorPreset('#0071e3', '#ffffff', '#0071e3')" title="Azul Corporativo" style="width:26px; height:26px; border-radius:50%; background:#0071e3; border:2px solid #ffffff; box-shadow:0 1px 4px rgba(0,0,0,0.2); cursor:pointer;"></button>
                            <button type="button" onclick="cmApplyColorPreset('#10b981', '#ffffff', '#10b981')" title="Verde Esmeralda" style="width:26px; height:26px; border-radius:50%; background:#10b981; border:2px solid #ffffff; box-shadow:0 1px 4px rgba(0,0,0,0.2); cursor:pointer;"></button>
                            <button type="button" onclick="cmApplyColorPreset('#6366f1', '#ffffff', '#6366f1')" title="Índigo Moderno" style="width:26px; height:26px; border-radius:50%; background:#6366f1; border:2px solid #ffffff; box-shadow:0 1px 4px rgba(0,0,0,0.2); cursor:pointer;"></button>
                            <button type="button" onclick="cmApplyColorPreset('#8b5cf6', '#ffffff', '#8b5cf6')" title="Púrpura Vibrante" style="width:26px; height:26px; border-radius:50%; background:#8b5cf6; border:2px solid #ffffff; box-shadow:0 1px 4px rgba(0,0,0,0.2); cursor:pointer;"></button>
                            <button type="button" onclick="cmApplyColorPreset('#f59e0b', '#ffffff', '#f59e0b')" title="Ámbar Ejecutivo" style="width:26px; height:26px; border-radius:50%; background:#f59e0b; border:2px solid #ffffff; box-shadow:0 1px 4px rgba(0,0,0,0.2); cursor:pointer;"></button>
                            <button type="button" onclick="cmApplyColorPreset('#0f172a', '#ffffff', '#0f172a')" title="Grafito / Oscuro" style="width:26px; height:26px; border-radius:50%; background:#0f172a; border:2px solid #ffffff; box-shadow:0 1px 4px rgba(0,0,0,0.2); cursor:pointer;"></button>
                            <button type="button" onclick="cmApplyTransparentPreset()" title="Transparente con Borde" style="padding:2px 8px; font-size:11px; font-weight:700; border-radius:12px; background:#ffffff; border:1.5px solid #0071e3; color:#0071e3; cursor:pointer;">⚪ Transparente</button>
                        </div>
                    </div>

                    <!-- Color de Fondo del Botón -->
                    <div style="margin-bottom: 14px;">
                        <label style="font-size: 12px; font-weight: 700; color: #1e293b; display: flex; justify-content: space-between; align-items: center;">
                            <span><?php _e('Color de Fondo del Botón:', 'contacto-multidestino'); ?></span>
                            <input type="color" id="cm-tset-btn-bg" value="<?php echo esc_attr($settings['btn_bg_color']); ?>" oninput="jQuery('#cm-tset-btn-bg-txt').val(this.value); cmUpdateTrackerPreview();" style="width:30px; height:30px; border:none; cursor:pointer; background:none; border-radius:6px;" />
                        </label>
                        <input type="text" id="cm-tset-btn-bg-txt" value="<?php echo esc_attr($settings['btn_bg_color']); ?>" onchange="jQuery('#cm-tset-btn-bg').val(this.value); cmUpdateTrackerPreview();" style="width:100%; height:32px; font-family:monospace; font-size:12.5px; border-radius:8px; border:1px solid #d1d5db; padding:0 8px; margin-top:4px;" />
                    </div>

                    <!-- Color del Texto del Botón -->
                    <div style="margin-bottom: 14px;">
                        <label style="font-size: 12px; font-weight: 700; color: #1e293b; display: flex; justify-content: space-between; align-items: center;">
                            <span><?php _e('Color del Texto del Botón:', 'contacto-multidestino'); ?></span>
                            <input type="color" id="cm-tset-btn-color" value="<?php echo esc_attr($settings['btn_text_color']); ?>" oninput="jQuery('#cm-tset-btn-color-txt').val(this.value); cmUpdateTrackerPreview();" style="width:30px; height:30px; border:none; cursor:pointer; background:none; border-radius:6px;" />
                        </label>
                        <input type="text" id="cm-tset-btn-color-txt" value="<?php echo esc_attr($settings['btn_text_color']); ?>" onchange="jQuery('#cm-tset-btn-color').val(this.value); cmUpdateTrackerPreview();" style="width:100%; height:32px; font-family:monospace; font-size:12.5px; border-radius:8px; border:1px solid #d1d5db; padding:0 8px; margin-top:4px;" />
                    </div>

                    <!-- Color del Borde (para estilo transparente) -->
                    <div style="margin-bottom: 14px;">
                        <label style="font-size: 12px; font-weight: 700; color: #1e293b; display: flex; justify-content: space-between; align-items: center;">
                            <span><?php _e('Color del Borde del Botón:', 'contacto-multidestino'); ?></span>
                            <input type="color" id="cm-tset-btn-border" value="<?php echo esc_attr($settings['btn_border_color'] ?? $settings['btn_bg_color']); ?>" oninput="jQuery('#cm-tset-btn-border-txt').val(this.value); cmUpdateTrackerPreview();" style="width:30px; height:30px; border:none; cursor:pointer; background:none; border-radius:6px;" />
                        </label>
                        <input type="text" id="cm-tset-btn-border-txt" value="<?php echo esc_attr($settings['btn_border_color'] ?? $settings['btn_bg_color']); ?>" onchange="jQuery('#cm-tset-btn-border').val(this.value); cmUpdateTrackerPreview();" style="width:100%; height:32px; font-family:monospace; font-size:12.5px; border-radius:8px; border:1px solid #d1d5db; padding:0 8px; margin-top:4px;" />
                    </div>

                </div>

                <!-- CONTENIDO PESTAÑA 2: PLANTILLA Y MODO VISUAL -->
                <div id="tab-visual-mode" class="cm-insp-content" style="display:none; padding: 22px;">
                    
                    <div style="font-size: 11.5px; font-weight: 800; color: #0071e3; letter-spacing: 0.05em; text-transform: uppercase; margin-bottom: 12px;">
                        🎨 <?php _e('Plantilla y Efectos Visuales', 'contacto-multidestino'); ?>
                    </div>

                    <div style="margin-bottom: 18px;">
                        <label style="font-size: 12px; font-weight: 700; color: #1e293b; display: block; margin-bottom: 6px;">
                            <?php _e('Modo Visual del Portal:', 'contacto-multidestino'); ?>
                        </label>
                        <select id="cm-tset-style" onchange="cmUpdateTrackerPreview()" style="width: 100%; height: 38px; border-radius: 10px; border: 1px solid #d1d5db; font-size: 13px; font-weight: 600; padding: 0 10px; background: #f8fafc;">
                            <option value="signature" <?php selected($settings['card_style'], 'signature'); ?>>📜 <?php _e('Firma Automática / Verificación Oficial (Certificado)', 'contacto-multidestino'); ?></option>
                            <option value="apple" <?php selected($settings['card_style'], 'apple'); ?>>💎 <?php _e('Pro Moderno (Elegante y Limpio)', 'contacto-multidestino'); ?></option>
                            <option value="glass" <?php selected($settings['card_style'], 'glass'); ?>>🪟 <?php _e('Cristal Glassmorphism (Desenfoque Translúcido)', 'contacto-multidestino'); ?></option>
                            <option value="dark" <?php selected($settings['card_style'], 'dark'); ?>>🌑 <?php _e('Modo Oscuro / Dark Mode Ejecutivo', 'contacto-multidestino'); ?></option>
                        </select>
                    </div>

                    <!-- Color de Acento -->
                    <div style="margin-bottom: 14px;">
                        <label style="font-size: 12px; font-weight: 700; color: #1e293b; display: flex; justify-content: space-between; align-items: center;">
                            <span><?php _e('Color de Acento (Insignias / Sello):', 'contacto-multidestino'); ?></span>
                            <input type="color" id="cm-tset-primary" value="<?php echo esc_attr($settings['primary_color']); ?>" oninput="jQuery('#cm-tset-primary-txt').val(this.value); cmUpdateTrackerPreview();" style="width:30px; height:30px; border:none; cursor:pointer; background:none; border-radius:6px;" />
                        </label>
                        <input type="text" id="cm-tset-primary-txt" value="<?php echo esc_attr($settings['primary_color']); ?>" onchange="jQuery('#cm-tset-primary').val(this.value); cmUpdateTrackerPreview();" style="width:100%; height:32px; font-family:monospace; font-size:12.5px; border-radius:8px; border:1px solid #d1d5db; padding:0 8px; margin-top:4px;" />
                    </div>

                    <!-- Fondo del Contenedor -->
                    <div style="margin-bottom: 14px;">
                        <label style="font-size: 12px; font-weight: 700; color: #1e293b; display: flex; justify-content: space-between; align-items: center;">
                            <span><?php _e('Fondo de la Tarjeta / Marco:', 'contacto-multidestino'); ?></span>
                            <input type="color" id="cm-tset-card-bg" value="<?php echo esc_attr($settings['card_bg_color']); ?>" oninput="jQuery('#cm-tset-card-bg-txt').val(this.value); cmUpdateTrackerPreview();" style="width:30px; height:30px; border:none; cursor:pointer; background:none; border-radius:6px;" />
                        </label>
                        <input type="text" id="cm-tset-card-bg-txt" value="<?php echo esc_attr($settings['card_bg_color']); ?>" onchange="jQuery('#cm-tset-card-bg').val(this.value); cmUpdateTrackerPreview();" style="width:100%; height:32px; font-family:monospace; font-size:12.5px; border-radius:8px; border:1px solid #d1d5db; padding:0 8px; margin-top:4px;" />
                    </div>

                    <!-- Sello de Autenticidad Digital -->
                    <div style="margin-top: 18px; border-top: 1px solid #f1f5f9; padding-top: 14px;">
                        <label style="display: flex; align-items: center; gap: 8px; font-size: 12.5px; font-weight: 700; color: #1e293b; cursor: pointer; margin-bottom: 8px;">
                            <input type="checkbox" id="cm-tset-show-seal" value="1" <?php checked($settings['show_seal'], 1); ?> onchange="cmUpdateTrackerPreview()" />
                            <span>🛡️ <?php _e('Mostrar Sello de Firma Electrónica / Verificación', 'contacto-multidestino'); ?></span>
                        </label>
                        <div>
                            <label style="font-size: 11px; font-weight: 700; color: #64748b; display: block; margin-bottom: 2px;"><?php _e('Texto del Sello:', 'contacto-multidestino'); ?></label>
                            <input type="text" id="cm-tset-seal-text" value="<?php echo esc_attr($settings['seal_text']); ?>" oninput="cmUpdateTrackerPreview()" style="width:100%; height:32px; font-size:12.5px; border-radius:8px; border:1px solid #d1d5db; padding:0 8px;" />
                        </div>
                    </div>

                </div>

                <!-- CONTENIDO PESTAÑA 3: TEXTOS Y ENCABEZADOS -->
                <div id="tab-texts-titles" class="cm-insp-content" style="display:none; padding: 22px;">
                    
                    <div style="font-size: 11.5px; font-weight: 800; color: #0071e3; letter-spacing: 0.05em; text-transform: uppercase; margin-bottom: 12px;">
                        🔤 <?php _e('Encabezados y Mensajes', 'contacto-multidestino'); ?>
                    </div>

                    <div style="margin-bottom: 12px;">
                        <label style="font-size: 11.5px; font-weight: 700; color: #475569; display: block; margin-bottom: 3px;"><?php _e('Insignia Superior (Badge):', 'contacto-multidestino'); ?></label>
                        <input type="text" id="cm-tset-badge" value="<?php echo esc_attr($settings['badge_text']); ?>" oninput="cmUpdateTrackerPreview()" style="width:100%; height:32px; font-size:12.5px; border-radius:8px; border:1px solid #d1d5db; padding:0 8px;" />
                    </div>

                    <div style="margin-bottom: 12px;">
                        <label style="font-size: 11.5px; font-weight: 700; color: #475569; display: block; margin-bottom: 3px;"><?php _e('Título Principal:', 'contacto-multidestino'); ?></label>
                        <input type="text" id="cm-tset-title" value="<?php echo esc_attr($settings['title']); ?>" oninput="cmUpdateTrackerPreview()" style="width:100%; height:32px; font-size:12.5px; border-radius:8px; border:1px solid #d1d5db; padding:0 8px;" />
                    </div>

                    <div style="margin-bottom: 12px;">
                        <label style="font-size: 11.5px; font-weight: 700; color: #475569; display: block; margin-bottom: 3px;"><?php _e('Subtítulo / Instrucciones:', 'contacto-multidestino'); ?></label>
                        <textarea id="cm-tset-subtitle" oninput="cmUpdateTrackerPreview()" style="width:100%; height:55px; font-size:12px; border-radius:8px; border:1px solid #d1d5db; padding:6px 8px; resize:vertical;"><?php echo esc_textarea($settings['subtitle']); ?></textarea>
                    </div>

                    <div style="margin-bottom: 12px;">
                        <label style="font-size: 11.5px; font-weight: 700; color: #475569; display: block; margin-bottom: 3px;"><?php _e('Texto del Botón de Búsqueda:', 'contacto-multidestino'); ?></label>
                        <input type="text" id="cm-tset-btn-text" value="<?php echo esc_attr($settings['search_btn_text']); ?>" oninput="cmUpdateTrackerPreview()" style="width:100%; height:32px; font-size:12.5px; font-weight:700; border-radius:8px; border:1px solid #d1d5db; padding:0 8px;" />
                    </div>

                    <div style="margin-bottom: 12px;">
                        <label style="font-size: 11.5px; font-weight: 700; color: #475569; display: block; margin-bottom: 3px;"><?php _e('Placeholder del Campo:', 'contacto-multidestino'); ?></label>
                        <input type="text" id="cm-tset-placeholder" value="<?php echo esc_attr($settings['search_placeholder']); ?>" oninput="cmUpdateTrackerPreview()" style="width:100%; height:32px; font-size:12.5px; border-radius:8px; border:1px solid #d1d5db; padding:0 8px;" />
                    </div>

                    <div>
                        <label style="font-size: 11.5px; font-weight: 700; color: #475569; display: block; margin-bottom: 3px;"><?php _e('Mensaje de Ayuda / Pie:', 'contacto-multidestino'); ?></label>
                        <textarea id="cm-tset-hint" oninput="cmUpdateTrackerPreview()" style="width:100%; height:45px; font-size:12px; border-radius:8px; border:1px solid #d1d5db; padding:6px 8px; resize:vertical;"><?php echo esc_textarea($settings['hint_text']); ?></textarea>
                    </div>

                </div>

            </div>

            <!-- VISTA PREVIA EN VIVO (MARCO DE VENTANA INTERACTIVA) -->
            <div style="background: #ffffff; border: 1px solid #e5e5ea; border-radius: 18px; box-shadow: 0 8px 30px rgba(0,0,0,0.06); overflow: hidden;">
                
                <!-- Barra Superior del Marco de Ventana -->
                <div style="background: #f1f5f9; border-bottom: 1px solid #e2e8f0; padding: 12px 18px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px;">
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <span style="width: 12px; height: 12px; border-radius: 50%; background: #ef4444; display: inline-block;"></span>
                        <span style="width: 12px; height: 12px; border-radius: 50%; background: #f59e0b; display: inline-block;"></span>
                        <span style="width: 12px; height: 12px; border-radius: 50%; background: #10b981; display: inline-block;"></span>
                    </div>

                    <!-- Simulador de Barra de Navegación -->
                    <div style="background: #ffffff; border: 1px solid #cbd5e1; border-radius: 8px; padding: 4px 16px; font-size: 11.5px; color: #475569; display: flex; align-items: center; gap: 6px; font-family: -apple-system, monospace; width: 340px; justify-content: center; box-shadow: 0 1px 2px rgba(0,0,0,0.03);">
                        <span style="color: #10b981; font-size: 10px;">🔒</span>
                        <span>https://tusitio.cl/<strong>[seguimiento_caso]</strong></span>
                    </div>

                    <!-- Selector de Dispositivos -->
                    <div style="display: flex; gap: 4px; background: #e2e8f0; padding: 3px; border-radius: 8px;">
                        <button type="button" class="cm-vp-btn active" onclick="cmSetPreviewViewport('desktop', this)" style="padding: 4px 10px; font-size: 11px; font-weight: 700; border: none; border-radius: 6px; cursor: pointer; background: #ffffff; color: #0f172a;">🖥️ Escritorio</button>
                        <button type="button" class="cm-vp-btn" onclick="cmSetPreviewViewport('tablet', this)" style="padding: 4px 10px; font-size: 11px; font-weight: 700; border: none; border-radius: 6px; cursor: pointer; background: transparent; color: #64748b;">📱 Tablet</button>
                        <button type="button" class="cm-vp-btn" onclick="cmSetPreviewViewport('mobile', this)" style="padding: 4px 10px; font-size: 11px; font-weight: 700; border: none; border-radius: 6px; cursor: pointer; background: transparent; color: #64748b;">📲 Móvil</button>
                    </div>
                </div>

                <!-- LIENZO DE LA VISTA PREVIA INTERACTIVA -->
                <div id="cm-tracker-preview-box" style="background: #f8fafc; padding: 40px 24px; min-height: 580px; display: flex; justify-content: center; align-items: flex-start; transition: all 0.25s ease;">
                    
                    <div id="cm-live-portal-container" class="cm-tracker-container" style="width: 100%; max-width: 680px; margin: 0 auto; transition: all 0.25s ease;">
                        
                        <!-- Encabezado -->
                        <div class="cm-tracker-header" style="text-align: center; margin-bottom: 24px;">
                            <div id="cm-prev-badge" class="cm-tracker-badge" style="display: inline-flex; align-items: center; gap: 6px; font-size: 11px; font-weight: 800; padding: 4px 12px; border-radius: 20px; margin-bottom: 10px;">
                                🛡️ PORTAL OFICIAL DE VERIFICACIÓN
                            </div>
                            <h2 id="cm-prev-title" class="cm-tracker-title" style="font-size: 22px; font-weight: 800; margin: 0 0 6px 0;">
                                Consulta de Estado
                            </h2>
                            <p id="cm-prev-subtitle" class="cm-tracker-subtitle" style="font-size: 13.5px; margin: 0; line-height: 1.5;">
                                Ingresa tu código para consultar el estado.
                            </p>
                        </div>

                        <!-- Sello de Firma Electrónica -->
                        <div id="cm-prev-seal-wrap" style="text-align: center; margin-bottom: 18px;">
                            <div id="cm-prev-seal-badge" style="display: inline-flex; align-items: center; gap: 6px; font-size: 10.5px; font-weight: 800; letter-spacing: 0.5px; text-transform: uppercase; padding: 4px 12px; border-radius: 6px; border: 1px dashed #0284c7; background: #f0f9ff; color: #0369a1;">
                                <span>🔒</span> <span id="cm-prev-seal-text">VERIFICACIÓN DIGITAL VÁLIDA</span>
                            </div>
                        </div>

                        <!-- Formulario de Búsqueda -->
                        <div class="cm-tracker-search-form" style="margin-bottom: 20px;">
                            <div class="cm-tracker-input-group" style="display: flex; gap: 8px; position: relative;">
                                <div style="position: absolute; left: 12px; top: 50%; transform: translateY(-50%); font-size: 15px; pointer-events: none; z-index: 2;">🔍</div>
                                <input 
                                    type="text" 
                                    id="cm-prev-input" 
                                    class="cm-tracker-input" 
                                    placeholder="Ejemplo: CL849201" 
                                    value="CL849201" 
                                    style="height: 44px; padding-left: 36px !important; font-size: 15px; font-weight: 700; font-family: monospace; letter-spacing: 1px; flex: 1; border-radius: 8px;" 
                                    readonly 
                                />
                                <button 
                                    type="button" 
                                    id="cm-prev-submit-btn" 
                                    class="cm-tracker-search-btn" 
                                    style="height: 44px; padding: 0 22px; font-size: 14px; font-weight: 800; display: inline-flex; align-items: center; justify-content: center; gap: 6px; cursor: pointer;"
                                >
                                    <span id="cm-prev-btn-text">Consultar y Verificar</span>
                                </button>
                            </div>
                            <div id="cm-prev-hint" class="cm-tracker-search-hint" style="font-size: 11.5px; margin-top: 8px; text-align: center;">
                                💡 El código fue emitido y firmado electrónicamente al momento de completar la solicitud web.
                            </div>
                        </div>

                        <!-- Muestra de Caso (Simulado con Firma Digital) -->
                        <div id="cm-prev-sample-case">
                            <div id="cm-prev-card" class="cm-case-card" style="border-radius: 14px; padding: 22px; box-shadow: 0 4px 16px rgba(0,0,0,0.06);">
                                
                                <!-- Encabezado de la Ficha / Certificado -->
                                <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px; padding-bottom: 14px; border-bottom: 1px solid #e2e8f0;">
                                    <div>
                                        <div style="font-size: 10px; font-weight: 800; color: #0071e3; text-transform: uppercase; letter-spacing: 0.05em;">EXPEDIENTE OFICIAL FIRMADO</div>
                                        <div style="font-size: 18px; font-weight: 800; font-family: monospace; color: #0f172a;">CL849201</div>
                                    </div>
                                    <div>
                                        <span style="background: #eff6ff; color: #0071e3; border: 1px solid #bfdbfe; font-weight: 800; font-size: 12px; padding: 4px 12px; border-radius: 20px;">
                                            ⚙️ En Proceso / Gestión
                                        </span>
                                    </div>
                                </div>

                                <!-- Datos del Solicitante -->
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin: 16px 0; font-size: 12.5px;">
                                    <div><strong>Solicitante:</strong> Claudio Morales</div>
                                    <div><strong>Departamento:</strong> Dirección Académica</div>
                                    <div><strong>Fecha de Ingreso:</strong> 24/08/2026 01:20 hrs</div>
                                    <div><strong>Firma Digital:</strong> <code style="font-size: 11px; color: #059669;">SHA1-VERIFIED-OK</code></div>
                                </div>

                                <!-- Timeline Simulado -->
                                <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; padding: 12px; margin-top: 14px;">
                                    <div style="font-size: 11.5px; font-weight: 700; color: #0f172a; margin-bottom: 4px;">🏛️ Dirección Académica — 24/08/2026 01:22 hrs</div>
                                    <div style="font-size: 12px; color: #475569;">Su requerimiento ha sido recibido y se encuentra en revisión de antecedentes.</div>
                                </div>

                                <!-- Sello Oficial al Pie -->
                                <div style="margin-top: 18px; padding-top: 12px; border-top: 1px dashed #cbd5e1; display: flex; align-items: center; justify-content: space-between; font-size: 10.5px; color: #64748b;">
                                    <div>🔒 Certificación de Autenticidad Digital</div>
                                    <div>Hash: <code>9E4B2F7C1A8D0E35</code></div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- SCRIPT DEL PERSONALIZADOR PRO STUDIO -->
    <script>
    function cmSwitchCustomizerTab(btn, tabId) {
        jQuery('.cm-insp-tab').removeClass('active').css({ background: 'transparent', color: '#64748b', 'box-shadow': 'none' });
        jQuery(btn).addClass('active').css({ background: '#ffffff', color: '#0071e3', 'box-shadow': '0 1px 4px rgba(0,0,0,0.08)' });
        jQuery('.cm-insp-content').hide();
        jQuery('#' + tabId).show();
    }

    function cmSetPreviewViewport(mode, btn) {
        jQuery('.cm-vp-btn').removeClass('active').css({ background: 'transparent', color: '#64748b' });
        jQuery(btn).addClass('active').css({ background: '#ffffff', color: '#0f172a' });

        var container = jQuery('#cm-live-portal-container');
        if (mode === 'mobile') {
            container.css({ 'max-width': '380px' });
        } else if (mode === 'tablet') {
            container.css({ 'max-width': '520px' });
        } else {
            container.css({ 'max-width': '680px' });
        }
    }

    function cmSetButtonRadius(radius, btn) {
        jQuery('.cm-radius-btn').removeClass('active').css({ 'border-color': '#cbd5e1', 'background': '#f8fafc' });
        jQuery(btn).addClass('active').css({ 'border-color': '#0071e3', 'background': '#eff6ff' });
        jQuery('#cm-tset-btn-radius').val(radius);
        cmUpdateTrackerPreview();
    }

    function cmApplyColorPreset(bg, text, primary) {
        jQuery('#cm-tset-btn-bg').val(bg);
        jQuery('#cm-tset-btn-bg-txt').val(bg);
        jQuery('#cm-tset-btn-color').val(text);
        jQuery('#cm-tset-btn-color-txt').val(text);
        jQuery('#cm-tset-btn-border').val(bg);
        jQuery('#cm-tset-btn-border-txt').val(bg);
        jQuery('#cm-tset-primary').val(primary);
        jQuery('#cm-tset-primary-txt').val(primary);
        jQuery('#cm-tset-btn-style').val('solid');
        cmUpdateTrackerPreview();
    }

    function cmApplyTransparentPreset() {
        var currentPrimary = jQuery('#cm-tset-primary').val() || '#0071e3';
        jQuery('#cm-tset-btn-style').val('transparent');
        jQuery('#cm-tset-btn-border').val(currentPrimary);
        jQuery('#cm-tset-btn-border-txt').val(currentPrimary);
        jQuery('#cm-tset-btn-color').val(currentPrimary);
        jQuery('#cm-tset-btn-color-txt').val(currentPrimary);
        cmUpdateTrackerPreview();
    }

    function cmUpdateTrackerPreview() {
        var style       = jQuery('#cm-tset-style').val();
        var badge       = jQuery('#cm-tset-badge').val();
        var title       = jQuery('#cm-tset-title').val();
        var subtitle    = jQuery('#cm-tset-subtitle').val();
        var btnText     = jQuery('#cm-tset-btn-text').val();
        var placeholder = jQuery('#cm-tset-placeholder').val();
        var hint        = jQuery('#cm-tset-hint').val();
        var btnStyle    = jQuery('#cm-tset-btn-style').val();
        var btnBg       = jQuery('#cm-tset-btn-bg').val();
        var btnColor    = jQuery('#cm-tset-btn-color').val();
        var btnBorder   = jQuery('#cm-tset-btn-border').val();
        var btnRadius   = jQuery('#cm-tset-btn-radius').val() || '8';
        var primary     = jQuery('#cm-tset-primary').val();
        var cardBg      = jQuery('#cm-tset-card-bg').val();
        var showSeal    = jQuery('#cm-tset-show-seal').is(':checked');
        var sealText    = jQuery('#cm-tset-seal-text').val();

        // Actualizar textos
        jQuery('#cm-prev-badge').text(badge);
        jQuery('#cm-prev-title').text(title);
        jQuery('#cm-prev-subtitle').text(subtitle);
        jQuery('#cm-prev-btn-text').text(btnText);
        jQuery('#cm-prev-input').attr('placeholder', placeholder);
        jQuery('#cm-prev-hint').text(hint ? '💡 ' + hint : '');
        jQuery('#cm-prev-seal-text').text(sealText);

        if (showSeal) {
            jQuery('#cm-prev-seal-wrap').show();
        } else {
            jQuery('#cm-prev-seal-wrap').hide();
        }

        // Aplicar estilos al botón
        var btn = jQuery('#cm-prev-submit-btn');
        btn.css({
            'border-radius': btnRadius + 'px'
        });

        if (btnStyle === 'transparent') {
            btn.css({
                'background': 'transparent',
                'border': '2px solid ' + btnBorder,
                'color': btnColor,
                'box-shadow': 'none'
            });
        } else if (btnStyle === 'glass') {
            btn.css({
                'background': 'rgba(255, 255, 255, 0.4)',
                'backdrop-filter': 'blur(12px)',
                '-webkit-backdrop-filter': 'blur(12px)',
                'border': '1.5px solid rgba(255, 255, 255, 0.7)',
                'color': btnColor,
                'box-shadow': '0 4px 12px rgba(0,0,0,0.06)'
            });
        } else if (btnStyle === 'gradient') {
            btn.css({
                'background': 'linear-gradient(135deg, ' + btnBg + ' 0%, ' + primary + ' 100%)',
                'border': 'none',
                'color': btnColor,
                'box-shadow': '0 4px 14px rgba(0, 113, 227, 0.3)'
            });
        } else {
            btn.css({
                'background': btnBg,
                'border': 'none',
                'color': btnColor,
                'box-shadow': '0 3px 10px rgba(0,0,0,0.18)'
            });
        }

        // Contenedor y Fondo
        var portal = jQuery('#cm-live-portal-container');
        var previewBox = jQuery('#cm-tracker-preview-box');
        var card = jQuery('#cm-prev-card');

        // Estilos según Preset
        if (style === 'dark') {
            previewBox.css('background', '#0b0f19');
            portal.css({
                'background': '#111827',
                'color': '#f8fafc',
                'border': '1px solid #1f2937',
                'border-radius': '16px',
                'padding': '24px'
            });
            jQuery('#cm-prev-title').css('color', '#f8fafc');
            jQuery('#cm-prev-subtitle').css('color', '#94a3b8');
            jQuery('#cm-prev-badge').css({ 'background': '#1e293b', 'color': primary, 'border': '1px solid #334155' });
            card.css({ 'background': '#1f2937', 'border': '1px solid #374151', 'color': '#f8fafc' });
        } else if (style === 'glass') {
            previewBox.css('background', 'linear-gradient(135deg, #e0f2fe 0%, #ede9fe 100%)');
            portal.css({
                'background': 'rgba(255, 255, 255, 0.75)',
                'backdrop-filter': 'blur(16px)',
                '-webkit-backdrop-filter': 'blur(16px)',
                'color': '#0f172a',
                'border': '1.5px solid rgba(255, 255, 255, 0.9)',
                'border-radius': '18px',
                'padding': '24px',
                'box-shadow': '0 10px 30px rgba(0,0,0,0.06)'
            });
            jQuery('#cm-prev-title').css('color', '#0f172a');
            jQuery('#cm-prev-subtitle').css('color', '#475569');
            jQuery('#cm-prev-badge').css({ 'background': 'rgba(255,255,255,0.9)', 'color': primary, 'border': '1px solid rgba(0,0,0,0.06)' });
            card.css({ 'background': 'rgba(255,255,255,0.85)', 'border': '1px solid rgba(255,255,255,0.8)', 'color': '#0f172a' });
        } else if (style === 'signature') {
            // Estilo Firma Automática / Certificado Digital
            previewBox.css('background', '#f8fafc');
            portal.css({
                'background': cardBg,
                'color': '#0f172a',
                'border': '2px solid ' + primary,
                'border-top': '6px solid ' + primary,
                'border-radius': '14px',
                'padding': '26px',
                'box-shadow': '0 4px 20px rgba(0, 113, 227, 0.08)'
            });
            jQuery('#cm-prev-title').css('color', '#0f172a');
            jQuery('#cm-prev-subtitle').css('color', '#475569');
            jQuery('#cm-prev-badge').css({ 'background': '#f0f9ff', 'color': primary, 'border': '1px solid #bae6fd' });
            card.css({ 'background': '#ffffff', 'border': '1.5px solid #e2e8f0', 'color': '#0f172a' });
            jQuery('#cm-prev-seal-badge').css({ 'border-color': primary, 'color': primary });
        } else {
            // Pro Moderno Clásico
            previewBox.css('background', '#f1f5f9');
            portal.css({
                'background': cardBg,
                'color': '#1d1d1f',
                'border': '1px solid #e5e5ea',
                'border-top': 'none',
                'border-radius': '14px',
                'padding': '22px',
                'box-shadow': '0 2px 10px rgba(0,0,0,0.04)'
            });
            jQuery('#cm-prev-title').css('color', '#1d1d1f');
            jQuery('#cm-prev-subtitle').css('color', '#86868b');
            jQuery('#cm-prev-badge').css({ 'background': '#f5f5f7', 'color': primary, 'border': '1px solid #e5e5ea' });
            card.css({ 'background': '#ffffff', 'border': '1px solid #e5e5ea', 'color': '#1d1d1f' });
        }
    }

    function cmSaveTrackerCustomizer() {
        var btn = jQuery('#cm-save-tracker-btn');
        btn.prop('disabled', true).find('span').text('Guardando...');

        var data = {
            action: 'cm_save_tracker_settings',
            nonce: '<?php echo esc_js($nonce); ?>',
            settings: {
                badge_text: jQuery('#cm-tset-badge').val(),
                title: jQuery('#cm-tset-title').val(),
                subtitle: jQuery('#cm-tset-subtitle').val(),
                search_btn_text: jQuery('#cm-tset-btn-text').val(),
                search_placeholder: jQuery('#cm-tset-placeholder').val(),
                hint_text: jQuery('#cm-tset-hint').val(),
                btn_style: jQuery('#cm-tset-btn-style').val(),
                btn_bg_color: jQuery('#cm-tset-btn-bg').val(),
                btn_text_color: jQuery('#cm-tset-btn-color').val(),
                btn_border_color: jQuery('#cm-tset-btn-border').val(),
                btn_border_radius: jQuery('#cm-tset-btn-radius').val(),
                primary_color: jQuery('#cm-tset-primary').val(),
                card_bg_color: jQuery('#cm-tset-card-bg').val(),
                card_style: jQuery('#cm-tset-style').val(),
                show_seal: jQuery('#cm-tset-show-seal').is(':checked') ? 1 : 0,
                seal_text: jQuery('#cm-tset-seal-text').val()
            }
        };

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: data,
            success: function(res) {
                btn.prop('disabled', false).find('span').text('Guardar Cambios');
                if (res.success) {
                    alert('✓ ' + (res.data.message || 'Personalización del Portal guardada exitosamente.'));
                } else {
                    alert(res.data.message || 'Error al guardar.');
                }
            },
            error: function() {
                btn.prop('disabled', false).find('span').text('Guardar Cambios');
                alert('Error de conexión al guardar.');
            }
        });
    }

    jQuery(document).ready(function() {
        cmUpdateTrackerPreview();
    });
    </script>
    <?php
}
