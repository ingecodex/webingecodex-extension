# Form Studio Pro — Formulario Multidestino para WordPress
**Diseñado y Desarrollado por Ingecodex (ingecodex.com)**

---

## 📊 Estado Actual del Proyecto y Registro de Funcionalidades

### 0. 📥 Centro de Casos, Gestión Jerárquica Multi-Área, Auto-Respuesta y Portal Público (v2.5.2)
- **Roles y Niveles Jerárquicos:**
  - 👑 **Director / Administrador:** Acceso global a Dashboard en Tiempo Real, Kanban y todos los casos.
  - 🛡️ **Subdirector / Moderador Multi-Área:** Puede supervisar y atender 2, 3 o más áreas asignadas simultáneamente, con filtros automáticos.
  - 🏢 **Encargado de Área:** Acceso exclusivo a los departamentos asignados.
  - ⚡ **Superadmin WP:** Administración técnica total de la plataforma.
- **🤖 Respuestas Automáticas por Área (ej. Currículum / Postulaciones):**
  - Activable o desactivable por área de forma independiente.
  - Temporizador configurable: Inmediata (al enviar formulario) o programada a los 5, 10, 15, 30 o 60 minutos.
  - Asignación de estado automático (🟢 *En Proceso / Tomado*, ⚪ *Resuelto / Finalizado*, 🟡 *En Revisión*) y mensaje oficial de respuesta predeterminado.
- **⚡ Plantillas Rápidas de Notas Predeterminadas en el Inspector:**
  - 6 Notas oficiales integradas por defecto (Toma de conocimiento, Trazabilidad, Derivación, Presencia física, Documentos complementarios, Resolución y cierre).
  - Creador dinámico `➕ Nueva Nota` para redactar, guardar y reutilizar notas personalizadas en 1 clic con opción de eliminar (`✕`).
- **Versión Actual:** `2.5.2`
- **Novedades de la versión 2.5.2:**
  - **💎 Rediseño Visual Estilo Phoenix Tailwind Widgets / SaaS:** Interfaz ejecutiva con cards limpias (`#ffffff` con bordes sutiles `#e2e8f0`), tipografía nítida `Nunito Sans / Inter`, badges pastel de alto contraste (`badge-phoenix-*`), KPIs widget cards en grid con micro-interacciones hover, tablas con cabeceras en mayúsculas pequeñas, y timeline con líneas punteadas y nodos circulares.
  - **📱 Modales Responsivos y Bottom Sheet en Móvil:** Modales de expediente, usuarios y lightbox adaptables con formato bottom-sheet en pantallas móviles (≤ 600px).
  - **👤 Lista Ejecutiva de Usuarios y Panel Lateral (Slide-in Drawer):** Lista limpia de 4 columnas (Usuario, Correo, Estado, Rol) y panel lateral deslizable con ficha técnica completa y 5 botones de gestión sin saturación visual.
  - **Selector y Carga Rápida de Áreas en Constructor Visual:** Menú dropdown para añadir áreas existentes al formulario con sus correos sin redactar y botón de carga masiva `📥 Cargar Todas las Áreas`.
  - **Asignación Multi-Área y Perfiles Institucionales:** Asignación de 1, 2 o más áreas por moderador o encargado con selectores de verificación y acciones masivas.
  - **Control de Derivación por Usuario:** El Super Administrador puede permitir o bloquear la derivación de casos a otras áreas usuario por usuario, restringiendo la vista exclusivamente a sus áreas asignadas.
  - **Respuestas Automáticas por Departamento (Auto-Reply):** Respuesta automática configurable por departamento con temporizador (inmediato, 5, 10, 15, 30, 60 mins), cambio de estado y nota oficial.
  - **Notas Rápidas Predeterminadas y Personalizables:** 6 notas oficiales integradas + drawer dinámico `➕ Nueva Nota`.
  - **Conmutador de Envío de Confirmación por Correo:** Configurable en ajustes con visualización del código en pantalla si no se envía email.
  - **Sistema Cromático de Casos y Pestañas:** Códigos de color por estado (rojo, amarillo, verde, púrpura, gris) y pestañas rápidas (`Todos`, `Activos`, `Completados`).
- **🏢 Selector Rápido e Importación de Áreas en Constructor Visual (Form Studio):**
  - En el subpanel *Opciones y Correos Destino*, se integra un selector desplegable con todas las áreas creadas y registradas en el sistema.
  - Botón `➕ Añadir` para cargar el departamento con su nombre y correos pre-llenados automáticamente sin escribir.
  - Botón `📥 Cargar Todas las Áreas` para poblar el selector con todos los departamentos existentes en 1 clic.
- **✉️ Conmutador de Envío de Confirmación por Correo:**
  - Ajuste global para decidir si enviar correo de comprobante al solicitante o solo mostrar el código generado en pantalla para su anotación.
- **🎨 Sistema Visual de Estados con Códigos de Color y Pestañas:**
  - Acentos de fila y badges cromáticos: 🔴 **Rojo** para nuevo/recibido, 🟡 **Amarillo/Ámbar** para en revisión, 🟢 **Verde** para tomado/en proceso, 🟣 **Púrpura** para requerimiento al usuario, y ⚪ **Gris** para completado/finalizado.
  - Pestañas rápidas en la bandeja: `📋 Todos los Casos`, `🔥 Activos / En Trámite` y `✅ Completados / Finalizados`.
- **Portal Público de Consulta de Estado (`[seguimiento_caso]`):**
  - Shortcode público para que los solicitantes consulten el estado de su requerimiento ingresando su código (`CL123456`).
  - Barra de progreso del trámite (*Stepper*) con indicador de paso activo o de alerta.
  - Alerta destacada para llamados o requerimientos presenciales del área responsable.
  - Línea de tiempo oficial y desglose del formulario inicial.
  - Botón para imprimir comprobante oficial en formato Carta/PDF.

### 1. 🏛️ Galería de Plantillas & Nuevo Formulario (12+ Plantillas Listas)
- **Acceso Directo:** Botón `🏛️ Galería / ＋ Nuevo` en la barra superior del Form Studio.
- **Catálogo de 12 Plantillas Especializadas:**
  1. 🏫 **Contacto Colegios y Multidestino:** Enrutamiento a Dirección, Convivencia Escolar, Inspectoría, PIE, adjunto de archivos y modal de términos y condiciones.
  2. 💼 **Cotización y Servicios B2B:** Nombre, empresa, selector de servicio requerido, rango de presupuesto estimado, detalles del proyecto y adjunto de requerimientos.
  3. 🩺 **Citas Médicas y de Salud:** Identificación/RUT, selector de fecha de cita, especialidad médica (Medicina General, Odontología, Pediatría, Kinesiología) y horarios.
  4. 🏢 **Inmobiliaria y Visita a Propiedades:** Tipo de operación (Comprar/Arrendar/Vender), tipo de inmueble (Depto/Casa/Oficina/Terreno), código y fecha estimada de visita.
  5. 🛠️ **Tickets de Soporte Técnico TI:** Niveles de urgencia (Baja/Media/Alta), módulo o sistema afectado, descripción de la incidencia y adjunto de captura de pantalla.
  6. ⭐ **Encuesta de Satisfacción y NPS:** Calificación interactiva por 5 estrellas (★★★★★), área evaluada, pregunta de recomendación y sugerencias de mejora.
  7. 🎓 **Admisión y Postulación Académica:** Datos del alumno, fecha de nacimiento, curso de postulación, datos del apoderado, adjunto de certificados/notas y reglamento escolar.
  8. 🍕 **Reserva de Mesa y Gastronomía:** Cantidad de personas, fecha de reserva, turno (almuerzo/cena), sector preferido (salón/terraza/lounge) y requerimientos de alergias.
  9. 🚗 **Test Drive y Venta Automotriz:** Modelo de vehículo de interés, sucursal preferida, entrega en parte de pago y fecha estimada de compra.
  10. ⚖️ **Consulta Legal y Jurídica:** Especialidad jurídica (Laboral, Civil, Familia, Corporativo, Penal), resumen del caso, adjunto de antecedentes y secreto profesional.
  11. 🏋️ **Inscripción y Membresía Gym:** Plan de membresía, sede de entrenamiento, declaración médica o lesiones previas y términos del gimnasio.
  12. 🎯 **Captura de Leads y Asesoría Express:** Diseño minimalista y transparente de alta conversión para landing pages.
  13. 📄 **Lienzo en Blanco:** Para crear formularios desde cero según requerimientos específicos.
- **Filtros por Categoría en Tiempo Real:** Todos, Educación, Negocios, Salud, Servicios, Tecnología y Marketing.
- **Asignación de Nombre:** Permite nombrar el formulario al crearlo o usar el nombre por defecto de la plantilla seleccionada.

---

### 2. 📧 Sistema de Correos Ejecutivos, Enrutamiento por Formulario & Código de Seguimiento (CL123456)
- **Configuración de Destinatarios por Formulario (Pestaña "Ajustes"):**
  - Permite definir **Correo(s) de Destino del Formulario** (separados por coma) para formularios que no tienen selector de departamentos o como respaldo general.
  - **Área / Asunto Predeterminado:** Asigna el nombre del área correspondiente cuando no existe selector de departamento.
  - **Asunto Personalizado del Correo:** Permite personalizar el subject del correo recibido.
  - **Acceso Rápido:** Al hacer clic en el botón de envío en el canvas del constructor, se abre directamente la sección de configuración de correos.
- **Generación de Código Único:** Cada envío genera automáticamente un código de seguimiento con formato de 2 letras mayúsculas aleatorias y 6 dígitos numéricos (ej. `CL849201`, `NX591234`, `AG782390`).
- **Diseño de Correo Ejecutivo de Alta Gama (HTML Responsivo):**
  - Maquetación responsiva compatible con todos los clientes de correo (Gmail, Outlook, Apple Mail).
  - Encabezado con gradiente institucional (`#0f172a` a `#312e81`) y badge oficial `✓ COMPROBANTE OFICIAL DE RECEPCIÓN`.
  - Tarjeta destacada con el código de seguimiento en tipografía monospace de alta legibilidad (`CL123456`).
  - Tabla estilizada con el desglose ordenado de todos los datos completados.
  - Sello de privacidad, aviso legal y firma tecnológica *"Ingecodex.com"*.
- **Doble Flujo de Envíos:**
  1. **Correo de Confirmación al Usuario (Auto-responder):** Enviado al correo del remitente como comprobante oficial de recepción con su código (activable/desactivable desde Ajustes).
  2. **Correo de Notificación al Administrador / Departamento:** Enviado a los destinatarios configurados para el área o formulario.
- **Confirmación Visual en Frontend:** Muestra una tarjeta verde con el código generado para que el visitante pueda copiarlo o guardarlo al instante.

---

### 3. 📜 Modal Flotante de Términos y Condiciones
- **Componente:** `📜 Términos / Modal` en la paleta del constructor.
- **Configuración desde el Inspector:**
  - Texto del enlace clickeable (ej: *"Términos y Condiciones"*).
  - Título del modal popup (ej: *"Políticas y Términos de Servicio"*).
  - Contenido completo de cláusulas o políticas que el usuario leerá en la ventana emergente.
- **Frontend Interactivo:**
  - Ventana flotante con desenfoque de fondo (*backdrop-filter*).
  - Botón **"✕"**, botón **"Cerrar"** y botón **"✓ Aceptar Términos y Marcar"** que cierra la ventana y marca la casilla automáticamente.

---

### 4. 💧 Presets de Contenedor y Modo Transparente
- **Presets Disponibles:**
  - **Transparente (`transparent`):** Sin fondo, sin bordes y sin sombras para integrarse de forma invisible sobre cualquier sección de Elementor o plantilla de WordPress.
  - **Plano Minimalista (`flat`):** Sin sombra, con borde fino personalizable.
  - **Moderno con Sombra (`modern`):** Fondo sólido con sombras difuminadas suaves.
  - **Cristal Glassmorphism (`glassmorphism`):** Fondo translúcido con desenfoque (*blur*).
  - **Extra Redondeado (`rounded`):** Curvatura de 26px.
- **Control Rápido:** Botón directo *"💧 Hacer Fondo Transparente"* con 1 clic en la pestaña Diseño.
- **Bordes:** Grosor de 0px a 3px y color de borde personalizable.

---

### 5. 📐 Grid Fluido Responsivo y Proporciones Espaciosas
- **Container Queries & Flex Wrapping:** Las columnas de 50% (`.cm-col-50`) utilizan `flex: 1 1 calc(50% - 9px); min-width: 250px;`, adaptándose automáticamente a 100% en pantallas móviles o contenedores estrechos.
- **Inputs Espaciosos:** Altura de 46px con padding de icono de 38px para visualización completa de placeholders largos sin truncamiento.
- **Ancho Máximo del Contenedor (`max_width`):** Selector de ancho configurable (`840px` Recomendado, `720px`, `960px`, `100%`).

---

### 6. 🎨 Estilos Individuales por Campo (Widgets)
- Posibilidad de personalizar el color de fondo y el color de borde de cada campo de manera individual desde el inspector.

---

### 7. 🏷️ Marca y Reconocimiento Ingecodex
- **Shortcodes Reconocidos:**
  - `[Formulario_Ingecodex]` *(Recomendado)*
  - `[formulario_ingecodex]`
  - `[ingecodex_form]`
  - `[formulario_contacto]` *(Retrocompatible)*
- **Widget de Elementor:**
  - Nombre del widget: **`Formulario Ingecodex`**
  - Palabras clave indexadas en Elementor: `ingecodex`, `ingecodex.com`, `formulario ingecodex`, `contacto ingecodex`, `formulario`, `contacto`, `multidestino`.
- **Crédito Opcional:** *"Diseñado por Ingecodex.com"* con interruptor para mostrar u ocultar.

---

## 🚀 Guía Rápida de Instalación y Uso

### En Elementor:
1. Abre tu página con el editor de **Elementor**.
2. En el panel izquierdo busca **"Ingecodex"** o **"Formulario"**.
3. Arrastra el widget **`Formulario Ingecodex`** al lienzo.

### Mediante Shortcode:
Inserta el shortcode en cualquier bloque de texto o shortcode:
```text
[Formulario_Ingecodex]
```

---

## 📂 Estructura de la Extensión

```
extension-wordpress/
├── contacto-multidestino.php    # Archivo principal del plugin y hooks de shortcode
├── readme.txt                   # Documentación estándar de WordPress
├── ESTADO_PROYECTO.md           # Registro de estado actual y funciones
├── includes/
│   ├── admin-builder.php        # Interfaz del Form Studio (Canvas, Paleta, Galería e Inspector)
│   ├── form-renderer.php        # Generador de HTML dinámico, presets y modal flotante
│   ├── form-handler.php         # Procesamiento AJAX, tickets CL123456, correos ejecutivos y adjuntos
│   ├── elementor-widget.php     # Widget nativo de Elementor con marca Ingecodex
│   └── smtp-settings.php        # Panel de configuración SMTP y diagnóstico
└── assets/
    ├── css/
    │   ├── contacto-style.css   # Estilos frontend, grid fluido, presets y modal de términos
    │   └── builder-admin.css    # Estilos del constructor Form Studio
    └── js/
        ├── contacto-script.js   # Script frontend (AJAX, dropzone de archivos, modal, ticket banner)
        └── builder-admin.js     # Lógica interactiva en vivo del constructor y galería
```
