<?php
/**
 * Ingecodex Form - Módulo de Autenticación de Dos Factores (2FA - TOTP RFC 6238)
 * Compatible con Google Authenticator, Microsoft Authenticator y Apple Passwords.
 */

if (!defined('ABSPATH')) {
    exit;
}

// ═════════════════════════════════════════════════════════════════════
// MOTOR CRIPTOGRÁFICO TOTP (RFC 6238 / RFC 4226) EN PHP PURO
// ═════════════════════════════════════════════════════════════════════

class CM_TOTP_Engine {
    private static $base32_chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

    /**
     * Genera una clave secreta aleatoria de 16 caracteres en Base32 (80 bits).
     */
    public static function generate_secret($length = 16) {
        $secret = '';
        $chars_length = strlen(self::$base32_chars);
        for ($i = 0; $i < $length; $i++) {
            $secret .= self::$base32_chars[random_int(0, $chars_length - 1)];
        }
        return $secret;
    }

    /**
     * Decodifica una cadena Base32 a binario.
     */
    public static function base32_decode($secret) {
        $secret = strtoupper(trim($secret));
        if (empty($secret)) return '';

        $buffer = 0;
        $buffer_size = 0;
        $binary = '';

        for ($i = 0; $i < strlen($secret); $i++) {
            $char = $secret[$i];
            $val = strpos(self::$base32_chars, $char);
            if ($val === false) continue; // Ignorar caracteres inválidos

            $buffer = ($buffer << 5) | $val;
            $buffer_size += 5;

            if ($buffer_size >= 8) {
                $buffer_size -= 8;
                $binary .= chr(($buffer >> $buffer_size) & 0xFF);
            }
        }

        return $binary;
    }

    /**
     * Calcula el código TOTP de 6 dígitos para un timestamp y secreto dados.
     */
    public static function get_code($secret, $time_slice = null) {
        if ($time_slice === null) {
            $time_slice = floor(time() / 30);
        }

        $secret_key = self::base32_decode($secret);
        if (empty($secret_key)) return false;

        // Empaquetar el contador de tiempo a entero de 64 bits big-endian
        $time_packed = pack('N*', 0) . pack('N*', $time_slice);

        // HMAC-SHA1
        $hmac = hash_hmac('sha1', $time_packed, $secret_key, true);

        // Truncado dinámico según RFC 4226
        $offset = ord($hmac[19]) & 0x0F;
        $hash_part = substr($hmac, $offset, 4);

        $value = unpack('N', $hash_part);
        $value = $value[1] & 0x7FFFFFFF;

        $modulo = $value % 1000000;
        return str_pad($modulo, 6, '0', STR_PAD_LEFT);
    }

    /**
     * Valida un código de 6 dígitos con tolerancia de desfase de ±1 ventana (±30 seg).
     */
    public static function verify_code($secret, $code, $discrepancy = 1) {
        $code = trim($code);
        if (strlen($code) !== 6 || !ctype_digit($code)) {
            return false;
        }

        $current_slice = floor(time() / 30);

        for ($i = -$discrepancy; $i <= $discrepancy; $i++) {
            $calculated = self::get_code($secret, $current_slice + $i);
            if (hash_equals($calculated, $code)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Genera la URL otpauth:// para escanear con la app.
     */
    public static function get_otpauth_url($user_login, $secret, $issuer = '') {
        if (empty($issuer)) {
            $issuer = get_bloginfo('name');
            if (empty($issuer)) $issuer = 'Ingecodex Platform';
        }
        $issuer_clean = rawurlencode($issuer);
        $user_clean   = rawurlencode($user_login);
        return "otpauth://totp/{$issuer_clean}:{$user_clean}?secret={$secret}&issuer={$issuer_clean}&algorithm=SHA1&digits=6&period=30";
    }

    /**
     * Genera una URL de imagen QR Code segura y nítida.
     */
    public static function get_qr_code_url($otpauth_url) {
        return 'https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=' . rawurlencode($otpauth_url);
    }
}

// ═════════════════════════════════════════════════════════════════════
// HELPERS DE ESTADO 2FA POR USUARIO
// ═════════════════════════════════════════════════════════════════════

function cm_is_2fa_enabled($user_id) {
    return (bool) get_user_meta($user_id, 'cm_2fa_enabled', true);
}

function cm_get_2fa_secret($user_id) {
    return get_user_meta($user_id, 'cm_2fa_secret', true);
}

function cm_get_2fa_activated_at($user_id) {
    return get_user_meta($user_id, 'cm_2fa_activated_at', true);
}

function cm_enable_2fa($user_id, $secret) {
    $now = current_time('mysql');
    update_user_meta($user_id, 'cm_2fa_enabled', 1);
    update_user_meta($user_id, 'cm_2fa_secret', sanitize_text_field($secret));
    update_user_meta($user_id, 'cm_2fa_activated_at', $now);
    delete_user_meta($user_id, 'cm_2fa_temp_secret');
    return true;
}

function cm_disable_2fa($user_id) {
    delete_user_meta($user_id, 'cm_2fa_enabled');
    delete_user_meta($user_id, 'cm_2fa_secret');
    delete_user_meta($user_id, 'cm_2fa_activated_at');
    delete_user_meta($user_id, 'cm_2fa_temp_secret');
    return true;
}

// ═════════════════════════════════════════════════════════════════════
// INTEGRACIÓN CON EL FORMULARIO DE LOGIN DE WORDPRESS
// ═════════════════════════════════════════════════════════════════════

/**
 * Añade el campo de 2FA al formulario estándar de login de WordPress.
 */
function cm_login_form_add_2fa_field() {
    ?>
    <p class="cm-2fa-login-wrap" style="margin-top: 14px; padding-top: 10px; border-top: 1px solid #e2e8f0;">
        <label for="cm_2fa_code" style="font-weight: 700; color: #0f172a; display: flex; align-items: center; justify-content: space-between;">
            <span>🛡️ <?php _e('Código de Seguridad 2FA:', 'contacto-multidestino'); ?></span>
            <small style="font-weight: normal; color: #64748b; font-size: 11px;"><?php _e('(Si tu cuenta tiene 2FA activo)', 'contacto-multidestino'); ?></small>
        </label>
        <input 
            type="text" 
            name="cm_2fa_code" 
            id="cm_2fa_code" 
            class="input" 
            value="" 
            size="6" 
            maxlength="6" 
            autocomplete="one-time-code" 
            placeholder="123456" 
            inputmode="numeric" 
            pattern="[0-9]*" 
            style="font-family: monospace; font-size: 18px; letter-spacing: 4px; text-align: center; font-weight: 700; background: #f8fafc; border: 1.5px solid #cbd5e1; border-radius: 8px; height: 42px;"
        />
    </p>
    <?php
}
// add_action('login_form', 'cm_login_form_add_2fa_field');

/**
 * Intercepta la autenticación para verificar el código 2FA si el usuario lo tiene activo.
 */
function cm_authenticate_2fa_check($user, $username, $password) {
    if (empty($username) || empty($password)) {
        return $user;
    }

    // Si ya hay un error previo (ej. contraseña incorrecta), retornar ese error
    if (is_wp_error($user)) {
        return $user;
    }

    if (!($user instanceof WP_User)) {
        return $user;
    }

    // Verificar si el usuario tiene el 2FA activado
    if (cm_is_2fa_enabled($user->ID)) {
        $secret = cm_get_2fa_secret($user->ID);
        $code   = isset($_POST['cm_2fa_code']) ? sanitize_text_field($_POST['cm_2fa_code']) : '';

        if (empty($code)) {
            return new WP_Error(
                'cm_2fa_required',
                '<strong>🛡️ Seguridad de 2 Factores requerida:</strong> Tu cuenta está protegida con 2FA. Por favor ingresa el código de 6 dígitos desde tu app de autenticación (Google Authenticator / Apple).'
            );
        }

        if (!CM_TOTP_Engine::verify_code($secret, $code)) {
            return new WP_Error(
                'cm_2fa_invalid',
                '<strong>❌ Código 2FA incorrecto o expirado:</strong> Por favor verifica el código de 6 dígitos en tu app e inténtalo nuevamente.'
            );
        }
    }

    return $user;
}
// add_filter('authenticate', 'cm_authenticate_2fa_check', 40, 3);

// ═════════════════════════════════════════════════════════════════════
// ENDPOINTS AJAX PARA CONFIGURACIÓN Y GESTIÓN DE 2FA
// ═════════════════════════════════════════════════════════════════════

/**
 * AJAX: Inicializa la configuración de 2FA generando un nuevo secreto temporal y su QR.
 */
function cm_ajax_2fa_setup_init() {
    check_ajax_referer('cm_contacto_nonce', 'nonce');
    $user_id = get_current_user_id();
    if (!$user_id) {
        wp_send_json_error(array('message' => __('Debes iniciar sesión.', 'contacto-multidestino')));
    }

    $user = get_userdata($user_id);
    $secret = CM_TOTP_Engine::generate_secret(16);
    update_user_meta($user_id, 'cm_2fa_temp_secret', $secret);

    $site_name   = get_bloginfo('name');
    $otpauth_url = CM_TOTP_Engine::get_otpauth_url($user->user_login, $secret, $site_name);
    $qr_url      = CM_TOTP_Engine::get_qr_code_url($otpauth_url);

    wp_send_json_success(array(
        'secret'      => $secret,
        'otpauth_url' => $otpauth_url,
        'qr_url'      => $qr_url,
        'user_login'  => $user->user_login,
    ));
}
add_action('wp_ajax_cm_2fa_setup_init', 'cm_ajax_2fa_setup_init');

/**
 * AJAX: Valida el código de 6 dígitos ingresado por el usuario y activa el 2FA.
 */
function cm_ajax_2fa_verify_and_enable() {
    check_ajax_referer('cm_contacto_nonce', 'nonce');
    $user_id = get_current_user_id();
    if (!$user_id) {
        wp_send_json_error(array('message' => __('Debes iniciar sesión.', 'contacto-multidestino')));
    }

    $code   = isset($_POST['code']) ? sanitize_text_field($_POST['code']) : '';
    $secret = get_user_meta($user_id, 'cm_2fa_temp_secret', true);

    if (empty($secret)) {
        wp_send_json_error(array('message' => __('No hay una configuración en progreso. Vuelve a iniciar el asistente.', 'contacto-multidestino')));
    }

    if (!CM_TOTP_Engine::verify_code($secret, $code)) {
        wp_send_json_error(array('message' => __('El código de 6 dígitos es incorrecto o ha expirado. Verifica tu app móvil.', 'contacto-multidestino')));
    }

    cm_enable_2fa($user_id, $secret);

    wp_send_json_success(array(
        'message' => __('¡Excelente! La Autenticación de Dos Factores (2FA) ha sido activada exitosamente en tu cuenta.', 'contacto-multidestino'),
        'activated_at' => date_i18n('d/m/Y - H:i \h\r\s'),
    ));
}
add_action('wp_ajax_cm_2fa_verify_and_enable', 'cm_ajax_2fa_verify_and_enable');

/**
 * AJAX: Desactiva el 2FA de un usuario (Solo Super Admin).
 */
function cm_ajax_admin_disable_2fa() {
    check_ajax_referer('cm_contacto_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Solo el Super Administrador puede revocar o desactivar el 2FA de otros usuarios.', 'contacto-multidestino')));
    }

    $target_user_id = isset($_POST['user_id']) ? absint($_POST['user_id']) : 0;
    if (!$target_user_id) {
        wp_send_json_error(array('message' => __('Usuario no válido.', 'contacto-multidestino')));
    }

    $user = get_userdata($target_user_id);
    if (!$user) {
        wp_send_json_error(array('message' => __('No se encontró el usuario.', 'contacto-multidestino')));
    }

    cm_disable_2fa($target_user_id);

    wp_send_json_success(array(
        'message' => sprintf(__('La seguridad de 2 Factores del usuario "%s" ha sido desactivada exitosamente.', 'contacto-multidestino'), $user->user_login)
    ));
}
add_action('wp_ajax_cm_admin_disable_2fa', 'cm_ajax_admin_disable_2fa');

/**
 * AJAX: Restablece el 2FA de un usuario (Desactiva y limpia para permitir una nueva vinculación).
 */
function cm_ajax_admin_reset_user_2fa() {
    check_ajax_referer('cm_contacto_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Solo el Super Administrador puede restablecer el 2FA de otros usuarios.', 'contacto-multidestino')));
    }

    $target_user_id = isset($_POST['user_id']) ? absint($_POST['user_id']) : 0;
    if (!$target_user_id) {
        wp_send_json_error(array('message' => __('Usuario no válido.', 'contacto-multidestino')));
    }

    $user = get_userdata($target_user_id);
    if (!$user) {
        wp_send_json_error(array('message' => __('No se encontró el usuario.', 'contacto-multidestino')));
    }

    cm_disable_2fa($target_user_id);

    wp_send_json_success(array(
        'message' => sprintf(__('La seguridad 2FA del usuario "%s" fue restablecida. El usuario podrá volver a vincular su app al iniciar sesión.', 'contacto-multidestino'), $user->user_login)
    ));
}
add_action('wp_ajax_cm_admin_reset_user_2fa', 'cm_ajax_admin_reset_user_2fa');

/**
 * AJAX: Genera un QR y Clave Secreta para un usuario específico (ejecutado por el Super Admin).
 */
function cm_ajax_admin_generate_user_2fa() {
    check_ajax_referer('cm_contacto_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('No tienes permisos suficientes.', 'contacto-multidestino')));
    }

    $target_user_id = isset($_POST['user_id']) ? absint($_POST['user_id']) : 0;
    if (!$target_user_id) {
        wp_send_json_error(array('message' => __('Usuario no válido.', 'contacto-multidestino')));
    }

    $user = get_userdata($target_user_id);
    if (!$user) {
        wp_send_json_error(array('message' => __('No se encontró el usuario.', 'contacto-multidestino')));
    }

    $secret      = CM_TOTP_Engine::generate_secret(16);
    $issuer      = get_bloginfo('name');
    $otpauth_url = CM_TOTP_Engine::get_otpauth_url($user->user_login, $secret, $issuer);
    $qr_url      = CM_TOTP_Engine::get_qr_code_url($otpauth_url);

    update_user_meta($target_user_id, 'cm_2fa_temp_secret', $secret);

    wp_send_json_success(array(
        'secret'      => $secret,
        'qr_url'      => $qr_url,
        'otpauth_url' => $otpauth_url,
        'username'    => $user->user_login,
    ));
}
add_action('wp_ajax_cm_admin_generate_user_2fa', 'cm_ajax_admin_generate_user_2fa');

/**
 * AJAX: Asigna y Activa el 2FA generado para el usuario.
 */
function cm_ajax_admin_assign_user_2fa() {
    check_ajax_referer('cm_contacto_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('No tienes permisos suficientes.', 'contacto-multidestino')));
    }

    $target_user_id = isset($_POST['user_id']) ? absint($_POST['user_id']) : 0;
    $code           = isset($_POST['code']) ? sanitize_text_field($_POST['code']) : '';
    $secret         = get_user_meta($target_user_id, 'cm_2fa_temp_secret', true);

    if (empty($secret)) {
        wp_send_json_error(array('message' => __('Primero debes generar la clave y QR.', 'contacto-multidestino')));
    }

    if (!empty($code) && !CM_TOTP_Engine::verify_code($secret, $code)) {
        wp_send_json_error(array('message' => __('El código de 6 dígitos ingresado es incorrecto.', 'contacto-multidestino')));
    }

    cm_enable_2fa($target_user_id, $secret);

    $user = get_userdata($target_user_id);
    wp_send_json_success(array(
        'message' => sprintf(__('¡2FA asignado y activado exitosamente para "%s"!', 'contacto-multidestino'), $user ? $user->user_login : 'el usuario')
    ));
}
add_action('wp_ajax_cm_admin_assign_user_2fa', 'cm_ajax_admin_assign_user_2fa');

