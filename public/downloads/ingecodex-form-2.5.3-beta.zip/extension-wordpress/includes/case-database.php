<?php
/**
 * Ingecodex Form — Base de Datos de Envíos y Seguimiento de Casos
 * Gestión de tablas MySQL para registrar cada mensaje y su historial de estados.
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Crea o actualiza las tablas personalizadas de base de datos para envíos y seguimiento.
 */
function cm_create_database_tables() {
    global $wpdb;

    $charset_collate = $wpdb->get_charset_collate();
    $table_submissions = $wpdb->prefix . 'cm_form_submissions';
    $table_updates     = $wpdb->prefix . 'cm_case_updates';

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    // Tabla principal de envíos
    $sql_submissions = "CREATE TABLE $table_submissions (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        ticket_code varchar(32) NOT NULL,
        form_id varchar(64) NOT NULL DEFAULT '',
        form_name varchar(255) NOT NULL DEFAULT '',
        sender_name varchar(255) DEFAULT '',
        sender_email varchar(255) DEFAULT '',
        sender_phone varchar(100) DEFAULT '',
        department varchar(255) DEFAULT '',
        subject varchar(255) DEFAULT '',
        submitted_data longtext DEFAULT '',
        attachments longtext DEFAULT '',
        status varchar(50) NOT NULL DEFAULT 'recibido',
        is_deleted tinyint(1) NOT NULL DEFAULT 0,
        deleted_at datetime DEFAULT NULL,
        deleted_by varchar(255) DEFAULT '',
        restored_at datetime DEFAULT NULL,
        restored_by varchar(255) DEFAULT '',
        ip_address varchar(100) DEFAULT '',
        user_agent text DEFAULT '',
        created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        UNIQUE KEY ticket_code (ticket_code),
        KEY form_id (form_id),
        KEY status (status),
        KEY is_deleted (is_deleted),
        KEY created_at (created_at)
    ) $charset_collate;";

    $sql_updates = "CREATE TABLE $table_updates (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        submission_id bigint(20) unsigned NOT NULL,
        ticket_code varchar(32) NOT NULL,
        author_name varchar(255) NOT NULL DEFAULT 'Sistema',
        status varchar(50) NOT NULL DEFAULT '',
        action_type varchar(50) NOT NULL DEFAULT 'update',
        note longtext NOT NULL,
        is_public tinyint(1) NOT NULL DEFAULT 1,
        notified_user tinyint(1) NOT NULL DEFAULT 0,
        created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        KEY submission_id (submission_id),
        KEY ticket_code (ticket_code),
        KEY created_at (created_at)
    ) $charset_collate;";

    $table_audit_logs = $wpdb->prefix . 'cm_case_audit_logs';
    $sql_audit_logs = "CREATE TABLE $table_audit_logs (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        submission_id bigint(20) unsigned NOT NULL,
        ticket_code varchar(32) NOT NULL,
        user_id bigint(20) unsigned NOT NULL DEFAULT 0,
        user_name varchar(255) NOT NULL DEFAULT '',
        action varchar(100) NOT NULL,
        details longtext NOT NULL,
        ip_address varchar(100) DEFAULT '',
        created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        KEY submission_id (submission_id),
        KEY ticket_code (ticket_code),
        KEY created_at (created_at)
    ) $charset_collate;";

    dbDelta($sql_submissions);
    dbDelta($sql_updates);
    dbDelta($sql_audit_logs);

    cm_ensure_soft_delete_columns();

    update_option('cm_db_version', '2.4.9');
}

/**
 * Asegura que las columnas de papelera/recuperación existan en la tabla cm_form_submissions sin reinstalar.
 */
function cm_ensure_soft_delete_columns() {
    global $wpdb;
    $table = $wpdb->prefix . 'cm_form_submissions';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table'") !== $table) {
        return;
    }
    $columns = $wpdb->get_col("DESCRIBE $table");
    if (!empty($columns) && !in_array('is_deleted', $columns)) {
        $wpdb->query("ALTER TABLE $table 
            ADD COLUMN is_deleted tinyint(1) NOT NULL DEFAULT 0, 
            ADD COLUMN deleted_at datetime DEFAULT NULL, 
            ADD COLUMN deleted_by varchar(255) DEFAULT '', 
            ADD COLUMN restored_at datetime DEFAULT NULL, 
            ADD COLUMN restored_by varchar(255) DEFAULT '', 
            ADD KEY is_deleted (is_deleted)");
    }
}
add_action('admin_init', 'cm_ensure_soft_delete_columns');

/**
 * Obtiene los estados posibles del caso con sus etiquetas, colores e íconos.
 */
function cm_get_case_statuses() {
    return array(
        'recibido' => array(
            'label'       => __('Nuevo / Recibido', 'contacto-multidestino'),
            'description' => __('Formulario ingresado, a la espera de atención del área.', 'contacto-multidestino'),
            'color'       => '#dc2626', // 🔴 Rojo Alerta
            'bg_color'    => '#fef2f2',
            'border'      => '#fecaca',
            'icon'        => '🔴',
            'step'        => 1,
        ),
        'en_revision' => array(
            'label'       => __('En Revisión', 'contacto-multidestino'),
            'description' => __('El área responsable está revisando los antecedentes.', 'contacto-multidestino'),
            'color'       => '#d97706', // 🟡 Amarillo / Ámbar
            'bg_color'    => '#fffbeb',
            'border'      => '#fde68a',
            'icon'        => '🟡',
            'step'        => 2,
        ),
        'en_proceso' => array(
            'label'       => __('En Proceso / Tomado', 'contacto-multidestino'),
            'description' => __('El caso se encuentra tomado y en gestión activa.', 'contacto-multidestino'),
            'color'       => '#16a34a', // 🟢 Verde
            'bg_color'    => '#f0fdf4',
            'border'      => '#86efac',
            'icon'        => '🟢',
            'step'        => 3,
        ),
        'pendiente_usuario' => array(
            'label'       => __('Requiere Acción / Presencia del Solicitante', 'contacto-multidestino'),
            'description' => __('Se solicita información adicional o la presencia física de la persona.', 'contacto-multidestino'),
            'color'       => '#7c3aed', // 🟣 Púrpura
            'bg_color'    => '#f5f3ff',
            'border'      => '#ddd6fe',
            'icon'        => '⚠️',
            'step'        => 3,
        ),
        'resuelto' => array(
            'label'       => __('Resuelto / Finalizado', 'contacto-multidestino'),
            'description' => __('El caso fue gestionado y concluido satisfactoriamente.', 'contacto-multidestino'),
            'color'       => '#475569', // ⚪ Gris Finalizado
            'bg_color'    => '#f1f5f9',
            'border'      => '#cbd5e1',
            'icon'        => '✅',
            'step'        => 4,
        ),
        'cerrado' => array(
            'label'       => __('Cerrado / Desestimado', 'contacto-multidestino'),
            'description' => __('El caso se encuentra cerrado.', 'contacto-multidestino'),
            'color'       => '#64748b', // ⚪ Gris
            'bg_color'    => '#f8fafc',
            'border'      => '#e2e8f0',
            'icon'        => '🔒',
            'step'        => 4,
        ),
    );
}

/**
 * Inserta un nuevo envío en la base de datos y crea su primer registro histórico.
 */
function cm_insert_submission($args = array()) {
    global $wpdb;
    $table = $wpdb->prefix . 'cm_form_submissions';

    $ticket_code     = !empty($args['ticket_code']) ? sanitize_text_field($args['ticket_code']) : cm_generate_ticket_code();
    $form_id         = !empty($args['form_id']) ? sanitize_text_field($args['form_id']) : 'principal';
    $form_name       = !empty($args['form_name']) ? sanitize_text_field($args['form_name']) : 'Formulario';
    $sender_name     = !empty($args['sender_name']) ? sanitize_text_field($args['sender_name']) : '';
    $sender_email    = !empty($args['sender_email']) ? sanitize_email($args['sender_email']) : '';
    $sender_phone    = !empty($args['sender_phone']) ? sanitize_text_field($args['sender_phone']) : '';
    $department      = !empty($args['department']) ? sanitize_text_field($args['department']) : 'General';
    $subject         = !empty($args['subject']) ? sanitize_text_field($args['subject']) : '';
    $submitted_data  = !empty($args['submitted_data']) ? (is_string($args['submitted_data']) ? $args['submitted_data'] : wp_json_encode($args['submitted_data'])) : '{}';
    $attachments     = !empty($args['attachments']) ? (is_string($args['attachments']) ? $args['attachments'] : wp_json_encode($args['attachments'])) : '';
    $status          = !empty($args['status']) ? sanitize_key($args['status']) : 'recibido';
    $ip_address      = !empty($_SERVER['REMOTE_ADDR']) ? sanitize_text_field($_SERVER['REMOTE_ADDR']) : '';
    $user_agent      = !empty($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(substr($_SERVER['HTTP_USER_AGENT'], 0, 500)) : '';
    $now             = current_time('mysql');

    // Asegurar que las tablas existan
    if ($wpdb->get_var("SHOW TABLES LIKE '$table'") !== $table) {
        cm_create_database_tables();
    }

    $result = $wpdb->insert(
        $table,
        array(
            'ticket_code'    => $ticket_code,
            'form_id'        => $form_id,
            'form_name'      => $form_name,
            'sender_name'    => $sender_name,
            'sender_email'   => $sender_email,
            'sender_phone'   => $sender_phone,
            'department'     => $department,
            'subject'        => $subject,
            'submitted_data' => $submitted_data,
            'attachments'    => $attachments,
            'status'         => $status,
            'ip_address'     => $ip_address,
            'user_agent'     => $user_agent,
            'created_at'     => $now,
            'updated_at'     => $now,
        ),
        array('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')
    );

    if ($result) {
        $submission_id = $wpdb->insert_id;

        // Crear primer hito en el historial del caso
        cm_add_case_update(array(
            'submission_id' => $submission_id,
            'ticket_code'   => $ticket_code,
            'author_name'   => 'Sistema Web',
            'status'        => $status,
            'action_type'   => 'created',
            'note'          => sprintf(__('Formulario recibido correctamente y asignado al área de %s.', 'contacto-multidestino'), $department),
            'is_public'     => 1,
            'notified_user' => 1,
        ));

        return array(
            'id'          => $submission_id,
            'ticket_code' => $ticket_code,
        );
    }

    return false;
}

/**
 * Añade una actualización o evento en el historial del caso.
 */
function cm_add_case_update($args = array()) {
    global $wpdb;
    $table = $wpdb->prefix . 'cm_case_updates';

    $submission_id = !empty($args['submission_id']) ? absint($args['submission_id']) : 0;
    $ticket_code   = !empty($args['ticket_code']) ? sanitize_text_field($args['ticket_code']) : '';
    $author_name   = !empty($args['author_name']) ? sanitize_text_field($args['author_name']) : 'Administrador';
    $status        = !empty($args['status']) ? sanitize_key($args['status']) : '';
    $action_type   = !empty($args['action_type']) ? sanitize_key($args['action_type']) : 'update';
    $note          = !empty($args['note']) ? wp_kses_post($args['note']) : '';
    $is_public     = isset($args['is_public']) ? (int)$args['is_public'] : 1;
    $notified_user = isset($args['notified_user']) ? (int)$args['notified_user'] : 0;
    $now           = current_time('mysql');

    if (!$submission_id && $ticket_code) {
        $sub = cm_get_submission_by_code($ticket_code);
        if ($sub) {
            $submission_id = $sub->id;
        }
    }

    if (!$submission_id) {
        return false;
    }

    $inserted = $wpdb->insert(
        $table,
        array(
            'submission_id' => $submission_id,
            'ticket_code'   => $ticket_code,
            'author_name'   => $author_name,
            'status'        => $status,
            'action_type'   => $action_type,
            'note'          => $note,
            'is_public'     => $is_public,
            'notified_user' => $notified_user,
            'created_at'    => $now,
        ),
        array('%d', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%s')
    );

    // Actualizar estado y fecha en la tabla principal
    if ($inserted && $status) {
        $wpdb->update(
            $wpdb->prefix . 'cm_form_submissions',
            array(
                'status'     => $status,
                'updated_at' => $now,
            ),
            array('id' => $submission_id),
            array('%s', '%s'),
            array('%d')
        );
    }

    return $inserted ? $wpdb->insert_id : false;
}

/**
 * Obtiene un caso por su ID.
 */
function cm_get_submission_by_id($id) {
    global $wpdb;
    $table = $wpdb->prefix . 'cm_form_submissions';
    $id = absint($id);
    return $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", $id));
}

/**
 * Obtiene un caso por su Código de Seguimiento (Ticket).
 * Por defecto solo busca casos activos (oculta casos eliminados del portal público).
 */
function cm_get_submission_by_code($ticket_code, $include_deleted = false) {
    global $wpdb;
    $table = $wpdb->prefix . 'cm_form_submissions';
    $ticket_code = sanitize_text_field(trim($ticket_code));
    if (!$ticket_code) return null;

    cm_ensure_soft_delete_columns();

    if ($include_deleted) {
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE ticket_code = %s", $ticket_code));
    }

    return $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE ticket_code = %s AND (is_deleted = 0 OR is_deleted IS NULL)", $ticket_code));
}

/**
 * Obtiene el historial de eventos de un caso.
 */
function cm_get_case_updates($submission_id_or_code, $public_only = false) {
    global $wpdb;
    $table = $wpdb->prefix . 'cm_case_updates';

    if (is_numeric($submission_id_or_code)) {
        $id = absint($submission_id_or_code);
        $where = $public_only ? "WHERE submission_id = $id AND is_public = 1" : "WHERE submission_id = $id";
    } else {
        $code = sanitize_text_field(trim($submission_id_or_code));
        $where = $public_only ? $wpdb->prepare("WHERE ticket_code = %s AND is_public = 1", $code) : $wpdb->prepare("WHERE ticket_code = %s", $code);
    }

    return $wpdb->get_results("SELECT * FROM $table $where ORDER BY created_at ASC");
}

/**
 * Obtiene la lista de envíos con filtros y paginación para el panel de administración.
 */
function cm_get_submissions($args = array()) {
    global $wpdb;
    $table = $wpdb->prefix . 'cm_form_submissions';

    // Asegurar que la tabla y columnas existan
    if ($wpdb->get_var("SHOW TABLES LIKE '$table'") !== $table) {
        cm_create_database_tables();
    } else {
        cm_ensure_soft_delete_columns();
    }

    $defaults = array(
        'form_id'    => '',
        'status'     => '',
        'department' => '',
        'search'     => '',
        'trash_only' => false,
        'limit'      => 20,
        'offset'     => 0,
        'orderby'    => 'created_at',
        'order'      => 'DESC',
    );
    $args = wp_parse_args($args, $defaults);

    $where_clauses = array('1=1');
    $query_params  = array();

    // Filtro de Papelera (Casos Eliminados vs Casos Activos)
    if (!empty($args['trash_only']) || (isset($args['is_deleted']) && $args['is_deleted'] == 1)) {
        $where_clauses[] = 'is_deleted = 1';
    } else {
        $where_clauses[] = '(is_deleted = 0 OR is_deleted IS NULL)';
    }

    if (!empty($args['form_id'])) {
        $where_clauses[] = 'form_id = %s';
        $query_params[]  = sanitize_text_field($args['form_id']);
    }

    if (!empty($args['status'])) {
        $where_clauses[] = 'status = %s';
        $query_params[]  = sanitize_text_field($args['status']);
    } elseif (!empty($args['filter_bucket'])) {
        if ($args['filter_bucket'] === 'active') {
            $where_clauses[] = "status NOT IN ('resuelto', 'cerrado')";
        } elseif ($args['filter_bucket'] === 'completed') {
            $where_clauses[] = "status IN ('resuelto', 'cerrado')";
        } elseif ($args['filter_bucket'] === 'pending') {
            $where_clauses[] = "status IN ('recibido', 'pendiente')";
        }
    }

    if (!empty($args['department'])) {
        if (is_array($args['department'])) {
            $depts = array_values(array_filter(array_map('sanitize_text_field', $args['department'])));
            if (!empty($depts)) {
                $placeholders = implode(',', array_fill(0, count($depts), '%s'));
                $where_clauses[] = "department IN ($placeholders)";
                foreach ($depts as $d) {
                    $query_params[] = $d;
                }
            }
        } else {
            $where_clauses[] = 'department = %s';
            $query_params[]  = sanitize_text_field($args['department']);
        }
    }

    if (!empty($args['search'])) {
        $search_term = '%' . $wpdb->esc_like(trim($args['search'])) . '%';
        $where_clauses[] = '(ticket_code LIKE %s OR sender_name LIKE %s OR sender_email LIKE %s OR department LIKE %s OR subject LIKE %s)';
        $query_params[]  = $search_term;
        $query_params[]  = $search_term;
        $query_params[]  = $search_term;
        $query_params[]  = $search_term;
        $query_params[]  = $search_term;
    }

    $where_sql = implode(' AND ', $where_clauses);
    $orderby   = in_array(strtoupper($args['orderby']), array('ID', 'CREATED_AT', 'UPDATED_AT', 'TICKET_CODE', 'STATUS', 'DELETED_AT')) ? $args['orderby'] : 'created_at';
    $order     = strtoupper($args['order']) === 'ASC' ? 'ASC' : 'DESC';
    $limit     = absint($args['limit']);
    $offset    = absint($args['offset']);

    $sql = "SELECT * FROM $table WHERE $where_sql ORDER BY $orderby $order LIMIT $limit OFFSET $offset";

    if (!empty($query_params)) {
        $sql = $wpdb->prepare($sql, $query_params);
    }

    $items = $wpdb->get_results($sql);

    // Contar total
    $count_sql = "SELECT COUNT(*) FROM $table WHERE $where_sql";
    if (!empty($query_params)) {
        $count_sql = $wpdb->prepare($count_sql, $query_params);
    }
    $total = (int)$wpdb->get_var($count_sql);

    return array(
        'items' => $items,
        'total' => $total,
    );
}

/**
 * Obtiene estadísticas generales de envíos para el dashboard.
 */
function cm_get_submission_stats($department = '') {
    global $wpdb;
    $table = $wpdb->prefix . 'cm_form_submissions';

    if ($wpdb->get_var("SHOW TABLES LIKE '$table'") !== $table) {
        return array(
            'total'             => 0,
            'recibido'          => 0,
            'en_revision'       => 0,
            'en_proceso'        => 0,
            'pendiente_usuario' => 0,
            'resuelto'          => 0,
            'cerrado'           => 0,
        );
    }

    cm_ensure_soft_delete_columns();

    $where = '(is_deleted = 0 OR is_deleted IS NULL)';
    if (!empty($department)) {
        if (is_array($department)) {
            $depts = array_values(array_filter(array_map('sanitize_text_field', $department)));
            if (!empty($depts)) {
                $placeholders = implode(',', array_fill(0, count($depts), '%s'));
                $where .= $wpdb->prepare(" AND department IN ($placeholders)", $depts);
            }
        } else {
            $where .= $wpdb->prepare(" AND department = %s", sanitize_text_field($department));
        }
    }

    $results = $wpdb->get_results("SELECT status, COUNT(*) as count FROM $table WHERE $where GROUP BY status");

    $stats = array(
        'total'             => 0,
        'recibido'          => 0,
        'en_revision'       => 0,
        'en_proceso'        => 0,
        'pendiente_usuario' => 0,
        'resuelto'          => 0,
        'cerrado'           => 0,
    );

    foreach ($results as $row) {
        if (isset($stats[$row->status])) {
            $stats[$row->status] = (int)$row->count;
        }
        $stats['total'] += (int)$row->count;
    }

    return $stats;
}

/**
 * Obtiene la cantidad de casos en la papelera.
 */
function cm_get_trash_count() {
    global $wpdb;
    $table = $wpdb->prefix . 'cm_form_submissions';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table'") !== $table) {
        return 0;
    }
    cm_ensure_soft_delete_columns();
    return (int)$wpdb->get_var("SELECT COUNT(*) FROM $table WHERE is_deleted = 1");
}

/**
 * Obtiene métricas analíticas avanzadas, desglose por departamentos y actividad en vivo para el Dashboard.
 */
function cm_get_dashboard_analytics() {
    global $wpdb;
    $sub_table = $wpdb->prefix . 'cm_form_submissions';
    $upd_table = $wpdb->prefix . 'cm_case_updates';

    $stats = cm_get_submission_stats();
    
    // Agrupación ejecutiva
    $iniciados   = (int)$stats['recibido'];
    $continuidad = (int)($stats['en_revision'] + $stats['en_proceso']);
    $pendientes  = (int)$stats['pendiente_usuario'];
    $finalizados = (int)($stats['resuelto'] + $stats['cerrado']);
    $total       = (int)$stats['total'];
    $tasa_cierre = $total > 0 ? round(($finalizados / $total) * 100, 1) : 0;

    // Desglose por Departamento (Solo casos activos)
    $dept_rows = $wpdb->get_results("
        SELECT department, 
               COUNT(*) as total_cases,
               SUM(CASE WHEN status = 'recibido' THEN 1 ELSE 0 END) as count_iniciados,
               SUM(CASE WHEN status IN ('en_revision', 'en_proceso') THEN 1 ELSE 0 END) as count_continuidad,
               SUM(CASE WHEN status = 'pendiente_usuario' THEN 1 ELSE 0 END) as count_pendientes,
               SUM(CASE WHEN status IN ('resuelto', 'cerrado') THEN 1 ELSE 0 END) as count_finalizados
        FROM $sub_table 
        WHERE (is_deleted = 0 OR is_deleted IS NULL)
        GROUP BY department 
        ORDER BY total_cases DESC
    ");

    // Feed de Actividad Reciente en Vivo (últimas 15 acciones de todas las áreas)
    $recent_activity = $wpdb->get_results("
        SELECT u.*, s.sender_name, s.department as current_department 
        FROM $upd_table u 
        LEFT JOIN $sub_table s ON u.submission_id = s.id 
        ORDER BY u.created_at DESC 
        LIMIT 15
    ");

    return array(
        'total'           => $total,
        'iniciados'       => $iniciados,
        'continuidad'     => $continuidad,
        'pendientes'      => $pendientes,
        'finalizados'     => $finalizados,
        'tasa_cierre'     => $tasa_cierre,
        'departments'     => $dept_rows ? $dept_rows : array(),
        'recent_activity' => $recent_activity ? $recent_activity : array(),
    );
}

/**
 * Obtiene los casos organizados por estado para el Tablero Kanban visual del Dashboard.
 */
function cm_get_kanban_columns_data() {
    global $wpdb;
    $table = $wpdb->prefix . 'cm_form_submissions';

    $iniciados   = $wpdb->get_results("SELECT * FROM $table WHERE (is_deleted = 0 OR is_deleted IS NULL) AND status = 'recibido' ORDER BY updated_at DESC LIMIT 25");
    $continuidad = $wpdb->get_results("SELECT * FROM $table WHERE (is_deleted = 0 OR is_deleted IS NULL) AND status IN ('en_revision', 'en_proceso') ORDER BY updated_at DESC LIMIT 25");
    $pendientes  = $wpdb->get_results("SELECT * FROM $table WHERE (is_deleted = 0 OR is_deleted IS NULL) AND status = 'pendiente_usuario' ORDER BY updated_at DESC LIMIT 25");
    $finalizados = $wpdb->get_results("SELECT * FROM $table WHERE (is_deleted = 0 OR is_deleted IS NULL) AND status IN ('resuelto', 'cerrado') ORDER BY updated_at DESC LIMIT 25");

    return array(
        'iniciados'   => $iniciados ? $iniciados : array(),
        'continuidad' => $continuidad ? $continuidad : array(),
        'pendientes'  => $pendientes ? $pendientes : array(),
        'finalizados' => $finalizados ? $finalizados : array(),
    );
}

/**
 * Comprueba si el usuario actual o el ID especificado tiene perfil de Director / Auditor Institucional (Acceso Total).
 */
function cm_is_director($user_id = 0) {
    if (!$user_id) $user_id = get_current_user_id();
    if (!$user_id) return false;
    return get_user_meta($user_id, 'cm_user_profile', true) === 'director';
}

/**
 * Comprueba si el usuario actual o el ID especificado tiene perfil de Subdirector / Moderador (Multi-Área).
 */
function cm_is_moderator($user_id = 0) {
    if (!$user_id) $user_id = get_current_user_id();
    if (!$user_id) return false;
    $profile = get_user_meta($user_id, 'cm_user_profile', true);
    return $profile === 'moderator' || $profile === 'subdirector';
}

/**
 * Comprueba si el usuario tiene permiso para ver el Dashboard Global y todos los casos (Superadmin o Director).
 */
function cm_can_view_global_dashboard($user_id = 0) {
    if (!$user_id) $user_id = get_current_user_id();
    if (!$user_id) return false;
    return user_can($user_id, 'manage_options') || cm_is_director($user_id);
}

/**
 * Obtiene la lista de departamentos asignados a un usuario específico.
 * @param int $user_id ID del usuario.
 * @return array Arreglo con los nombres de departamentos asignados.
 */
function cm_get_user_assigned_departments($user_id = 0) {
    if (!$user_id) $user_id = get_current_user_id();
    if (!$user_id) return array();

    // 1. Revisar meta cm_assigned_departments (array)
    $assigned = get_user_meta($user_id, 'cm_assigned_departments', true);
    if (is_array($assigned) && !empty($assigned)) {
        return array_values(array_unique(array_filter($assigned)));
    }

    // 2. Si tiene meta individual cm_user_department
    $single = get_user_meta($user_id, 'cm_user_department', true);
    if (!empty($single)) {
        return array($single);
    }

    // 3. Buscar en el registro de departamentos donde coincida user_id
    $deps = cm_get_available_departments(false);
    $found = array();
    foreach ($deps as $name => $d) {
        if (!empty($d['user_id']) && (int)$d['user_id'] === (int)$user_id) {
            $found[] = $name;
        }
    }

    return $found;
}

/**
 * Asigna una lista de departamentos a un usuario específico.
 * @param int $user_id ID del usuario.
 * @param array|string $departments Departamentos a asignar.
 */
function cm_set_user_assigned_departments($user_id, $departments = array()) {
    if (!$user_id) return false;
    if (!is_array($departments)) {
        $departments = $departments ? array($departments) : array();
    }
    $clean_depts = array_values(array_unique(array_filter(array_map('sanitize_text_field', $departments))));
    update_user_meta($user_id, 'cm_assigned_departments', $clean_depts);
    if (!empty($clean_depts)) {
        update_user_meta($user_id, 'cm_user_department', $clean_depts[0]);
    } else {
        delete_user_meta($user_id, 'cm_user_department');
    }
    return true;
}

/**
 * Obtiene los departamentos asignados al usuario actual.
 * Retorna array vacío si el usuario es Super Admin o Director (acceso global a todas las áreas).
 * Retorna un array con 1 o más departamentos para Moderadores o Encargados.
 */
function cm_get_current_user_assigned_departments() {
    $current_user_id = get_current_user_id();
    if (!$current_user_id) return array();

    // Superadmin y Directores tienen acceso global a todos los casos
    if (current_user_can('manage_options') || cm_is_director($current_user_id)) {
        return array();
    }

    return cm_get_user_assigned_departments($current_user_id);
}

/**
 * Obtiene el departamento principal asignado al usuario actual.
 * Retorna cadena vacía para Superadmin y Directores.
 */
function cm_get_current_user_assigned_department() {
    $depts = cm_get_current_user_assigned_departments();
    return !empty($depts) ? $depts[0] : '';
}

/**
 * Comprueba si un usuario tiene permisos para derivar casos a otros departamentos.
 * @param int $user_id ID de usuario (por defecto el usuario actual).
 * @return bool True si puede derivar casos, false si solo puede atender su área asignada.
 */
function cm_user_can_reassign_cases($user_id = 0) {
    if (!$user_id) $user_id = get_current_user_id();
    if (!$user_id) return false;
    if (user_can($user_id, 'manage_options') || cm_is_director($user_id)) {
        return true;
    }
    $allow = get_user_meta($user_id, 'cm_allow_reassign', true);
    return ($allow !== '0');
}

/**
 * Retorna las notas rápidas predeterminadas oficiales del sistema.
 */
function cm_get_default_quick_notes() {
    return array(
        array(
            'id'            => 'nota_conocimiento',
            'title'         => '📌 Toma de Conocimiento e Inicio',
            'content'       => 'Se toma conocimiento del caso y se inicia la actividad institucional correspondiente.',
            'status'        => 'en_proceso',
            'is_default'    => true,
        ),
        array(
            'id'            => 'nota_trazabilidad',
            'title'         => '🔍 Seguimiento y Trazabilidad',
            'content'       => 'Se sigue la trazabilidad del requerimiento. Se encuentra en etapa de validación y análisis de antecedentes.',
            'status'        => 'en_revision',
            'is_default'    => true,
        ),
        array(
            'id'            => 'nota_derivacion',
            'title'         => '🔄 Derivación a Área Técnica',
            'content'       => 'Se deriva el caso al área especializada para su análisis y resolución técnica correspondiente.',
            'status'        => 'en_proceso',
            'is_default'    => true,
        ),
        array(
            'id'            => 'nota_presencia',
            'title'         => '🏛️ Solicitud de Presencia Física',
            'content'       => 'Se solicita la presencia física de la persona que generó el caso en nuestras dependencias u oficinas de atención para validar antecedentes y continuar con la gestión del trámite.',
            'status'        => 'pendiente_usuario',
            'req_presence'  => true,
            'is_default'    => true,
        ),
        array(
            'id'            => 'nota_documentos',
            'title'         => '📁 Solicitud de Documentos',
            'content'       => 'Se solicita adjuntar o remitir documentación complementaria (imágenes JPG/PNG/SVG/BMP o archivo PDF hasta 4 MB) a través de este portal de seguimiento para dar curso a su requerimiento.',
            'status'        => 'pendiente_usuario',
            'req_doc'       => true,
            'is_default'    => true,
        ),
        array(
            'id'            => 'nota_finalizacion',
            'title'         => '✅ Finalización y Cierre de Caso',
            'content'       => 'Su requerimiento ha sido resuelto y procesado exitosamente por nuestra área. Se da por concluido el expediente institucional.',
            'status'        => 'resuelto',
            'is_default'    => true,
        ),
    );
}

/**
 * Obtiene todas las notas rápidas disponibles (predeterminadas activas + personalizadas guardadas).
 */
function cm_get_saved_quick_notes() {
    $defaults = cm_get_default_quick_notes();
    $disabled = get_option('cm_disabled_quick_notes', array());
    if (!is_array($disabled)) {
        $disabled = array();
    }

    $active_defaults = array();
    foreach ($defaults as $d) {
        if (!in_array($d['id'], $disabled)) {
            $active_defaults[] = $d;
        }
    }

    $custom = get_option('cm_saved_quick_notes', array());
    if (!is_array($custom)) {
        $custom = array();
    }
    return array_merge($active_defaults, $custom);
}

/**
 * Guarda una nueva nota rápida personalizada para respuestas institucionales.
 */
function cm_save_quick_note($title, $content, $status = '', $req_doc = false, $req_presence = false) {
    $title   = sanitize_text_field(trim($title));
    $content = sanitize_textarea_field(trim($content));
    $status  = sanitize_key(trim($status));

    if (!$title || !$content) {
        return false;
    }

    $custom = get_option('cm_saved_quick_notes', array());
    if (!is_array($custom)) {
        $custom = array();
    }

    $note_id = 'custom_' . time() . '_' . wp_rand(100, 999);
    $new_note = array(
        'id'           => $note_id,
        'title'        => $title,
        'content'      => $content,
        'status'       => $status ? $status : 'en_proceso',
        'req_doc'      => !empty($req_doc),
        'req_presence' => !empty($req_presence),
        'is_default'   => false,
        'created_at'   => current_time('mysql'),
    );

    $custom[] = $new_note;
    update_option('cm_saved_quick_notes', $custom);
    return $new_note;
}

/**
 * Elimina cualquier nota rápida (predeterminada o personalizada).
 */
function cm_delete_quick_note($note_id) {
    $note_id = sanitize_key($note_id);
    if (!$note_id) {
        return false;
    }

    // Si es nota por defecto, se añade a la lista de deshabilitadas
    if (strpos($note_id, 'custom_') !== 0) {
        $disabled = get_option('cm_disabled_quick_notes', array());
        if (!is_array($disabled)) {
            $disabled = array();
        }
        if (!in_array($note_id, $disabled)) {
            $disabled[] = $note_id;
            update_option('cm_disabled_quick_notes', $disabled);
        }
        return true;
    }

    // Si es personalizada, se remueve del array
    $custom = get_option('cm_saved_quick_notes', array());
    if (!is_array($custom)) {
        return false;
    }

    $filtered = array();
    $deleted  = false;
    foreach ($custom as $note) {
        if (($note['id'] ?? '') === $note_id) {
            $deleted = true;
            continue;
        }
        $filtered[] = $note;
    }

    if ($deleted) {
        update_option('cm_saved_quick_notes', $filtered);
    }
    return $deleted;
}

/**
 * Restaura todas las notas rápidas predeterminadas del sistema.
 */
function cm_restore_default_quick_notes() {
    delete_option('cm_disabled_quick_notes');
    return true;
}

/**
 * Obtiene la lista unificada de áreas/departamentos disponibles en el sistema.
 * @param bool $only_enabled Si es true, retorna solo las áreas activas/habilitadas.
 */
function cm_get_available_departments($only_enabled = false) {
    $departments = array();

    // 1. Áreas registradas manualmente por el Superadmin
    $registry = get_option('cm_departments_registry', array());
    if (is_array($registry) && !empty($registry)) {
        foreach ($registry as $key => $dep) {
            $name    = is_array($dep) ? ($dep['name'] ?? $key) : $dep;
            $enabled = is_array($dep) ? (!isset($dep['enabled']) || $dep['enabled']) : true;
            if ($only_enabled && !$enabled) continue;

            $departments[$name] = array(
                'id'                 => is_array($dep) ? ($dep['id'] ?? sanitize_title($name)) : sanitize_title($name),
                'name'               => $name,
                'emails'             => is_array($dep) ? ($dep['emails'] ?? '') : '',
                'user_id'            => is_array($dep) ? ($dep['user_id'] ?? 0) : 0,
                'user'               => is_array($dep) ? ($dep['user'] ?? '') : '',
                'enabled'            => $enabled ? 1 : 0,
                'auto_reply_enabled' => is_array($dep) ? (!empty($dep['auto_reply_enabled']) ? 1 : 0) : 0,
                'auto_reply_delay'   => is_array($dep) ? (int)($dep['auto_reply_delay'] ?? 0) : 0,
                'auto_reply_msg'     => is_array($dep) ? ($dep['auto_reply_msg'] ?? '') : '',
                'auto_reply_status'  => is_array($dep) ? ($dep['auto_reply_status'] ?? 'en_proceso') : 'en_proceso',
            );
        }
    }

    // 2. Extraer áreas configuradas dentro de formularios ÚNICAMENTE si son campos de tipo 'department'
    $forms = function_exists('cm_get_all_forms') ? cm_get_all_forms() : array();
    $deleted_depts = get_option('cm_deleted_departments_list', array());
    if (!is_array($deleted_depts)) $deleted_depts = array();

    foreach ($forms as $f) {
        $schema = $f['schema'] ?? array();
        $fields = $schema['fields'] ?? array();
        foreach ($fields as $field) {
            // Estricto: NUNCA incluir campos de tipo 'select' o 'radio' como áreas de atención
            if (($field['type'] ?? '') === 'department') {
                $options = $field['options'] ?? array();
                foreach ($options as $opt) {
                    $opt_name = is_array($opt) ? ($opt['nombre'] ?? '') : $opt;
                    $opt_emails = is_array($opt) ? ($opt['email'] ?? '') : '';
                    if ($opt_name && !isset($departments[$opt_name]) && !in_array($opt_name, $deleted_depts, true)) {
                        $departments[$opt_name] = array(
                            'id'                 => sanitize_title($opt_name),
                            'name'               => $opt_name,
                            'emails'             => $opt_emails,
                            'user_id'            => 0,
                            'user'               => 'Administrador General',
                            'enabled'            => 1,
                            'auto_reply_enabled' => 0,
                            'auto_reply_delay'   => 0,
                            'auto_reply_msg'     => '',
                            'auto_reply_status'  => 'en_proceso',
                        );
                    }
                }
            }
        }
        // Área por defecto del formulario
        $default_area = $schema['settings']['default_area_name'] ?? '';
        if ($default_area && !isset($departments[$default_area]) && !in_array($default_area, $deleted_depts, true)) {
            $departments[$default_area] = array(
                'id'                 => sanitize_title($default_area),
                'name'               => $default_area,
                'emails'             => $schema['settings']['destination_emails'] ?? '',
                'user_id'            => 0,
                'user'               => 'Administrador General',
                'enabled'            => 1,
                'auto_reply_enabled' => 0,
                'auto_reply_delay'   => 0,
                'auto_reply_msg'     => '',
                'auto_reply_status'  => 'en_proceso',
            );
        }
    }

    // Si aún está vacío, proveer áreas estándar
    if (empty($departments)) {
        $defaults = array(
            'Dirección General'        => 'direccion@ejemplo.com',
            'Atención al Cliente'      => 'atencion@ejemplo.com',
            'Soporte Técnico'          => 'soporte@ejemplo.com',
            'Administración y Finanzas' => 'finanzas@ejemplo.com',
            'Currículum y Postulaciones' => 'rrhh@ejemplo.com',
            'Convivencia Escolar'      => 'convivencia@ejemplo.com',
        );
        foreach ($defaults as $d => $em) {
            $departments[$d] = array(
                'id'                 => sanitize_title($d),
                'name'               => $d,
                'emails'             => $em,
                'user_id'            => 0,
                'user'               => 'Administrador General',
                'enabled'            => 1,
                'auto_reply_enabled' => ($d === 'Currículum y Postulaciones') ? 1 : 0,
                'auto_reply_delay'   => 0,
                'auto_reply_msg'     => ($d === 'Currículum y Postulaciones') ? 'Documentos y antecedentes recibidos correctamente. Su currículum ha ingresado a nuestra área y se encuentra en etapa de evaluación y registro.' : '',
                'auto_reply_status'  => 'en_proceso',
            );
        }
    }

    return $departments;
}

/**
 * Guarda o actualiza un departamento en el registro del Superadmin.
 */
function cm_save_department_entry($dept_data) {
    $name = sanitize_text_field(trim($dept_data['name'] ?? ''));
    if (!$name) return false;

    $registry = cm_get_available_departments(false);
    $id = !empty($dept_data['id']) ? sanitize_title($dept_data['id']) : sanitize_title($name);

    $user_id   = !empty($dept_data['user_id']) ? absint($dept_data['user_id']) : 0;
    $user_name = sanitize_text_field($dept_data['user'] ?? '');
    if ($user_id > 0) {
        $u = get_userdata($user_id);
        if ($u) $user_name = $u->display_name;
    }

    $registry[$name] = array(
        'id'                 => $id,
        'name'               => $name,
        'emails'             => sanitize_text_field($dept_data['emails'] ?? ''),
        'user_id'            => $user_id,
        'user'               => $user_name ? $user_name : 'Administrador General',
        'enabled'            => isset($dept_data['enabled']) ? ($dept_data['enabled'] ? 1 : 0) : 1,
        'auto_reply_enabled' => !empty($dept_data['auto_reply_enabled']) ? 1 : 0,
        'auto_reply_delay'   => isset($dept_data['auto_reply_delay']) ? absint($dept_data['auto_reply_delay']) : 0,
        'auto_reply_msg'     => isset($dept_data['auto_reply_msg']) ? wp_kses_post($dept_data['auto_reply_msg']) : '',
        'auto_reply_status'  => !empty($dept_data['auto_reply_status']) ? sanitize_key($dept_data['auto_reply_status']) : 'en_proceso',
    );

    update_option('cm_departments_registry', $registry);

    $deleted_depts = get_option('cm_deleted_departments_list', array());
    if (is_array($deleted_depts) && in_array($name, $deleted_depts, true)) {
        $deleted_depts = array_values(array_diff($deleted_depts, array($name)));
        update_option('cm_deleted_departments_list', $deleted_depts);
    }

    return true;
}

/**
 * Dispara la respuesta automática configurada para un área si está habilitada.
 */
function cm_trigger_department_auto_reply($submission_id, $dept_name) {
    $submission_id = absint($submission_id);
    if (!$submission_id || !$dept_name) return false;

    $departments = cm_get_available_departments(false);
    if (!isset($departments[$dept_name]) || empty($departments[$dept_name]['auto_reply_enabled'])) {
        return false;
    }

    $dept_cfg = $departments[$dept_name];
    $delay    = absint($dept_cfg['auto_reply_delay'] ?? 0);

    if ($delay > 0) {
        // Programar ejecución diferida en minutos
        wp_schedule_single_event(time() + ($delay * 60), 'cm_execute_department_auto_reply', array($submission_id, $dept_name));
        return true;
    }

    // Ejecución inmediata
    return cm_execute_department_auto_reply_now($submission_id, $dept_cfg);
}

/**
 * Ejecuta la respuesta automática oficial y notifica al usuario.
 */
function cm_execute_department_auto_reply_now($submission_id, $dept_cfg) {
    $case = cm_get_submission_by_id($submission_id);
    if (!$case) return false;

    $reply_msg    = !empty($dept_cfg['auto_reply_msg']) ? $dept_cfg['auto_reply_msg'] : __('Documentos y antecedentes recibidos correctamente por el área.', 'contacto-multidestino');
    $reply_status = !empty($dept_cfg['auto_reply_status']) ? $dept_cfg['auto_reply_status'] : 'en_proceso';
    $author_name  = 'Área ' . $dept_cfg['name'] . ' (Respuesta Automática)';

    // Registrar en el historial del caso
    cm_add_case_update(array(
        'submission_id' => $submission_id,
        'ticket_code'   => $case->ticket_code,
        'author_name'   => $author_name,
        'status'        => $reply_status,
        'action_type'   => 'auto_reply',
        'note'          => $reply_msg,
        'is_public'     => 1,
        'notified_user' => 1,
    ));

    // Actualizar estado del caso principal
    global $wpdb;
    $wpdb->update(
        $wpdb->prefix . 'cm_form_submissions',
        array(
            'status'     => $reply_status,
            'updated_at' => current_time('mysql')
        ),
        array('id' => $submission_id),
        array('%s', '%s'),
        array('%d')
    );

    // Enviar correo al solicitante si tiene correo registrado
    if (!empty($case->sender_email) && is_email($case->sender_email)) {
        $site_name    = get_bloginfo('name');
        $from_email   = get_option('cm_smtp_from', get_option('admin_email'));
        $tracker_url  = cm_get_case_tracker_url($case->ticket_code);
        $user_subject = sprintf('[%s] Respuesta Oficial del Área %s — %s', $case->ticket_code, $dept_cfg['name'], $site_name);

        $body = '
        <!DOCTYPE html>
        <html lang="es">
        <head><meta charset="UTF-8"></head>
        <body style="font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, sans-serif; background-color: #f1f5f9; padding: 24px 15px; margin: 0;">
            <div style="max-width: 580px; margin: 0 auto; background: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.06); border: 1px solid #e2e8f0;">
                <div style="background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%); padding: 24px 28px; color: #ffffff;">
                    <div style="display:inline-block; background:rgba(255,255,255,0.15); padding:3px 10px; border-radius:20px; font-size:10.5px; font-weight:800; color:#c7d2fe; text-transform:uppercase; letter-spacing:0.05em;">
                        🏢 ' . esc_html($dept_cfg['name']) . '
                    </div>
                    <h2 style="margin: 8px 0 0 0; font-size: 19px; font-weight: 800; color: #ffffff;">Actualización de su Caso: ' . esc_html($case->ticket_code) . '</h2>
                </div>
                <div style="padding: 24px 28px;">
                    <p style="margin: 0 0 14px 0; font-size: 14px; color: #334155;">Estimado(a) <strong>' . esc_html($case->sender_name ? $case->sender_name : 'Usuario') . '</strong>:</p>
                    <div style="background: #f8fafc; border-left: 4px solid #0284c7; border-radius: 4px; padding: 14px 16px; font-size: 13.5px; color: #1e293b; line-height: 1.5; margin-bottom: 20px;">
                        ' . nl2br(esc_html($reply_msg)) . '
                    </div>
                    <div style="text-align: center; margin-bottom: 18px;">
                        <a href="' . esc_url($tracker_url) . '" target="_blank" style="display: inline-block; background: #0071e3; color: #ffffff; text-decoration: none; padding: 11px 24px; border-radius: 8px; font-size: 13.5px; font-weight: 700;">
                            🔍 Ver y Seguir Mi Expediente en Línea &rarr;
                        </a>
                    </div>
                </div>
                <div style="background: #f8fafc; padding: 14px 28px; border-top: 1px solid #e2e8f0; text-align: center; font-size: 11.5px; color: #94a3b8;">
                    Ingecodex Form • ' . esc_html($site_name) . '
                </div>
            </div>
        </body>
        </html>';

        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . esc_html($site_name) . ' <' . $from_email . '>'
        );
        wp_mail($case->sender_email, $user_subject, $body, $headers);
    }

    return true;
}

/**
 * Hook disparado por el cron diferido para respuesta automática.
 */
function cm_cron_handle_department_auto_reply($submission_id, $dept_name) {
    $departments = cm_get_available_departments(false);
    if (isset($departments[$dept_name])) {
        cm_execute_department_auto_reply_now($submission_id, $departments[$dept_name]);
    }
}
add_action('cm_execute_department_auto_reply', 'cm_cron_handle_department_auto_reply', 10, 2);

/**
 * Alterna el estado de un departamento entre Habilitado y Deshabilitado.
 */
function cm_toggle_department_status($dept_name) {
    $registry = cm_get_available_departments(false);
    if (!isset($registry[$dept_name])) return false;

    $registry[$dept_name]['enabled'] = empty($registry[$dept_name]['enabled']) ? 1 : 0;
    update_option('cm_departments_registry', $registry);
    return $registry[$dept_name]['enabled'];
}

/**
 * Elimina un departamento del registro.
 */
function cm_delete_department_entry($dept_name) {
    $registry = cm_get_available_departments(false);
    if (isset($registry[$dept_name])) {
        unset($registry[$dept_name]);
        update_option('cm_departments_registry', $registry);

        $deleted_depts = get_option('cm_deleted_departments_list', array());
        if (!is_array($deleted_depts)) $deleted_depts = array();
        if (!in_array($dept_name, $deleted_depts, true)) {
            $deleted_depts[] = $dept_name;
            update_option('cm_deleted_departments_list', $deleted_depts);
        }
        return true;
    }
    return false;
}

/**
 * Suspende o activa un usuario de WordPress.
 */
function cm_toggle_user_suspension($user_id) {
    $user_id = absint($user_id);
    if (!$user_id) return false;

    $is_suspended = get_user_meta($user_id, 'cm_user_suspended', true);
    if ($is_suspended) {
        delete_user_meta($user_id, 'cm_user_suspended');
        return 'active';
    } else {
        update_user_meta($user_id, 'cm_user_suspended', 1);
        return 'suspended';
    }
}

/**
 * Bloquea el inicio de sesión para usuarios suspendidos.
 */
function cm_check_user_suspension_on_login($user, $username, $password) {
    if ($user instanceof WP_User) {
        $is_suspended = get_user_meta($user->ID, 'cm_user_suspended', true);
        if ($is_suspended) {
            return new WP_Error('cm_account_suspended', __('⚠️ Tu cuenta ha sido suspendida por el Administrador. Contacta a la dirección del sistema.', 'contacto-multidestino'));
        }
    }
    return $user;
}
add_filter('authenticate', 'cm_check_user_suspension_on_login', 30, 3);


/**
 * Deriva un caso de un departamento a otro y registra el evento en el historial.
 */
function cm_reassign_case_department($submission_id, $new_department, $reason = '', $author_name = 'Área Responsable', $notify_new_area = true, $notify_user = false) {
    global $wpdb;
    $submission_id = absint($submission_id);
    $case = cm_get_submission_by_id($submission_id);
    if (!$case) return false;

    $old_department = $case->department ? $case->department : 'Sin Área';
    $new_department = sanitize_text_field(trim($new_department));
    if (!$new_department || $old_department === $new_department) return false;

    $now = current_time('mysql');

    // Actualizar departamento en el registro principal
    $updated = $wpdb->update(
        $wpdb->prefix . 'cm_form_submissions',
        array(
            'department' => $new_department,
            'updated_at' => $now,
        ),
        array('id' => $submission_id),
        array('%s', '%s'),
        array('%d')
    );

    if ($updated !== false) {
        $note_text = sprintf(__('🔄 Caso derivado de "%s" a "%s".', 'contacto-multidestino'), $old_department, $new_department);
        if (!empty($reason)) {
            $note_text .= ' ' . sprintf(__('Motivo: %s', 'contacto-multidestino'), $reason);
        }

        // Registrar evento en la línea de tiempo
        cm_add_case_update(array(
            'submission_id' => $submission_id,
            'ticket_code'   => $case->ticket_code,
            'author_name'   => $author_name,
            'status'        => $case->status,
            'action_type'   => 'transfer',
            'note'          => $note_text,
            'is_public'     => 1,
            'notified_user' => $notify_user ? 1 : 0,
        ));

        // Enviar notificación a la nueva área si está configurado
        if ($notify_new_area) {
            $all_deps = cm_get_available_departments();
            $target_emails = !empty($all_deps[$new_department]['emails']) ? $all_deps[$new_department]['emails'] : get_option('admin_email');
            $parsed_emails = array_values(array_filter(array_map('trim', explode(',', $target_emails)), 'is_email'));

            if (!empty($parsed_emails)) {
                $site_name = get_bloginfo('name');
                $subject   = sprintf('[%s] 🔄 Caso Derivado a su Área: %s — %s', $case->ticket_code, $case->sender_name, $new_department);

                $submitted_data = array();
                if (!empty($case->submitted_data)) {
                    $decoded = json_decode($case->submitted_data, true);
                    if (is_array($decoded)) $submitted_data = $decoded;
                }

                $body = cm_build_executive_email_html(array(
                    'is_confirmation'     => false,
                    'ticket_code'         => $case->ticket_code,
                    'site_name'           => $site_name,
                    'site_url'            => home_url(),
                    'sender_name'         => $case->sender_name,
                    'sender_email'        => $case->sender_email,
                    'nombre_departamento' => $new_department . ' (Derivado desde ' . $old_department . ')',
                    'submitted_data'      => $submitted_data,
                ));

                $from_email = get_option('cm_smtp_from', get_option('admin_email'));
                $headers = array(
                    'Content-Type: text/html; charset=UTF-8',
                    'From: ' . esc_html($site_name) . ' <' . $from_email . '>'
                );

                wp_mail($parsed_emails, $subject, $body, $headers);
            }
        }

        return true;
    }

    return false;
}

/**
 * Envía un caso a la papelera (Soft Delete) y registra el evento en el historial.
 * Nunca se borra físicamente de la base de datos para permitir su recuperación.
 */
function cm_soft_delete_submission($id, $author_name = '') {
    global $wpdb;
    $table = $wpdb->prefix . 'cm_form_submissions';
    $id = absint($id);
    if (!$id) return false;

    cm_ensure_soft_delete_columns();

    $case = cm_get_submission_by_id($id);
    if (!$case) return false;

    if (empty($author_name)) {
        $current_user = wp_get_current_user();
        $author_name = ($current_user && $current_user->display_name) ? $current_user->display_name : 'Administrador';
    }

    $now = current_time('mysql');

    $res = $wpdb->update(
        $table,
        array(
            'is_deleted'  => 1,
            'deleted_at'  => $now,
            'deleted_by'  => $author_name,
            'updated_at'  => $now,
        ),
        array('id' => $id),
        array('%d', '%s', '%s', '%s'),
        array('%d')
    );

    if ($res !== false) {
        // Registrar en el historial de trazabilidad del caso
        cm_add_case_update(array(
            'submission_id' => $id,
            'ticket_code'   => $case->ticket_code,
            'author_name'   => $author_name,
            'status'        => $case->status,
            'action_type'   => 'deleted',
            'note'          => sprintf(__('🗑️ Caso enviado a la papelera por %s el %s.', 'contacto-multidestino'), $author_name, date_i18n('d/m/Y - H:i \h\r\s', strtotime($now))),
            'is_public'     => 0,
            'notified_user' => 0,
        ));
        return true;
    }

    return false;
}

/**
 * Elimina un caso (redireccionado a soft-delete).
 */
function cm_delete_submission($id, $author_name = '') {
    return cm_soft_delete_submission($id, $author_name);
}

/**
 * Restaura un caso desde la papelera (Solo Super Admin) y registra el evento en el historial.
 */
function cm_restore_submission($id, $author_name = '') {
    global $wpdb;
    $table = $wpdb->prefix . 'cm_form_submissions';
    $id = absint($id);
    if (!$id) return false;

    cm_ensure_soft_delete_columns();

    $case = cm_get_submission_by_id($id);
    if (!$case) return false;

    if (empty($author_name)) {
        $current_user = wp_get_current_user();
        $author_name = ($current_user && $current_user->display_name) ? $current_user->display_name : 'Super Admin';
    }

    $now = current_time('mysql');

    $res = $wpdb->update(
        $table,
        array(
            'is_deleted'   => 0,
            'restored_at'  => $now,
            'restored_by'  => $author_name,
            'updated_at'   => $now,
        ),
        array('id' => $id),
        array('%d', '%s', '%s', '%s'),
        array('%d')
    );

    if ($res !== false) {
        // Registrar en el historial de trazabilidad del caso
        cm_add_case_update(array(
            'submission_id' => $id,
            'ticket_code'   => $case->ticket_code,
            'author_name'   => $author_name,
            'status'        => $case->status,
            'action_type'   => 'restored',
            'note'          => sprintf(__('♻️ Caso recuperado y restaurado desde la papelera por %s el %s.', 'contacto-multidestino'), $author_name, date_i18n('d/m/Y - H:i \h\r\s', strtotime($now))),
            'is_public'     => 0,
            'notified_user' => 0,
        ));
        return true;
    }

    return false;
}

/**
 * AJAX para restablecer la contraseña de un usuario desde el panel de áreas.
 */
function cm_ajax_admin_reset_user_password() {
    check_ajax_referer('cm_contacto_nonce', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Permiso denegado.', 'contacto-multidestino')));
    }

    $user_id      = isset($_POST['user_id']) ? absint($_POST['user_id']) : 0;
    $new_password = isset($_POST['new_password']) ? trim($_POST['new_password']) : '';

    if (!$user_id) {
        wp_send_json_error(array('message' => __('ID de usuario no válido.', 'contacto-multidestino')));
    }

    if (empty($new_password) || strlen($new_password) < 6) {
        wp_send_json_error(array('message' => __('La contraseña debe tener al menos 6 caracteres.', 'contacto-multidestino')));
    }

    $user = get_userdata($user_id);
    if (!$user) {
        wp_send_json_error(array('message' => __('El usuario no existe.', 'contacto-multidestino')));
    }

    wp_set_password($new_password, $user_id);

    wp_send_json_success(array(
        'message'  => sprintf(__('Contraseña actualizada exitosamente para el usuario %s.', 'contacto-multidestino'), $user->user_login),
        'username' => $user->user_login,
    ));
}
add_action('wp_ajax_cm_admin_reset_user_password', 'cm_ajax_admin_reset_user_password');

/**
 * Comprueba si un caso tiene una solicitud activa de documentos pendientes y retorna su título/instrucción.
 */
function cm_get_case_pending_doc_request($history = array(), $case_status = '') {
    if ($case_status === 'resuelto' || $case_status === 'cerrado') {
        return null;
    }

    if (!empty($history)) {
        // Recorrer del más reciente al más antiguo
        $reversed = array_reverse($history);
        foreach ($reversed as $h) {
            if ($h->action_type === 'applicant_attachment') {
                // El usuario ya respondió y subió antecedentes
                return null;
            }
            if ($h->action_type === 'doc_request') {
                $title = __('Adjuntar Documentación Solicitada', 'contacto-multidestino');
                if (preg_match('/\[REQ_DOC:\s*(.*?)\]/i', $h->note, $matches)) {
                    $title = trim($matches[1]);
                }
                return array(
                    'active'      => true,
                    'title'       => $title,
                    'author_name' => $h->author_name,
                    'created_at'  => $h->created_at,
                    'note'        => trim(preg_replace('/\[REQ_DOC:\s*.*?\]/i', '', $h->note)),
                );
            }
        }
    }

    if ($case_status === 'pendiente_usuario') {
        return array(
            'active'      => true,
            'title'       => __('Adjuntar Documentación o Antecedentes Requeridos', 'contacto-multidestino'),
            'author_name' => __('Área Responsable', 'contacto-multidestino'),
            'created_at'  => '',
            'note'        => '',
        );
    }

    return null;
}

/**
 * Extrae y estructura todos los archivos adjuntos presentes en el historial o datos del formulario.
 */
function cm_extract_case_attachments($history = array(), $submitted_data = array(), $raw_attachments = '') {
    $attachments = array();
    $valid_exts  = array('jpg', 'jpeg', 'png', 'svg', 'bmp', 'webp', 'gif', 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'zip', 'txt', 'csv', 'ppt', 'pptx');
    $img_exts    = array('jpg', 'jpeg', 'png', 'svg', 'bmp', 'webp', 'gif');

    // 1. Extraer desde notas de historial ($history)
    if (!empty($history)) {
        foreach ($history as $h) {
            $note = $h->note;
            if (preg_match_all('/<a[^>]+href=[\'"]([^\'"]+)[\'"][^>]*>(.*?)<\/a>/is', $note, $matches, PREG_SET_ORDER)) {
                foreach ($matches as $m) {
                    $url = $m[1];
                    $label = strip_tags($m[2]);
                    $path_info = pathinfo(parse_url($url, PHP_URL_PATH));
                    $ext = strtolower($path_info['extension'] ?? '');
                    if (in_array($ext, $valid_exts)) {
                        $cleaned_name = trim(str_replace(array('📄', '🖼️', '📑', 'Descargar', 'Ver'), '', $label));
                        if (empty($cleaned_name)) {
                            $cleaned_name = basename(parse_url($url, PHP_URL_PATH));
                        }
                        $attachments[] = array(
                            'url'         => $url,
                            'name'        => $cleaned_name,
                            'ext'         => $ext,
                            'is_image'    => in_array($ext, $img_exts),
                            'author'      => $h->author_name,
                            'date'        => date_i18n('d/m/Y H:i', strtotime($h->created_at)),
                            'action_type' => $h->action_type,
                        );
                    }
                }
            }
        }
    }

    // 2. Extraer desde campos del formulario ($submitted_data)
    if (!empty($submitted_data)) {
        foreach ($submitted_data as $label => $val) {
            if (is_string($val)) {
                $val_trimmed = trim($val);
                if (filter_var($val_trimmed, FILTER_VALIDATE_URL) || preg_match('/https?:\/\/[^\s<"\']+/i', $val_trimmed, $url_match)) {
                    $url = filter_var($val_trimmed, FILTER_VALIDATE_URL) ? $val_trimmed : $url_match[0];
                    $path_info = pathinfo(parse_url($url, PHP_URL_PATH));
                    $ext = strtolower($path_info['extension'] ?? '');
                    if (in_array($ext, $valid_exts)) {
                        $attachments[] = array(
                            'url'         => $url,
                            'name'        => basename(parse_url($url, PHP_URL_PATH)),
                            'ext'         => $ext,
                            'is_image'    => in_array($ext, $img_exts),
                            'author'      => 'Solicitante (' . $label . ')',
                            'date'        => '',
                            'action_type' => 'initial_upload',
                        );
                    }
                }
            }
        }
    }

    // 3. Extraer desde columna attachments de la BD ($raw_attachments)
    if (!empty($raw_attachments)) {
        $upload_dir = wp_upload_dir();
        $att_list = is_array($raw_attachments) ? $raw_attachments : json_decode($raw_attachments, true);
        if (!empty($att_list) && is_array($att_list)) {
            foreach ($att_list as $fpath) {
                if (is_string($fpath) && !empty($fpath)) {
                    $url = filter_var($fpath, FILTER_VALIDATE_URL) ? $fpath : str_replace($upload_dir['basedir'], $upload_dir['baseurl'], $fpath);
                    $path_info = pathinfo(parse_url($url, PHP_URL_PATH));
                    $ext = strtolower($path_info['extension'] ?? '');
                    if (in_array($ext, $valid_exts)) {
                        $already = false;
                        foreach ($attachments as $existing) {
                            if ($existing['url'] === $url) {
                                $already = true;
                                break;
                            }
                        }
                        if (!$already) {
                            $attachments[] = array(
                                'url'         => $url,
                                'name'        => basename(parse_url($url, PHP_URL_PATH)),
                                'ext'         => $ext,
                                'is_image'    => in_array($ext, $img_exts),
                                'author'      => 'Solicitante (Adjunto)',
                                'date'        => '',
                                'action_type' => 'initial_upload',
                            );
                        }
                    }
                }
            }
        }
    }

    return $attachments;
}

/**
 * Renderiza una tarjeta interactiva estilo Hoja de Documento (Sheet Card) con miniatura y visualizador.
 */
function cm_render_attachment_sheet_card($att) {
    $is_img = !empty($att['is_image']);
    $url    = esc_url($att['url']);
    $name   = esc_html($att['name'] ? $att['name'] : basename($att['url']));
    $ext    = strtoupper($att['ext']);
    $author = esc_html($att['author'] ? $att['author'] : 'Adjunto');
    $date   = esc_html($att['date'] ? $att['date'] : '');

    ob_start();
    ?>
    <div class="cm-doc-sheet-card" onclick="cmOpenDocumentPreview('<?php echo esc_js($url); ?>', '<?php echo esc_js($name); ?>', <?php echo $is_img ? 'true' : 'false'; ?>)" title="<?php esc_attr_e('Clic para ver documento en tamaño completo', 'contacto-multidestino'); ?>">
        <div class="cm-doc-sheet-corner"></div>
        <div class="cm-doc-sheet-preview">
            <?php if ($is_img) : ?>
                <img src="<?php echo $url; ?>" alt="<?php echo $name; ?>" class="cm-doc-sheet-img" loading="lazy" />
                <div class="cm-doc-sheet-zoom-badge">🔍 <?php _e('Ver Hoja', 'contacto-multidestino'); ?></div>
            <?php else : ?>
                <div class="cm-doc-sheet-pdf-view">
                    <span class="cm-doc-sheet-pdf-icon">📑</span>
                    <span class="cm-doc-sheet-ext-tag"><?php echo $ext; ?></span>
                    <div class="cm-doc-sheet-lines">
                        <div class="cm-doc-line"></div>
                        <div class="cm-doc-line cm-line-short"></div>
                        <div class="cm-doc-line"></div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <div class="cm-doc-sheet-info">
            <div class="cm-doc-sheet-name" title="<?php echo $name; ?>"><?php echo $name; ?></div>
            <div class="cm-doc-sheet-meta">
                <span>👤 <?php echo $author; ?></span>
                <?php if ($date) : ?><span>• <?php echo $date; ?></span><?php endif; ?>
            </div>
            <div class="cm-doc-sheet-foot">
                <span class="cm-doc-badge-pill"><?php echo $ext; ?></span>
                <span class="cm-doc-action-label">👁️ <?php _e('Abrir', 'contacto-multidestino'); ?></span>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * Agrega la sección de Gestión de Áreas y Permisos de Ingecodex Form en el perfil de usuario de WordPress.
 */
function cm_add_custom_user_profile_fields($user) {
    if (!current_user_can('manage_options')) {
        return;
    }

    $departments    = cm_get_available_departments(true);
    $user_deps      = cm_get_user_assigned_departments($user->ID);
    $user_profile   = get_user_meta($user->ID, 'cm_user_profile', true);
    if (!$user_profile) {
        $user_profile = user_can($user->ID, 'administrator') ? 'director' : 'area_manager';
    }
    $allow_reassign = get_user_meta($user->ID, 'cm_allow_reassign', true);
    $can_reassign   = ($allow_reassign !== '0');
    ?>
    <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:14px; padding:22px 24px; margin-top:24px; max-width:850px; box-shadow:0 4px 16px rgba(0,0,0,0.04);">
        <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:16px; border-bottom:1px solid #f1f5f9; padding-bottom:12px; flex-wrap:wrap; gap:10px;">
            <div style="display:flex; align-items:center; gap:10px;">
                <span style="font-size:24px;">🏢</span>
                <div>
                    <h3 style="margin:0; font-size:16px; font-weight:800; color:#0f172a;">
                        <?php _e('Ingecodex Form — Asignación de Áreas y Permisos Institucionales', 'contacto-multidestino'); ?>
                    </h3>
                    <p style="margin:2px 0 0 0; font-size:12px; color:#64748b;">
                        <?php _e('Define el rol institucional, las áreas que puede ver y administrar, y sus permisos de derivación.', 'contacto-multidestino'); ?>
                    </p>
                </div>
            </div>
            <a href="<?php echo esc_url(admin_url('admin.php?page=cm-form-submissions&tab=departments')); ?>" class="button button-secondary" style="font-size:12px; font-weight:600;">
                📊 <?php _e('Ver Tablero de Áreas &rarr;', 'contacto-multidestino'); ?>
            </a>
        </div>

        <table class="form-table" role="presentation" style="margin:0;">
            <tr>
                <th scope="row" style="width:220px; padding-top:10px;">
                    <label for="cm_user_profile_select"><strong><?php _e('Perfil / Nivel Institucional:', 'contacto-multidestino'); ?></strong></label>
                </th>
                <td style="padding-top:10px;">
                    <select name="cm_user_profile" id="cm_user_profile_select" style="min-width:340px; font-weight:600; height:34px;" onchange="cmToggleWpProfileDeptWrap(this.value)">
                        <option value="area_manager" <?php selected($user_profile, 'area_manager'); ?>>🏢 <?php _e('Encargado de Área (Atención de áreas específicas)', 'contacto-multidestino'); ?></option>
                        <option value="moderator" <?php selected($user_profile, 'moderator'); ?>>🛡️ <?php _e('Subdirector / Moderador (Multi-Área: 2 o más departamentos)', 'contacto-multidestino'); ?></option>
                        <option value="director" <?php selected($user_profile, 'director'); ?>>👑 <?php _e('Director / Administrador (Acceso Global a Todo el Sistema)', 'contacto-multidestino'); ?></option>
                    </select>
                    <p class="description" style="margin-top:5px; font-size:12px; color:#64748b;">
                        <?php _e('Los directores y administradores tienen acceso global e irrestricto a todos los expedientes.', 'contacto-multidestino'); ?>
                    </p>
                </td>
            </tr>

            <tr id="cm_wp_profile_dept_row" style="<?php echo ($user_profile === 'director') ? 'display:none;' : ''; ?>">
                <th scope="row" style="padding-top:14px; vertical-align:top;">
                    <label><strong><?php _e('Áreas Asignadas (Multi-Área):', 'contacto-multidestino'); ?></strong></label>
                </th>
                <td style="padding-top:14px;">
                    <div style="display:flex; gap:8px; margin-bottom:8px;">
                        <button type="button" class="button button-small" onclick="jQuery('.cm-wp-dept-cb').prop('checked', true);">
                            <?php _e('Marcar Todas', 'contacto-multidestino'); ?>
                        </button>
                        <button type="button" class="button button-small" onclick="jQuery('.cm-wp-dept-cb').prop('checked', false);">
                            <?php _e('Desmarcar', 'contacto-multidestino'); ?>
                        </button>
                    </div>
                    <div style="max-height:180px; overflow-y:auto; background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:10px 14px; max-width:540px;">
                        <?php if (!empty($departments)) : ?>
                            <?php foreach ($departments as $dkey => $dinfo) : 
                                $dname = is_array($dinfo) ? ($dinfo['name'] ?? $dkey) : $dinfo;
                                $is_checked = in_array($dname, $user_deps);
                            ?>
                                <label style="display:flex; align-items:center; gap:8px; padding:5px 0; border-bottom:1px solid #f1f5f9; font-size:12.5px; cursor:pointer;">
                                    <input type="checkbox" name="cm_assigned_departments[]" class="cm-wp-dept-cb" value="<?php echo esc_attr($dname); ?>" <?php checked($is_checked); ?> style="accent-color:#0284c7;" />
                                    <span>🏢 <strong><?php echo esc_html($dname); ?></strong></span>
                                </label>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <p style="color:#94a3b8; font-size:12px; margin:0;"><?php _e('No hay departamentos registrados aún.', 'contacto-multidestino'); ?></p>
                        <?php endif; ?>
                    </div>
                    <p class="description" style="margin-top:5px; font-size:12px; color:#64748b;">
                        <?php _e('Marca las áreas a las que este usuario tendrá acceso exclusivo para ver y atender expedientes.', 'contacto-multidestino'); ?>
                    </p>
                </td>
            </tr>

            <tr>
                <th scope="row" style="padding-top:14px; vertical-align:top;">
                    <label><strong><?php _e('Permisos de Derivación:', 'contacto-multidestino'); ?></strong></label>
                </th>
                <td style="padding-top:14px;">
                    <label style="display:inline-flex; align-items:center; gap:8px; cursor:pointer; font-weight:700; color:#1e293b;">
                        <input type="checkbox" name="cm_allow_reassign" value="1" <?php checked($can_reassign); ?> style="accent-color:#0284c7;" />
                        <span>🔄 <?php _e('Permitir a este usuario derivar casos a otros departamentos', 'contacto-multidestino'); ?></span>
                    </label>
                    <p class="description" style="margin-top:4px; font-size:12px; color:#64748b;">
                        <?php _e('Si está desmarcado, el usuario solo podrá gestionar las solicitudes dentro de sus áreas asignadas sin derivar a otras.', 'contacto-multidestino'); ?>
                    </p>
                </td>
            </tr>
        </table>
        <script>
        function cmToggleWpProfileDeptWrap(role) {
            if (role === 'director') {
                jQuery('#cm_wp_profile_dept_row').slideUp(120);
            } else {
                jQuery('#cm_wp_profile_dept_row').slideDown(120);
            }
        }
        </script>
    </div>
    <?php
}
add_action('show_user_profile', 'cm_add_custom_user_profile_fields');
add_action('edit_user_profile', 'cm_add_custom_user_profile_fields');

/**
 * Guarda los campos personalizados del perfil de usuario en WordPress.
 */
function cm_save_custom_user_profile_fields($user_id) {
    if (!current_user_can('manage_options')) {
        return false;
    }

    if (isset($_POST['cm_user_profile'])) {
        $profile = sanitize_key($_POST['cm_user_profile']);
        update_user_meta($user_id, 'cm_user_profile', $profile);
    }

    $departments = isset($_POST['cm_assigned_departments']) ? (array)$_POST['cm_assigned_departments'] : array();
    cm_set_user_assigned_departments($user_id, $departments);

    $allow_reassign = !empty($_POST['cm_allow_reassign']) ? '1' : '0';
    update_user_meta($user_id, 'cm_allow_reassign', $allow_reassign);
}
add_action('personal_options_update', 'cm_save_custom_user_profile_fields');
add_action('edit_user_profile_update', 'cm_save_custom_user_profile_fields');

/**
 * Log an audit action for a case.
 */
function cm_log_audit_action($submission_id, $ticket_code, $action, $details = '') {
    global $wpdb;
    $table = $wpdb->prefix . 'cm_case_audit_logs';

    $user_id = get_current_user_id();
    $user_name = 'Sistema';
    if ($user_id) {
        $user = get_userdata($user_id);
        $user_name = $user ? $user->display_name : 'Usuario Desconocido';
    }

    $ip_address = $_SERVER['REMOTE_ADDR'] ?? '';

    $wpdb->insert(
        $table,
        array(
            'submission_id' => $submission_id,
            'ticket_code'   => $ticket_code,
            'user_id'       => $user_id,
            'user_name'     => $user_name,
            'action'        => $action,
            'details'       => is_array($details) ? json_encode($details) : $details,
            'ip_address'    => $ip_address,
            'created_at'    => current_time('mysql')
        ),
        array('%d', '%s', '%d', '%s', '%s', '%s', '%s', '%s')
    );
}

/**
 * Retrieve audit logs for a specific case.
 */
function cm_get_audit_logs($submission_id) {
    global $wpdb;
    $table = $wpdb->prefix . 'cm_case_audit_logs';
    return $wpdb->get_results(
        $wpdb->prepare("SELECT * FROM $table WHERE submission_id = %d ORDER BY created_at DESC", $submission_id)
    );
}

/**
 * Retrieve paginated audit logs with search and action filters.
 */
function cm_get_all_audit_logs($args = array()) {
    global $wpdb;
    $table = $wpdb->prefix . 'cm_case_audit_logs';

    $defaults = array(
        'search'        => '',
        'action'        => '',
        'limit'         => 25,
        'offset'        => 0,
        'orderby'       => 'created_at',
        'order'         => 'DESC',
    );
    $r = wp_parse_args($args, $defaults);

    $where = "1=1";
    if (!empty($r['search'])) {
        $like = '%' . $wpdb->esc_like($r['search']) . '%';
        $where .= $wpdb->prepare(" AND (ticket_code LIKE %s OR user_name LIKE %s OR details LIKE %s OR ip_address LIKE %s)", $like, $like, $like, $like);
    }
    if (!empty($r['action'])) {
        $where .= $wpdb->prepare(" AND action = %s", $r['action']);
    }

    $orderby = in_array(strtolower($r['orderby']), array('created_at', 'id', 'action', 'ticket_code')) ? $r['orderby'] : 'created_at';
    $order   = strtoupper($r['order']) === 'ASC' ? 'ASC' : 'DESC';
    $limit   = absint($r['limit']);
    $offset  = absint($r['offset']);

    $total = (int)$wpdb->get_var("SELECT COUNT(*) FROM $table WHERE $where");
    $items = $wpdb->get_results("SELECT * FROM $table WHERE $where ORDER BY $orderby $order LIMIT $limit OFFSET $offset");

    return array(
        'total' => $total,
        'items' => $items ? $items : array(),
    );
}

/**
 * AJAX: Registrar eventos de auditoría desde el cliente (vistas de adjuntos, clics en enlaces, etc.)
 */
function cm_ajax_log_client_audit_event() {
    $nonce = $_POST['nonce'] ?? '';
    if (!wp_verify_nonce($nonce, 'cm_contacto_nonce') && !check_ajax_referer('cm_contacto_nonce', 'nonce', false)) {
        if (!is_user_logged_in() || (!current_user_can('edit_posts') && !current_user_can('manage_options'))) {
            wp_send_json_error(array('message' => 'No autorizado'));
        }
    }
    $case_id = absint($_POST['case_id'] ?? 0);
    $ticket  = sanitize_text_field($_POST['ticket_code'] ?? 'SISTEMA');
    $action  = sanitize_key($_POST['audit_action'] ?? 'viewed');
    $details = sanitize_text_field($_POST['details'] ?? '');

    if (function_exists('cm_log_audit_action')) {
        cm_log_audit_action($case_id, $ticket, $action, $details);
    }
    wp_send_json_success();
}
add_action('wp_ajax_cm_log_client_audit_event', 'cm_ajax_log_client_audit_event');

/**
 * Scan a file with ClamAV if enabled.
 * Returns true if the file is clean or if scanning is disabled/unavailable.
 * Returns false if a virus is detected.
 */
function cm_scan_file_with_clamav($file_path) {
    if (get_option('cm_enable_clamav', 'no') !== 'yes') {
        return true;
    }
    
    $clamav_path = get_option('cm_clamav_path', '/usr/bin/clamscan');
    
    if (!function_exists('exec') || !is_executable($clamav_path)) {
        error_log("ClamAV is enabled but exec() is disabled or clamscan binary not found/executable at: $clamav_path");
        return true; 
    }

    $cmd = escapeshellcmd($clamav_path) . ' ' . escapeshellarg($file_path);
    @exec($cmd, $output, $return_var);

    if ($return_var === 1) {
        // Virus detected
        return false;
    }
    
    return true;
}

/**
 * Loguear en la auditoría cuando un usuario inicia sesión en WordPress.
 */
function cm_log_wp_login_audit($user_login, $user) {
    if (function_exists('cm_log_audit_action') && (in_array('administrator', (array)$user->roles) || in_array('editor', (array)$user->roles) || in_array('author', (array)$user->roles))) {
        // Para que cm_log_audit_action asigne correctamente el nombre, simulamos el user_id
        // (Aunque wp_login ocurre después de autenticar, a veces get_current_user_id() falla porque el contexto no está completo, pero wp_set_current_user ya debió ocurrir)
        cm_log_audit_action(0, 'SISTEMA', 'login', "El usuario {$user_login} ha iniciado sesión en la plataforma WordPress.");
    }
}
add_action('wp_login', 'cm_log_wp_login_audit', 10, 2);

/**
 * Handle Audit Print Export
 */
add_action('init', 'cm_handle_audit_print_export');
function cm_handle_audit_print_export() {
    if (isset($_GET['print_audit']) && $_GET['print_audit'] == '1') {
        if (!current_user_can('manage_options') && !current_user_can('edit_posts') && !current_user_can('administrator') && !current_user_can('editor')) {
            wp_die('No tienes permisos para ver este reporte de auditoría.');
        }

        global $wpdb;
        $table_audit = $wpdb->prefix . 'cm_case_audit_logs';

        $where = "1=1";
        $type = isset($_GET['type']) ? sanitize_text_field($_GET['type']) : 'all';
        $case_id = isset($_GET['case']) ? sanitize_text_field($_GET['case']) : '';
        $date_from = isset($_GET['date_from']) ? sanitize_text_field($_GET['date_from']) : '';
        $date_to = isset($_GET['date_to']) ? sanitize_text_field($_GET['date_to']) : '';

        if ($type === 'case' && !empty($case_id)) {
            $where .= $wpdb->prepare(" AND ticket_code = %s", $case_id);
        } elseif ($type === 'date' && !empty($date_from) && !empty($date_to)) {
            $where .= $wpdb->prepare(" AND DATE(created_at) >= %s AND DATE(created_at) <= %s", $date_from, $date_to);
        }

        $logs = $wpdb->get_results("SELECT * FROM $table_audit WHERE $where ORDER BY created_at DESC LIMIT 2000");

        $user_info = wp_get_current_user();
        ?>
        <!DOCTYPE html>
        <html lang="es">
        <head>
            <meta charset="UTF-8">
            <title>Reporte de Auditoría - Ingecodex</title>
            <style>
                body { font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; font-size: 12px; color: #333; margin: 40px; }
                h1 { font-size: 20px; color: #6b21a8; margin-bottom: 5px; }
                p.meta { font-size: 11px; color: #666; margin-top: 0; margin-bottom: 20px; }
                table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                th { background: #faf5ff; color: #6b21a8; text-align: left; padding: 10px; font-size: 11px; text-transform: uppercase; border-bottom: 2px solid #e9d5ff; }
                td { padding: 8px 10px; border-bottom: 1px solid #eee; vertical-align: top; }
                .action-type { font-weight: bold; color: #7e22ce; }
                @media print {
                    body { margin: 0; }
                    button.no-print { display: none; }
                }
            </style>
        </head>
        <body>
            <button class="no-print" onclick="window.print()" style="margin-bottom: 20px; padding: 8px 16px; background: #6b21a8; color: #fff; border: none; border-radius: 4px; cursor: pointer;">🖨️ Imprimir Ahora</button>
            <h1>Reporte de Auditoría del Sistema</h1>
            <p class="meta">
                Generado el <?php echo date_i18n('d/m/Y H:i'); ?> por <?php echo esc_html($user_info->display_name); ?><br>
                Filtro aplicado: <?php 
                    if ($type === 'case') echo "Caso Específico ($case_id)"; 
                    elseif ($type === 'date') echo "Rango de Fechas ($date_from a $date_to)";
                    else echo "Todo el historial"; 
                ?>
            </p>

            <table>
                <thead>
                    <tr>
                        <th style="width: 15%">Fecha/Hora</th>
                        <th style="width: 20%">Caso / Usuario</th>
                        <th style="width: 50%">Acción / Detalles</th>
                        <th style="width: 15%">IP</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($logs)): foreach ($logs as $log): ?>
                        <tr>
                            <td><?php echo date_i18n('d/m/Y', strtotime($log->created_at)); ?><br><span style="color:#888"><?php echo date_i18n('H:i:s', strtotime($log->created_at)); ?></span></td>
                            <td><strong><?php echo esc_html($log->ticket_code ? $log->ticket_code : 'SISTEMA'); ?></strong><br>👤 <?php echo esc_html($log->user_name); ?></td>
                            <td><span class="action-type">[<?php echo esc_html(strtoupper($log->action)); ?>]</span> <?php echo wp_kses_post($log->details); ?></td>
                            <td><?php echo esc_html($log->ip_address); ?></td>
                        </tr>
                    <?php endforeach; else: ?>
                        <tr><td colspan="4" style="text-align:center; padding:20px;">No se encontraron registros.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
            
            <script>
                window.onload = function() {
                    window.print();
                };
            </script>
        </body>
        </html>
        <?php
        exit;
    }
}
