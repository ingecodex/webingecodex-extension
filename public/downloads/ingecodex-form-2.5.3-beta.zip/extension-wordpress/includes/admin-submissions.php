<?php
/**
 * Ingecodex Form — Bandeja de Entradas y Gestión de Casos (Estilo Apple / Office Pro)
 * Panel de administración para revisar envíos de formularios, derivar entre áreas, gestionar encargados, habilitar/deshabilitar departamentos y suspender usuarios.
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Genera la URL de una pestaña del panel de casos.
 * Detecta si estamos en el Portal Standalone y genera URLs apropiadas.
 *
 * @param string $tab  Nombre de la pestaña (dashboard, inbox, departments, trash).
 * @return string      URL escapada lista para HTML.
 */
function cm_get_view_tab_url($tab = 'inbox') {
    $is_standalone = (isset($_GET['cm_portal']) && $_GET['cm_portal'] == '1')
                  || (function_exists('get_query_var') && get_query_var('cm_portal') == '1');

    if ($is_standalone) {
        // Modo Portal Standalone: URLs relativas al front-end con cm_portal=1
        $base = home_url('/') . '?cm_portal=1';
        if (!empty($tab)) {
            $base .= '&tab=' . urlencode($tab);
        }
        return esc_url($base);
    }

    // Modo WP-Admin normal
    $base = admin_url('admin.php?page=cm-form-submissions');
    if (!empty($tab)) {
        $base = add_query_arg('tab', $tab, $base);
    }
    return esc_url($base);
}

/**
 * Obtiene la URL para ver un caso en página completa respetando el entorno (Portal Standalone vs WP-Admin).
 *
 * @param int $case_id ID del caso / envío.
 * @return string      URL lista para HTML.
 */
function cm_get_case_view_url($case_id) {
    $is_standalone = (isset($_GET['cm_portal']) && $_GET['cm_portal'] == '1')
                  || (isset($_GET['amp;cm_portal']) && $_GET['amp;cm_portal'] == '1')
                  || (function_exists('get_query_var') && get_query_var('cm_portal') == '1');

    if ($is_standalone) {
        return esc_url_raw(home_url('/?cm_portal=1&case_id=' . absint($case_id)));
    }

    return esc_url_raw(admin_url('admin.php?page=cm-form-submissions&case_id=' . absint($case_id)));
}

/**
 * Renderiza la página principal de la Bandeja de Casos y Envíos en WP-Admin.
 */
function cm_render_admin_submissions_page() {
    if (!current_user_can('edit_posts') && !current_user_can('manage_options')) {
        wp_die(__('No tienes permisos suficientes para acceder a esta página.', 'contacto-multidestino'));
    }

    $is_superadmin        = current_user_can('manage_options');
    $is_director          = function_exists('cm_is_director') && cm_is_director();
    $is_moderator         = function_exists('cm_is_moderator') && cm_is_moderator();
    $can_view_dashboard   = $is_superadmin || $is_director;
    $user_assigned_depts  = function_exists('cm_get_current_user_assigned_departments') ? cm_get_current_user_assigned_departments() : array();
    $user_assigned_dept   = !empty($user_assigned_depts) ? $user_assigned_depts[0] : '';

    // ══════════════════════════════════════════════════════════════════
    // VISTA DE CASO EN PÁGINA COMPLETA ESTILO APPLE PRO (SI VIENE case_id)
    // ══════════════════════════════════════════════════════════════════
    $view_case_id = 0;
    if (!empty($_GET['case_id'])) {
        $view_case_id = absint($_GET['case_id']);
    } elseif (!empty($_GET['amp;case_id'])) {
        $view_case_id = absint($_GET['amp;case_id']);
    } elseif (!empty($_GET['view_case'])) {
        $view_case_id = absint($_GET['view_case']);
    } elseif (!empty($_GET['amp;view_case'])) {
        $view_case_id = absint($_GET['amp;view_case']);
    }

    if ($view_case_id > 0) {
        $payload = cm_build_case_inspector_payload($view_case_id);
        if (!is_wp_error($payload)) {
            if (function_exists('cm_log_audit_action')) {
                cm_log_audit_action($view_case_id, $payload['case']->ticket_code, 'viewed', 'Visualizó los detalles del caso a pantalla completa.');
            }
            cm_render_fullpage_case_view($payload);
            return;
        }
    }
    
    $default_tab  = $can_view_dashboard ? 'dashboard' : 'inbox';
    $active_tab   = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : $default_tab;
    if (!$can_view_dashboard && ($active_tab === 'dashboard' || $active_tab === 'departments' || $active_tab === 'trash')) {
        $active_tab = 'inbox';
    }
    if (!$is_superadmin && ($active_tab === 'departments' || $active_tab === 'trash')) {
        $active_tab = 'inbox';
    }

    $current_page = isset($_GET['paged']) ? max(1, absint($_GET['paged'])) : 1;
    $per_page     = 20;
    $offset       = ($current_page - 1) * $per_page;

    $filter_form   = isset($_GET['form_filter']) ? sanitize_text_field($_GET['form_filter']) : '';
    $filter_status = isset($_GET['status_filter']) ? sanitize_text_field($_GET['status_filter']) : '';
    $filter_bucket = isset($_GET['filter_bucket']) ? sanitize_key($_GET['filter_bucket']) : 'all';
    
    // Filtro de Departamento inteligente según perfil
    $requested_dept = isset($_GET['dept_filter']) ? sanitize_text_field($_GET['dept_filter']) : '';
    if ($can_view_dashboard) {
        $filter_dept = $requested_dept;
    } elseif (!empty($user_assigned_depts)) {
        if ($requested_dept && in_array($requested_dept, $user_assigned_depts)) {
            $filter_dept = $requested_dept;
        } else {
            $filter_dept = count($user_assigned_depts) === 1 ? $user_assigned_depts[0] : $user_assigned_depts;
        }
    } else {
        $filter_dept = $requested_dept;
    }
    
    $search_query  = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';

    $trash_count = function_exists('cm_get_trash_count') ? cm_get_trash_count() : 0;

    // Conteos rápidos de buckets para la bandeja
    $active_cases_count    = 0;
    $completed_cases_count = 0;
    $total_cases_count     = 0;

    if ($active_tab === 'inbox') {
        $active_cases_count    = cm_get_submissions(array('filter_bucket' => 'active', 'department' => $filter_dept, 'form_id' => $filter_form, 'limit' => 1))['total'];
        $completed_cases_count = cm_get_submissions(array('filter_bucket' => 'completed', 'department' => $filter_dept, 'form_id' => $filter_form, 'limit' => 1))['total'];
        $total_cases_count     = cm_get_submissions(array('filter_bucket' => 'all', 'department' => $filter_dept, 'form_id' => $filter_form, 'limit' => 1))['total'];
    }

    $filter_action = isset($_GET['action_filter']) ? sanitize_key($_GET['action_filter']) : '';

    if ($active_tab === 'trash') {
        $results = cm_get_submissions(array(
            'trash_only' => true,
            'search'     => $search_query,
            'limit'      => $per_page,
            'offset'     => $offset,
            'orderby'    => 'deleted_at',
            'order'      => 'DESC',
        ));
    } elseif ($active_tab === 'audit') {
        $results = function_exists('cm_get_all_audit_logs') ? cm_get_all_audit_logs(array(
            'search' => $search_query,
            'action' => $filter_action,
            'limit'  => $per_page,
            'offset' => $offset,
        )) : array('total' => 0, 'items' => array());
    } else {
        $results = cm_get_submissions(array(
            'form_id'       => $filter_form,
            'status'        => $filter_status,
            'filter_bucket' => $filter_bucket,
            'department'    => $filter_dept,
            'search'        => $search_query,
            'limit'         => $per_page,
            'offset'        => $offset,
        ));
    }

    $submissions = $results['items'];
    $total_items = $results['total'];
    $total_pages = ceil($total_items / $per_page);

    $stats       = cm_get_submission_stats($filter_dept);
    $statuses    = cm_get_case_statuses();
    $forms       = cm_get_all_forms();
    $departments = cm_get_available_departments(false);
    $wp_users    = get_users(array('fields' => array('ID', 'display_name', 'user_email', 'user_login')));

    // Datos del Dashboard Analítico para Superadmin y Directores
    $analytics = function_exists('cm_get_dashboard_analytics') ? cm_get_dashboard_analytics() : array();
    $kanban    = function_exists('cm_get_kanban_columns_data') ? cm_get_kanban_columns_data() : array();

    // Enqueue nonce y datos para AJAX
    wp_localize_script('jquery', 'cmSubmissionsVars', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('cm_contacto_nonce'),
    ));
    ?>
    <script>
    window.cmToggleManageForm = window.cmToggleManageForm || function() {
        var $ = window.jQuery || jQuery;
        if (!$) return;
        var $body = $('#cm-manage-form-body');
        if ($body.is(':visible')) {
            $body.slideUp(180);
            $('#cm-toggle-manage-btn-icon').text('🔽');
            $('#cm-toggle-manage-btn-text').text('Desplegar Formulario');
        } else {
            $body.slideDown(180);
            $('#cm-toggle-manage-btn-icon').text('🔼');
            $('#cm-toggle-manage-btn-text').text('Ocultar Formulario');
        }
    };

    window.cmToggleQuickNotesSection = window.cmToggleQuickNotesSection || function() {
        var $ = window.jQuery || jQuery;
        if (!$) return;
        var $c = $('#cm-quick-notes-container');
        if ($c.is(':visible')) {
            $c.slideUp(150);
            $('#cm-txt-toggle-qn').text('Mostrar Notas');
            try { localStorage.setItem('cm_hide_quick_notes', '1'); } catch(e) {}
        } else {
            $c.slideDown(150);
            $('#cm-txt-toggle-qn').text('Ocultar Notas');
            try { localStorage.removeItem('cm_hide_quick_notes'); } catch(e) {}
        }
    };
    </script>
    <div class="wrap cm-apple-wrap">
        <!-- Barra Superior Compacta Estilo macOS / Office — oculta en Portal Standalone -->
        <?php if (empty($_GET['cm_portal'])) : ?>
        <div class="cm-apple-header">
            <?php if (empty($_GET['cm_portal'])) : ?>
            <!-- Logo y título — ocultos en modo Portal Standalone (ya aparece en la topbar) -->
            <div class="cm-apple-header-left">
                <div class="cm-apple-logo-badge" style="background:#ffffff; border:1px solid #e2e8f0; overflow:hidden; padding:2px; display:flex; align-items:center; justify-content:center;">
                    <img src="<?php echo esc_url(CM_PLUGIN_URL . 'assets/images/logo.gif'); ?>" alt="Ingecodex Form" style="width:100%; height:100%; object-fit:cover; border-radius:8px; display:block;" />
                </div>
                <div>
                    <h1 class="cm-apple-title">
                        <?php if ($is_superadmin) : ?>
                            <?php _e('Centro de Casos y Solicitudes', 'contacto-multidestino'); ?>
                        <?php elseif ($is_director) : ?>
                            <?php _e('👑 Panel Directivo • Monitoreo Institucional', 'contacto-multidestino'); ?>
                        <?php else : ?>
                            <?php printf(__('Bandeja de Casos • %s', 'contacto-multidestino'), esc_html($user_assigned_dept ? $user_assigned_dept : 'Mi Área')); ?>
                        <?php endif; ?>
                        <span class="cm-apple-version">v<?php echo CM_VERSION; ?> Pro</span>
                    </h1>
                    <p class="cm-apple-desc">
                        <?php if ($is_superadmin) : ?>
                            <?php _e('Monitoreo en tiempo real, gestión ejecutiva, derivación entre áreas y seguimiento.', 'contacto-multidestino'); ?>
                        <?php elseif ($is_director) : ?>
                            <?php _e('Supervisión en tiempo real de todos los casos, flujo de atención y auditoría institucional.', 'contacto-multidestino'); ?>
                        <?php else : ?>
                            <?php printf(__('Expedientes y solicitudes dirigidas al departamento de %s.', 'contacto-multidestino'), esc_html($user_assigned_dept ? $user_assigned_dept : 'tu área')); ?>
                        <?php endif; ?>
                    </p>
                </div>
            </div>
            <?php endif; ?>

            <!-- Segmented Control (Pestañas estilo macOS) -->
            <?php if ($can_view_dashboard) : ?>
                <div class="cm-segmented-control">
                    <a href="<?php echo cm_get_view_tab_url('dashboard'); ?>" class="cm-segment-btn <?php echo $active_tab === 'dashboard' ? 'active' : ''; ?>">
                        📊 <?php _e('Dashboard en Vivo', 'contacto-multidestino'); ?>
                    </a>
                    <a href="<?php echo cm_get_view_tab_url('inbox'); ?>" class="cm-segment-btn <?php echo $active_tab === 'inbox' ? 'active' : ''; ?>">
                        📥 <?php _e('Todos los Casos', 'contacto-multidestino'); ?> (<?php echo esc_html($stats['total']); ?>)
                    </a>
                    <?php if ($is_superadmin) : ?>
                        <a href="<?php echo cm_get_view_tab_url('departments'); ?>" class="cm-segment-btn <?php echo $active_tab === 'departments' ? 'active' : ''; ?>">
                            👥 <?php _e('Áreas y Encargados', 'contacto-multidestino'); ?>
                        </a>
                        <a href="<?php echo cm_get_view_tab_url('trash'); ?>" class="cm-segment-btn <?php echo $active_tab === 'trash' ? 'active' : ''; ?>" style="<?php echo $trash_count > 0 ? 'color:#dc2626; font-weight:700;' : ''; ?>">
                            🗑️ <?php _e('Papelera', 'contacto-multidestino'); ?> (<?php echo esc_html($trash_count); ?>)
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="cm-apple-header-actions">
                <?php if (function_exists('cm_get_standalone_portal_url') && empty($_GET['cm_portal'])) : ?>
                    <a href="<?php echo esc_url(cm_get_standalone_portal_url()); ?>" target="_blank" class="cm-apple-btn-secondary" style="background:#eff6ff; color:#2563eb !important; border-color:#bfdbfe; font-weight:700;" title="<?php esc_attr_e('Abrir Portal Ejecutivo Independiente en pantalla completa', 'contacto-multidestino'); ?>">
                        🚀 <?php _e('Portal Standalone ↗', 'contacto-multidestino'); ?>
                    </a>
                <?php endif; ?>
                <?php if (empty($_GET['cm_portal'])) : ?>
                <a href="https://link.mercadopago.cl/ingecodex" target="_blank" rel="noopener noreferrer" class="cm-apple-btn-secondary" style="background: linear-gradient(135deg, #009ee3 0%, #007eb5 100%); color: #ffffff !important; border: none; font-weight: 700; display: inline-flex; align-items: center; gap: 6px; box-shadow: 0 2px 8px rgba(0, 158, 227, 0.32); padding: 7px 14px; border-radius: 10px;" title="Apoyar el desarrollo con Mercado Pago">
                    <img src="<?php echo esc_url(CM_PLUGIN_URL . 'assets/images/logo.gif'); ?>" alt="Ingecodex" style="width: 19px; height: 19px; border-radius: 50%; object-fit: cover; display: inline-block;" />
                    <span>Donar</span>
                </a>
                <?php endif; ?>
                <?php if ($is_superadmin) : ?>
                    <?php if (empty($_GET['cm_portal'])) : ?>
                    <a href="<?php echo admin_url('admin.php?page=cm-tracker-customizer'); ?>" class="cm-apple-btn-secondary" title="<?php esc_attr_e('Personalizar y editar la apariencia de la página de consulta por código', 'contacto-multidestino'); ?>">
                        🌐 <?php _e('Portal', 'contacto-multidestino'); ?>
                    </a>
                    <a href="<?php echo admin_url('admin.php?page=cm-form-studio'); ?>" class="cm-apple-btn-secondary">
                        🛠️ <?php _e('Editor', 'contacto-multidestino'); ?>
                    </a>
                    <a href="<?php echo admin_url('admin.php?page=cm-form-smtp'); ?>" class="cm-apple-btn-secondary">
                        ⚙️ <?php _e('SMTP', 'contacto-multidestino'); ?>
                    </a>
                    <?php endif; ?>
                <?php else : ?>
                    <?php if (empty($_GET['cm_portal'])) : ?>
                        <a href="<?php echo esc_url(wp_logout_url(home_url())); ?>" class="cm-apple-btn-secondary" style="color:#ef4444 !important; border-color:#fca5a5;">
                            🚪 <?php _e('Cerrar Sesión', 'contacto-multidestino'); ?>
                        </a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; /* fin cm-portal check */ ?>

        <?php 
        $cm_curr_uid = get_current_user_id();
        $cm_has_2fa  = function_exists('cm_is_2fa_enabled') && cm_is_2fa_enabled($cm_curr_uid);
        ?>
        <?php if (!$cm_has_2fa) : ?>
            <!-- BANNER 2FA ULTRA COMPACTO -->
            <div id="cm-2fa-suggestion-banner" style="background:#f0f9ff; border:1px solid #bae6fd; border-radius:8px; padding:6px 12px; margin-bottom:10px; display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:8px;">
                <div style="display:flex; align-items:center; gap:8px; font-size:12px; color:#0369a1;">
                    <span>🛡️</span>
                    <span><strong><?php _e('Seguridad Recomendada:', 'contacto-multidestino'); ?></strong> <?php _e('Activa 2FA con Google Authenticator o Apple Passwords.', 'contacto-multidestino'); ?></span>
                </div>
                <button type="button" class="cm-btn-view" style="background:#0284c7; border-color:#0284c7; color:#ffffff; font-weight:700; font-size:11px; height:24px; padding:0 10px;" onclick="cmOpen2FASetupModal()">
                    🔐 <?php _e('Activar 2FA', 'contacto-multidestino'); ?>
                </button>
            </div>
        <?php endif; ?>

        <?php if ($active_tab === 'dashboard' && $can_view_dashboard) : ?>
            <!-- ══════════════════════════════════════════════════════════
                 PESTAÑA 1: DASHBOARD ANALYTICS EN TIEMPO REAL (ESTILO PHOENIX WIDGETS)
                 ══════════════════════════════════════════════════════════ -->
            
            <!-- Header de Sección Dashboard -->
            <div style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:12px; margin-bottom:18px;">
                <div style="display:flex; align-items:center; gap:12px;">
                    <span style="width:38px; height:38px; border-radius:50%; background:#e0edff; color:#3874ff; display:inline-flex; align-items:center; justify-content:center; font-size:18px; font-weight:800; box-shadow:0 2px 6px rgba(56,116,255,0.18);">
                        📊
                    </span>
                    <div>
                        <div style="display:flex; align-items:center; gap:8px;">
                            <h2 style="font-size:17px; font-weight:800; color:#0f172a; margin:0; line-height:1.2;">
                                <?php _e('Dashboard Analítico Institucional', 'contacto-multidestino'); ?>
                            </h2>
                            <span style="font-size:11px; font-weight:700; background:#dcfce7; color:#15803d; border:1px solid #bbf7d0; padding:2px 8px; border-radius:20px;">
                                ⚡ En Vivo
                            </span>
                        </div>
                        <p style="margin:3px 0 0 0; font-size:12px; color:#64748b;">
                            <?php _e('Monitoreo en tiempo real del flujo de trabajo, derivaciones y rendimiento por área.', 'contacto-multidestino'); ?>
                        </p>
                    </div>
                </div>
                <div style="display:flex; align-items:center; gap:8px;">
                    <a href="<?php echo cm_get_view_tab_url('inbox'); ?>" class="cm-btn-view" style="font-size:12px; text-decoration:none;">
                        📥 <?php _e('Ir a Bandeja de Casos', 'contacto-multidestino'); ?> &rarr;
                    </a>
                    <button type="button" class="cm-apple-btn-secondary" style="font-size:12px; font-weight:700;" onclick="location.reload()">
                        🔄 <?php _e('Actualizar Datos', 'contacto-multidestino'); ?>
                    </button>
                </div>
            </div>

            <!-- 4 Hero KPIs (Estilo Phoenix Widget Cards) -->
            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(220px, 1fr)); gap:16px; margin-bottom:24px;">
                
                <!-- KPI 1: Iniciados -->
                <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:14px; padding:20px; box-shadow:0 1px 3px rgba(0,0,0,0.03); display:flex; align-items:center; justify-content:space-between; transition:transform 0.15s ease, box-shadow 0.15s ease;" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 4px 12px rgba(0,0,0,0.06)';" onmouseout="this.style.transform=''; this.style.boxShadow='0 1px 3px rgba(0,0,0,0.03)';">
                    <div>
                        <div style="font-size:26px; font-weight:900; color:#0f172a; line-height:1.1;">
                            <?php echo esc_html($analytics['iniciados']); ?>
                        </div>
                        <div style="font-size:11.5px; font-weight:700; color:#64748b; text-transform:uppercase; letter-spacing:0.04em; margin-top:6px;">
                            <?php _e('Iniciados (Nuevos)', 'contacto-multidestino'); ?>
                        </div>
                        <div style="font-size:11px; font-weight:700; color:#ef4444; margin-top:4px;">
                            🔔 <?php _e('Por asignar / atender', 'contacto-multidestino'); ?>
                        </div>
                    </div>
                    <div style="width:46px; height:46px; border-radius:12px; background:#eff6ff; border:1px solid #bfdbfe; color:#2563eb; display:flex; align-items:center; justify-content:center; font-size:22px; flex-shrink:0;">
                        📥
                    </div>
                </div>

                <!-- KPI 2: Continuidad / En Gestión -->
                <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:14px; padding:20px; box-shadow:0 1px 3px rgba(0,0,0,0.03); display:flex; align-items:center; justify-content:space-between; transition:transform 0.15s ease, box-shadow 0.15s ease;" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 4px 12px rgba(0,0,0,0.06)';" onmouseout="this.style.transform=''; this.style.boxShadow='0 1px 3px rgba(0,0,0,0.03)';">
                    <div>
                        <div style="font-size:26px; font-weight:900; color:#0f172a; line-height:1.1;">
                            <?php echo esc_html($analytics['continuidad']); ?>
                        </div>
                        <div style="font-size:11.5px; font-weight:700; color:#64748b; text-transform:uppercase; letter-spacing:0.04em; margin-top:6px;">
                            <?php _e('En Gestión / Proceso', 'contacto-multidestino'); ?>
                        </div>
                        <div style="font-size:11px; font-weight:700; color:#4338ca; margin-top:4px;">
                            ⚡ <?php _e('Trámite activo', 'contacto-multidestino'); ?>
                        </div>
                    </div>
                    <div style="width:46px; height:46px; border-radius:12px; background:#eef2ff; border:1px solid #c7d2fe; color:#4338ca; display:flex; align-items:center; justify-content:center; font-size:22px; flex-shrink:0;">
                        ⚡
                    </div>
                </div>

                <!-- KPI 3: Requiere Acción -->
                <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:14px; padding:20px; box-shadow:0 1px 3px rgba(0,0,0,0.03); display:flex; align-items:center; justify-content:space-between; transition:transform 0.15s ease, box-shadow 0.15s ease;" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 4px 12px rgba(0,0,0,0.06)';" onmouseout="this.style.transform=''; this.style.boxShadow='0 1px 3px rgba(0,0,0,0.03)';">
                    <div>
                        <div style="font-size:26px; font-weight:900; color:#0f172a; line-height:1.1;">
                            <?php echo esc_html($analytics['pendientes']); ?>
                        </div>
                        <div style="font-size:11.5px; font-weight:700; color:#64748b; text-transform:uppercase; letter-spacing:0.04em; margin-top:6px;">
                            <?php _e('Requiere Presencia / Docs', 'contacto-multidestino'); ?>
                        </div>
                        <div style="font-size:11px; font-weight:700; color:#b45309; margin-top:4px;">
                            ⚠️ <?php _e('Esperando al solicitante', 'contacto-multidestino'); ?>
                        </div>
                    </div>
                    <div style="width:46px; height:46px; border-radius:12px; background:#fef3c7; border:1px solid #fde68a; color:#b45309; display:flex; align-items:center; justify-content:center; font-size:22px; flex-shrink:0;">
                        ⚠️
                    </div>
                </div>

                <!-- KPI 4: Finalizados + Tasa de Cierre -->
                <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:14px; padding:20px; box-shadow:0 1px 3px rgba(0,0,0,0.03); display:flex; align-items:center; justify-content:space-between; transition:transform 0.15s ease, box-shadow 0.15s ease;" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 4px 12px rgba(0,0,0,0.06)';" onmouseout="this.style.transform=''; this.style.boxShadow='0 1px 3px rgba(0,0,0,0.03)';">
                    <div>
                        <div style="display:flex; align-items:baseline; gap:8px;">
                            <span style="font-size:26px; font-weight:900; color:#0f172a; line-height:1.1;">
                                <?php echo esc_html($analytics['finalizados']); ?>
                            </span>
                            <span style="font-size:11px; font-weight:800; color:#15803d; background:#dcfce7; border:1px solid #bbf7d0; padding:2px 8px; border-radius:12px;">
                                <?php echo esc_html($analytics['tasa_cierre']); ?>% <?php _e('Cierre', 'contacto-multidestino'); ?>
                            </span>
                        </div>
                        <div style="font-size:11.5px; font-weight:700; color:#64748b; text-transform:uppercase; letter-spacing:0.04em; margin-top:6px;">
                            <?php _e('Finalizados / Resueltos', 'contacto-multidestino'); ?>
                        </div>
                        <div style="font-size:11px; font-weight:700; color:#16a34a; margin-top:4px;">
                            ✅ <?php _e('Casos concluidos con éxito', 'contacto-multidestino'); ?>
                        </div>
                    </div>
                    <div style="width:46px; height:46px; border-radius:12px; background:#dcfce7; border:1px solid #bbf7d0; color:#15803d; display:flex; align-items:center; justify-content:center; font-size:22px; flex-shrink:0;">
                        ✅
                    </div>
                </div>

            </div>

            <!-- Resumen Ejecutivo de Casos en Gestión Activa (Phoenix Data Table Card) -->
            <div class="cm-apple-card-panel" style="background:#ffffff; border:1px solid #e2e8f0; border-radius:14px; box-shadow:0 1px 4px rgba(0,0,0,0.03); overflow:hidden; padding:0; margin-bottom:24px;">
                <div style="display:flex; align-items:center; justify-content:space-between; padding:18px 24px; border-bottom:1px solid #edf2f9; background:#ffffff; flex-wrap:wrap; gap:12px;">
                    <div>
                        <div style="display:flex; align-items:center; gap:8px;">
                            <h3 style="font-size:15px; font-weight:800; margin:0; color:#0f172a;">
                                📋 <?php _e('Casos y Solicitudes en Gestión Activa', 'contacto-multidestino'); ?>
                            </h3>
                            <span style="font-size:11px; font-weight:700; background:#e0edff; color:#2563eb; border:1px solid #bfdbfe; padding:2px 8px; border-radius:20px;">
                                <?php echo count(array_merge($kanban['iniciados'], $kanban['continuidad'], $kanban['pendientes'])); ?> <?php _e('en curso', 'contacto-multidestino'); ?>
                            </span>
                        </div>
                        <p style="margin:4px 0 0 0; font-size:12px; color:#64748b;">
                            <?php _e('Monitoreo en tiempo real de los requerimientos en trámite institucional.', 'contacto-multidestino'); ?>
                        </p>
                    </div>
                    <a href="<?php echo cm_get_view_tab_url('inbox'); ?>" class="cm-btn-view" style="font-size:12px; text-decoration:none; padding:6px 14px; height:32px;">
                        📥 <?php _e('Ver Todos en Bandeja', 'contacto-multidestino'); ?> &rarr;
                    </a>
                </div>

                <?php 
                $active_cases = array_merge($kanban['iniciados'], $kanban['continuidad'], $kanban['pendientes']);
                if (empty($active_cases)) : ?>
                    <div style="text-align:center; padding:36px 20px; color:#64748b;">
                        <div style="font-size:32px; margin-bottom:8px;">✨</div>
                        <strong style="color:#0f172a; font-size:14px;"><?php _e('No hay solicitudes pendientes de gestión en este momento.', 'contacto-multidestino'); ?></strong>
                        <p style="margin:4px 0 0 0; font-size:12px; color:#94a3b8;"><?php _e('Todos los requerimientos están al día o han sido resueltos.', 'contacto-multidestino'); ?></p>
                    </div>
                <?php else : ?>
                    <div style="overflow-x:auto; -webkit-overflow-scrolling:touch; width:100%;">
                        <table style="width:100%; border-collapse:collapse; font-size:13px; min-width:760px; margin:0;">
                            <thead>
                                <tr style="border-bottom:2px solid #edf2f9; background:#f8fafc;">
                                    <th style="padding:12px 20px; text-align:left; font-size:10.5px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.06em; width:16%;"><?php _e('Código', 'contacto-multidestino'); ?></th>
                                    <th style="padding:12px 18px; text-align:left; font-size:10.5px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.06em; width:26%;"><?php _e('Solicitante', 'contacto-multidestino'); ?></th>
                                    <th style="padding:12px 18px; text-align:left; font-size:10.5px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.06em; width:22%;"><?php _e('Área / Departamento', 'contacto-multidestino'); ?></th>
                                    <th style="padding:12px 14px; text-align:center; font-size:10.5px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.06em; width:16%;"><?php _e('Estado Actual', 'contacto-multidestino'); ?></th>
                                    <th style="padding:12px 16px; text-align:left; font-size:10.5px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.06em; width:12%;"><?php _e('Fecha', 'contacto-multidestino'); ?></th>
                                    <th style="padding:12px 20px; text-align:right; font-size:10.5px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.06em; width:8%;"><?php _e('Acción', 'contacto-multidestino'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach (array_slice($active_cases, 0, 10) as $c) : 
                                    $badge_bg = '#eff6ff'; $badge_color = '#1e40af'; $badge_border = '#bfdbfe'; $st_label = 'INICIADO';
                                    if ($c->status === 'en_proceso' || $c->status === 'en_revision') {
                                        $badge_bg = '#eef2ff'; $badge_color = '#4338ca'; $badge_border = '#c7d2fe'; $st_label = 'EN GESTIÓN';
                                    } elseif ($c->status === 'pendiente_usuario') {
                                        $badge_bg = '#fef3c7'; $badge_color = '#b45309'; $badge_border = '#fde68a'; $st_label = 'ACCIÓN REQUERIDA';
                                    } elseif ($c->status === 'resuelto' || $c->status === 'cerrado') {
                                        $badge_bg = '#dcfce7'; $badge_color = '#15803d'; $badge_border = '#bbf7d0'; $st_label = 'FINALIZADO';
                                    }
                                ?>
                                    <tr style="border-bottom:1px solid #f1f5f9; transition:background 0.15s ease;" onmouseover="this.style.background='#f8fafc';" onmouseout="this.style.background='';">
                                        <td style="padding:14px 20px;">
                                            <span class="cm-tag-code" style="cursor:pointer;" onclick="cmOpenCaseModal(<?php echo esc_attr($c->id); ?>, '<?php echo esc_attr($c->ticket_code); ?>')">
                                                <?php echo esc_html($c->ticket_code); ?>
                                            </span>
                                        </td>
                                        <td style="padding:14px 18px;">
                                            <strong style="color:#0f172a; font-size:13px;"><?php echo esc_html($c->sender_name ? $c->sender_name : 'Solicitante'); ?></strong>
                                            <?php if (!empty($c->sender_email)) : ?>
                                                <div style="font-size:11.5px; color:#64748b; margin-top:2px;">✉️ <?php echo esc_html($c->sender_email); ?></div>
                                            <?php endif; ?>
                                        </td>
                                        <td style="padding:14px 18px;">
                                            <span style="font-size:11.5px; font-weight:700; color:#4338ca; background:#eef2ff; border:1px solid #c7d2fe; padding:3px 9px; border-radius:6px; display:inline-block;">
                                                🏢 <?php echo esc_html($c->department ? $c->department : 'General'); ?>
                                            </span>
                                        </td>
                                        <td style="padding:14px 14px; text-align:center;">
                                            <span style="background:<?php echo $badge_bg; ?>; color:<?php echo $badge_color; ?>; border:1px solid <?php echo $badge_border; ?>; font-size:11px; padding:3px 10px; border-radius:12px; font-weight:700; display:inline-block; white-space:nowrap;">
                                                <?php echo esc_html($st_label); ?>
                                            </span>
                                        </td>
                                        <td style="padding:14px 16px; color:#64748b; font-size:12px; font-weight:500;">
                                            📅 <?php echo date_i18n('d/m/Y H:i', strtotime($c->created_at)); ?>
                                        </td>
                                        <td style="padding:14px 20px; text-align:right;">
                                            <button type="button" class="cm-btn-view" style="font-size:11.5px; padding:4px 10px; height:28px;" onclick="cmOpenCaseModal(<?php echo esc_attr($c->id); ?>, '<?php echo esc_attr($c->ticket_code); ?>')">
                                                👁️ <?php _e('Ver', 'contacto-multidestino'); ?>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Fila Inferior 2 Columnas: Rendimiento por Áreas + Feed de Actividad en Vivo (Estilo Phoenix Analytics) -->
            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(340px, 1fr)); gap:20px; margin-bottom:24px;">
                
                <!-- Columna Izquierda: Rendimiento por Departamento / Área -->
                <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:14px; box-shadow:0 1px 4px rgba(0,0,0,0.03); overflow:hidden; padding:0;">
                    <div style="padding:18px 24px; border-bottom:1px solid #edf2f9; background:#ffffff;">
                        <h3 style="font-size:15px; font-weight:800; color:#0f172a; margin:0;">
                            🏢 <?php _e('Rendimiento por Departamento / Área', 'contacto-multidestino'); ?>
                        </h3>
                        <p style="margin:4px 0 0 0; font-size:12px; color:#64748b;">
                            <?php _e('Distribución de carga de trabajo y progreso de resolución por área.', 'contacto-multidestino'); ?>
                        </p>
                    </div>

                    <?php if (empty($analytics['departments'])) : ?>
                        <p style="color:#94a3b8; font-size:13px; text-align:center; padding:32px;"><?php _e('No hay registros de casos aún.', 'contacto-multidestino'); ?></p>
                    <?php else : ?>
                        <div style="overflow-x:auto; -webkit-overflow-scrolling:touch;">
                            <table style="width:100%; border-collapse:collapse; font-size:12.5px; margin:0;">
                                <thead>
                                    <tr style="border-bottom:2px solid #edf2f9; background:#f8fafc;">
                                        <th style="padding:10px 18px; text-align:left; font-size:10.5px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.06em; width:45%;"><?php _e('Área / Progreso', 'contacto-multidestino'); ?></th>
                                        <th style="padding:10px 10px; text-align:center; font-size:10.5px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.06em; width:13%;"><?php _e('Nuevos', 'contacto-multidestino'); ?></th>
                                        <th style="padding:10px 10px; text-align:center; font-size:10.5px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.06em; width:14%;"><?php _e('Gestión', 'contacto-multidestino'); ?></th>
                                        <th style="padding:10px 10px; text-align:center; font-size:10.5px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.06em; width:14%;"><?php _e('Cerrados', 'contacto-multidestino'); ?></th>
                                        <th style="padding:10px 16px; text-align:center; font-size:10.5px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.06em; width:14%;"><?php _e('Total', 'contacto-multidestino'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($analytics['departments'] as $dr) : 
                                        $d_tot  = (int)$dr->total_cases;
                                        $d_ini  = (int)$dr->count_iniciados;
                                        $d_con  = (int)$dr->count_continuidad + (int)$dr->count_pendientes;
                                        $d_fin  = (int)$dr->count_finalizados;
                                        $p_ini  = $d_tot > 0 ? round(($d_ini / $d_tot) * 100) : 0;
                                        $p_con  = $d_tot > 0 ? round(($d_con / $d_tot) * 100) : 0;
                                        $p_fin  = $d_tot > 0 ? round(($d_fin / $d_tot) * 100) : 0;
                                    ?>
                                        <tr style="border-bottom:1px solid #f1f5f9; transition:background 0.15s ease;" onmouseover="this.style.background='#f8fafc';" onmouseout="this.style.background='';">
                                            <td style="padding:12px 18px;">
                                                <div style="font-weight:700; color:#0f172a; font-size:13px; margin-bottom:4px;">
                                                    🏢 <?php echo esc_html($dr->department ? $dr->department : 'General'); ?>
                                                </div>
                                                <div style="height:6px; border-radius:3px; background:#f1f5f9; display:flex; overflow:hidden;" title="Nuevos: <?php echo $p_ini; ?>% | Gestión: <?php echo $p_con; ?>% | Finalizados: <?php echo $p_fin; ?>%">
                                                    <div style="width:<?php echo $p_ini; ?>%; background:#ef4444;"></div>
                                                    <div style="width:<?php echo $p_con; ?>%; background:#3874ff;"></div>
                                                    <div style="width:<?php echo $p_fin; ?>%; background:#10b981;"></div>
                                                </div>
                                            </td>
                                            <td style="padding:12px 10px; text-align:center;"><span style="color:#ef4444; font-weight:800; font-size:13px;"><?php echo $d_ini; ?></span></td>
                                            <td style="padding:12px 10px; text-align:center;"><span style="color:#3874ff; font-weight:800; font-size:13px;"><?php echo $d_con; ?></span></td>
                                            <td style="padding:12px 10px; text-align:center;"><span style="color:#10b981; font-weight:800; font-size:13px;"><?php echo $d_fin; ?></span></td>
                                            <td style="padding:12px 16px; text-align:center;"><strong style="color:#0f172a; font-size:13px;"><?php echo $d_tot; ?></strong></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Columna Derecha: Feed de Auditoría y Actividad en Vivo (Phoenix Activity Feed) -->
                <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:14px; box-shadow:0 1px 4px rgba(0,0,0,0.03); overflow:hidden; padding:0;">
                    <div style="padding:18px 24px; border-bottom:1px solid #edf2f9; background:#ffffff;">
                        <h3 style="font-size:15px; font-weight:800; color:#0f172a; margin:0;">
                            ⚡ <?php _e('Línea de Tiempo y Auditoría en Vivo', 'contacto-multidestino'); ?>
                        </h3>
                        <p style="margin:4px 0 0 0; font-size:12px; color:#64748b;">
                            <?php _e('Registro de acciones y respuestas en tiempo real.', 'contacto-multidestino'); ?>
                        </p>
                    </div>

                    <?php if (empty($analytics['recent_activity'])) : ?>
                        <p style="color:#94a3b8; font-size:13px; text-align:center; padding:32px;"><?php _e('Sin actividad reciente registrada.', 'contacto-multidestino'); ?></p>
                    <?php else : ?>
                        <div style="max-height:400px; overflow-y:auto; padding:16px 20px; display:flex; flex-direction:column; gap:12px;">
                            <?php foreach ($analytics['recent_activity'] as $act) : 
                                $icon = '📢'; $bg_ico = '#eff6ff'; $color_ico = '#2563eb';
                                if ($act->action_type === 'created') { $icon = '📥'; $bg_ico = '#eff6ff'; $color_ico = '#2563eb'; }
                                elseif ($act->action_type === 'transfer') { $icon = '🔄'; $bg_ico = '#fef3c7'; $color_ico = '#b45309'; }
                                elseif ($act->status === 'resuelto' || $act->status === 'cerrado') { $icon = '✅'; $bg_ico = '#dcfce7'; $color_ico = '#15803d'; }
                                elseif ($act->status === 'pendiente_usuario') { $icon = '⚠️'; $bg_ico = '#fef3c7'; $color_ico = '#b45309'; }
                                elseif ($act->status === 'en_revision' || $act->status === 'en_proceso') { $icon = '⚡'; $bg_ico = '#eef2ff'; $color_ico = '#4338ca'; }
                            ?>
                                <div style="display:flex; align-items:flex-start; gap:12px; padding:10px 12px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; transition:background 0.15s ease;" onmouseover="this.style.background='#f1f5f9';" onmouseout="this.style.background='#f8fafc';">
                                    <span style="width:32px; height:32px; border-radius:8px; background:<?php echo $bg_ico; ?>; color:<?php echo $color_ico; ?>; display:flex; align-items:center; justify-content:center; font-size:15px; flex-shrink:0;">
                                        <?php echo $icon; ?>
                                    </span>
                                    <div style="flex:1; min-width:0;">
                                        <div style="display:flex; align-items:center; justify-content:space-between; gap:6px; flex-wrap:wrap;">
                                            <span style="font-size:12.5px; font-weight:800; color:#0f172a;">
                                                <code style="color:#2563eb; font-size:12px; background:#eff6ff; padding:1px 6px; border-radius:4px;"><?php echo esc_html($act->ticket_code); ?></code> • <?php echo esc_html($act->author_name); ?>
                                            </span>
                                            <span style="font-size:11px; color:#94a3b8; font-weight:600;">
                                                🕒 <?php echo date_i18n('d/m H:i', strtotime($act->created_at)); ?> hrs
                                            </span>
                                        </div>
                                        <div style="color:#475569; font-size:12px; margin-top:3px; line-height:1.35; word-break:break-word;">
                                            <?php echo esc_html(wp_strip_all_tags($act->note)); ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        <?php elseif ($active_tab === 'inbox') : ?>
            <!-- ══════════════════════════════════════════════════════════
                 MÉTRICAS ULTRA COMPACTAS DE CASOS (ESTILO PHOENIX COMPACT)
                 ══════════════════════════════════════════════════════════ -->
            
            <?php
            $tot_c     = (int)($stats['total'] ?? 0);
            $rec_c     = (int)($stats['recibido'] ?? 0);
            $gest_c    = (int)(($stats['en_revision'] ?? 0) + ($stats['en_proceso'] ?? 0));
            $req_c     = (int)($stats['pendiente_usuario'] ?? 0);
            $fin_c     = (int)($stats['resuelto'] ?? 0);
            $act_c     = $tot_c - $fin_c;
            $rate_fin  = $tot_c > 0 ? round(($fin_c / $tot_c) * 100) : 0;
            $rate_act  = $tot_c > 0 ? round(($act_c / $tot_c) * 100) : 0;
            $rate_rec  = $tot_c > 0 ? round(($rec_c / $tot_c) * 100) : 0;
            $rate_gest = $tot_c > 0 ? round(($gest_c / $tot_c) * 100) : 0;
            $general_tracker_url = function_exists('cm_get_case_tracker_url') ? cm_get_case_tracker_url('') : home_url('/');
            ?>

            <!-- Barra Horizontal de Métricas Compacta de 1 sola fila con micro-barra -->
            <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:10px; box-shadow:0 1px 3px rgba(0,0,0,0.02); margin-bottom:10px; overflow:hidden;">
                <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(110px, 1fr));">
                    
                    <!-- 1. Total Casos -->
                    <div style="padding:8px 10px; text-align:center; border-right:1px solid #f1f5f9;">
                        <div style="font-size:10px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.04em;">
                            📥 <?php _e('Total', 'contacto-multidestino'); ?>
                        </div>
                        <div style="font-size:17px; font-weight:900; color:#0f172a; line-height:1.2; margin-top:2px;">
                            <?php echo number_format_i18n($tot_c); ?>
                        </div>
                    </div>

                    <!-- 2. Nuevos / Recibidos -->
                    <div style="padding:8px 10px; text-align:center; border-right:1px solid #f1f5f9;">
                        <div style="font-size:10px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.04em;">
                            🔔 <?php _e('Nuevos', 'contacto-multidestino'); ?>
                        </div>
                        <div style="font-size:17px; font-weight:900; color:#dc2626; line-height:1.2; margin-top:2px;">
                            <?php echo number_format_i18n($rec_c); ?>
                        </div>
                    </div>

                    <!-- 3. En Gestión -->
                    <div style="padding:8px 10px; text-align:center; border-right:1px solid #f1f5f9;">
                        <div style="font-size:10px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.04em;">
                            ⚡ <?php _e('En Gestión', 'contacto-multidestino'); ?>
                        </div>
                        <div style="font-size:17px; font-weight:900; color:#2563eb; line-height:1.2; margin-top:2px;">
                            <?php echo number_format_i18n($gest_c); ?>
                        </div>
                    </div>

                    <!-- 4. Requiere Acción -->
                    <div style="padding:8px 10px; text-align:center; border-right:1px solid #f1f5f9;">
                        <div style="font-size:10px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.04em;">
                            ⚠️ <?php _e('Pendiente', 'contacto-multidestino'); ?>
                        </div>
                        <div style="font-size:17px; font-weight:900; color:#d97706; line-height:1.2; margin-top:2px;">
                            <?php echo number_format_i18n($req_c); ?>
                        </div>
                    </div>

                    <!-- 5. Finalizados -->
                    <div style="padding:8px 10px; text-align:center; border-right:1px solid #f1f5f9;">
                        <div style="font-size:10px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.04em;">
                            ✅ <?php _e('Resueltos', 'contacto-multidestino'); ?>
                        </div>
                        <div style="font-size:17px; font-weight:900; color:#16a34a; line-height:1.2; margin-top:2px;">
                            <?php echo number_format_i18n($fin_c); ?>
                        </div>
                    </div>

                    <!-- 6. Tasa de Cierre -->
                    <div style="padding:8px 10px; text-align:center;">
                        <div style="font-size:10px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.04em;">
                            📈 <?php _e('Cierre', 'contacto-multidestino'); ?>
                        </div>
                        <div style="font-size:17px; font-weight:900; color:#0d9488; line-height:1.2; margin-top:2px;">
                            <?php echo $rate_fin; ?>%
                        </div>
                    </div>

                </div>
                <!-- Micro barra apilada integrada -->
                <div style="height:3px; background:#f1f5f9; display:flex; width:100%;">
                    <div style="width:<?php echo $rate_rec; ?>%; background:#ef4444;" title="Nuevos"></div>
                    <div style="width:<?php echo $rate_gest; ?>%; background:#3874ff;" title="En Gestión"></div>
                    <div style="width:<?php echo $rate_fin; ?>%; background:#10b981;" title="Resueltos"></div>
                </div>
            </div>

            <!-- Barra de Filtros Compacta estilo Barra de Herramientas -->
            <div class="cm-apple-toolbar">
                <form method="GET" action="<?php echo !empty($_GET['cm_portal']) ? esc_url(home_url('/')) : admin_url('admin.php'); ?>" class="cm-toolbar-form">
                    <?php if (!empty($_GET['cm_portal'])) : ?>
                        <input type="hidden" name="cm_portal" value="1" />
                    <?php else : ?>
                        <input type="hidden" name="page" value="cm-form-submissions" />
                    <?php endif; ?>
                    <input type="hidden" name="tab" value="inbox" />

                    <!-- Filtro Formulario -->
                    <div class="cm-tool-item">
                        <select name="form_filter" onchange="this.form.submit()" class="cm-apple-select">
                            <option value=""><?php _e('Formularios (Todos)', 'contacto-multidestino'); ?></option>
                            <?php foreach ($forms as $fid => $f) : ?>
                                <option value="<?php echo esc_attr($fid); ?>" <?php selected($filter_form, $fid); ?>>
                                    <?php echo esc_html($f['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- Filtro Estado -->
                    <div class="cm-tool-item">
                        <select name="status_filter" onchange="this.form.submit()" class="cm-apple-select">
                            <option value=""><?php _e('Estados (Todos)', 'contacto-multidestino'); ?></option>
                            <?php foreach ($statuses as $skey => $sinfo) : ?>
                                <option value="<?php echo esc_attr($skey); ?>" <?php selected($filter_status, $skey); ?>>
                                    <?php echo $sinfo['icon'] . ' ' . esc_html($sinfo['label']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- Filtro Departamento Inteligente según perfil -->
                    <?php if ($can_view_dashboard) : ?>
                        <div class="cm-tool-item">
                            <select name="dept_filter" onchange="this.form.submit()" class="cm-apple-select">
                                <option value=""><?php _e('Áreas (Todas)', 'contacto-multidestino'); ?></option>
                                <?php foreach ($departments as $dkey => $dinfo) : 
                                    $dname = is_array($dinfo) ? ($dinfo['name'] ?? $dkey) : $dinfo;
                                ?>
                                    <option value="<?php echo esc_attr($dname); ?>" <?php selected($requested_dept, $dname); ?>>
                                        🏢 <?php echo esc_html($dname); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    <?php elseif (!empty($user_assigned_depts) && count($user_assigned_depts) > 1) : ?>
                        <div class="cm-tool-item">
                            <select name="dept_filter" onchange="this.form.submit()" class="cm-apple-select">
                                <option value=""><?php printf(__('🏢 Mis Áreas (%d)', 'contacto-multidestino'), count($user_assigned_depts)); ?></option>
                                <?php foreach ($user_assigned_depts as $dname) : ?>
                                    <option value="<?php echo esc_attr($dname); ?>" <?php selected($requested_dept, $dname); ?>>
                                        🏢 <?php echo esc_html($dname); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    <?php elseif (!empty($user_assigned_dept)) : ?>
                        <div class="cm-tool-item">
                            <span class="cm-tag-dept" style="padding:5px 10px; font-size:12.5px;">
                                🏢 <?php printf(__('Área: %s', 'contacto-multidestino'), esc_html($user_assigned_dept)); ?>
                            </span>
                        </div>
                    <?php endif; ?>

                    <!-- Buscador Apple Minimalista -->
                    <div class="cm-tool-item cm-tool-search">
                        <div class="cm-search-wrap">
                            <span class="dashicons dashicons-search cm-search-icon"></span>
                            <input 
                                type="search" 
                                name="s" 
                                value="<?php echo esc_attr($search_query); ?>" 
                                placeholder="<?php esc_attr_e('Buscar por código, solicitante, correo...', 'contacto-multidestino'); ?>" 
                                class="cm-apple-search-input"
                            />
                        </div>
                        <?php if ($filter_form || $filter_status || ($filter_dept && $is_superadmin) || $search_query) : ?>
                            <a href="<?php echo cm_get_view_tab_url('inbox'); ?>" class="cm-btn-clear-filter" title="<?php esc_attr_e('Limpiar filtros', 'contacto-multidestino'); ?>">
                                ✕ <?php _e('Limpiar', 'contacto-multidestino'); ?>
                            </a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>

            <!-- Pestañas de Filtrado Rápido (Todos / Activos / Completados) -->
            <?php
            $bucket_all_url    = add_query_arg(array('filter_bucket'=>'all', 'form_filter'=>$filter_form, 'status_filter'=>'', 'dept_filter'=>$requested_dept, 's'=>$search_query), cm_get_view_tab_url('inbox'));
            $bucket_active_url = add_query_arg(array('filter_bucket'=>'active', 'form_filter'=>$filter_form, 'status_filter'=>'', 'dept_filter'=>$requested_dept, 's'=>$search_query), cm_get_view_tab_url('inbox'));
            $bucket_comp_url   = add_query_arg(array('filter_bucket'=>'completed', 'form_filter'=>$filter_form, 'status_filter'=>'', 'dept_filter'=>$requested_dept, 's'=>$search_query), cm_get_view_tab_url('inbox'));
            ?>
            <div class="cm-inbox-buckets-bar" style="display:flex; align-items:center; gap:8px; margin-bottom:12px; flex-wrap:wrap;">
                <a href="<?php echo esc_url($bucket_all_url); ?>" 
                   style="text-decoration:none; display:inline-flex; align-items:center; gap:6px; padding:6px 14px; border-radius:20px; font-size:12px; font-weight:700; transition:all 0.2s; <?php echo $filter_bucket === 'all' ? 'background:#0f172a; color:#ffffff; box-shadow:0 2px 6px rgba(15,23,42,0.25);' : 'background:#ffffff; color:#475569; border:1px solid #e2e8f0;'; ?>">
                    📋 <?php _e('Todos los Casos', 'contacto-multidestino'); ?>
                    <span style="font-size:11px; padding:1px 6px; border-radius:10px; <?php echo $filter_bucket === 'all' ? 'background:rgba(255,255,255,0.2); color:#ffffff;' : 'background:#f1f5f9; color:#64748b;'; ?>">
                        <?php echo (int)$total_cases_count; ?>
                    </span>
                </a>
                <a href="<?php echo esc_url($bucket_active_url); ?>" 
                   style="text-decoration:none; display:inline-flex; align-items:center; gap:6px; padding:6px 14px; border-radius:20px; font-size:12px; font-weight:700; transition:all 0.2s; <?php echo $filter_bucket === 'active' ? 'background:#dc2626; color:#ffffff; box-shadow:0 2px 6px rgba(220,38,38,0.25);' : 'background:#ffffff; color:#dc2626; border:1px solid #fca5a5;'; ?>">
                    🔥 <?php _e('Activos / En Trámite', 'contacto-multidestino'); ?>
                    <span style="font-size:11px; padding:1px 6px; border-radius:10px; <?php echo $filter_bucket === 'active' ? 'background:rgba(255,255,255,0.2); color:#ffffff;' : 'background:#fee2e2; color:#991b1b;'; ?>">
                        <?php echo (int)$active_cases_count; ?>
                    </span>
                </a>
                <a href="<?php echo esc_url($bucket_comp_url); ?>" 
                   style="text-decoration:none; display:inline-flex; align-items:center; gap:6px; padding:6px 14px; border-radius:20px; font-size:12px; font-weight:700; transition:all 0.2s; <?php echo $filter_bucket === 'completed' ? 'background:#16a34a; color:#ffffff; box-shadow:0 2px 6px rgba(22,163,74,0.25);' : 'background:#ffffff; color:#15803d; border:1px solid #bbf7d0;'; ?>">
                    ✅ <?php _e('Completados / Finalizados', 'contacto-multidestino'); ?>
                    <span style="font-size:11px; padding:1px 6px; border-radius:10px; <?php echo $filter_bucket === 'completed' ? 'background:rgba(255,255,255,0.2); color:#ffffff;' : 'background:#f0fdf4; color:#166534;'; ?>">
                        <?php echo (int)$completed_cases_count; ?>
                    </span>
                </a>
            </div>

            <!-- Contenedor Flotante de Avisos en Vivo -->
            

            <!-- Tabla de Casos Compacta y Elegante -->
            <div class="cm-apple-table-card">
                <table class="cm-table-apple">
                    <thead>
                        <tr>
                            <th style="width: 140px;"><?php _e('Código / Portal', 'contacto-multidestino'); ?></th>
                            <th style="width: 190px;"><?php _e('Solicitante', 'contacto-multidestino'); ?></th>
                            <th style="width: 160px;"><?php _e('Área Asignada', 'contacto-multidestino'); ?></th>
                            <th><?php _e('Formulario / Asunto', 'contacto-multidestino'); ?></th>
                            <th style="width: 130px;"><?php _e('Fecha', 'contacto-multidestino'); ?></th>
                            <th style="width: 160px;"><?php _e('Estado Actual', 'contacto-multidestino'); ?></th>
                            <th style="width: 110px; text-align: center;"><?php _e('Acción', 'contacto-multidestino'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($submissions)) : ?>
                            <?php foreach ($submissions as $sub) : 
                                $status_key  = $sub->status;
                                $status_info = isset($statuses[$status_key]) ? $statuses[$status_key] : array(
                                    'label'    => ucfirst($status_key),
                                    'color'    => '#475569',
                                    'bg_color' => '#f1f5f9',
                                    'icon'     => '📌'
                                );
                                $date_short = date_i18n('d/m/y H:i', strtotime($sub->created_at));
                                $tracker_url = function_exists('cm_get_case_tracker_url') ? cm_get_case_tracker_url($sub->ticket_code) : home_url('/?codigo=' . $sub->ticket_code);
                                
                                // Color de acento de fila por estado
                                $row_border = '#cbd5e1';
                                $row_bg     = '#ffffff';
                                if ($status_key === 'recibido') {
                                    $row_border = '#ef4444'; // 🔴 Rojo Alerta
                                    $row_bg     = '#fffdfd';
                                } elseif ($status_key === 'en_revision') {
                                    $row_border = '#f59e0b'; // 🟡 Amarillo / Ámbar
                                    $row_bg     = '#fffdfa';
                                } elseif ($status_key === 'en_proceso') {
                                    $row_border = '#10b981'; // 🟢 Verde / Tomado
                                    $row_bg     = '#f7fdfa';
                                } elseif ($status_key === 'pendiente_usuario') {
                                    $row_border = '#8b5cf6'; // 🟣 Púrpura
                                    $row_bg     = '#faf5ff';
                                } elseif ($status_key === 'resuelto' || $status_key === 'cerrado') {
                                    $row_border = '#94a3b8'; // ⚪ Gris
                                    $row_bg     = '#f8fafc';
                                }
                            ?>
                                <tr id="cm-row-<?php echo esc_attr($sub->id); ?>" class="cm-table-row" style="border-left: 4.5px solid <?php echo esc_attr($row_border); ?> !important; background: <?php echo esc_attr($row_bg); ?>;">
                                    <td>
                                        <code class="cm-tag-code"><?php echo esc_html($sub->ticket_code); ?></code>
                                        <div style="margin-top:4px;">
                                            <a href="<?php echo cm_get_case_view_url($sub->id); ?>" class="cm-portal-link-btn" title="<?php esc_attr_e('Ver Expediente Oficial en Página Completa', 'contacto-multidestino'); ?>" style="font-size:10.5px; font-weight:700; color:#0284c7; text-decoration:none; display:inline-flex; align-items:center; gap:3px; background:#e0f2fe; padding:2px 7px; border-radius:5px; border:1px solid #bae6fd;">
                                                🖥️ <?php _e('Ver Caso', 'contacto-multidestino'); ?>
                                            </a>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="cm-cell-name"><?php echo esc_html($sub->sender_name ? $sub->sender_name : 'Anónimo'); ?></div>
                                        <?php if ($sub->sender_email) : ?>
                                            <div class="cm-cell-sub">✉️ <?php echo esc_html($sub->sender_email); ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="cm-tag-dept" id="cm-row-dept-<?php echo esc_attr($sub->id); ?>">
                                            🏢 <?php echo esc_html($sub->department ? $sub->department : 'General'); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="cm-cell-form"><?php echo esc_html($sub->form_name ? $sub->form_name : $sub->form_id); ?></div>
                                    </td>
                                    <td>
                                        <span class="cm-cell-date"><?php echo esc_html($date_short); ?></span>
                                    </td>
                                    <td>
                                        <span class="cm-badge-status" id="cm-status-pill-<?php echo esc_attr($sub->id); ?>" style="background-color: <?php echo esc_attr($status_info['bg_color']); ?>; color: <?php echo esc_attr($status_info['color']); ?>; border-color: <?php echo esc_attr($status_info['border'] ?? $status_info['color']); ?>;">
                                            <?php echo $status_info['icon'] . ' ' . esc_html($status_info['label']); ?>
                                        </span>
                                    </td>
                                    <td style="text-align: center;">
                                        <div class="cm-action-group">
                                            <button 
                                                type="button" 
                                                class="cm-btn-view" 
                                                onclick="cmOpenCaseModal(<?php echo esc_attr($sub->id); ?>)" 
                                                title="<?php esc_attr_e('Abrir en Modal Flotante', 'contacto-multidestino'); ?>"
                                            >
                                                👁️ <?php _e('Modal', 'contacto-multidestino'); ?>
                                            </button>
                                            <a 
                                                href="<?php echo cm_get_case_view_url($sub->id); ?>" 
                                                class="cm-apple-btn-secondary" 
                                                style="font-size:11px; padding:3px 8px; height:26px; display:inline-flex; align-items:center; gap:3px; text-decoration:none; font-weight:700; color:#0f172a; background:#f8fafc; border-color:#cbd5e1;" 
                                                title="<?php esc_attr_e('Ver Expediente Oficial en Página Completa', 'contacto-multidestino'); ?>"
                                            >
                                                🖥️ <?php _e('Ver Página', 'contacto-multidestino'); ?>
                                            </a>
                                            <button 
                                                type="button" 
                                                class="cm-btn-del" 
                                                onclick="cmDeleteCase(<?php echo esc_attr($sub->id); ?>)" 
                                                title="<?php esc_attr_e('Eliminar', 'contacto-multidestino'); ?>"
                                            >
                                                🗑️
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="7" class="cm-empty-cell">
                                    <div class="cm-empty-wrap">
                                        <span class="dashicons dashicons-inbox cm-empty-icon"></span>
                                        <h4><?php _e('No hay casos registrados', 'contacto-multidestino'); ?></h4>
                                        <p><?php _e('Los mensajes enviados desde tus formularios aparecerán ordenados aquí en tiempo real.', 'contacto-multidestino'); ?></p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Paginación Compacta -->
            <?php if ($total_pages > 1) : ?>
                <div class="cm-pagination-bar">
                    <span><?php printf(__('Total: %d casos', 'contacto-multidestino'), $total_items); ?></span>
                    <div class="cm-page-links">
                        <?php
                        echo paginate_links(array(
                            'base'      => add_query_arg('paged', '%#%'),
                            'format'    => '',
                            'prev_text' => '&lsaquo;',
                            'next_text' => '&rsaquo;',
                            'total'     => $total_pages,
                            'current'   => $current_page,
                        ));
                        ?>
                    </div>
                </div>
            <?php endif; ?>

        <?php elseif ($active_tab === 'departments') : ?>
            <!-- ══════════════════════════════════════════════════════════
                 PESTAÑA: GESTIÓN DE ÁREAS Y ENCARGADOS (ESTILO PHOENIX SAAS)
                 ══════════════════════════════════════════════════════════ -->
            <div class="cm-apple-card-panel" style="background:#ffffff; border:1px solid #e2e8f0; border-radius:14px; box-shadow:0 1px 4px rgba(0,0,0,0.03); overflow:hidden; padding:0; margin-bottom:24px;">
                <!-- Header de Tarjeta Phoenix -->
                <div style="display:flex; align-items:center; justify-content:space-between; padding:18px 24px; border-bottom:1px solid #edf2f9; background:#ffffff; flex-wrap:wrap; gap:12px;">
                    <div>
                        <div style="display:flex; align-items:center; gap:8px;">
                            <h2 style="font-size:16px; font-weight:800; color:#0f172a; margin:0; line-height:1.2;">
                                🏢 <?php _e('Departamentos y Áreas de Atención', 'contacto-multidestino'); ?>
                            </h2>
                            <span style="font-size:11px; font-weight:700; background:#e0edff; color:#2563eb; border:1px solid #bfdbfe; padding:2px 8px; border-radius:20px;">
                                <?php echo count($departments); ?> <?php _e('áreas', 'contacto-multidestino'); ?>
                            </span>
                        </div>
                        <p style="margin:4px 0 0 0; font-size:12px; color:#64748b;">
                            <?php _e('Habilita, edita o asigna encargados responsables a cada área. Las áreas deshabilitadas no aceptarán solicitudes.', 'contacto-multidestino'); ?>
                        </p>
                    </div>
                    <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
                        <button type="button" class="cm-btn-view" style="font-size:12.5px; padding:7px 16px; height:34px;" onclick="cmOpenNewDeptModal()">
                            ➕ <?php _e('Nueva Área', 'contacto-multidestino'); ?>
                        </button>
                        <button type="button" class="cm-apple-btn-secondary" style="font-size:12.5px; padding:7px 16px; height:34px; font-weight:700;" onclick="cmOpenNewUserModal()">
                            👤 <?php _e('Crear Usuario', 'contacto-multidestino'); ?>
                        </button>
                    </div>
                </div>

                <!-- Banner Informativo con URL de Acceso para Encargados (Estilo Phoenix Alert) -->
                <div style="padding:14px 24px; background:#f8fafc; border-bottom:1px solid #edf2f9;">
                    <div style="background:#f0f7ff; border:1px solid #bae6fd; border-radius:10px; padding:12px 16px; display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:12px;">
                        <div style="display:flex; align-items:center; gap:10px;">
                            <span style="font-size:20px; line-height:1;">🔗</span>
                            <div>
                                <strong style="color:#0369a1; font-size:12.5px; font-weight:800;"><?php _e('Enlace de Acceso Directo para Encargados de Área:', 'contacto-multidestino'); ?></strong>
                                <div style="font-size:11.5px; color:#475569; margin-top:2px;">
                                    <?php _e('Comparte esta URL con los encargados para que ingresen directo a su bandeja:', 'contacto-multidestino'); ?>
                                </div>
                            </div>
                        </div>
                        <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
                            <code style="font-size:12px; font-weight:700; color:#0369a1; background:#ffffff; border:1px solid #bfdbfe; padding:4px 10px; border-radius:6px; font-family:monospace;">
                                <?php echo esc_url(admin_url('admin.php?page=cm-form-submissions')); ?>
                            </code>
                            <button type="button" class="cm-btn-view" style="font-size:11.5px; padding:4px 12px; height:28px; background:#0284c7;" onclick="navigator.clipboard.writeText('<?php echo esc_url(admin_url('admin.php?page=cm-form-submissions')); ?>'); alert('✓ ¡Enlace copiado al portapapeles!');">
                                📋 <?php _e('Copiar', 'contacto-multidestino'); ?>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Tabla de Departamentos (Estilo Phoenix Data Table) -->
                <div style="overflow-x:auto; -webkit-overflow-scrolling:touch; width:100%;">
                    <table style="width:100%; border-collapse:collapse; font-size:13px; min-width:850px; margin:0;">
                        <thead>
                            <tr style="border-bottom:2px solid #edf2f9; background:#f8fafc;">
                                <th style="padding:12px 20px; text-align:left; font-size:10.5px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.06em; width:28%;"><?php _e('Área / Departamento', 'contacto-multidestino'); ?></th>
                                <th style="padding:12px 18px; text-align:left; font-size:10.5px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.06em; width:26%;"><?php _e('Correos de Notificación', 'contacto-multidestino'); ?></th>
                                <th style="padding:12px 18px; text-align:left; font-size:10.5px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.06em; width:20%;"><?php _e('Encargado', 'contacto-multidestino'); ?></th>
                                <th style="padding:12px 14px; text-align:center; font-size:10.5px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.06em; width:12%;"><?php _e('Auto-Respuesta', 'contacto-multidestino'); ?></th>
                                <th style="padding:12px 14px; text-align:center; font-size:10.5px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.06em; width:10%;"><?php _e('Estado', 'contacto-multidestino'); ?></th>
                                <th style="padding:12px 20px; text-align:center; font-size:10.5px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.06em; width:14%;"><?php _e('Acciones', 'contacto-multidestino'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($departments as $dkey => $ddata) : 
                                $dname        = is_array($ddata) ? ($ddata['name'] ?? $dkey) : $ddata;
                                $demails      = is_array($ddata) ? ($ddata['emails'] ?? '') : '';
                                $duser        = is_array($ddata) ? ($ddata['user'] ?? '') : '';
                                $duser_id     = is_array($ddata) ? ($ddata['user_id'] ?? 0) : 0;
                                $denabled     = is_array($ddata) ? (!empty($ddata['enabled'])) : true;
                                $d_ar_enabled = is_array($ddata) ? (!empty($ddata['auto_reply_enabled'])) : false;
                                $d_ar_delay   = is_array($ddata) ? (int)($ddata['auto_reply_delay'] ?? 0) : 0;
                                $d_ar_msg     = is_array($ddata) ? ($ddata['auto_reply_msg'] ?? '') : '';
                                $d_ar_status  = is_array($ddata) ? ($ddata['auto_reply_status'] ?? 'en_proceso') : 'en_proceso';
                                $delay_label  = $d_ar_delay > 0 ? sprintf(__('⏱️ %d min', 'contacto-multidestino'), $d_ar_delay) : __('⚡ Inmediata', 'contacto-multidestino');
                            ?>
                                <tr id="cm-dept-row-<?php echo esc_attr(sanitize_title($dname)); ?>" style="border-bottom:1px solid #f1f5f9; transition:background 0.15s ease;" onmouseover="this.style.background='#f8fafc';" onmouseout="this.style.background='';">
                                    <td style="padding:14px 20px;">
                                        <div style="display:flex; align-items:center; gap:8px;">
                                            <span style="font-size:15px;">🏢</span>
                                            <strong style="color:#0f172a; font-size:13px; font-weight:700;"><?php echo esc_html($dname); ?></strong>
                                        </div>
                                    </td>
                                    <td style="padding:14px 18px;">
                                        <code style="font-size:11.5px; color:#475569; background:#f1f5f9; border:1px solid #e2e8f0; padding:3px 8px; border-radius:6px; font-family:monospace; display:inline-block; max-width:280px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="<?php echo esc_attr($demails ? $demails : get_option('admin_email')); ?>">
                                            <?php echo esc_html($demails ? $demails : get_option('admin_email')); ?>
                                        </code>
                                    </td>
                                    <td style="padding:14px 18px;">
                                        <div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap;">
                                            <span style="font-size:12px; font-weight:600; color:#334155; background:#f8fafc; border:1px solid #e2e8f0; padding:3px 9px; border-radius:6px; display:inline-flex; align-items:center; gap:4px;">
                                                👤 <?php echo esc_html($duser ? $duser : 'Administrador General'); ?>
                                            </span>
                                            <?php if ($duser_id > 0) : ?>
                                                <button 
                                                    type="button" 
                                                    class="cm-btn-copy-sm" 
                                                    style="font-size:10.5px; padding:2px 7px; background:#eff6ff; color:#2563eb; border:1px solid #bfdbfe; font-weight:700; cursor:pointer;" 
                                                    onclick="cmOpenResetPasswordModal(<?php echo esc_attr($duser_id); ?>, '<?php echo esc_attr(addslashes($duser)); ?>')" 
                                                    title="<?php esc_attr_e('Restablecer o cambiar la contraseña de este encargado', 'contacto-multidestino'); ?>"
                                                >
                                                    🔑 <?php _e('Clave', 'contacto-multidestino'); ?>
                                                </button>
                                                <a 
                                                    href="<?php echo esc_url(admin_url('user-edit.php?user_id=' . $duser_id)); ?>" 
                                                    target="_blank" 
                                                    class="cm-btn-copy-sm" 
                                                    style="font-size:10.5px; padding:2px 7px; text-decoration:none; background:#f8fafc; color:#64748b; border:1px solid #e2e8f0; font-weight:700;" 
                                                    title="<?php esc_attr_e('Editar perfil en WordPress', 'contacto-multidestino'); ?>"
                                                >
                                                    ✏️ <?php _e('Editar', 'contacto-multidestino'); ?>
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td style="padding:14px 14px; text-align:center;">
                                        <?php if ($d_ar_enabled) : ?>
                                            <span style="background:#ede9fe; color:#6d28d9; border:1px solid #ddd6fe; font-size:11px; font-weight:700; padding:3px 9px; border-radius:12px; display:inline-block; white-space:nowrap;">
                                                🤖 <?php echo esc_html($delay_label); ?>
                                            </span>
                                        <?php else : ?>
                                            <span style="color:#94a3b8; font-size:11px; background:#f8fafc; border:1px solid #e2e8f0; padding:2px 8px; border-radius:8px; display:inline-block;">
                                                ⚪ <?php _e('Inactiva', 'contacto-multidestino'); ?>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="padding:14px 14px; text-align:center;">
                                        <?php if ($denabled) : ?>
                                            <span style="font-size:11px; font-weight:700; color:#15803d; background:#dcfce7; border:1px solid #bbf7d0; padding:3px 9px; border-radius:12px; display:inline-block; white-space:nowrap;">
                                                🟢 <?php _e('Habilitada', 'contacto-multidestino'); ?>
                                            </span>
                                        <?php else : ?>
                                            <span style="font-size:11px; font-weight:700; color:#b91c1c; background:#fee2e2; border:1px solid #fecaca; padding:3px 9px; border-radius:12px; display:inline-block; white-space:nowrap;">
                                                🔴 <?php _e('Deshabilitada', 'contacto-multidestino'); ?>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="padding:14px 20px; text-align:center;">
                                        <div style="display:inline-flex; align-items:center; justify-content:center; gap:5px;">
                                            <button 
                                                type="button" 
                                                class="cm-btn-view" 
                                                style="font-size:11.5px; padding:4px 10px; height:28px;"
                                                onclick='cmOpenEditDeptModal(<?php echo json_encode($dname); ?>, <?php echo json_encode($demails); ?>, <?php echo (int)$duser_id; ?>, <?php echo $denabled ? 1 : 0; ?>, <?php echo $d_ar_enabled ? 1 : 0; ?>, <?php echo (int)$d_ar_delay; ?>, <?php echo json_encode($d_ar_msg); ?>, <?php echo json_encode($d_ar_status); ?>)'
                                                title="<?php esc_attr_e('Editar configuración del área', 'contacto-multidestino'); ?>"
                                            >
                                                ✏️ <?php _e('Editar', 'contacto-multidestino'); ?>
                                            </button>
                                            <button 
                                                type="button" 
                                                class="cm-btn-del" 
                                                style="height:28px; padding:4px 8px; color:<?php echo $denabled ? '#b45309' : '#15803d'; ?> !important; background:<?php echo $denabled ? '#fef3c7' : '#dcfce7'; ?>; border-color:<?php echo $denabled ? '#fde68a' : '#bbf7d0'; ?>;" 
                                                onclick="cmToggleDeptStatus('<?php echo esc_attr(addslashes($dname)); ?>')" 
                                                title="<?php echo $denabled ? esc_attr__('Pausar / Deshabilitar área', 'contacto-multidestino') : esc_attr__('Habilitar área', 'contacto-multidestino'); ?>"
                                            >
                                                <?php echo $denabled ? '⏸️' : '▶️'; ?>
                                            </button>
                                            <button 
                                                type="button" 
                                                class="cm-btn-del" 
                                                style="height:28px; padding:4px 8px;"
                                                onclick="cmDeleteDept('<?php echo esc_attr(addslashes($dname)); ?>')" 
                                                title="<?php esc_attr_e('Eliminar Área', 'contacto-multidestino'); ?>"
                                            >
                                                🗑️
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- ╔══════════════════════════════════════════╗ -->
            <!-- ║  USUARIOS DEL SISTEMA — LISTA PHOENIX    ║ -->
            <!-- ╚══════════════════════════════════════════╝ -->

            <!-- Panel lateral: Perfil de Usuario (Liquid Glassmorphism Apple / iOS 18) -->
            <div id="cm-user-profile-panel" style="position:fixed; top:0; right:-430px; width:400px; max-width:96vw; height:100vh; background:rgba(255,255,255,0.78); backdrop-filter:blur(28px) saturate(190%); -webkit-backdrop-filter:blur(28px) saturate(190%); border-left:1px solid rgba(255,255,255,0.7); box-shadow:-12px 0 45px rgba(15,23,42,0.12), inset 1px 0 0 rgba(255,255,255,0.9); z-index:99999; display:flex; flex-direction:column; overflow:hidden; font-family:inherit; transition:right 0.3s cubic-bezier(0.16, 1, 0.3, 1);">
                <!-- Cabecera Glass -->
                <div style="background:rgba(255,255,255,0.5); backdrop-filter:blur(10px); border-bottom:1px solid rgba(226,232,240,0.7); padding:14px 18px; display:flex; align-items:center; justify-content:space-between; flex-shrink:0;">
                    <div style="display:flex; align-items:center; gap:8px;">
                        <span style="font-size:14px;">✨</span>
                        <span style="font-size:11px; font-weight:800; color:#475569; text-transform:uppercase; letter-spacing:0.08em;">Ficha de Usuario</span>
                    </div>
                    <button type="button" onclick="cmCloseUserPanel()" style="background:rgba(241,245,249,0.7); border:1px solid rgba(255,255,255,0.9); color:#475569; width:26px; height:26px; border-radius:50%; cursor:pointer; font-size:12px; line-height:1; display:flex; align-items:center; justify-content:center; transition:all 0.15s ease;" onmouseover="this.style.background='rgba(254,226,226,0.8)'; this.style.color='#dc2626';" onmouseout="this.style.background='rgba(241,245,249,0.7)'; this.style.color='#475569';">&#x2715;</button>
                </div>
                <!-- Body scrolleable -->
                <div style="flex:1; overflow-y:auto; -webkit-overflow-scrolling:touch; padding:14px;">
                    <!-- Hero Card Liquid Glass: avatar + datos -->
                    <div style="background:rgba(255,255,255,0.65); border:1px solid rgba(255,255,255,0.9); backdrop-filter:blur(16px); border-radius:16px; padding:18px 14px; text-align:center; box-shadow:0 4px 20px rgba(0,0,0,0.03); margin-bottom:12px;">
                        <div id="cm-upp-avatar" style="width:58px; height:58px; border-radius:50%; margin:0 auto 10px; display:flex; align-items:center; justify-content:center; font-size:20px; font-weight:800; box-shadow:0 0 0 4px rgba(255,255,255,0.9), 0 4px 14px rgba(0,0,0,0.08);"></div>
                        <div id="cm-upp-name" style="font-size:15.5px; font-weight:800; color:#0f172a; line-height:1.2;"></div>
                        <div id="cm-upp-login" style="font-size:12px; color:#64748b; font-family:monospace; margin-top:2px;"></div>
                        <div id="cm-upp-email" style="margin-top:6px;"></div>
                        <div id="cm-upp-badges" style="margin-top:10px; display:flex; align-items:center; justify-content:center; flex-wrap:wrap; gap:6px;"></div>
                    </div>

                    <!-- Glass Card: Perfil y Permisos -->
                    <div style="background:rgba(255,255,255,0.6); border:1px solid rgba(255,255,255,0.85); backdrop-filter:blur(14px); border-radius:14px; padding:14px 16px; box-shadow:0 2px 12px rgba(0,0,0,0.02); margin-bottom:12px;">
                        <div style="font-size:10px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.07em; margin-bottom:10px;">
                            🛡️ Perfil y Nivel de Acceso
                        </div>
                        <div style="display:flex; flex-direction:column; gap:9px;">
                            <div style="display:flex; align-items:center; justify-content:space-between;">
                                <span style="font-size:12px; color:#64748b; font-weight:600;">Rol Asignado</span>
                                <div id="cm-upp-role"></div>
                            </div>
                            <div style="display:flex; align-items:center; justify-content:space-between;">
                                <span style="font-size:12px; color:#64748b; font-weight:600;">Derivación de Casos</span>
                                <div id="cm-upp-reassign"></div>
                            </div>
                            <div style="display:flex; align-items:center; justify-content:space-between;">
                                <span style="font-size:12px; color:#64748b; font-weight:600;">Seguridad 2FA</span>
                                <div id="cm-upp-2fa-badge"></div>
                            </div>
                        </div>
                    </div>

                    <!-- Glass Card: Áreas Asignadas -->
                    <div style="background:rgba(255,255,255,0.6); border:1px solid rgba(255,255,255,0.85); backdrop-filter:blur(14px); border-radius:14px; padding:14px 16px; box-shadow:0 2px 12px rgba(0,0,0,0.02); margin-bottom:12px;">
                        <div style="font-size:10px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.07em; margin-bottom:8px;">
                            🏢 Departamentos Asignados
                        </div>
                        <div id="cm-upp-areas" style="display:flex; flex-wrap:wrap; gap:6px;"></div>
                    </div>

                    <!-- Glass Card: Acciones Disponibles -->
                    <div style="background:rgba(255,255,255,0.6); border:1px solid rgba(255,255,255,0.85); backdrop-filter:blur(14px); border-radius:14px; padding:14px 16px; box-shadow:0 2px 12px rgba(0,0,0,0.02);">
                        <div style="font-size:10px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.07em; margin-bottom:10px;">
                            ⚡ Acciones Rápidas
                        </div>
                        <div style="display:flex; flex-direction:column; gap:7px;">
                            <button type="button" id="cm-upp-btn-areas" class="cm-glass-act-btn" style="width:100%; display:flex; align-items:center; gap:8px; font-size:12px; font-weight:700; color:#1e293b; background:rgba(255,255,255,0.7); border:1px solid rgba(255,255,255,0.9); padding:9px 12px; border-radius:10px; cursor:pointer; text-align:left; transition:all 0.15s ease; box-shadow:0 1px 3px rgba(0,0,0,0.03);" onmouseover="this.style.background='rgba(255,255,255,0.95)'; this.style.borderColor='#3874ff'; this.style.color='#2563eb'; this.style.transform='translateY(-1px)';" onmouseout="this.style.background='rgba(255,255,255,0.7)'; this.style.borderColor='rgba(255,255,255,0.9)'; this.style.color='#1e293b'; this.style.transform='';">
                                🏢 <?php _e('Gestionar Áreas y Rol', 'contacto-multidestino'); ?>
                            </button>
                            <button type="button" id="cm-upp-btn-pass" class="cm-glass-act-btn" style="width:100%; display:flex; align-items:center; gap:8px; font-size:12px; font-weight:700; color:#1e293b; background:rgba(255,255,255,0.7); border:1px solid rgba(255,255,255,0.9); padding:9px 12px; border-radius:10px; cursor:pointer; text-align:left; transition:all 0.15s ease; box-shadow:0 1px 3px rgba(0,0,0,0.03);" onmouseover="this.style.background='rgba(255,255,255,0.95)'; this.style.borderColor='#3874ff'; this.style.color='#2563eb'; this.style.transform='translateY(-1px)';" onmouseout="this.style.background='rgba(255,255,255,0.7)'; this.style.borderColor='rgba(255,255,255,0.9)'; this.style.color='#1e293b'; this.style.transform='';">
                                🔑 <?php _e('Cambiar Contraseña', 'contacto-multidestino'); ?>
                            </button>
                            <a id="cm-upp-btn-wp" href="#" target="_blank" class="cm-glass-act-btn" style="width:100%; display:flex; align-items:center; gap:8px; font-size:12px; font-weight:700; color:#1e293b; background:rgba(255,255,255,0.7); border:1px solid rgba(255,255,255,0.9); padding:9px 12px; border-radius:10px; text-decoration:none; transition:all 0.15s ease; box-shadow:0 1px 3px rgba(0,0,0,0.03); box-sizing:border-box;" onmouseover="this.style.background='rgba(255,255,255,0.95)'; this.style.borderColor='#3874ff'; this.style.color='#2563eb'; this.style.transform='translateY(-1px)';" onmouseout="this.style.background='rgba(255,255,255,0.7)'; this.style.borderColor='rgba(255,255,255,0.9)'; this.style.color='#1e293b'; this.style.transform='';">
                                ✏️ <?php _e('Editar Perfil en WordPress', 'contacto-multidestino'); ?> ↗
                            </a>
                            <button type="button" id="cm-upp-btn-2fa" class="cm-glass-act-btn" style="width:100%; display:flex; align-items:center; gap:8px; font-size:12px; font-weight:700; color:#1e293b; background:rgba(255,255,255,0.7); border:1px solid rgba(255,255,255,0.9); padding:9px 12px; border-radius:10px; cursor:pointer; text-align:left; transition:all 0.15s ease; box-shadow:0 1px 3px rgba(0,0,0,0.03);" onmouseover="this.style.background='rgba(255,255,255,0.95)'; this.style.borderColor='#3874ff'; this.style.color='#2563eb'; this.style.transform='translateY(-1px)';" onmouseout="this.style.background='rgba(255,255,255,0.7)'; this.style.borderColor='rgba(255,255,255,0.9)'; this.style.color='#1e293b'; this.style.transform='';">
                                🛡️ <?php _e('Gestionar 2FA', 'contacto-multidestino'); ?>
                            </button>
                            <div id="cm-upp-btn-suspend-wrap">
                                <button type="button" id="cm-upp-btn-suspend" class="cm-glass-act-btn" style="width:100%; display:flex; align-items:center; gap:8px; font-size:12px; font-weight:700; color:#dc2626; background:rgba(254,242,242,0.7); border:1px solid rgba(254,202,202,0.8); padding:9px 12px; border-radius:10px; cursor:pointer; text-align:left; transition:all 0.15s ease; box-shadow:0 1px 3px rgba(0,0,0,0.03);" onmouseover="this.style.background='rgba(254,226,226,0.95)'; this.style.transform='translateY(-1px)';" onmouseout="this.style.background='rgba(254,242,242,0.7)'; this.style.transform='';">
                                    ⛔ <?php _e('Suspender Acceso', 'contacto-multidestino'); ?>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Overlay Liquid Glass con Blur Profundo -->
            <div id="cm-user-panel-overlay" onclick="cmCloseUserPanel()" style="display:none; position:fixed; inset:0; background:rgba(15,23,42,0.25); backdrop-filter:blur(8px) saturate(160%); -webkit-backdrop-filter:blur(8px) saturate(160%); z-index:99998; transition:opacity 0.25s ease;"></div>

            <!-- Lista compacta de usuarios (Phoenix Card) -->
            <div class="cm-members-card" style="background:#ffffff; border:1px solid #e2e8f0; border-radius:14px; box-shadow:0 1px 4px rgba(0,0,0,0.03); overflow:hidden; margin-top:24px;">
                <div style="display:flex; align-items:center; justify-content:space-between; padding:18px 24px; border-bottom:1px solid #edf2f9; background:#ffffff; flex-wrap:wrap; gap:12px;">
                    <div>
                        <div style="display:flex; align-items:center; gap:8px;">
                            <h3 style="font-size:15px; font-weight:800; margin:0; color:#0f172a;">
                                👥 Usuarios del Sistema y Control de Cuentas
                            </h3>
                            <span style="font-size:11px; font-weight:700; background:#f1f5f9; color:#475569; border:1px solid #e2e8f0; padding:2px 8px; border-radius:20px;">
                                <?php echo count($wp_users); ?> <?php _e('usuarios', 'contacto-multidestino'); ?>
                            </span>
                        </div>
                        <p style="margin:4px 0 0 0; font-size:12px; color:#64748b;">
                            <?php _e('Haz clic en cualquier fila para ver el perfil completo, modificar áreas asignadas o gestionar seguridad.', 'contacto-multidestino'); ?>
                        </p>
                    </div>
                    <button type="button" class="cm-btn-view" style="font-size:12px; padding:6px 14px; height:32px;" onclick="cmOpenNewUserModal()">
                        + Nuevo Usuario
                    </button>
                </div>

                <div style="overflow-x:auto; -webkit-overflow-scrolling:touch; width:100%;">
                    <table style="width:100%; border-collapse:collapse; font-size:13px; min-width:560px; margin:0;">
                        <thead>
                            <tr style="border-bottom:2px solid #edf2f9; background:#f8fafc;">
                                <th style="padding:12px 20px; text-align:left; font-size:10.5px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.06em; width:40%;">Usuario</th>
                                <th style="padding:12px 18px; text-align:left; font-size:10.5px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.06em; width:30%;">Correo</th>
                                <th style="padding:12px 16px; text-align:center; font-size:10.5px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.06em; width:15%;">Estado</th>
                                <th style="padding:12px 16px; text-align:center; font-size:10.5px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.06em; width:15%;">Rol</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $avatar_palettes = array(
                                array('bg' => '#dbeafe', 'color' => '#1e40af'),
                                array('bg' => '#fef3c7', 'color' => '#92400e'),
                                array('bg' => '#ede9fe', 'color' => '#5b21b6'),
                                array('bg' => '#dcfce7', 'color' => '#166534'),
                                array('bg' => '#fee2e2', 'color' => '#991b1b'),
                                array('bg' => '#fce7f3', 'color' => '#9d174d'),
                                array('bg' => '#ccfbf1', 'color' => '#134e4a'),
                            );
                            foreach ($wp_users as $u) :
                                $is_suspended     = get_user_meta($u->ID, 'cm_user_suspended', true);
                                $user_2fa_enabled = function_exists('cm_is_2fa_enabled') && cm_is_2fa_enabled($u->ID);
                                $user_2fa_date    = function_exists('cm_get_2fa_activated_at') ? cm_get_2fa_activated_at($u->ID) : '';
                                $user_obj         = new WP_User($u->ID);
                                $is_admin         = in_array('administrator', (array)$user_obj->roles);
                                $user_profile     = get_user_meta($u->ID, 'cm_user_profile', true);
                                $user_deps        = function_exists('cm_get_user_assigned_departments') ? cm_get_user_assigned_departments($u->ID) : array();
                                $is_wp_superadmin = $is_admin;
                                $is_dir_profile   = ($user_profile === 'director');
                                $is_mod_profile   = ($user_profile === 'moderator' || $user_profile === 'subdirector');
                                $user_allow_reassign = get_user_meta($u->ID, 'cm_allow_reassign', true);
                                $can_reassign_val    = ($user_allow_reassign !== '0');
                                $display_name_clean  = $u->display_name ? $u->display_name : $u->user_login;
                                $initials            = strtoupper(mb_substr($display_name_clean, 0, 2));
                                $pal                 = $avatar_palettes[$u->ID % count($avatar_palettes)];

                                if ($is_wp_superadmin) { $role_label = 'Superadmin'; $role_bg = '#fee2e2'; $role_c = '#991b1b'; }
                                elseif ($is_dir_profile) { $role_label = 'Director'; $role_bg = '#fef3c7'; $role_c = '#92400e'; }
                                elseif ($is_mod_profile) { $role_label = 'Moderador'; $role_bg = '#ede9fe'; $role_c = '#5b21b6'; }
                                else { $role_label = 'Encargado'; $role_bg = '#eff6ff'; $role_c = '#1e40af'; }

                                $panel_data = json_encode(array(
                                    'id'         => $u->ID,
                                    'login'      => $u->user_login,
                                    'name'       => $display_name_clean,
                                    'email'      => $u->user_email,
                                    'initials'   => $initials,
                                    'pal_bg'     => $pal['bg'],
                                    'pal_color'  => $pal['color'],
                                    'profile'    => $user_profile ? $user_profile : 'area_manager',
                                    'role_label' => $role_label,
                                    'role_bg'    => $role_bg,
                                    'role_c'     => $role_c,
                                    'is_admin'   => (bool)$is_wp_superadmin,
                                    'is_dir'     => (bool)$is_dir_profile,
                                    'is_mod'     => (bool)$is_mod_profile,
                                    'deps'       => array_values($user_deps),
                                    'reassign'   => (bool)$can_reassign_val,
                                    'suspended'  => (bool)$is_suspended,
                                    'twofa'      => (bool)$user_2fa_enabled,
                                    'twofa_date' => ($user_2fa_date ? date_i18n('d/m/Y H:i', strtotime($user_2fa_date)) : ''),
                                    'wp_edit_url'=> esc_url(admin_url('user-edit.php?user_id=' . $u->ID)),
                                    'current_uid'=> get_current_user_id(),
                                ));
                            ?>
                                <tr id="cm-user-row-<?php echo esc_attr($u->ID); ?>"
                                    onclick="cmOpenUserPanel(<?php echo htmlspecialchars($panel_data, ENT_QUOTES, 'UTF-8'); ?>)"
                                    style="cursor:pointer; border-bottom:1px solid #f1f5f9; transition:background 0.15s ease;"
                                    onmouseover="this.style.background='#f8fafc';" onmouseout="this.style.background='';">
                                    <td style="padding:14px 20px;">
                                        <div style="display:flex; align-items:center; gap:12px;">
                                            <div class="cm-user-avatar-circle" style="background:<?php echo esc_attr($pal['bg']); ?>; color:<?php echo esc_attr($pal['color']); ?>; flex-shrink:0; width:36px; height:36px; font-size:12.5px;">
                                                <?php echo esc_html($initials); ?>
                                            </div>
                                            <div>
                                                <div style="font-weight:700; color:#0f172a; font-size:13.5px; line-height:1.2;"><?php echo esc_html($display_name_clean); ?></div>
                                                <div style="font-size:11.5px; color:#64748b; font-family:monospace; margin-top:2px;">@<?php echo esc_html($u->user_login); ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td style="padding:14px 18px;">
                                        <span style="font-size:12.5px; color:#334155; font-weight:500;"><?php echo esc_html($u->user_email); ?></span>
                                    </td>
                                    <td style="padding:14px 16px; text-align:center;">
                                        <?php if ($is_suspended) : ?>
                                            <span style="font-size:11px; font-weight:700; color:#b91c1c; background:#fee2e2; border:1px solid #fecaca; padding:3px 10px; border-radius:12px; display:inline-block; white-space:nowrap;">⛔ Suspendido</span>
                                        <?php else : ?>
                                            <span style="font-size:11px; font-weight:700; color:#15803d; background:#dcfce7; border:1px solid #bbf7d0; padding:3px 10px; border-radius:12px; display:inline-block; white-space:nowrap;">🟢 Activo</span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="padding:14px 16px; text-align:center;">
                                        <span style="font-size:11px; font-weight:700; padding:3px 10px; border-radius:12px; display:inline-block; white-space:nowrap; background:<?php echo esc_attr($role_bg); ?>; color:<?php echo esc_attr($role_c); ?>; border:1px solid <?php echo esc_attr($role_c); ?>22;"><?php echo esc_html($role_label); ?></span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <script>
            function cmOpenUserPanel(data) {
                var av = document.getElementById('cm-upp-avatar');
                av.textContent = data.initials;
                av.style.background = data.pal_bg;
                av.style.color = data.pal_color;

                document.getElementById('cm-upp-name').textContent = data.name;
                document.getElementById('cm-upp-login').textContent = '@' + data.login;
                document.getElementById('cm-upp-email').innerHTML =
                    '<a href="mailto:' + data.email + '" style="color:#2563eb; font-size:12.5px; font-weight:600; text-decoration:none;" onclick="event.stopPropagation();">' + data.email + '</a>';

                var suspBadge = data.suspended
                    ? '<span style="font-size:11px;font-weight:700;color:#b91c1c;background:#fee2e2;border:1px solid #fecaca;padding:3px 10px;border-radius:12px;">⛔ Suspendido</span>'
                    : '<span style="font-size:11px;font-weight:700;color:#15803d;background:#dcfce7;border:1px solid #bbf7d0;padding:3px 10px;border-radius:12px;">🟢 Activo</span>';
                var tfaBadge = data.twofa
                    ? '<span style="font-size:11px;font-weight:700;color:#0369a1;background:#e0f2fe;border:1px solid #bae6fd;padding:3px 10px;border-radius:12px;">🛡️ 2FA Activo</span>'
                    : '<span style="font-size:11px;color:#64748b;background:#f1f5f9;border:1px solid #e2e8f0;padding:3px 10px;border-radius:12px;">2FA No activo</span>';
                document.getElementById('cm-upp-badges').innerHTML = suspBadge + tfaBadge;

                document.getElementById('cm-upp-role').innerHTML =
                    '<span style="font-size:11.5px;font-weight:700;padding:3px 10px;border-radius:8px;background:' + data.role_bg + ';color:' + data.role_c + ';border:1px solid ' + data.role_c + '33;">' + data.role_label + '</span>';

                document.getElementById('cm-upp-reassign').innerHTML = data.reassign
                    ? '<span style="font-size:11px;font-weight:700;color:#059669;background:#dcfce7;border:1px solid #bbf7d0;padding:3px 9px;border-radius:6px;">🔄 Puede derivar</span>'
                    : '<span style="font-size:11px;font-weight:700;color:#b45309;background:#fef9c3;border:1px solid #fde68a;padding:3px 9px;border-radius:6px;">🔒 Solo su área</span>';

                document.getElementById('cm-upp-2fa-badge').innerHTML = data.twofa
                    ? '<span style="font-size:11px;font-weight:700;color:#0369a1;background:#e0f2fe;border:1px solid #bae6fd;padding:3px 9px;border-radius:6px;">Activa' + (data.twofa_date ? ' · ' + data.twofa_date : '') + '</span>'
                    : '<span style="font-size:11px;color:#94a3b8;background:#f1f5f9;border:1px solid #e2e8f0;padding:3px 9px;border-radius:6px;">No activada</span>';

                var areasEl = document.getElementById('cm-upp-areas');
                if (data.is_admin || data.is_dir) {
                    areasEl.innerHTML = '<span style="font-size:12px;font-weight:700;color:#059669;background:#ecfdf5;border:1px solid #a7f3d0;padding:4px 10px;border-radius:6px;">🌐 Acceso global — todas las áreas</span>';
                } else if (data.deps && data.deps.length > 0) {
                    areasEl.innerHTML = data.deps.map(function(d) {
                        return '<span style="font-size:11.5px;font-weight:600;padding:3px 9px;background:#f0f9ff;color:#0369a1;border:1px solid #bae6fd;border-radius:6px;">🏢 ' + d + '</span>';
                    }).join('');
                } else {
                    areasEl.innerHTML = '<span style="font-size:12px;color:#94a3b8;font-style:italic;">Sin áreas asignadas</span>';
                }

                document.getElementById('cm-upp-btn-areas').onclick = function() {
                    cmOpenEditUserModal(data.id, data.login, data.name, data.email, data.profile, data.deps, data.reassign ? 1 : 0);
                };
                document.getElementById('cm-upp-btn-pass').onclick = function() {
                    cmOpenResetPasswordModal(data.id, data.login);
                };
                document.getElementById('cm-upp-btn-wp').href = data.wp_edit_url;

                var btn2fa = document.getElementById('cm-upp-btn-2fa');
                btn2fa.className = 'cm-act-btn ' + (data.twofa ? 'cm-act-btn-2fa-active' : 'cm-act-btn-2fa-inactive');
                btn2fa.onclick = function() {
                    cmOpenAdminUser2FAModal(data.id, data.login, data.name, data.twofa ? 1 : 0, data.twofa_date);
                };

                var suspWrap = document.getElementById('cm-upp-btn-suspend-wrap');
                var btnSusp  = document.getElementById('cm-upp-btn-suspend');
                if (data.id == data.current_uid) {
                    suspWrap.style.display = 'none';
                } else {
                    suspWrap.style.display = '';
                    if (data.suspended) {
                        btnSusp.className = 'cm-act-btn cm-act-btn-activate';
                        btnSusp.textContent = '🟢 Reactivar Acceso';
                    } else {
                        btnSusp.className = 'cm-act-btn cm-act-btn-suspend';
                        btnSusp.textContent = '⛔ Suspender Acceso';
                    }
                    btnSusp.onclick = function() { cmToggleUserSuspension(data.id); };
                }

                document.getElementById('cm-user-profile-panel').style.right = '0';
                document.getElementById('cm-user-panel-overlay').style.display = 'block';
                document.body.style.overflow = 'hidden';
            }

            function cmCloseUserPanel() {
                document.getElementById('cm-user-profile-panel').style.right = '-420px';
                document.getElementById('cm-user-panel-overlay').style.display = 'none';
                document.body.style.overflow = '';
            }

            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape') { cmCloseUserPanel(); }
            });
            </script>

        <?php elseif ($active_tab === 'trash' && $is_superadmin) : ?>
            <!-- ══════════════════════════════════════════════════════════
                 PESTAÑA 4: PAPELERA DE CASOS ELIMINADOS (ESTILO PHOENIX WIDGETS)
                 ══════════════════════════════════════════════════════════ -->

            <!-- Header de Sección Papelera -->
            <div style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:12px; margin-bottom:18px;">
                <div style="display:flex; align-items:center; gap:12px;">
                    <span style="width:38px; height:38px; border-radius:50%; background:#fee2e2; color:#dc2626; display:inline-flex; align-items:center; justify-content:center; font-size:18px; font-weight:800; box-shadow:0 2px 6px rgba(220,38,38,0.18);">
                        🗑️
                    </span>
                    <div>
                        <div style="display:flex; align-items:center; gap:8px;">
                            <h2 style="font-size:17px; font-weight:800; color:#0f172a; margin:0; line-height:1.2;">
                                <?php _e('Papelera y Auditoría de Casos Eliminados', 'contacto-multidestino'); ?>
                            </h2>
                            <span style="font-size:11px; font-weight:700; background:#fee2e2; color:#b91c1c; border:1px solid #fecaca; padding:2px 8px; border-radius:20px;">
                                <?php printf(_n('%s caso archivado', '%s casos archivados', $total_items, 'contacto-multidestino'), number_format_i18n($total_items)); ?>
                            </span>
                        </div>
                        <p style="margin:3px 0 0 0; font-size:12px; color:#64748b;">
                            <?php _e('Trazabilidad permanente: puedes consultar quién eliminó el expediente y restaurarlo con un solo clic.', 'contacto-multidestino'); ?>
                        </p>
                    </div>
                </div>
                <div style="display:flex; align-items:center; gap:8px;">
                    <a href="<?php echo cm_get_view_tab_url('inbox'); ?>" class="cm-btn-view" style="font-size:12px; text-decoration:none;">
                        📥 <?php _e('Volver a Bandeja Activa', 'contacto-multidestino'); ?> &rarr;
                    </a>
                </div>
            </div>

            <!-- Card Contenedor Principal estilo Phoenix Data Table -->
            <div class="cm-apple-card-panel" style="background:#ffffff; border:1px solid #e2e8f0; border-radius:14px; box-shadow:0 1px 4px rgba(0,0,0,0.03); overflow:hidden; padding:0; margin-bottom:24px;">
                
                <!-- Buscador Integrado en Cabecera de Tarjeta -->
                <div style="padding:16px 20px; border-bottom:1px solid #edf2f9; background:#ffffff;">
                    <form method="get" action="<?php echo esc_url(admin_url('admin.php')); ?>" style="display:flex; gap:10px; width:100%; align-items:center; flex-wrap:wrap; margin:0;">
                        <input type="hidden" name="page" value="cm-form-submissions" />
                        <input type="hidden" name="tab" value="trash" />
                        <div style="position:relative; flex:1; min-width:240px;">
                            <span style="position:absolute; left:12px; top:50%; transform:translateY(-50%); font-size:14px; color:#94a3b8; pointer-events:none;">🔍</span>
                            <input 
                                type="text" 
                                name="s" 
                                value="<?php echo esc_attr($search_query); ?>" 
                                placeholder="<?php esc_attr_e('Buscar por código, solicitante, correo o departamento...', 'contacto-multidestino'); ?>" 
                                style="width:100%; height:36px; padding:0 12px 0 34px; border:1px solid #cbd5e1; border-radius:8px; font-size:12.5px; background:#f8fafc; color:#0f172a; outline:none; transition:all 0.15s ease;"
                                onfocus="this.style.background='#ffffff'; this.style.borderColor='#3874ff'; this.style.boxShadow='0 0 0 3px rgba(56,116,255,0.15)';"
                                onblur="this.style.background='#f8fafc'; this.style.borderColor='#cbd5e1'; this.style.boxShadow='none';"
                            />
                        </div>
                        <button type="submit" class="cm-btn-view" style="font-size:12px; padding:0 16px; height:36px; font-weight:700;">
                            <?php _e('Buscar en Papelera', 'contacto-multidestino'); ?>
                        </button>
                        <?php if (!empty($search_query)) : ?>
                            <a href="<?php echo cm_get_view_tab_url('trash'); ?>" class="cm-apple-btn-secondary" style="height:36px; line-height:34px; padding:0 12px; text-decoration:none; font-size:12px; font-weight:700;">
                                ✕ <?php _e('Limpiar', 'contacto-multidestino'); ?>
                            </a>
                        <?php endif; ?>
                    </form>
                </div>

                <!-- Tabla de Casos en Papelera -->
                <div style="overflow-x:auto; -webkit-overflow-scrolling:touch; width:100%;">
                    <table style="width:100%; border-collapse:collapse; font-size:13px; min-width:800px; margin:0;">
                        <thead>
                            <tr style="border-bottom:2px solid #edf2f9; background:#f8fafc;">
                                <th style="padding:12px 20px; text-align:left; font-size:10.5px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.06em; width:15%;"><?php _e('Código / Ticket', 'contacto-multidestino'); ?></th>
                                <th style="padding:12px 18px; text-align:left; font-size:10.5px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.06em; width:22%;"><?php _e('Solicitante', 'contacto-multidestino'); ?></th>
                                <th style="padding:12px 18px; text-align:left; font-size:10.5px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.06em; width:18%;"><?php _e('Área Asignada', 'contacto-multidestino'); ?></th>
                                <th style="padding:12px 16px; text-align:left; font-size:10.5px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.06em; width:15%;"><?php _e('Fecha Eliminación', 'contacto-multidestino'); ?></th>
                                <th style="padding:12px 14px; text-align:left; font-size:10.5px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.06em; width:12%;"><?php _e('Eliminado Por', 'contacto-multidestino'); ?></th>
                                <th style="padding:12px 14px; text-align:center; font-size:10.5px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.06em; width:10%;"><?php _e('Último Estado', 'contacto-multidestino'); ?></th>
                                <th style="padding:12px 20px; text-align:center; font-size:10.5px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.06em; width:18%;"><?php _e('Acciones', 'contacto-multidestino'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($submissions)) : ?>
                                <?php foreach ($submissions as $sub) : 
                                    $st_info = isset($statuses[$sub->status]) ? $statuses[$sub->status] : array('label' => ucfirst($sub->status), 'color' => '#475569', 'bg_color' => '#f1f5f9', 'icon' => '📌');
                                    $del_date = !empty($sub->deleted_at) ? date_i18n('d/m/Y H:i', strtotime($sub->deleted_at)) . ' hrs' : '—';
                                    $del_by = !empty($sub->deleted_by) ? esc_html($sub->deleted_by) : 'Administrador';
                                ?>
                                    <tr id="cm-trash-row-<?php echo esc_attr($sub->id); ?>" style="border-bottom:1px solid #f1f5f9; transition:background 0.15s ease;" onmouseover="this.style.background='#f8fafc';" onmouseout="this.style.background='';">
                                        <td style="padding:14px 20px;">
                                            <span class="cm-tag-code" style="cursor:pointer;" onclick="cmOpenCaseModal(<?php echo esc_attr($sub->id); ?>, '<?php echo esc_attr($sub->ticket_code); ?>')">
                                                <?php echo esc_html($sub->ticket_code); ?>
                                            </span>
                                        </td>
                                        <td style="padding:14px 18px;">
                                            <div style="font-weight:700; color:#0f172a; font-size:13px;">
                                                <?php echo esc_html($sub->sender_name ? $sub->sender_name : __('Anónimo', 'contacto-multidestino')); ?>
                                            </div>
                                            <div style="font-size:11.5px; color:#64748b; margin-top:2px;">
                                                <a href="mailto:<?php echo esc_attr($sub->sender_email); ?>" style="color:#64748b; text-decoration:none;">
                                                    ✉️ <?php echo esc_html($sub->sender_email); ?>
                                                </a>
                                            </div>
                                        </td>
                                        <td style="padding:14px 18px;">
                                            <span style="font-size:11.5px; font-weight:700; color:#4338ca; background:#eef2ff; border:1px solid #c7d2fe; padding:3px 9px; border-radius:6px; display:inline-block;">
                                                🏢 <?php echo esc_html($sub->department ? $sub->department : 'General'); ?>
                                            </span>
                                        </td>
                                        <td style="padding:14px 16px;">
                                            <div style="display:inline-flex; align-items:center; gap:4px; font-size:11.5px; color:#b91c1c; font-weight:700; background:#fef2f2; border:1px solid #fecaca; padding:3px 9px; border-radius:6px;">
                                                🗑️ <?php echo esc_html($del_date); ?>
                                            </div>
                                        </td>
                                        <td style="padding:14px 14px;">
                                            <div style="font-size:12px; color:#334155; font-weight:700; display:flex; align-items:center; gap:4px;">
                                                👤 <?php echo $del_by; ?>
                                            </div>
                                        </td>
                                        <td style="padding:14px 14px; text-align:center;">
                                            <span style="background-color:<?php echo esc_attr($st_info['bg_color']); ?>; color:<?php echo esc_attr($st_info['color']); ?>; font-weight:700; font-size:11px; padding:3px 9px; border-radius:10px; display:inline-block; white-space:nowrap;">
                                                <?php echo $st_info['icon'] . ' ' . esc_html($st_info['label']); ?>
                                            </span>
                                        </td>
                                        <td style="padding:14px 20px; text-align:center;">
                                            <div style="display:flex; justify-content:center; gap:6px; flex-wrap:nowrap;">
                                                <button 
                                                    type="button" 
                                                    class="cm-btn-view" 
                                                    style="font-size:11.5px; font-weight:700; height:28px; padding:0 12px; background:#16a34a; border-color:#15803d; color:#ffffff; display:inline-flex; align-items:center; gap:4px; box-shadow:0 1px 3px rgba(22,163,74,0.25); cursor:pointer;"
                                                    onclick="cmRestoreCase(<?php echo esc_attr($sub->id); ?>)" 
                                                    title="<?php esc_attr_e('Restaurar este caso a la bandeja de casos activos', 'contacto-multidestino'); ?>"
                                                >
                                                    ♻️ <?php _e('Recuperar', 'contacto-multidestino'); ?>
                                                </button>
                                                <button 
                                                    type="button" 
                                                    class="cm-btn-view" 
                                                    style="font-size:11.5px; font-weight:700; height:28px; padding:0 10px; display:inline-flex; align-items:center; gap:4px; cursor:pointer;"
                                                    onclick="cmOpenCaseModal(<?php echo esc_attr($sub->id); ?>)" 
                                                    title="<?php esc_attr_e('Abrir expediente en ventana flotante', 'contacto-multidestino'); ?>"
                                                >
                                                    👁️ <?php _e('Modal', 'contacto-multidestino'); ?>
                                                </button>
                                                <a 
                                                    href="<?php echo esc_url(admin_url('admin.php?page=cm-form-submissions&case_id=' . $sub->id)); ?>" 
                                                    class="cm-apple-btn-secondary" 
                                                    style="font-size:11.5px; font-weight:700; height:28px; padding:0 10px; text-decoration:none; display:inline-flex; align-items:center; gap:4px; color:#0f172a; background:#ffffff; border-color:#cbd5e1; border-radius:6px;"
                                                    title="<?php esc_attr_e('Ver en página completa', 'contacto-multidestino'); ?>"
                                                >
                                                    🖥️ <?php _e('Página', 'contacto-multidestino'); ?>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <tr>
                                    <td colspan="7" style="text-align:center; padding:48px 20px;">
                                        <div style="font-size:36px; margin-bottom:10px;">✨</div>
                                        <strong style="color:#0f172a; font-size:14.5px; font-weight:800; display:block; margin-bottom:4px;">
                                            <?php _e('No hay casos en la papelera', 'contacto-multidestino'); ?>
                                        </strong>
                                        <p style="color:#64748b; font-size:12.5px; margin:0;">
                                            <?php _e('Todos los casos activos se encuentran en la bandeja principal.', 'contacto-multidestino'); ?>
                                        </p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Paginación en Papelera estilo Phoenix -->
                <?php if ($total_pages > 1) : ?>
                    <div style="display:flex; justify-content:space-between; align-items:center; padding:14px 20px; border-top:1px solid #edf2f9; background:#ffffff;">
                        <div style="font-size:12px; font-weight:600; color:#64748b;">
                            <?php printf(__('Página %s de %s (%s casos archivados)', 'contacto-multidestino'), $current_page, $total_pages, $total_items); ?>
                        </div>
                        <div style="display:flex; gap:6px;">
                            <?php for ($i = 1; $i <= $total_pages; $i++) : ?>
                                <a 
                                    href="<?php echo esc_url(add_query_arg(array('paged' => $i, 's' => $search_query), cm_get_view_tab_url('trash'))); ?>" 
                                    style="padding:5px 12px; border-radius:6px; font-size:12px; font-weight:700; text-decoration:none; border:1px solid <?php echo $i === $current_page ? '#3874ff' : '#cbd5e1'; ?>; background:<?php echo $i === $current_page ? '#3874ff' : '#ffffff'; ?>; color:<?php echo $i === $current_page ? '#ffffff' : '#334155'; ?>;"
                                >
                                    <?php echo $i; ?>
                                </a>
                            <?php endfor; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        <?php elseif ($active_tab === 'audit' && $is_superadmin) : ?>
            <!-- ══════════════════════════════════════════════════════════
                 PESTAÑA 5: AUDITORÍA Y TRAZABILIDAD (DISEÑO EJECUTIVO ROBUSTO)
                 ══════════════════════════════════════════════════════════ -->
            <?php
            global $wpdb;
            $table_audit = $wpdb->prefix . 'cm_case_audit_logs';
            $stat_total   = (int)$wpdb->get_var("SELECT COUNT(*) FROM $table_audit");
            $stat_logins  = (int)$wpdb->get_var("SELECT COUNT(*) FROM $table_audit WHERE action = 'login'");
            $stat_views   = (int)$wpdb->get_var("SELECT COUNT(*) FROM $table_audit WHERE action = 'viewed'");
            $stat_status  = (int)$wpdb->get_var("SELECT COUNT(*) FROM $table_audit WHERE action IN ('status', 'status_changed')");
            $stat_notes   = (int)$wpdb->get_var("SELECT COUNT(*) FROM $table_audit WHERE action IN ('note', 'note_added', 'update', 'attachment_view')");
            ?>

            <!-- Header de Auditoría -->
            <div style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:12px; margin-bottom:14px;">
                <div style="display:flex; align-items:center; gap:12px;">
                    <span style="width:38px; height:38px; border-radius:10px; background:#f3e8ff; color:#7e22ce; display:inline-flex; align-items:center; justify-content:center; font-size:20px; font-weight:800; border:1px solid #e9d5ff; box-shadow:0 2px 5px rgba(126,34,206,0.12);">
                        🕵️‍♂️
                    </span>
                    <div>
                        <div style="display:flex; align-items:center; gap:8px;">
                            <h2 style="font-size:16.5px; font-weight:800; color:#0f172a; margin:0; line-height:1.2;">
                                <?php _e('Centro de Auditoría y Trazabilidad Institucional', 'contacto-multidestino'); ?>
                            </h2>
                            <span style="font-size:11px; font-weight:700; background:#f3e8ff; color:#7e22ce; border:1px solid #d8b4fe; padding:2px 8px; border-radius:20px;">
                                🛡️ Inmutable
                            </span>
                        </div>
                        <p style="margin:2px 0 0 0; font-size:12px; color:#64748b;">
                            <?php _e('Monitoreo en tiempo real de inicios de sesión, consultas a expedientes, visualizaciones de adjuntos y respuestas.', 'contacto-multidestino'); ?>
                        </p>
                    </div>
                </div>
                <div>
                    <button type="button" class="cm-apple-btn-secondary" style="font-size:12px; font-weight:700; height:32px; padding:0 12px;" onclick="location.reload()">
                        🔄 <?php _e('Actualizar', 'contacto-multidestino'); ?>
                    </button>
                </div>
            </div>

            <!-- Barra Horizontal de Métricas de Auditoría (1 sola fila limpia e integrada) -->
            <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:10px; box-shadow:0 1px 3px rgba(0,0,0,0.02); margin-bottom:12px; overflow:hidden;">
                <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(130px, 1fr));">
                    
                    <div style="padding:10px 14px; text-align:center; border-right:1px solid #f1f5f9;">
                        <div style="font-size:10px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.04em;">
                            📊 <?php _e('Total Eventos', 'contacto-multidestino'); ?>
                        </div>
                        <div style="font-size:19px; font-weight:900; color:#0f172a; line-height:1.2; margin-top:2px;">
                            <?php echo number_format_i18n($stat_total); ?>
                        </div>
                    </div>

                    <div style="padding:10px 14px; text-align:center; border-right:1px solid #f1f5f9;">
                        <div style="font-size:10px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.04em;">
                            🔑 <?php _e('Inicios Sesión', 'contacto-multidestino'); ?>
                        </div>
                        <div style="font-size:19px; font-weight:900; color:#16a34a; line-height:1.2; margin-top:2px;">
                            <?php echo number_format_i18n($stat_logins); ?>
                        </div>
                    </div>

                    <div style="padding:10px 14px; text-align:center; border-right:1px solid #f1f5f9;">
                        <div style="font-size:10px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.04em;">
                            👁️ <?php _e('Vistas de Caso', 'contacto-multidestino'); ?>
                        </div>
                        <div style="font-size:19px; font-weight:900; color:#2563eb; line-height:1.2; margin-top:2px;">
                            <?php echo number_format_i18n($stat_views); ?>
                        </div>
                    </div>

                    <div style="padding:10px 14px; text-align:center; border-right:1px solid #f1f5f9;">
                        <div style="font-size:10px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.04em;">
                            🔄 <?php _e('Cambios Estado', 'contacto-multidestino'); ?>
                        </div>
                        <div style="font-size:19px; font-weight:900; color:#7e22ce; line-height:1.2; margin-top:2px;">
                            <?php echo number_format_i18n($stat_status); ?>
                        </div>
                    </div>

                    <div style="padding:10px 14px; text-align:center;">
                        <div style="font-size:10px; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.04em;">
                            📝 <?php _e('Notas / Adjuntos', 'contacto-multidestino'); ?>
                        </div>
                        <div style="font-size:19px; font-weight:900; color:#d97706; line-height:1.2; margin-top:2px;">
                            <?php echo number_format_i18n($stat_notes); ?>
                        </div>
                    </div>

                </div>
                <!-- Micro barra apilada integrada -->
                <div style="height:3px; background:#f1f5f9; display:flex; width:100%;">
                    <div style="width:<?php echo $stat_total > 0 ? round(($stat_logins/$stat_total)*100) : 0; ?>%; background:#10b981;" title="Logins"></div>
                    <div style="width:<?php echo $stat_total > 0 ? round(($stat_views/$stat_total)*100) : 0; ?>%; background:#3874ff;" title="Vistas"></div>
                    <div style="width:<?php echo $stat_total > 0 ? round(($stat_status/$stat_total)*100) : 0; ?>%; background:#7e22ce;" title="Estados"></div>
                    <div style="width:<?php echo $stat_total > 0 ? round(($stat_notes/$stat_total)*100) : 0; ?>%; background:#d97706;" title="Notas y Adjuntos"></div>
                </div>
            </div>

            <!-- Barra de Filtros y Herramientas -->
            <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:10px; padding:10px 14px; margin-bottom:14px; box-shadow:0 1px 3px rgba(0,0,0,0.02);">
                <form method="GET" action="<?php echo !empty($_GET['cm_portal']) ? esc_url(home_url('/')) : admin_url('admin.php'); ?>" style="display:flex; align-items:center; gap:10px; flex-wrap:wrap; width:100%; margin:0;">
                    <?php if (!empty($_GET['cm_portal'])) : ?>
                        <input type="hidden" name="cm_portal" value="1" />
                    <?php else : ?>
                        <input type="hidden" name="page" value="cm-form-submissions" />
                    <?php endif; ?>
                    <input type="hidden" name="tab" value="audit" />

                    <!-- Filtro Tipo de Acción -->
                    <div>
                        <select name="action_filter" onchange="this.form.submit()" style="height:36px; padding:0 28px 0 10px; font-weight:700; color:#334155; border-radius:8px; border:1px solid #cbd5e1; font-size:12.5px; background:#ffffff;">
                            <option value=""><?php _e('Tipo de Evento (Todos)', 'contacto-multidestino'); ?></option>
                            <option value="login" <?php selected($filter_action, 'login'); ?>>🔑 <?php _e('Inicios de Sesión', 'contacto-multidestino'); ?></option>
                            <option value="viewed" <?php selected($filter_action, 'viewed'); ?>>👁️ <?php _e('Visualizaciones de Caso', 'contacto-multidestino'); ?></option>
                            <option value="attachment_view" <?php selected($filter_action, 'attachment_view'); ?>>📎 <?php _e('Visualizaciones de Adjuntos', 'contacto-multidestino'); ?></option>
                            <option value="status" <?php selected($filter_action, 'status'); ?>>🔄 <?php _e('Cambios de Estado', 'contacto-multidestino'); ?></option>
                            <option value="note" <?php selected($filter_action, 'note'); ?>>📝 <?php _e('Notas y Respuestas', 'contacto-multidestino'); ?></option>
                            <option value="deleted" <?php selected($filter_action, 'deleted'); ?>>🗑️ <?php _e('Eliminaciones / Papelera', 'contacto-multidestino'); ?></option>
                            <option value="reassigned" <?php selected($filter_action, 'reassigned'); ?>>👥 <?php _e('Derivaciones de Área', 'contacto-multidestino'); ?></option>
                        </select>
                    </div>

                    <!-- Buscador -->
                    <div style="flex:1; min-width:240px; position:relative; display:flex; align-items:center;">
                        <span style="position:absolute; left:10px; font-size:14px; color:#94a3b8; pointer-events:none;">🔍</span>
                        <input 
                            type="search" 
                            name="s" 
                            value="<?php echo esc_attr($search_query); ?>" 
                            placeholder="<?php esc_attr_e('Buscar por código, usuario, detalle o IP...', 'contacto-multidestino'); ?>" 
                            style="width:100%; height:36px; padding:0 12px 0 32px; font-size:12.5px; border:1px solid #cbd5e1; border-radius:8px; outline:none; background:#ffffff;"
                        />
                        <?php if ($filter_action || $search_query) : ?>
                            <a href="<?php echo cm_get_view_tab_url('audit'); ?>" style="position:absolute; right:8px; font-size:11px; font-weight:700; color:#ef4444; text-decoration:none; background:#fee2e2; padding:2px 6px; border-radius:4px;" title="<?php esc_attr_e('Limpiar filtros', 'contacto-multidestino'); ?>">
                                ✕ Limpiar
                            </a>
                        <?php endif; ?>
                    </div>

                    <!-- Botón Desplegar / Contraer Historiales -->
                    <div>
                        <button type="button" onclick="cmToggleAllAuditSubRows()" style="background:#ffffff; border:1px solid #d8b4fe; color:#6b21a8; height:36px; padding:0 12px; font-weight:700; border-radius:8px; display:inline-flex; align-items:center; gap:5px; cursor:pointer; font-size:12px;">
                            <span id="cm-ico-toggle-all-sub">📂</span> <span id="cm-txt-toggle-all-sub"><?php _e('Desplegar Historiales', 'contacto-multidestino'); ?></span>
                        </button>
                    </div>

                    <!-- Botón Imprimir Informe Oficial -->
                    <div style="margin-left:auto;">
                        <button type="button" onclick="cmOpenPrintModal('all')" style="background:#6b21a8; border:1px solid #581c87; color:#ffffff; height:36px; padding:0 14px; font-weight:700; border-radius:8px; display:inline-flex; align-items:center; gap:6px; cursor:pointer; font-size:12px; box-shadow:0 2px 6px rgba(107,33,168,0.25);">
                            🖨️ <?php _e('Imprimir Informe', 'contacto-multidestino'); ?>
                        </button>
                    </div>
                </form>
            </div>

            <!-- Tabla de Auditoría Ejecutiva Phoenix (Estilo exacto widgets-clone.html) -->
            <?php
            // Agrupar registros de auditoría por caso / código para comprimir si hay más de 1 evento
            $grouped_audit = array();
            if (!empty($submissions)) {
                foreach ($submissions as $item) {
                    $c = empty($item->ticket_code) ? 'SISTEMA' : $item->ticket_code;
                    if (!isset($grouped_audit[$c])) {
                        $grouped_audit[$c] = array(
                            'ticket_code'   => $c,
                            'submission_id' => $item->submission_id,
                            'main'          => $item,
                            'history'       => array(),
                        );
                    } else {
                        $grouped_audit[$c]['history'][] = $item;
                    }
                }
            }
            ?>
            <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:12px; padding:18px; margin-bottom:20px; box-shadow:0 1px 3px rgba(0,0,0,0.02);">
                <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:14px; flex-wrap:wrap; gap:8px;">
                    <h3 style="font-weight:700; font-size:15px; color:#0f172a; margin:0; display:flex; align-items:center; gap:8px;">
                        <span>📋</span> <?php _e('Registro de Actividades y Trazabilidad', 'contacto-multidestino'); ?>
                    </h3>
                    <span style="font-size:12px; color:#64748b; font-weight:600;">
                        <?php printf(__('Mostrando %d grupos de expedientes', 'contacto-multidestino'), count($grouped_audit)); ?>
                    </span>
                </div>
                <div style="overflow-x:auto; -webkit-overflow-scrolling:touch;">
                    <table style="width:100%; border-collapse:collapse; font-size:13px; text-align:left;">
                        <thead>
                            <tr style="border-bottom:2px solid #e2e8f0; background:#f8fafc;">
                                <th style="padding:10px 14px; color:#64748b; font-weight:700; font-size:11px; text-transform:uppercase; letter-spacing:0.04em; width:150px;"><?php _e('Expediente / Caso', 'contacto-multidestino'); ?></th>
                                <th style="padding:10px 14px; color:#64748b; font-weight:700; font-size:11px; text-transform:uppercase; letter-spacing:0.04em; width:170px;"><?php _e('Operador / Usuario', 'contacto-multidestino'); ?></th>
                                <th style="padding:10px 14px; color:#64748b; font-weight:700; font-size:11px; text-transform:uppercase; letter-spacing:0.04em; width:140px;"><?php _e('Tipo de Evento', 'contacto-multidestino'); ?></th>
                                <th style="padding:10px 14px; color:#64748b; font-weight:700; font-size:11px; text-transform:uppercase; letter-spacing:0.04em;"><?php _e('Detalle de la Actividad', 'contacto-multidestino'); ?></th>
                                <th style="padding:10px 14px; color:#64748b; font-weight:700; font-size:11px; text-transform:uppercase; letter-spacing:0.04em; width:130px;"><?php _e('Fecha y Hora', 'contacto-multidestino'); ?></th>
                                <th style="padding:10px 14px; color:#64748b; font-weight:700; font-size:11px; text-transform:uppercase; letter-spacing:0.04em; width:110px;"><?php _e('Dirección IP', 'contacto-multidestino'); ?></th>
                                <th style="padding:10px 14px; text-align:right; width:100px;"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($grouped_audit)) : ?>
                                <?php foreach ($grouped_audit as $code => $group) : 
                                    $al = $group['main'];
                                    $history_count = count($group['history']);
                                    $grp_id = 'cm-sub-grp-' . md5($code);
                                    $act  = strtolower($al->action);
                                    
                                    // Color y estilo por acción
                                    $act_color = '#475569';
                                    $act_label = strtoupper($al->action);

                                    if ($act === 'login') {
                                        $act_color = '#10b981';
                                        $act_label = 'LOGIN';
                                    } elseif ($act === 'viewed') {
                                        $act_color = '#3874ff';
                                        $act_label = 'VISTA';
                                    } elseif ($act === 'attachment_view') {
                                        $act_color = '#0097eb';
                                        $act_label = 'ADJUNTO';
                                    } elseif ($act === 'status' || $act === 'status_changed') {
                                        $act_color = '#7e22ce';
                                        $act_label = 'ESTADO';
                                    } elseif ($act === 'note' || $act === 'note_added' || $act === 'update') {
                                        $act_color = '#e5780b';
                                        $act_label = 'NOTA';
                                    } elseif ($act === 'deleted') {
                                        $act_color = '#ef4444';
                                        $act_label = 'PAPELERA';
                                    } elseif ($act === 'reassigned') {
                                        $act_color = '#6366f1';
                                        $act_label = 'DERIVACIÓN';
                                    }
                                    
                                    $date_short = date_i18n('d/m/Y', strtotime($al->created_at));
                                    $time_short = date_i18n('H:i:s', strtotime($al->created_at));
                                ?>
                                    <!-- Fila Principal del Caso -->
                                    <tr style="border-bottom:1px solid #f1f5f9; transition:background 0.15s ease;" onmouseover="this.style.background='#f8fafc';" onmouseout="this.style.background='';">
                                        <td style="padding:12px 14px; vertical-align:middle;">
                                            <a style="font-weight:700; color:#2563eb; text-decoration:none; font-size:13.5px; display:inline-flex; align-items:center; gap:4px;" href="<?php echo !empty($al->submission_id) ? cm_get_case_view_url($al->submission_id) : '#'; ?>">
                                                <?php echo esc_html($code); ?>
                                            </a>
                                            
                                            <!-- Si existe más de 1 evento, botón para desplegar -->
                                            <?php if ($history_count > 0) : ?>
                                                <div style="margin-top:4px;">
                                                    <button 
                                                        type="button" 
                                                        class="cm-audit-subtoggle-btn" 
                                                        onclick="cmToggleCaseSubRows('<?php echo esc_attr($grp_id); ?>', this)" 
                                                        style="font-size:10.5px; font-weight:800; background:#f3e8ff; color:#7e22ce; border:1px solid #d8b4fe; border-radius:12px; padding:2px 8px; cursor:pointer; display:inline-flex; align-items:center; gap:4px; transition:all 0.15s ease;"
                                                        title="<?php esc_attr_e('Ver registros anteriores de este caso', 'contacto-multidestino'); ?>"
                                                    >
                                                        <span class="cm-sub-arrow">▶</span> <?php printf(_n('+%d evento', '+%d eventos', $history_count, 'contacto-multidestino'), $history_count); ?>
                                                    </button>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                        <td style="padding:12px 14px; vertical-align:middle;">
                                            <div style="display:flex; align-items:center; gap:8px;">
                                                <div style="width:26px; height:26px; border-radius:50%; background:#e0edff; color:#2563eb; font-weight:800; font-size:11px; display:flex; align-items:center; justify-content:center; flex-shrink:0;">
                                                    👤
                                                </div>
                                                <span style="font-weight:600; color:#1e293b;"><?php echo esc_html($al->user_name ? $al->user_name : 'Sistema / Anónimo'); ?></span>
                                            </div>
                                        </td>
                                        <td style="padding:12px 14px; vertical-align:middle;">
                                            <div style="display:flex; align-items:center; gap:6px;">
                                                <div style="width:14px; height:14px; border-radius:50%; border:2.5px solid <?php echo esc_attr($act_color); ?>; border-top-color:transparent; transform:rotate(-90deg); flex-shrink:0;"></div>
                                                <span style="font-size:11.5px; font-weight:700; color:<?php echo esc_attr($act_color); ?>;"><?php echo esc_html($act_label); ?></span>
                                            </div>
                                        </td>
                                        <td style="padding:12px 14px; vertical-align:middle; color:#334155; line-height:1.4;">
                                            <?php echo wp_kses_post($al->details); ?>
                                        </td>
                                        <td style="padding:12px 14px; vertical-align:middle; white-space:nowrap;">
                                            <div style="font-weight:600; color:#0f172a; font-size:12px;"><?php echo esc_html($date_short); ?></div>
                                            <div style="font-size:10.5px; color:#64748b; font-family:monospace;"><?php echo esc_html($time_short); ?></div>
                                        </td>
                                        <td style="padding:12px 14px; vertical-align:middle;">
                                            <code style="font-size:11px; background:#f1f5f9; padding:2px 6px; border-radius:4px; color:#475569; border:1px solid #e2e8f0; font-family:monospace;">
                                                <?php echo esc_html($al->ip_address ? $al->ip_address : '—'); ?>
                                            </code>
                                        </td>
                                        <td style="padding:12px 14px; vertical-align:middle; text-align:right;">
                                            <div style="display:flex; align-items:center; justify-content:flex-end; gap:4px;">
                                                <?php if ($code !== 'SISTEMA' && !empty($al->submission_id)) : ?>
                                                    <button 
                                                        type="button" 
                                                        onclick="cmOpenCaseModal(<?php echo esc_attr($al->submission_id); ?>)" 
                                                        title="<?php esc_attr_e('Abrir Caso en Modal', 'contacto-multidestino'); ?>"
                                                        style="padding:4px 8px; border-radius:6px; border:1px solid #e2e8f0; background:#f8fafc; font-size:11px; font-weight:700; cursor:pointer; color:#1e293b; display:inline-flex; align-items:center; gap:2px;"
                                                    >
                                                        👁️ <?php _e('Modal', 'contacto-multidestino'); ?>
                                                    </button>
                                                    <a 
                                                        href="<?php echo cm_get_case_view_url($al->submission_id); ?>" 
                                                        style="padding:4px 8px; border-radius:6px; border:1px solid #e2e8f0; background:#ffffff; font-size:11px; font-weight:700; text-decoration:none; color:#2563eb; display:inline-flex; align-items:center; gap:2px;" 
                                                        title="<?php esc_attr_e('Página Completa', 'contacto-multidestino'); ?>"
                                                    >
                                                        🖥️ <?php _e('Ver', 'contacto-multidestino'); ?>
                                                    </a>
                                                    <a 
                                                        href="<?php echo esc_url(add_query_arg(array('print_audit' => '1', 'type' => 'case', 'case' => $code), home_url('/'))); ?>" 
                                                        target="_blank" 
                                                        style="padding:4px 6px; border-radius:6px; border:1px solid #d8b4fe; background:#faf5ff; font-size:11px; text-decoration:none; color:#7e22ce;" 
                                                        title="<?php esc_attr_e('Imprimir', 'contacto-multidestino'); ?>"
                                                    >
                                                        🖨️
                                                    </a>
                                                <?php else : ?>
                                                    <span style="color:#cbd5e1; font-size:12px;">—</span>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>

                                    <!-- Sub-filas desplegables para eventos previos del mismo caso -->
                                    <?php if ($history_count > 0) : ?>
                                        <?php foreach ($group['history'] as $sub_al) : 
                                            $sub_act = strtolower($sub_al->action);
                                            $sub_color = '#475569';
                                            $sub_label = strtoupper($sub_al->action);

                                            if ($sub_act === 'login') {
                                                $sub_color = '#10b981'; $sub_label = 'LOGIN';
                                            } elseif ($sub_act === 'viewed') {
                                                $sub_color = '#3874ff'; $sub_label = 'VISTA';
                                            } elseif ($sub_act === 'attachment_view') {
                                                $sub_color = '#0097eb'; $sub_label = 'ADJUNTO';
                                            } elseif ($sub_act === 'status' || $sub_act === 'status_changed') {
                                                $sub_color = '#7e22ce'; $sub_label = 'ESTADO';
                                            } elseif ($sub_act === 'note' || $sub_act === 'note_added' || $sub_act === 'update') {
                                                $sub_color = '#e5780b'; $sub_label = 'NOTA';
                                            } elseif ($sub_act === 'deleted') {
                                                $sub_color = '#ef4444'; $sub_label = 'PAPELERA';
                                            } elseif ($sub_act === 'reassigned') {
                                                $sub_color = '#6366f1'; $sub_label = 'DERIVACIÓN';
                                            }
                                            $sub_date = date_i18n('d/m/Y', strtotime($sub_al->created_at));
                                            $sub_time = date_i18n('H:i:s', strtotime($sub_al->created_at));
                                        ?>
                                            <tr class="cm-table-row cm-sub-row <?php echo esc_attr($grp_id); ?>" style="display:none; background:#faf5ff; border-bottom:1px solid #f3e8ff;">
                                                <td style="padding:8px 14px 8px 24px; vertical-align:middle;">
                                                    <span style="font-size:11px; color:#7e22ce; font-weight:800;">↳ Historial</span>
                                                </td>
                                                <td style="padding:8px 14px; vertical-align:middle;">
                                                    <div style="display:flex; align-items:center; gap:6px;">
                                                        <div style="width:22px; height:22px; border-radius:50%; background:#f3e8ff; color:#7e22ce; font-weight:800; font-size:10px; display:flex; align-items:center; justify-content:center; flex-shrink:0;">
                                                            👤
                                                        </div>
                                                        <span style="font-size:11.5px; color:#475569; font-weight:600;"><?php echo esc_html($sub_al->user_name ? $sub_al->user_name : 'Sistema'); ?></span>
                                                    </div>
                                                </td>
                                                <td style="padding:8px 14px; vertical-align:middle;">
                                                    <div style="display:flex; align-items:center; gap:5px;">
                                                        <div style="width:12px; height:12px; border-radius:50%; border:2px solid <?php echo esc_attr($sub_color); ?>; border-top-color:transparent; transform:rotate(-90deg); flex-shrink:0;"></div>
                                                        <span style="font-size:10.5px; font-weight:700; color:<?php echo esc_attr($sub_color); ?>;"><?php echo esc_html($sub_label); ?></span>
                                                    </div>
                                                </td>
                                                <td style="padding:8px 14px; vertical-align:middle; font-size:12px; color:#475569; line-height:1.4;">
                                                    <?php echo wp_kses_post($sub_al->details); ?>
                                                </td>
                                                <td style="padding:8px 14px; vertical-align:middle; white-space:nowrap;">
                                                    <span style="font-size:11px; font-weight:600; color:#475569;"><?php echo esc_html($sub_date); ?></span>
                                                    <span style="font-size:10px; color:#64748b; font-family:monospace;"><?php echo esc_html($sub_time); ?></span>
                                                </td>
                                                <td style="padding:8px 14px; vertical-align:middle;">
                                                    <code style="font-size:10.5px; background:#ffffff; border:1px solid #e2e8f0; padding:1px 5px; border-radius:3px; color:#64748b; font-family:monospace;"><?php echo esc_html($sub_al->ip_address ? $sub_al->ip_address : '—'); ?></code>
                                                </td>
                                                <td style="padding:8px 14px; vertical-align:middle; text-align:right;">
                                                    <span style="font-size:11px; color:#cbd5e1;">—</span>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>

                                <?php endforeach; ?>
                            <?php else : ?>
                                <tr>
                                    <td colspan="7" style="text-align:center; padding:40px 20px;">
                                        <div style="font-size:32px; margin-bottom:8px;">🕵️‍♂️</div>
                                        <strong style="color:#0f172a; font-size:14px; font-weight:800; display:block; margin-bottom:3px;">
                                            <?php _e('No se encontraron registros de auditoría', 'contacto-multidestino'); ?>
                                        </strong>
                                        <p style="color:#64748b; font-size:12px; margin:0;">
                                            <?php _e('Los eventos del sistema, accesos a expedientes, visualizaciones de adjuntos e inicios de sesión aparecerán aquí automáticamente.', 'contacto-multidestino'); ?>
                                        </p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Paginación en Auditoría (Idéntica a Bandeja) -->
            <?php if ($total_pages > 1) : ?>
                <div style="display:flex; justify-content:space-between; align-items:center; padding:14px 20px; border-top:1px solid #edf2f9; background:#ffffff; border-radius:0 0 10px 10px; margin-top:-2px; border:1px solid #e2e8f0; border-top:none;">
                    <div style="font-size:12px; font-weight:600; color:#64748b;">
                        <?php printf(__('Página %s de %s (%s registros de auditoría)', 'contacto-multidestino'), $current_page, $total_pages, $total_items); ?>
                    </div>
                    <div style="display:flex; gap:6px;">
                        <?php for ($i = 1; $i <= $total_pages; $i++) : ?>
                            <a 
                                href="<?php echo esc_url(add_query_arg(array('paged' => $i, 's' => $search_query, 'action_filter' => $filter_action), cm_get_view_tab_url('audit'))); ?>" 
                                style="padding:5px 12px; border-radius:6px; font-size:12px; font-weight:700; text-decoration:none; border:1px solid <?php echo $i === $current_page ? '#3874ff' : '#cbd5e1'; ?>; background:<?php echo $i === $current_page ? '#3874ff' : '#ffffff'; ?>; color:<?php echo $i === $current_page ? '#ffffff' : '#334155'; ?>;"
                            >
                                <?php echo $i; ?>
                            </a>
                        <?php endfor; ?>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Modal para Imprimir Informe de Auditoría -->
            <div id="cm-audit-print-modal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(15,23,42,0.6); backdrop-filter:blur(4px); z-index:99999; justify-content:center; align-items:center;">
                <div style="background:#ffffff; padding:28px; border-radius:16px; width:440px; max-width:92%; box-shadow:0 20px 40px rgba(0,0,0,0.25); border:1px solid #e2e8f0;">
                    <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:16px;">
                        <h3 style="margin:0; color:#6b21a8; font-size:18px; font-weight:800; display:flex; align-items:center; gap:8px;">
                            <span>🖨️</span> <?php _e('Imprimir Informe de Auditoría', 'contacto-multidestino'); ?>
                        </h3>
                        <button type="button" onclick="document.getElementById('cm-audit-print-modal').style.display='none';" style="background:none; border:none; font-size:18px; cursor:pointer; color:#64748b;">✕</button>
                    </div>
                    
                    <p style="font-size:13px; color:#64748b; margin-top:0; margin-bottom:18px;">
                        <?php _e('Selecciona el alcance del reporte para generar la vista de impresión oficial:', 'contacto-multidestino'); ?>
                    </p>
                    
                    <div style="display:flex; flex-direction:column; gap:12px; margin-bottom:20px;">
                        <label style="display:flex; align-items:center; gap:10px; font-size:13.5px; font-weight:600; color:#1e293b; cursor:pointer; padding:10px; background:#f8fafc; border-radius:8px; border:1px solid #e2e8f0;">
                            <input type="radio" name="cm_print_type" value="all" checked onchange="cmTogglePrintOption(this.value)">
                            <span><?php _e('Todo el Historial de Auditoría', 'contacto-multidestino'); ?></span>
                        </label>
                        
                        <label style="display:flex; flex-direction:column; gap:8px; font-size:13.5px; font-weight:600; color:#1e293b; cursor:pointer; padding:10px; background:#f8fafc; border-radius:8px; border:1px solid #e2e8f0;">
                            <div style="display:flex; align-items:center; gap:10px;">
                                <input type="radio" name="cm_print_type" id="cm_print_type_case" value="case" onchange="cmTogglePrintOption(this.value)">
                                <span><?php _e('Expediente / Caso Específico', 'contacto-multidestino'); ?></span>
                            </div>
                            <div id="cm-print-case-input" style="display:none; padding-left:26px; padding-top:4px;">
                                <input type="text" id="cm_print_case_code" placeholder="Ej: CL123456 o SISTEMA" style="width:100%; height:36px; border:1.5px solid #cbd5e1; padding:0 10px; border-radius:6px; font-size:13px;">
                            </div>
                        </label>

                        <label style="display:flex; flex-direction:column; gap:8px; font-size:13.5px; font-weight:600; color:#1e293b; cursor:pointer; padding:10px; background:#f8fafc; border-radius:8px; border:1px solid #e2e8f0;">
                            <div style="display:flex; align-items:center; gap:10px;">
                                <input type="radio" name="cm_print_type" value="date" onchange="cmTogglePrintOption(this.value)">
                                <span><?php _e('Filtrar por Rango de Fechas', 'contacto-multidestino'); ?></span>
                            </div>
                            <div id="cm-print-date-range" style="display:none; padding-left:26px; padding-top:4px;">
                                <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
                                    <div>
                                        <span style="font-size:11px; color:#64748b; display:block; margin-bottom:2px;"><?php _e('Desde', 'contacto-multidestino'); ?></span>
                                        <input type="date" id="cm_print_date_from" style="width:100%; height:34px; border:1.5px solid #cbd5e1; padding:0 8px; border-radius:6px; font-size:12px;">
                                    </div>
                                    <div>
                                        <span style="font-size:11px; color:#64748b; display:block; margin-bottom:2px;"><?php _e('Hasta', 'contacto-multidestino'); ?></span>
                                        <input type="date" id="cm_print_date_to" style="width:100%; height:34px; border:1.5px solid #cbd5e1; padding:0 8px; border-radius:6px; font-size:12px;">
                                    </div>
                                </div>
                            </div>
                        </label>
                    </div>
                    
                    <div style="display:flex; justify-content:flex-end; gap:10px;">
                        <button type="button" onclick="document.getElementById('cm-audit-print-modal').style.display='none';" class="cm-apple-btn-secondary" style="background:#f1f5f9; color:#475569; border-color:#cbd5e1; padding:8px 16px;">
                            <?php _e('Cancelar', 'contacto-multidestino'); ?>
                        </button>
                        <button type="button" onclick="cmGenerateAuditPrint()" class="cm-apple-btn-secondary" style="background:#6b21a8; color:#ffffff; border-color:#581c87; padding:8px 16px; font-weight:700;">
                            🖨️ <?php _e('Generar e Imprimir', 'contacto-multidestino'); ?>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Scripts Auxiliares del Modal de Impresión -->
            <script>
            function cmToggleCaseSubRows(targetClass, btn) {
                var rows = document.querySelectorAll('.' + targetClass);
                if (!rows.length) return;
                var isHidden = (rows[0].style.display === 'none');
                rows.forEach(function(r) {
                    r.style.display = isHidden ? 'table-row' : 'none';
                });
                if (btn) {
                    var arrow = btn.querySelector('.cm-sub-arrow');
                    if (arrow) arrow.textContent = isHidden ? '▼' : '▶';
                    btn.style.background = isHidden ? '#7e22ce' : '#f3e8ff';
                    btn.style.color = isHidden ? '#ffffff' : '#7e22ce';
                }
            }

            var cmAllAuditSubRowsOpen = false;
            function cmToggleAllAuditSubRows() {
                cmAllAuditSubRowsOpen = !cmAllAuditSubRowsOpen;
                var allSubRows = document.querySelectorAll('.cm-sub-row');
                allSubRows.forEach(function(r) {
                    r.style.display = cmAllAuditSubRowsOpen ? 'table-row' : 'none';
                });
                var btns = document.querySelectorAll('.cm-audit-subtoggle-btn');
                btns.forEach(function(b) {
                    var arrow = b.querySelector('.cm-sub-arrow');
                    if (arrow) arrow.textContent = cmAllAuditSubRowsOpen ? '▼' : '▶';
                    b.style.background = cmAllAuditSubRowsOpen ? '#7e22ce' : '#f3e8ff';
                    b.style.color = cmAllAuditSubRowsOpen ? '#ffffff' : '#7e22ce';
                });
                var topBtnText = document.getElementById('cm-txt-toggle-all-sub');
                var topBtnIcon = document.getElementById('cm-ico-toggle-all-sub');
                if (topBtnText) topBtnText.textContent = cmAllAuditSubRowsOpen ? '<?php echo esc_js(__("Contraer Historiales", "contacto-multidestino")); ?>' : '<?php echo esc_js(__("Desplegar Historiales", "contacto-multidestino")); ?>';
                if (topBtnIcon) topBtnIcon.textContent = cmAllAuditSubRowsOpen ? '📁' : '📂';
            }

            function cmTogglePrintOption(type) {
                var caseInp = document.getElementById('cm-print-case-input');
                var dateInp = document.getElementById('cm-print-date-range');
                if (caseInp) caseInp.style.display = (type === 'case') ? 'block' : 'none';
                if (dateInp) dateInp.style.display = (type === 'date') ? 'block' : 'none';
            }

            function cmOpenPrintModal(type, caseCode) {
                var modal = document.getElementById('cm-audit-print-modal');
                if (modal) modal.style.display = 'flex';
                
                cmTogglePrintOption(type);
                if (type === 'case' && caseCode) {
                    var caseRadio = document.getElementById('cm_print_type_case');
                    var codeInp = document.getElementById('cm_print_case_code');
                    if (caseRadio) caseRadio.checked = true;
                    if (codeInp) codeInp.value = caseCode;
                    cmTogglePrintOption('case');
                } else {
                    var allRadio = document.querySelector('input[name="cm_print_type"][value="all"]');
                    if (allRadio) allRadio.checked = true;
                    cmTogglePrintOption('all');
                }
            }

            function cmGenerateAuditPrint() {
                var checkedRadio = document.querySelector('input[name="cm_print_type"]:checked');
                var type = checkedRadio ? checkedRadio.value : 'all';
                var url = '<?php echo esc_url_raw(home_url("/")); ?>?print_audit=1&type=' + encodeURIComponent(type);
                
                if (type === 'case') {
                    var code = document.getElementById('cm_print_case_code') ? document.getElementById('cm_print_case_code').value.trim() : '';
                    if (!code) {
                        alert('<?php echo esc_js(__("Por favor ingresa un código de caso o expediente.", "contacto-multidestino")); ?>');
                        return;
                    }
                    url += '&case=' + encodeURIComponent(code);
                } else if (type === 'date') {
                    var from = document.getElementById('cm_print_date_from') ? document.getElementById('cm_print_date_from').value : '';
                    var to = document.getElementById('cm_print_date_to') ? document.getElementById('cm_print_date_to').value : '';
                    if (!from || !to) {
                        alert('<?php echo esc_js(__("Por favor selecciona ambas fechas (Desde y Hasta).", "contacto-multidestino")); ?>');
                        return;
                    }
                    url += '&date_from=' + encodeURIComponent(from) + '&date_to=' + encodeURIComponent(to);
                }
                
                window.open(url, '_blank');
                var modal = document.getElementById('cm-audit-print-modal');
                if (modal) modal.style.display = 'none';
            }
            </script>
        <?php endif; ?>

        <!-- Tarjeta Informativa Compacta de Shortcodes -->
        <div class="cm-apple-shortcode-bar">
            <?php if ($is_superadmin) : ?>
                <div class="cm-shortcode-icon">🔗</div>
                <div class="cm-shortcode-text">
                    <strong><?php _e('Portal Público de Consulta:', 'contacto-multidestino'); ?></strong>
                    <span><?php _e('Inserta el shortcode en una página para que los usuarios vean el estado y las solicitudes de su caso:', 'contacto-multidestino'); ?></span>
                </div>
                <div class="cm-shortcode-copy-group">
                    <code>[seguimiento_caso]</code>
                    <button type="button" class="cm-btn-copy-sm" onclick="navigator.clipboard.writeText('[seguimiento_caso]'); alert('¡Shortcode [seguimiento_caso] copiado!');">
                        📋 <?php _e('Copiar', 'contacto-multidestino'); ?>
                    </button>
                    <?php if (function_exists('cm_get_standalone_portal_url') && empty($_GET['cm_portal'])) : ?>
                        <a href="<?php echo esc_url(cm_get_standalone_portal_url()); ?>" target="_blank" class="cm-apple-btn-secondary" style="background:#eff6ff; color:#2563eb !important; border-color:#bfdbfe; font-weight:700;" title="<?php esc_attr_e('Abrir Portal Ejecutivo Independiente en pantalla completa', 'contacto-multidestino'); ?>">
                            🚀 <?php _e('Portal Standalone ↗', 'contacto-multidestino'); ?>
                        </a>
                    <?php endif; ?>
                    <a href="https://link.mercadopago.cl/ingecodex" target="_blank" rel="noopener noreferrer" class="cm-btn-copy-sm" style="background: #009ee3; color: #ffffff; border-color: #0088c6; font-weight: 700; text-decoration: none; display: inline-flex; align-items: center; gap: 5px; padding: 4px 10px;" title="Apoyar el desarrollo con Mercado Pago">
                        <img src="<?php echo esc_url(CM_PLUGIN_URL . 'assets/images/logo.gif'); ?>" alt="Ingecodex" style="width: 15px; height: 15px; border-radius: 50%; object-fit: cover; display: inline-block;" />
                        <span><?php _e('Donar', 'contacto-multidestino'); ?></span>
                    </a>
                </div>
            <?php else : ?>
                <?php if (function_exists('cm_get_standalone_portal_url') && empty($_GET['cm_portal'])) : ?>
                    <div class="cm-shortcode-icon">🚀</div>
                    <div class="cm-shortcode-text">
                        <strong><?php _e('Portal Ejecutivo:', 'contacto-multidestino'); ?></strong>
                        <span><?php _e('Accede al portal de gestión de casos en modo pantalla completa.', 'contacto-multidestino'); ?></span>
                    </div>
                    <div class="cm-shortcode-copy-group">
                        <a href="<?php echo esc_url(cm_get_standalone_portal_url()); ?>" target="_blank" class="cm-apple-btn-secondary" style="background:#eff6ff; color:#2563eb !important; border-color:#bfdbfe; font-weight:700;" title="<?php esc_attr_e('Abrir Portal Ejecutivo en pantalla completa', 'contacto-multidestino'); ?>">
                            🚀 <?php _e('Abrir Portal Ejecutivo ↗', 'contacto-multidestino'); ?>
                        </a>
                        <a href="https://link.mercadopago.cl/ingecodex" target="_blank" rel="noopener noreferrer" class="cm-btn-copy-sm" style="background: #009ee3; color: #ffffff; border-color: #0088c6; font-weight: 700; text-decoration: none; display: inline-flex; align-items: center; gap: 5px; padding: 4px 10px;" title="Apoyar el desarrollo con Mercado Pago">
                            <img src="<?php echo esc_url(CM_PLUGIN_URL . 'assets/images/logo.gif'); ?>" alt="Ingecodex" style="width: 15px; height: 15px; border-radius: 50%; object-fit: cover; display: inline-block;" />
                            <span><?php _e('Donar', 'contacto-multidestino'); ?></span>
                        </a>
                    </div>
                <?php else : ?>
                    <div class="cm-shortcode-icon">ℹ️</div>
                    <div class="cm-shortcode-text">
                        <span><?php _e('Gestiona los casos asignados a tu área desde esta bandeja.', 'contacto-multidestino'); ?></span>
                    </div>
                    <div class="cm-shortcode-copy-group">
                        <a href="https://link.mercadopago.cl/ingecodex" target="_blank" rel="noopener noreferrer" class="cm-btn-copy-sm" style="background: #009ee3; color: #ffffff; border-color: #0088c6; font-weight: 700; text-decoration: none; display: inline-flex; align-items: center; gap: 5px; padding: 4px 10px;" title="Apoyar el desarrollo con Mercado Pago">
                            <img src="<?php echo esc_url(CM_PLUGIN_URL . 'assets/images/logo.gif'); ?>" alt="Ingecodex" style="width: 15px; height: 15px; border-radius: 50%; object-fit: cover; display: inline-block;" />
                            <span><?php _e('Donar', 'contacto-multidestino'); ?></span>
                        </a>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- Contenedor de Alertas Flotantes Toast -->
    <div id="cm-live-toast-wrap" style="position:fixed; bottom:20px; right:20px; z-index:999999; display:flex; flex-direction:column-reverse; gap:10px; pointer-events:none; max-width:440px;"></div>

    <!-- MODAL EDITAR / CREAR ÁREA -->
    <div id="cm-dept-modal-overlay" class="cm-apple-modal-overlay" style="display:none;">
        <div class="cm-apple-modal-box" style="max-width: 520px;">
            <div class="cm-apple-modal-head">
                <div class="cm-modal-head-left">
                    <span class="cm-modal-badge-app">CONFIGURACIÓN</span>
                    <strong id="cm-dept-modal-title" style="font-size:14px;"><?php _e('Área / Departamento', 'contacto-multidestino'); ?></strong>
                </div>
                <button type="button" class="cm-apple-modal-close" onclick="jQuery('#cm-dept-modal-overlay').fadeOut(100)">✕</button>
            </div>
            <div class="cm-apple-modal-body" style="padding:18px;">
                <div class="cm-form-row-compact">
                    <label><strong><?php _e('Nombre del Área / Departamento:', 'contacto-multidestino'); ?></strong></label>
                    <input type="text" id="cm-input-dept-name" class="cm-apple-input-sm" style="height:34px !important;" placeholder="Ej: Inspectoría General, Finanzas..." />
                </div>
                <div class="cm-form-row-compact" style="margin-top:12px;">
                    <label><strong><?php _e('Correos de Notificación (Separados por coma):', 'contacto-multidestino'); ?></strong></label>
                    <input type="text" id="cm-input-dept-emails" class="cm-apple-input-sm" style="height:34px !important;" placeholder="encargado@colegio.cl, direccion@colegio.cl" />
                </div>
                <div class="cm-form-row-compact" style="margin-top:12px;">
                    <label><strong><?php _e('Usuario Encargado Asignado:', 'contacto-multidestino'); ?></strong></label>
                    <select id="cm-select-dept-user" class="cm-apple-select-lg">
                        <option value="0"><?php _e('— Sin Asignar / Administrador General —', 'contacto-multidestino'); ?></option>
                        <?php foreach ($wp_users as $wu) : ?>
                            <option value="<?php echo esc_attr($wu->ID); ?>">
                                👤 <?php echo esc_html($wu->display_name . ' (' . $wu->user_login . ')'); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="cm-form-row-compact" style="margin-top:12px;">
                    <label style="display:flex; align-items:center; gap:8px; cursor:pointer;">
                        <input type="checkbox" id="cm-checkbox-dept-enabled" value="1" checked />
                        <span>🟢 <strong><?php _e('Área Habilitada para recibir formularios y derivaciones', 'contacto-multidestino'); ?></strong></span>
                    </label>
                </div>

                <!-- RESPUESTA AUTOMÁTICA PREDEFINIDA PARA ESTA ÁREA (ej: Currículum / Postulaciones) -->
                <div style="margin-top:14px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:12px 14px;">
                    <label style="display:flex; align-items:center; gap:8px; cursor:pointer; margin-bottom:6px;">
                        <input type="checkbox" id="cm-checkbox-dept-autoreply" value="1" onchange="jQuery('#cm-wrap-dept-autoreply').toggle(this.checked)" style="border-radius:4px; accent-color:#7c3aed;" />
                        <span>🤖 <strong><?php _e('Habilitar Respuesta Automática para esta Área', 'contacto-multidestino'); ?></strong></span>
                    </label>
                    <small style="color:#64748b; font-size:11px; display:block; margin-bottom:10px;">
                        <?php _e('Al ingresar una solicitud a esta área (ej. Currículum), se generará automáticamente una respuesta y cambio de estado.', 'contacto-multidestino'); ?>
                    </small>

                    <div id="cm-wrap-dept-autoreply" style="display:none; padding-top:8px; border-top:1px dashed #cbd5e1;">
                        <div style="display:flex; gap:10px; flex-wrap:wrap; margin-bottom:10px;">
                            <div style="flex:1; min-width:180px;">
                                <label style="font-size:11.5px; font-weight:700; color:#334155; display:block; margin-bottom:4px;">
                                    ⏱️ <?php _e('Tiempo de Respuesta:', 'contacto-multidestino'); ?>
                                </label>
                                <select id="cm-select-dept-delay" class="cm-apple-select" style="width:100%; height:32px !important; font-size:12px;">
                                    <option value="0"><?php _e('⚡ Inmediata (Al recibir formulario)', 'contacto-multidestino'); ?></option>
                                    <option value="5"><?php _e('⏱️ A los 5 minutos', 'contacto-multidestino'); ?></option>
                                    <option value="10"><?php _e('⏱️ A los 10 minutos', 'contacto-multidestino'); ?></option>
                                    <option value="15"><?php _e('⏱️ A los 15 minutos', 'contacto-multidestino'); ?></option>
                                    <option value="30"><?php _e('⏱️ A los 30 minutos', 'contacto-multidestino'); ?></option>
                                    <option value="60"><?php _e('⏱️ A los 60 minutos (1 hora)', 'contacto-multidestino'); ?></option>
                                </select>
                            </div>
                            <div style="flex:1; min-width:180px;">
                                <label style="font-size:11.5px; font-weight:700; color:#334155; display:block; margin-bottom:4px;">
                                    📌 <?php _e('Estado a Asignar:', 'contacto-multidestino'); ?>
                                </label>
                                <select id="cm-select-dept-autoreply-status" class="cm-apple-select" style="width:100%; height:32px !important; font-size:12px;">
                                    <option value="en_proceso"><?php _e('🟢 En Proceso / Tomado', 'contacto-multidestino'); ?></option>
                                    <option value="en_revision"><?php _e('🟡 En Revisión', 'contacto-multidestino'); ?></option>
                                    <option value="resuelto"><?php _e('⚪ Resuelto / Finalizado', 'contacto-multidestino'); ?></option>
                                </select>
                            </div>
                        </div>

                        <div class="cm-form-row-compact">
                            <label style="font-size:11.5px; font-weight:700; color:#334155;">
                                💬 <?php _e('Mensaje Predeterminado (Se enviará al solicitante y al historial):', 'contacto-multidestino'); ?>
                            </label>
                            <textarea id="cm-input-dept-autoreply-msg" class="cm-apple-textarea" rows="3" style="font-size:12px;" placeholder="<?php esc_attr_e('Ej: Documentos y antecedentes recibidos correctamente. Su currículum ha ingresado a nuestra área y se encuentra en etapa de evaluación y registro...', 'contacto-multidestino'); ?>"></textarea>
                        </div>
                    </div>
                </div>

                <div style="margin-top:16px; text-align:right;">
                    <button type="button" class="cm-btn-view" style="font-size:12.5px; padding:7px 16px; height:34px; font-weight:700;" onclick="cmSaveDeptModal()">
                        💾 <?php _e('Guardar Área', 'contacto-multidestino'); ?>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL CREAR NUEVO USUARIO / ENCARGADO / MODERADOR -->
    <div id="cm-user-modal-overlay" class="cm-apple-modal-overlay" style="display:none;">
        <div class="cm-apple-modal-box" style="max-width: 520px;">
            <div class="cm-apple-modal-head">
                <div class="cm-modal-head-left">
                    <span class="cm-modal-badge-app">SUPERADMIN</span>
                    <strong style="font-size:14px;"><?php _e('Crear Nuevo Usuario Institucional', 'contacto-multidestino'); ?></strong>
                </div>
                <button type="button" class="cm-apple-modal-close" onclick="jQuery('#cm-user-modal-overlay').fadeOut(100)">✕</button>
            </div>
            <div class="cm-apple-modal-body" style="padding:18px;">
                <div style="background:#eff6ff; border:1px solid #bfdbfe; border-radius:10px; padding:10px 12px; margin-bottom:12px;">
                    <div style="font-size:11px; font-weight:700; color:#1e40af; text-transform:uppercase; margin-bottom:4px;">
                        🔗 <?php _e('URL de Acceso para el Usuario:', 'contacto-multidestino'); ?>
                    </div>
                    <div style="display:flex; align-items:center; gap:6px;">
                        <code style="font-size:11px; color:#1e293b; background:#ffffff; padding:4px 8px; border-radius:6px; flex:1; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;"><?php echo esc_url(admin_url('admin.php?page=cm-form-submissions')); ?></code>
                        <button type="button" class="cm-btn-copy-sm" onclick="navigator.clipboard.writeText('<?php echo esc_url(admin_url('admin.php?page=cm-form-submissions')); ?>'); alert('✓ ¡Enlace copiado al portapapeles!');">
                            📋 <?php _e('Copiar', 'contacto-multidestino'); ?>
                        </button>
                    </div>
                    <div style="font-size:11px; color:#3b82f6; margin-top:4px;">
                        💡 <?php _e('El sistema enviará un correo automático con sus credenciales y las áreas a las que tiene acceso.', 'contacto-multidestino'); ?>
                    </div>
                </div>

                <div class="cm-form-row-compact">
                    <label><strong><?php _e('Perfil / Nivel de Acceso:', 'contacto-multidestino'); ?></strong></label>
                    <select id="cm-newuser-role" class="cm-apple-select-lg" onchange="cmOnNewUserRoleChange(this.value)">
                        <option value="editor">🏢 <?php _e('Encargado de Área (Atención de 1 o más departamentos)', 'contacto-multidestino'); ?></option>
                        <option value="moderator">🛡️ <?php _e('Subdirector / Moderador (Multi-Área: Gestiona múltiples áreas asignadas)', 'contacto-multidestino'); ?></option>
                        <option value="administrator">👑 <?php _e('Director / Administrador (Acceso Total a Dashboard y Todos los Casos)', 'contacto-multidestino'); ?></option>
                    </select>
                    <div id="cm-newuser-role-tip" style="font-size:11px; color:#0369a1; background:#f0f9ff; border:1px solid #e0f2fe; padding:6px 10px; border-radius:6px; margin-top:5px;">
                        🏢 <?php _e('El usuario podrá gestionar las solicitudes dirigidas a las áreas seleccionadas.', 'contacto-multidestino'); ?>
                    </div>
                </div>

                <div class="cm-form-row-compact" style="margin-top:10px;">
                    <label><strong><?php _e('Nombre de Usuario (Login):', 'contacto-multidestino'); ?></strong></label>
                    <input type="text" id="cm-newuser-login" class="cm-apple-input-sm" style="height:32px !important;" placeholder="ej: subdireccion_academica" />
                </div>
                <div class="cm-form-row-compact" style="margin-top:10px;">
                    <label><strong><?php _e('Nombre y Apellido Público:', 'contacto-multidestino'); ?></strong></label>
                    <input type="text" id="cm-newuser-name" class="cm-apple-input-sm" style="height:32px !important;" placeholder="ej: Subdirector Rodrigo Tapia" />
                </div>
                <div class="cm-form-row-compact" style="margin-top:10px;">
                    <label><strong><?php _e('Correo Electrónico:', 'contacto-multidestino'); ?></strong></label>
                    <input type="email" id="cm-newuser-email" class="cm-apple-input-sm" style="height:32px !important;" placeholder="rodrigo.tapia@colegio.cl" />
                </div>
                <div class="cm-form-row-compact" style="margin-top:10px;">
                    <label><strong><?php _e('Contraseña de Acceso:', 'contacto-multidestino'); ?></strong></label>
                    <input type="password" id="cm-newuser-pass" class="cm-apple-input-sm" style="height:32px !important;" placeholder="Contraseña segura..." />
                </div>

                <!-- SELECTOR MULTI-ÁREA CON CASILLAS DE VERIFICACIÓN -->
                <div id="cm-newuser-dept-wrap" class="cm-form-row-compact" style="margin-top:10px;">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
                        <label style="margin:0;"><strong><?php _e('Asignar Áreas de Atención (Selección Múltiple):', 'contacto-multidestino'); ?></strong></label>
                        <div style="display:flex; gap:6px;">
                            <button type="button" class="cm-btn-view" style="font-size:10px; padding:1px 6px; height:20px;" onclick="jQuery('.cm-newuser-dept-cb').prop('checked', true);">
                                <?php _e('Marcar Todas', 'contacto-multidestino'); ?>
                            </button>
                            <button type="button" class="cm-btn-view" style="font-size:10px; padding:1px 6px; height:20px;" onclick="jQuery('.cm-newuser-dept-cb').prop('checked', false);">
                                <?php _e('Desmarcar', 'contacto-multidestino'); ?>
                            </button>
                        </div>
                    </div>
                    <div style="max-height:160px; overflow-y:auto; background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:8px 10px;">
                        <?php foreach ($departments as $dkey => $dinfo) : 
                            $dname = is_array($dinfo) ? ($dinfo['name'] ?? $dkey) : $dinfo;
                            $cb_id = 'cb-newuser-dept-' . sanitize_title($dname);
                        ?>
                            <label for="<?php echo esc_attr($cb_id); ?>" style="display:flex; align-items:center; gap:8px; padding:5px 0; border-bottom:1px solid #f1f5f9; font-size:12px; cursor:pointer;">
                                <input type="checkbox" id="<?php echo esc_attr($cb_id); ?>" class="cm-newuser-dept-cb" value="<?php echo esc_attr($dname); ?>" style="border-radius:4px; accent-color:#0284c7;" />
                                <span>🏢 <strong><?php echo esc_html($dname); ?></strong></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- PERMISO DE DERIVACIÓN DE CASOS -->
                <div class="cm-form-row-compact" style="margin-top:12px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:10px 12px;">
                    <label style="display:flex; align-items:center; gap:8px; cursor:pointer; margin:0;">
                        <input type="checkbox" id="cm-newuser-allow-reassign" value="1" checked style="border-radius:4px; accent-color:#0284c7;" />
                        <span style="font-size:12.5px; font-weight:700; color:#1e293b;">🔄 <?php _e('Permitir a este usuario derivar casos a otras áreas', 'contacto-multidestino'); ?></span>
                    </label>
                    <small style="color:#64748b; font-size:11px; display:block; margin-top:4px;">
                        <?php _e('Si se desmarca, este usuario solo podrá ver y atender los casos de su(s) área(s) asignada(s), sin permisos para transferir o derivar a otros departamentos.', 'contacto-multidestino'); ?>
                    </small>
                </div>

                <div style="margin-top:16px; text-align:right;">
                    <button type="button" class="cm-btn-view" style="font-size:12.5px; padding:7px 16px; height:34px; font-weight:700;" onclick="cmSaveNewUserModal()">
                        👤 <?php _e('Crear y Guardar Usuario', 'contacto-multidestino'); ?>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL EDITAR PERFIL Y ÁREAS ASIGNADAS DE USUARIO -->
    <div id="cm-edituser-modal-overlay" class="cm-apple-modal-overlay" style="display:none;">
        <div class="cm-apple-modal-box" style="max-width: 520px;">
            <div class="cm-apple-modal-head">
                <div class="cm-modal-head-left">
                    <span class="cm-modal-badge-app" style="background:#eff6ff; color:#0284c7; border:1px solid #bae6fd;">GESTIÓN DE ACCESOS</span>
                    <strong style="font-size:14px;"><?php _e('Editar Áreas y Perfil de Usuario', 'contacto-multidestino'); ?></strong>
                </div>
                <button type="button" class="cm-apple-modal-close" onclick="jQuery('#cm-edituser-modal-overlay').fadeOut(100)">✕</button>
            </div>
            <div class="cm-apple-modal-body" style="padding:18px;">
                <input type="hidden" id="cm-edituser-id" value="" />
                
                <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:10px 12px; margin-bottom:12px;">
                    <div style="font-size:11px; font-weight:700; color:#64748b; text-transform:uppercase; margin-bottom:2px;">
                        👤 <?php _e('Cuenta de Usuario:', 'contacto-multidestino'); ?>
                    </div>
                    <div style="font-size:14px; font-weight:800; color:#0f172a;" id="cm-edituser-login-display">—</div>
                </div>

                <div class="cm-form-row-compact">
                    <label><strong><?php _e('Perfil / Nivel de Acceso:', 'contacto-multidestino'); ?></strong></label>
                    <select id="cm-edituser-role" class="cm-apple-select-lg" onchange="cmOnEditUserRoleChange(this.value)">
                        <option value="editor">🏢 <?php _e('Encargado de Área (Atención de departamentos específicos)', 'contacto-multidestino'); ?></option>
                        <option value="moderator">🛡️ <?php _e('Subdirector / Moderador (Multi-Área: Gestiona múltiples áreas asignadas)', 'contacto-multidestino'); ?></option>
                        <option value="administrator">👑 <?php _e('Director / Administrador (Acceso Total a Dashboard y Todos los Casos)', 'contacto-multidestino'); ?></option>
                    </select>
                    <div id="cm-edituser-role-tip" style="font-size:11px; color:#0369a1; background:#f0f9ff; border:1px solid #e0f2fe; padding:6px 10px; border-radius:6px; margin-top:5px;">
                        🏢 <?php _e('El usuario tendrá acceso exclusivo a los expedientes de sus áreas asignadas.', 'contacto-multidestino'); ?>
                    </div>
                </div>

                <div class="cm-form-row-compact" style="margin-top:10px;">
                    <label><strong><?php _e('Nombre y Apellido Público:', 'contacto-multidestino'); ?></strong></label>
                    <input type="text" id="cm-edituser-name" class="cm-apple-input-sm" style="height:32px !important;" />
                </div>
                <div class="cm-form-row-compact" style="margin-top:10px;">
                    <label><strong><?php _e('Correo Electrónico:', 'contacto-multidestino'); ?></strong></label>
                    <input type="email" id="cm-edituser-email" class="cm-apple-input-sm" style="height:32px !important;" />
                </div>
                <div class="cm-form-row-compact" style="margin-top:10px;">
                    <label><strong><?php _e('Cambiar Contraseña (Opcional, dejar vacío si no cambia):', 'contacto-multidestino'); ?></strong></label>
                    <input type="password" id="cm-edituser-pass" class="cm-apple-input-sm" style="height:32px !important;" placeholder="Nueva contraseña..." />
                </div>

                <!-- SELECTOR MULTI-ÁREA PARA EDICIÓN -->
                <div id="cm-edituser-dept-wrap" class="cm-form-row-compact" style="margin-top:10px;">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
                        <label style="margin:0;"><strong><?php _e('Áreas Asignadas (Selección Múltiple):', 'contacto-multidestino'); ?></strong></label>
                        <div style="display:flex; gap:6px;">
                            <button type="button" class="cm-btn-view" style="font-size:10px; padding:1px 6px; height:20px;" onclick="jQuery('.cm-edituser-dept-cb').prop('checked', true);">
                                <?php _e('Marcar Todas', 'contacto-multidestino'); ?>
                            </button>
                            <button type="button" class="cm-btn-view" style="font-size:10px; padding:1px 6px; height:20px;" onclick="jQuery('.cm-edituser-dept-cb').prop('checked', false);">
                                <?php _e('Desmarcar', 'contacto-multidestino'); ?>
                            </button>
                        </div>
                    </div>
                    <div style="max-height:160px; overflow-y:auto; background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:8px 10px;">
                        <?php foreach ($departments as $dkey => $dinfo) : 
                            $dname = is_array($dinfo) ? ($dinfo['name'] ?? $dkey) : $dinfo;
                            $cb_id = 'cb-edituser-dept-' . sanitize_title($dname);
                        ?>
                            <label for="<?php echo esc_attr($cb_id); ?>" style="display:flex; align-items:center; gap:8px; padding:5px 0; border-bottom:1px solid #f1f5f9; font-size:12px; cursor:pointer;">
                                <input type="checkbox" id="<?php echo esc_attr($cb_id); ?>" class="cm-edituser-dept-cb" value="<?php echo esc_attr($dname); ?>" style="border-radius:4px; accent-color:#0284c7;" />
                                <span>🏢 <strong><?php echo esc_html($dname); ?></strong></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- PERMISO DE DERIVACIÓN DE CASOS EN EDICIÓN -->
                <div class="cm-form-row-compact" style="margin-top:12px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:10px 12px;">
                    <label style="display:flex; align-items:center; gap:8px; cursor:pointer; margin:0;">
                        <input type="checkbox" id="cm-edituser-allow-reassign" value="1" checked style="border-radius:4px; accent-color:#0284c7;" />
                        <span style="font-size:12.5px; font-weight:700; color:#1e293b;">🔄 <?php _e('Permitir a este usuario derivar casos a otras áreas', 'contacto-multidestino'); ?></span>
                    </label>
                    <small style="color:#64748b; font-size:11px; display:block; margin-top:4px;">
                        <?php _e('Si se desmarca, este usuario solo podrá ver y gestionar casos de su(s) área(s) asignada(s), sin poder derivar ni transferir casos a otros departamentos.', 'contacto-multidestino'); ?>
                    </small>
                </div>

                <div style="margin-top:16px; text-align:right; display:flex; justify-content:space-between; align-items:center;">
                    <button type="button" class="cm-apple-btn-secondary" onclick="jQuery('#cm-edituser-modal-overlay').fadeOut(100)">
                        ✕ <?php _e('Cancelar', 'contacto-multidestino'); ?>
                    </button>
                    <button type="button" class="cm-btn-view" style="font-size:12.5px; padding:7px 16px; height:34px; font-weight:700;" id="cm-btn-save-edituser" onclick="cmSaveEditUserModal()">
                        💾 <?php _e('Guardar Cambios de Áreas / Perfil', 'contacto-multidestino'); ?>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL RESTABLECER / CAMBIAR CONTRASEÑA DE USUARIO -->
    <div id="cm-resetpass-modal-overlay" class="cm-apple-modal-overlay" style="display:none;">
        <div class="cm-apple-modal-box" style="max-width: 460px;">
            <div class="cm-apple-modal-head">
                <div class="cm-modal-head-left">
                    <span class="cm-modal-badge-app" style="background:#eff6ff; color:#0071e3; border:1px solid #bfdbfe;">SEGURIDAD</span>
                    <strong style="font-size:14px;"><?php _e('Cambiar / Restablecer Clave', 'contacto-multidestino'); ?></strong>
                </div>
                <button type="button" class="cm-apple-modal-close" onclick="jQuery('#cm-resetpass-modal-overlay').fadeOut(100)">✕</button>
            </div>
            <div class="cm-apple-modal-body" style="padding:18px;">
                <input type="hidden" id="cm-resetpass-userid" value="" />
                
                <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:10px 14px; margin-bottom:14px; display:flex; align-items:center; gap:8px;">
                    <span style="font-size:18px;">👤</span>
                    <div>
                        <div style="font-size:11px; font-weight:700; color:#64748b; text-transform:uppercase;"><?php _e('Usuario a Modificar:', 'contacto-multidestino'); ?></div>
                        <strong id="cm-resetpass-username" style="font-size:14px; color:#0f172a;">—</strong>
                    </div>
                </div>

                <div class="cm-form-row-compact">
                    <label><strong><?php _e('Nueva Contraseña:', 'contacto-multidestino'); ?></strong></label>
                    <div style="display:flex; gap:6px; margin-top:4px;">
                        <input type="text" id="cm-resetpass-new" class="cm-apple-input-sm" style="height:34px !important; flex:1; font-family:monospace; font-size:13.5px;" placeholder="Escribe la nueva contraseña..." />
                        <button type="button" class="cm-btn-view" style="font-size:11.5px; padding:0 10px; height:34px;" onclick="cmGenerateRandomPass()" title="Generar una contraseña aleatoria segura">
                            🎲 <?php _e('Generar', 'contacto-multidestino'); ?>
                        </button>
                    </div>
                    <small style="color:#64748b; font-size:11px; margin-top:4px; display:block;">
                        <?php _e('Mínimo 6 caracteres. El usuario podrá iniciar sesión inmediatamente con esta clave.', 'contacto-multidestino'); ?>
                    </small>
                </div>

                <div style="margin-top:18px; text-align:right; display:flex; justify-content:flex-end; gap:8px;">
                    <button type="button" class="cm-apple-btn-secondary" onclick="jQuery('#cm-resetpass-modal-overlay').fadeOut(100)">
                        <?php _e('Cancelar', 'contacto-multidestino'); ?>
                    </button>
                    <button type="button" class="cm-btn-view" style="font-size:12.5px; padding:7px 16px; height:34px; font-weight:700;" id="cm-btn-submit-resetpass" onclick="cmSubmitResetPasswordModal()">
                        💾 <?php _e('Guardar Nueva Clave', 'contacto-multidestino'); ?>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL ACTIVAR AUTENTICACIÓN DE DOS FACTORES (2FA) -->
    <div id="cm-2fa-setup-modal-overlay" class="cm-apple-modal-overlay" style="display:none;">
        <div class="cm-apple-modal-box" style="max-width: 480px;">
            <div class="cm-apple-modal-head">
                <div class="cm-modal-head-left">
                    <span class="cm-modal-badge-app" style="background:#eff6ff; color:#0284c7; border:1px solid #bae6fd;">SEGURIDAD 2FA</span>
                    <strong style="font-size:14px;"><?php _e('Activar Autenticación 2FA', 'contacto-multidestino'); ?></strong>
                </div>
                <button type="button" class="cm-apple-modal-close" onclick="cmClose2FAModal()">✕</button>
            </div>
            <div class="cm-apple-modal-body" style="padding:18px;">
                <p style="font-size:12.5px; color:#475569; margin:0 0 14px 0; line-height:1.4;">
                    <?php _e('Escanea este código QR con tu aplicación móvil preferida (<strong>Google Authenticator</strong>, <strong>Microsoft Authenticator</strong> o <strong>Apple Passwords</strong>):', 'contacto-multidestino'); ?>
                </p>

                <div style="text-align:center; margin-bottom:14px;">
                    <div style="display:inline-block; padding:8px; background:#ffffff; border:1.5px solid #e2e8f0; border-radius:12px; box-shadow:0 2px 8px rgba(0,0,0,0.06);">
                        <img id="cm-2fa-qr-img" src="" alt="QR 2FA" style="width:180px; height:180px; display:block; margin:0 auto;" />
                    </div>
                </div>

                <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:8px 12px; margin-bottom:14px;">
                    <label style="font-size:10.5px; font-weight:700; color:#64748b; text-transform:uppercase; display:block; margin-bottom:2px;">
                        🔑 <?php _e('Clave de Configuración Manual:', 'contacto-multidestino'); ?>
                    </label>
                    <div style="display:flex; align-items:center; justify-content:space-between; gap:8px;">
                        <code id="cm-2fa-secret-text" style="font-size:13px; font-weight:800; color:#0f172a; letter-spacing:1.5px;">—</code>
                        <button type="button" class="cm-btn-view" style="font-size:11px; padding:2px 8px; height:24px;" onclick="cmCopy2FASecret()">
                            📋 <?php _e('Copiar', 'contacto-multidestino'); ?>
                        </button>
                    </div>
                </div>

                <div class="cm-form-row-compact">
                    <label><strong><?php _e('Ingresa el código de 6 dígitos que muestra tu app:', 'contacto-multidestino'); ?></strong></label>
                    <input 
                        type="text" 
                        id="cm-2fa-code-input" 
                        class="cm-apple-input-sm" 
                        maxlength="6" 
                        placeholder="123456" 
                        inputmode="numeric" 
                        pattern="[0-9]*" 
                        style="font-family:monospace; font-size:20px; letter-spacing:6px; text-align:center; font-weight:800; height:44px !important; width:100%; box-sizing:border-box; margin-top:4px;" 
                    />
                </div>

                <div style="margin-top:16px; text-align:right; display:flex; justify-content:flex-end; gap:8px;">
                    <button type="button" class="cm-apple-btn-secondary" onclick="cmClose2FAModal()">
                        <?php _e('Cancelar', 'contacto-multidestino'); ?>
                    </button>
                    <button type="button" class="cm-apple-btn-primary" id="cm-btn-submit-2fa" style="background:#0284c7; border-color:#0369a1; font-weight:700;" onclick="cmVerifyAndEnable2FA()">
                        ✓ <?php _e('Confirmar y Activar 2FA', 'contacto-multidestino'); ?>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL SUPERADMIN: GESTIÓN DE SEGURIDAD 2FA DE USUARIOS -->
    <div id="cm-admin-manage-2fa-modal-overlay" class="cm-apple-modal-overlay" style="display:none;">
        <div class="cm-apple-modal-box" style="max-width: 480px;">
            <div class="cm-apple-modal-head">
                <div class="cm-modal-head-left">
                    <span class="cm-modal-badge-app" style="background:#eff6ff; color:#0284c7; border:1px solid #bae6fd;">SEGURIDAD 2FA</span>
                    <strong style="font-size:14px;"><?php _e('Control de Seguridad 2FA', 'contacto-multidestino'); ?></strong>
                </div>
                <button type="button" class="cm-apple-modal-close" onclick="cmCloseAdminUser2FAModal()">✕</button>
            </div>
            <div class="cm-apple-modal-body" style="padding:18px;">
                <input type="hidden" id="cm-m2fa-userid" value="" />
                <input type="hidden" id="cm-m2fa-userlogin" value="" />

                <!-- Datos de la Cuenta -->
                <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:12px 14px; margin-bottom:14px; display:flex; align-items:center; gap:10px;">
                    <div style="font-size:24px; background:#ffffff; width:40px; height:40px; border-radius:8px; display:flex; align-items:center; justify-content:center; box-shadow:0 1px 3px rgba(0,0,0,0.06);">
                        👤
                    </div>
                    <div>
                        <div style="font-size:11px; font-weight:700; color:#64748b; text-transform:uppercase;"><?php _e('Usuario Seleccionado:', 'contacto-multidestino'); ?></div>
                        <div style="font-size:14px; font-weight:700; color:#0f172a;">
                            <code id="cm-m2fa-username">—</code> <span id="cm-m2fa-displayname" style="font-size:12px; color:#64748b; font-weight:normal;"></span>
                        </div>
                    </div>
                </div>

                <!-- Estado del 2FA -->
                <div id="cm-m2fa-status-box" style="border-radius:10px; padding:14px; margin-bottom:16px;">
                    <!-- Rellenado dinámicamente con JS -->
                </div>

                <!-- Opciones de Gestión -->
                <div id="cm-m2fa-actions-wrap" style="display:flex; flex-direction:column; gap:10px;">
                    <!-- Botón para desplegar Generación y Asignación de 2FA -->
                    <button 
                        type="button" 
                        class="cm-apple-btn-primary" 
                        id="cm-btn-show-generate-2fa"
                        style="background:#0284c7; border-color:#0369a1; font-weight:700; height:38px; display:flex; align-items:center; justify-content:center; gap:6px; cursor:pointer;"
                        onclick="cmAdminToggleGenerateUser2FA()"
                    >
                        📲 <?php _e('Asignar / Generar Nueva Clave y QR', 'contacto-multidestino'); ?>
                    </button>

                    <!-- Panel con QR y Clave para el Usuario Seleccionado (inicialmente oculto) -->
                    <div id="cm-m2fa-generate-panel" style="display:none; background:#f8fafc; border:1.5px solid #bae6fd; border-radius:10px; padding:14px; margin-top:4px;">
                        <div style="font-size:12px; color:#0369a1; font-weight:700; margin-bottom:10px;">
                            📲 <?php _e('Escanea este QR con la app del usuario (Google Authenticator / Apple):', 'contacto-multidestino'); ?>
                        </div>

                        <div style="text-align:center; margin-bottom:12px;">
                            <div style="display:inline-block; padding:6px; background:#ffffff; border:1px solid #e2e8f0; border-radius:10px; box-shadow:0 2px 6px rgba(0,0,0,0.05);">
                                <img id="cm-m2fa-qr-img" src="" alt="QR 2FA" style="width:160px; height:160px; display:block; margin:0 auto;" />
                            </div>
                        </div>

                        <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:8px; padding:8px 10px; margin-bottom:12px;">
                            <label style="font-size:10px; font-weight:700; color:#64748b; text-transform:uppercase; display:block; margin-bottom:2px;">
                                🔑 <?php _e('Clave de Configuración Manual:', 'contacto-multidestino'); ?>
                            </label>
                            <div style="display:flex; align-items:center; justify-content:space-between; gap:6px;">
                                <code id="cm-m2fa-secret-text" style="font-size:12.5px; font-weight:800; color:#0f172a; letter-spacing:1px;">—</code>
                                <button type="button" class="cm-btn-view" style="font-size:10.5px; padding:2px 7px; height:24px;" onclick="cmCopyAdminGenerated2FASecret()">
                                    📋 <?php _e('Copiar', 'contacto-multidestino'); ?>
                                </button>
                            </div>
                        </div>

                        <div class="cm-form-row-compact">
                            <label style="font-size:11.5px;"><strong><?php _e('Código de 6 dígitos de prueba (Opcional):', 'contacto-multidestino'); ?></strong></label>
                            <input 
                                type="text" 
                                id="cm-m2fa-verify-code-input" 
                                class="cm-apple-input-sm" 
                                maxlength="6" 
                                placeholder="123456" 
                                inputmode="numeric" 
                                pattern="[0-9]*" 
                                style="font-family:monospace; font-size:16px; letter-spacing:4px; text-align:center; font-weight:800; height:36px !important; width:100%; box-sizing:border-box; margin-top:3px;" 
                            />
                        </div>

                        <div style="margin-top:12px; display:flex; justify-content:flex-end; gap:6px;">
                            <button 
                                type="button" 
                                class="cm-apple-btn-primary" 
                                id="cm-btn-confirm-assign-2fa"
                                style="background:#059669; border-color:#047857; font-weight:700; height:34px; font-size:12px; width:100%;"
                                onclick="cmAdminConfirmAssignUser2FA()"
                            >
                                ✓ <?php _e('Activar y Asignar este 2FA al Usuario', 'contacto-multidestino'); ?>
                            </button>
                        </div>
                    </div>

                    <div id="cm-m2fa-active-actions" style="display:flex; flex-direction:column; gap:10px;">
                        <button 
                            type="button" 
                            class="cm-apple-btn-secondary" 
                            style="background:#fff1f2; border:1px solid #fecdd3; color:#e11d48 !important; font-weight:700; height:38px; display:flex; align-items:center; justify-content:center; gap:6px; cursor:pointer;"
                            onclick="cmAdminModalDisable2FA()"
                        >
                            🔓 <?php _e('Quitar 2FA a este Usuario', 'contacto-multidestino'); ?>
                        </button>
                        <button 
                            type="button" 
                            class="cm-apple-btn-secondary" 
                            style="background:#f0f9ff; border:1px solid #bae6fd; color:#0284c7 !important; font-weight:700; height:38px; display:flex; align-items:center; justify-content:center; gap:6px; cursor:pointer;"
                            onclick="cmAdminModalReset2FA()"
                        >
                            🔄 <?php _e('Restablecer 2FA (Re-vincular App)', 'contacto-multidestino'); ?>
                        </button>
                    </div>
                </div>

                <div style="margin-top:18px; text-align:right; border-top:1px solid #e2e8f0; padding-top:12px;">
                    <button type="button" class="cm-apple-btn-secondary" onclick="cmCloseAdminUser2FAModal()">
                        <?php _e('Cerrar', 'contacto-multidestino'); ?>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL APPLE PRO DE DETALLE Y GESTIÓN DEL CASO -->
    <div id="cm-case-modal-overlay" class="cm-apple-modal-overlay" style="display:none;">
        <div class="cm-apple-modal-box">
            <div class="cm-apple-modal-head">
                <div class="cm-modal-head-left">
                    <span class="cm-modal-badge-app">EXPEDIENTE</span>
                    <span id="cm-modal-ticket-title" class="cm-modal-ticket-code">CL000000</span>
                    <a id="cm-modal-public-link" href="#" target="_blank" class="cm-portal-link-btn" style="display:none; font-size:11px; font-weight:700; color:#0284c7; background:#e0f2fe; border:1px solid #bae6fd; border-radius:6px; padding:3px 9px; text-decoration:none; align-items:center; gap:4px; margin-left:6px;" title="<?php esc_attr_e('Abrir página pública donde el solicitante ve su caso', 'contacto-multidestino'); ?>">
                        🌐 <?php _e('Ir al Caso en la Web', 'contacto-multidestino'); ?> ↗
                    </a>
                </div>
                <div style="display:flex; align-items:center; gap:8px;">
                    <a id="cm-modal-fullpage-link" href="#" class="cm-apple-btn-secondary" style="display:none; font-size:12px; font-weight:700; align-items:center; gap:5px; padding:5px 12px; background:#f8fafc; border-color:#cbd5e1; text-decoration:none;" title="<?php esc_attr_e('Abrir este caso en página completa', 'contacto-multidestino'); ?>">
                        🖥️ <?php _e('Página Completa', 'contacto-multidestino'); ?>
                    </a>
                    <button type="button" class="cm-apple-btn-secondary" id="cm-btn-modal-print" onclick="cmOpenPrintPreview()" style="font-size:12px; font-weight:700; display:inline-flex; align-items:center; gap:5px; padding:5px 12px; background:#f8fafc; border-color:#cbd5e1;" title="<?php esc_attr_e('Vista Previa e Impresión Oficial en Tamaño Carta', 'contacto-multidestino'); ?>">
                        🖨️ <?php _e('Imprimir Informe (Carta)', 'contacto-multidestino'); ?>
                    </button>
                    <button type="button" class="cm-apple-modal-close" onclick="cmCloseCaseModal()">✕</button>
                </div>
            </div>
            <div class="cm-apple-modal-body" id="cm-modal-body-content">
                <div class="cm-modal-loading">
                    <span class="spinner is-active"></span>
                    <p><?php _e('Cargando expediente...', 'contacto-multidestino'); ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL LIGHTBOX DE VISUALIZACIÓN DE DOCUMENTOS/IMÁGENES -->
    <div id="cm-lightbox-modal" class="cm-lightbox-overlay" style="display:none;" onclick="cmCloseDocumentPreview(event)">
        <div class="cm-lightbox-box" onclick="event.stopPropagation();">
            <div class="cm-lightbox-head">
                <span id="cm-lightbox-filename" class="cm-lightbox-title">Documento</span>
                <div class="cm-lightbox-actions">
                    <a id="cm-lightbox-download" href="#" target="_blank" class="cm-apple-btn-secondary" style="font-size:12px; font-weight:700;">
                        ⬇️ <?php _e('Descargar Original', 'contacto-multidestino'); ?>
                    </a>
                    <button type="button" class="cm-apple-modal-close" onclick="cmCloseDocumentPreview()">✕</button>
                </div>
            </div>
            <div class="cm-lightbox-body" id="cm-lightbox-content"></div>
        </div>
    </div>

    <!-- Scripts AJAX Apple Pro -->
    <script>
    var cmCurrentCasePrintHtml = '';

    function cmOpenCaseModal(submissionId) {
        window.cmCurrentOpenCaseId = submissionId;
        var $overlay = jQuery('#cm-case-modal-overlay');
        var $body    = jQuery('#cm-modal-body-content');
        
        $overlay.fadeIn(120).css('display', 'flex');
        $body.html('<div class="cm-modal-loading"><span class="spinner is-active"></span><p>Cargando información del caso...</p></div>');
        jQuery('#cm-modal-public-link').hide();
        var isPortal = window.location.href.indexOf('cm_portal=1') !== -1;
        var fullpageBase = isPortal ? '<?php echo esc_url_raw(home_url("/")); ?>?cm_portal=1&case_id=' : '<?php echo esc_url_raw(admin_url("admin.php?page=cm-form-submissions&case_id=")); ?>';
        jQuery('#cm-modal-fullpage-link').attr('href', fullpageBase + submissionId).css('display', 'inline-flex');
        
        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_get_case_detail',
                id: submissionId,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                if (res.success) {
                    $body.html(res.data.html);
                    if (res.data.ticket_code) {
                        jQuery('#cm-modal-ticket-title').text(res.data.ticket_code);
                    }
                    if (res.data.tracker_url) {
                        jQuery('#cm-modal-public-link').attr('href', res.data.tracker_url).css('display', 'inline-flex');
                    }
                    if (res.data.print_html) {
                        cmCurrentCasePrintHtml = res.data.print_html;
                    }
                } else {
                    $body.html('<div class="cm-modal-error">' + (res.data.message || 'Error al cargar el caso.') + '</div>');
                }
            },
            error: function() {
                $body.html('<div class="cm-modal-error">Error de conexión con el servidor.</div>');
            }
        });
    }

    window.cmOpenPrintPreview = function() {
        if (!cmCurrentCasePrintHtml) {
            alert('Cargando datos del expediente para imprimir...');
            return;
        }
        
        var ticketCode = jQuery('#cm-modal-ticket-title').text() || 'EXPEDIENTE';
        var printWindow = window.open('', '_blank');
        if (!printWindow) {
            alert('Por favor habilita las ventanas emergentes en tu navegador para abrir el expediente en una página aparte.');
            return;
        }

        var doc = printWindow.document;
        doc.open();
        doc.write('<!DOCTYPE html>' +
            '<html lang="es"><head>' +
            '<meta charset="UTF-8">' +
            '<meta name="viewport" content="width=device-width, initial-scale=1.0">' +
            '<title>Expediente Oficial - ' + ticketCode + '</title>' +
            '<style>' +
            '@page { size: letter portrait; margin: 12mm 15mm; }' +
            '* { box-sizing: border-box; }' +
            'body { margin: 0; padding: 0; background: #525659; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; color: #111827; }' +
            '.cm-print-topbar { position: sticky; top: 0; z-index: 9999; background: #ffffff; padding: 12px 24px; display: flex; align-items: center; justify-content: space-between; box-shadow: 0 2px 10px rgba(0,0,0,0.18); border-bottom: 1px solid #e2e8f0; }' +
            '.cm-print-action-btn { background: #0071e3; color: #ffffff; border: none; border-radius: 8px; padding: 9px 22px; font-size: 14px; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 6px; box-shadow: 0 2px 8px rgba(0,113,227,0.35); transition: background 0.15s ease; }' +
            '.cm-print-action-btn:hover { background: #0077ed; }' +
            '.cm-print-close-btn { background: #f1f5f9; color: #475569; border: 1px solid #cbd5e1; border-radius: 8px; padding: 8px 16px; font-size: 13px; font-weight: 600; cursor: pointer; }' +
            '.cm-print-close-btn:hover { background: #e2e8f0; }' +
            '.cm-dossier-wrap { display: flex; justify-content: center; padding: 28px 16px 60px; }' +
            '.cm-dossier-sheet { width: 100%; max-width: 816px; background: #ffffff; padding: 48px 56px; box-shadow: 0 12px 36px rgba(0,0,0,0.3); border-radius: 4px; min-height: 1056px; }' +
            'table { width: 100%; border-collapse: collapse; }' +
            '@media print {' +
            '  body { background: #ffffff !important; padding: 0 !important; }' +
            '  .cm-print-topbar { display: none !important; }' +
            '  .cm-dossier-wrap { padding: 0 !important; display: block !important; }' +
            '  .cm-dossier-sheet { box-shadow: none !important; padding: 0 !important; border-radius: 0 !important; max-width: 100% !important; min-height: auto !important; }' +
            '}' +
            '</style>' +
            '</head><body>' +
            '<div class="cm-print-topbar">' +
            '  <div style="display:flex; align-items:center; gap:8px;">' +
            '    <span style="font-size:14.5px; font-weight:700; color:#1e293b;">📄 Expediente Oficial • Formato Carta (8.5" x 11")</span>' +
            '    <span style="font-size:11px; background:#e2e8f0; color:#475569; padding:2px 8px; border-radius:10px; font-weight:700;">' + ticketCode + '</span>' +
            '  </div>' +
            '  <div style="display:flex; align-items:center; gap:10px;">' +
            '    <button class="cm-print-action-btn" onclick="window.print()">🖨️ Imprimir Caso Ahora</button>' +
            '    <button class="cm-print-close-btn" onclick="window.close()">✕ Cerrar Pestaña</button>' +
            '  </div>' +
            '</div>' +
            '<div class="cm-dossier-wrap">' +
            '  <div class="cm-dossier-sheet">' +
            cmCurrentCasePrintHtml +
            '  </div>' +
            '</div>' +
            '</body></html>'
        );
        doc.close();
    };

    window.cmOpenDocumentPreview = function(fileUrl, fileName, isImage) {
        // Registrar en auditoría la visualización del archivo
        var curCaseId = window.cmCurrentOpenCaseId || 0;
        var curTicket = jQuery('#cm-modal-ticket-title').text() || 'EXPEDIENTE';
        if (typeof ajaxurl !== 'undefined') {
            jQuery.post(ajaxurl, {
                action: 'cm_log_client_audit_event',
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>',
                case_id: curCaseId,
                ticket_code: curTicket,
                audit_action: 'attachment_view',
                details: 'Visualizó ' + (isImage ? 'la imagen adjunta' : 'el documento') + ': ' + (fileName || 'Archivo')
            });
        }

        if (isImage) {
            jQuery('#cm-lightbox-filename').text(fileName);
            jQuery('#cm-lightbox-download').attr('href', fileUrl);
            jQuery('#cm-lightbox-content').html('<img src="' + fileUrl + '" class="cm-lightbox-img" alt="' + fileName + '" />');
            jQuery('#cm-lightbox-modal').fadeIn(150).css('display', 'flex');
        } else {
            window.open(fileUrl, '_blank');
        }
    };

    window.cmCloseDocumentPreview = function(e) {
        jQuery('#cm-lightbox-modal').fadeOut(120);
    };

    window.cmCloseCaseModal = function() {
        jQuery('#cm-case-modal-overlay').fadeOut(100);
    };

    window.cmSwitchInspectorTab = function(tab) {
        jQuery('.cm-modal-tab-btn').removeClass('active');
        jQuery('.cm-tab-pane').hide();
        if (tab === 'manage') {
            jQuery('#cm-tab-btn-manage').addClass('active');
            jQuery('#cm-pane-manage').fadeIn(100);
        } else if (tab === 'transfer') {
            jQuery('#cm-tab-btn-transfer').addClass('active');
            jQuery('#cm-pane-transfer').fadeIn(100);
        }
    };

    window.cmSwitchModalTab = function(tabId) {
        window.cmSwitchInspectorTab(tabId);
    };

    window.cmToggleDocTitleInput = function(checkbox) {
        var isChecked = checkbox && (checkbox.checked !== undefined ? checkbox.checked : jQuery(checkbox).is(':checked'));
        if (isChecked) {
            jQuery('#cm-wrap-doc-title').slideDown(120);
            jQuery('#cm-input-doc-title').focus();
            if (!jQuery('#cm-input-doc-title').val()) {
                jQuery('#cm-input-doc-title').val('Adjuntar documentación solicitada para dar curso al requerimiento');
            }
        } else {
            jQuery('#cm-wrap-doc-title').slideUp(100);
        }
    };

    window.cmToggleDocRequestTitle = function(chk) {
        window.cmToggleDocTitleInput(chk);
    };

    window.cmToggleManageForm = function() {
        var $body = jQuery('#cm-manage-form-body');
        if ($body.is(':visible')) {
            $body.slideUp(180);
            jQuery('#cm-toggle-manage-btn-icon').text('🔽');
            jQuery('#cm-toggle-manage-btn-text').text('Desplegar Formulario');
        } else {
            $body.slideDown(180);
            jQuery('#cm-toggle-manage-btn-icon').text('🔼');
            jQuery('#cm-toggle-manage-btn-text').text('Ocultar Formulario');
        }
    };

    window.cmApplyQuickResponse = function(text, status, reqDoc, reqPresence) {
        // Asegurar que el formulario esté expandido si estaba colapsado
        var $body = jQuery('#cm-manage-form-body');
        if ($body.length && !$body.is(':visible')) {
            $body.slideDown(180);
            jQuery('#cm-toggle-manage-btn-icon').text('🔼');
            jQuery('#cm-toggle-manage-btn-text').text('Ocultar Formulario');
        }

        var $note = jQuery('#cm-input-case-note').length ? jQuery('#cm-input-case-note') : jQuery('#cm-update-note');
        $note.val(text).focus();
        if (status) {
            jQuery('#cm-select-new-status').val(status);
        }
        if (reqDoc) {
            jQuery('#cm-check-req-doc').prop('checked', true);
            jQuery('#cm-wrap-doc-title').slideDown(120);
            if (!jQuery('#cm-input-doc-title').val()) {
                jQuery('#cm-input-doc-title').val('Adjuntar documentación solicitada para dar curso al requerimiento');
            }
        }
        if (reqPresence) {
            jQuery('#cm-check-req-presence').prop('checked', true);
        }
    };

    window.cmToggleNewQuickNoteForm = function() {
        var $form = jQuery('#cm-form-new-quick-note');
        if ($form.is(':visible')) {
            $form.slideUp(120);
        } else {
            $form.slideDown(120);
            jQuery('#cm-input-qn-title').focus();
        }
    };

    window.cmSaveNewQuickNote = function() {
        var title   = jQuery('#cm-input-qn-title').val().trim();
        var content = jQuery('#cm-input-qn-content').val().trim();
        var status  = jQuery('#cm-select-qn-status').val();
        var reqDoc  = jQuery('#cm-check-qn-doc').is(':checked') ? 1 : 0;
        var reqPres = jQuery('#cm-check-qn-pres').is(':checked') ? 1 : 0;

        if (!title || !content) {
            alert('Por favor ingresa un título corto y el contenido de la nota.');
            return;
        }

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_save_quick_note',
                title: title,
                content: content,
                status: status,
                req_doc: reqDoc,
                req_presence: reqPres,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                if (res.success && res.data && res.data.note) {
                    var n = res.data.note;
                    var pillHtml = '<div class="cm-qn-pill-wrap" style="display:inline-flex; align-items:center; gap:4px; background:#ffffff; border:1px solid #cbd5e1; border-radius:16px; padding:3px 10px; box-shadow:0 1px 2px rgba(0,0,0,0.04);">' +
                        '<button type="button" style="border:none; background:transparent; padding:0; font-size:11.5px; font-weight:600; color:#1e293b; cursor:pointer;" onclick=\'cmApplyQuickResponse(' + JSON.stringify(n.content) + ', ' + JSON.stringify(n.status) + ', ' + (n.req_doc ? 'true' : 'false') + ', ' + (n.req_presence ? 'true' : 'false') + ')\'>' +
                        jQuery('<div>').text(n.title).html() +
                        '</button>' +
                        '<button type="button" style="border:none; background:transparent; color:#ef4444; font-size:12px; font-weight:bold; cursor:pointer; padding:0 0 0 4px; line-height:1;" onclick="cmDeleteQuickNote(\'' + n.id + '\', event)">✕</button>' +
                        '</div>';
                    
                    jQuery('#cm-quick-notes-list').append(pillHtml);
                    cmApplyQuickResponse(n.content, n.status, n.req_doc, n.req_presence);
                    jQuery('#cm-input-qn-title').val('');
                    jQuery('#cm-input-qn-content').val('');
                    jQuery('#cm-form-new-quick-note').slideUp(120);
                    alert('✓ Nota rápida guardada y aplicada exitosamente.');
                } else {
                    alert('Error: ' + ((res.data && res.data.message) ? res.data.message : 'No se pudo guardar la nota.'));
                }
            },
            error: function() {
                alert('Error de conexión al guardar nota rápida.');
            }
        });
    };

    window.cmToggleQuickNotesSection = function() {
        var $c = jQuery('#cm-quick-notes-container');
        if ($c.is(':visible')) {
            $c.slideUp(150);
            jQuery('#cm-txt-toggle-qn').text('Mostrar Notas');
            try { localStorage.setItem('cm_hide_quick_notes', '1'); } catch(e) {}
        } else {
            $c.slideDown(150);
            jQuery('#cm-txt-toggle-qn').text('Ocultar Notas');
            try { localStorage.removeItem('cm_hide_quick_notes'); } catch(e) {}
        }
    };

    window.cmApplyQuickNotesPreference = function() {
        try {
            if (localStorage.getItem('cm_hide_quick_notes') === '1') {
                jQuery('#cm-quick-notes-container').hide();
                jQuery('#cm-txt-toggle-qn').text('Mostrar Notas');
            }
        } catch(e) {}
    };

    window.cmResetDefaultQuickNotes = function() {
        if (!confirm('¿Deseas restaurar todas las notas rápidas predeterminadas del sistema?')) return;
        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_reset_quick_notes',
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                if (res.success) {
                    alert('✓ Notas rápidas restauradas correctamente.');
                    location.reload();
                } else {
                    alert('Error: ' + ((res.data && res.data.message) ? res.data.message : 'No se pudieron restaurar.'));
                }
            },
            error: function() {
                alert('Error de conexión al restaurar notas.');
            }
        });
    };

    window.cmDeleteQuickNote = function(noteId, event) {
        if (event) event.stopPropagation();
        if (!confirm('¿Quitar esta nota rápida de la lista?')) return;

        var $btn = jQuery(event.target);
        var $pill = $btn.closest('.cm-qn-pill-wrap');

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_delete_quick_note',
                note_id: noteId,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                if (res.success) {
                    $pill.fadeOut(150, function() { jQuery(this).remove(); });
                } else {
                    alert('Error al eliminar: ' + (res.data.message || ''));
                }
            },
            error: function() {
                alert('Error de conexión al eliminar nota.');
            }
        });
    };

    window.cmSaveCaseUpdate = function(submissionId) {
        var $btn        = jQuery('.cm-apple-btn-primary, #cm-btn-save-update').first();
        var newStatus   = jQuery('#cm-select-new-status').val() || '';
        var $noteInput  = jQuery('#cm-input-case-note').length ? jQuery('#cm-input-case-note') : jQuery('#cm-update-note');
        var note        = ($noteInput.val() || '').trim();
        var notifyUser  = (jQuery('#cm-check-notify-user').is(':checked') || jQuery('#cm-checkbox-notify-user').is(':checked')) ? 1 : 0;
        var authorName  = (jQuery('#cm-input-author-name').val() || 'Área Responsable').trim();
        var fileInput   = document.getElementById('cm-admin-attach-file');
        var reqDoc      = jQuery('#cm-check-req-doc').is(':checked') ? 1 : 0;
        var docTitle    = (jQuery('#cm-input-doc-title').val() || '').trim();
        var reqPresence = jQuery('#cm-check-req-presence').is(':checked') ? 1 : 0;

        if (!note && !newStatus && !reqDoc && !reqPresence && (!fileInput || !fileInput.files || !fileInput.files.length)) {
            alert('Por favor selecciona un estado o escribe un mensaje.');
            return;
        }

        var formData = new FormData();
        formData.append('action', 'cm_admin_update_case');
        formData.append('id', submissionId);
        formData.append('status', newStatus);
        formData.append('note', note);
        formData.append('notify_user', notifyUser);
        formData.append('author_name', authorName);
        formData.append('req_doc', reqDoc);
        formData.append('doc_title', docTitle);
        formData.append('req_presence', reqPresence);
        formData.append('nonce', '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>');

        if (fileInput && fileInput.files && fileInput.files[0]) {
            if (fileInput.files[0].size > 4 * 1024 * 1024) {
                alert('El archivo adjunto supera los 4 Megabytes.');
                return;
            }
            formData.append('admin_attachment', fileInput.files[0]);
        }

        $btn.prop('disabled', true).text('Guardando...');

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            success: function(res) {
                $btn.prop('disabled', false).text('💾 Guardar y Actualizar Estado');
                if (res && res.success) {
                    alert('✓ Expediente actualizado exitosamente.');
                    if (typeof cmOpenCaseModal === 'function' && jQuery('#cm-case-modal-overlay').is(':visible')) {
                        cmOpenCaseModal(submissionId);
                    } else {
                        location.reload();
                    }
                } else {
                    alert('Error: ' + ((res && res.data && res.data.message) ? res.data.message : 'No se pudo actualizar el estado.'));
                }
            },
            error: function(xhr) {
                $btn.prop('disabled', false).text('💾 Guardar y Actualizar Estado');
                alert('Error de conexión con el servidor (Código: ' + xhr.status + ').');
            }
        });
    };

    window.cmExecuteTransferCase = function(submissionId) {
        var $btn          = jQuery('.cm-apple-btn-secondary, #cm-btn-reassign-area').filter(function() { return jQuery(this).text().indexOf('Derivar') !== -1; });
        var targetDept    = jQuery('#cm-select-transfer-dept').length ? jQuery('#cm-select-transfer-dept').val() : jQuery('#cm-select-target-dept').val();
        var note          = (jQuery('#cm-input-transfer-note').length ? jQuery('#cm-input-transfer-note').val() : jQuery('#cm-reassign-reason').val() || '').trim();
        var notifyNewArea = (jQuery('#cm-check-notify-transfer').is(':checked') || jQuery('#cm-checkbox-notify-area').is(':checked')) ? 1 : 0;
        var notifyUser    = jQuery('#cm-checkbox-notify-user-transfer').is(':checked') ? 1 : 0;
        var authorName    = (jQuery('#cm-input-author-name').val() || jQuery('#cm-reassign-author').val() || 'Área Responsable').trim();

        if (!targetDept) {
            alert('Por favor selecciona el área o departamento de destino.');
            return;
        }

        if (!confirm('¿Confirmas que deseas derivar este caso al departamento "' + targetDept + '"?')) {
            return;
        }

        $btn.prop('disabled', true).text('Derivando...');

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_reassign_case',
                id: submissionId,
                target_department: targetDept,
                reason: note,
                author_name: authorName,
                notify_new_area: notifyNewArea,
                notify_user: notifyUser,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            dataType: 'json',
            success: function(res) {
                $btn.prop('disabled', false).text('🔄 Derivar Caso a Esta Área');
                if (res && res.success) {
                    alert('✓ ' + (res.data.message || 'Caso derivado exitosamente.'));
                    location.reload();
                } else {
                    alert('Error: ' + ((res && res.data && res.data.message) ? res.data.message : 'No se pudo derivar el caso.'));
                }
            },
            error: function(xhr) {
                $btn.prop('disabled', false).text('🔄 Derivar Caso a Esta Área');
                alert('Error de conexión al derivar caso (Código: ' + xhr.status + ').');
            }
        });
    };

    window.cmReassignCase = function(submissionId) {
        window.cmExecuteTransferCase(submissionId);
    };

    function cmDeleteCase(submissionId) {
        if (!confirm('¿Mover este caso a la papelera? (Podrá ser recuperado en cualquier momento por el Administrador)')) return;

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_delete_case',
                id: submissionId,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                if (res.success) {
                    jQuery('#cm-row-' + submissionId).fadeOut(150, function() {
                        jQuery(this).remove();
                    });
                } else {
                    alert(res.data.message || 'Error al enviar el caso a la papelera.');
                }
            },
            error: function() {
                alert('Error de conexión al eliminar el caso.');
            }
        });
    }

    function cmRestoreCase(submissionId) {
        if (!confirm('¿Confirmas que deseas restaurar este caso y reincorporarlo a la bandeja de casos activos?')) return;

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_restore_case',
                id: submissionId,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                if (res.success) {
                    alert('✓ ' + (res.data.message || 'Caso recuperado y restaurado exitosamente.'));
                    jQuery('#cm-trash-row-' + submissionId).fadeOut(150, function() {
                        jQuery(this).remove();
                    });
                } else {
                    alert(res.data.message || 'Error al restaurar el caso.');
                }
            },
            error: function() {
                alert('Error de conexión al restaurar el caso.');
            }
        });
    }

    // Modal de Departamentos
    function cmOpenNewDeptModal() {
        jQuery('#cm-dept-modal-title').text('Nueva Área de Atención');
        jQuery('#cm-input-dept-name').val('').prop('readonly', false);
        jQuery('#cm-input-dept-emails').val('');
        jQuery('#cm-select-dept-user').val('0');
        jQuery('#cm-checkbox-dept-enabled').prop('checked', true);
        jQuery('#cm-checkbox-dept-autoreply').prop('checked', false);
        jQuery('#cm-select-dept-delay').val('0');
        jQuery('#cm-select-dept-autoreply-status').val('en_proceso');
        jQuery('#cm-input-dept-autoreply-msg').val('');
        jQuery('#cm-wrap-dept-autoreply').hide();
        jQuery('#cm-dept-modal-overlay').fadeIn(120).css('display', 'flex');
    }

    function cmOpenEditDeptModal(name, emails, userId, enabled, arEnabled, arDelay, arMsg, arStatus) {
        jQuery('#cm-dept-modal-title').text('Editar: ' + name);
        jQuery('#cm-input-dept-name').val(name);
        jQuery('#cm-input-dept-emails').val(emails || '');
        jQuery('#cm-select-dept-user').val(userId || '0');
        jQuery('#cm-checkbox-dept-enabled').prop('checked', enabled == 1);
        
        var isAr = (arEnabled == 1);
        jQuery('#cm-checkbox-dept-autoreply').prop('checked', isAr);
        jQuery('#cm-select-dept-delay').val(arDelay || '0');
        jQuery('#cm-select-dept-autoreply-status').val(arStatus || 'en_proceso');
        jQuery('#cm-input-dept-autoreply-msg').val(arMsg || '');
        if (isAr) {
            jQuery('#cm-wrap-dept-autoreply').show();
        } else {
            jQuery('#cm-wrap-dept-autoreply').hide();
        }

        jQuery('#cm-dept-modal-overlay').fadeIn(120).css('display', 'flex');
    }

    function cmSaveDeptModal() {
        var name     = jQuery('#cm-input-dept-name').val().trim();
        var emails   = jQuery('#cm-input-dept-emails').val().trim();
        var userId   = jQuery('#cm-select-dept-user').val();
        var enabled  = jQuery('#cm-checkbox-dept-enabled').is(':checked') ? 1 : 0;
        var arEnable = jQuery('#cm-checkbox-dept-autoreply').is(':checked') ? 1 : 0;
        var arDelay  = jQuery('#cm-select-dept-delay').val();
        var arStatus = jQuery('#cm-select-dept-autoreply-status').val();
        var arMsg    = jQuery('#cm-input-dept-autoreply-msg').val().trim();

        if (!name) {
            alert('El nombre del área es obligatorio.');
            return;
        }

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_save_dept',
                name: name,
                emails: emails,
                user_id: userId,
                enabled: enabled,
                auto_reply_enabled: arEnable,
                auto_reply_delay: arDelay,
                auto_reply_status: arStatus,
                auto_reply_msg: arMsg,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                if (res.success) {
                    location.reload();
                } else {
                    alert(res.data.message || 'Error al guardar el área.');
                }
            }
        });
    }

    function cmToggleDeptStatus(name) {
        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_toggle_dept',
                name: name,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                if (res.success) {
                    location.reload();
                } else {
                    alert(res.data.message || 'Error al cambiar estado.');
                }
            }
        });
    }

    function cmDeleteDept(name) {
        if (!confirm('¿Eliminar el área "' + name + '" del registro?')) return;

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_delete_dept',
                name: name,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                if (res.success) {
                    location.reload();
                } else {
                    alert(res.data.message || 'Error al eliminar área.');
                }
            }
        });
    }

    // Modal de Crear Nuevo Usuario
    function cmOpenNewUserModal() {
        jQuery('#cm-newuser-login').val('');
        jQuery('#cm-newuser-name').val('');
        jQuery('#cm-newuser-email').val('');
        jQuery('#cm-newuser-pass').val('');
        jQuery('.cm-newuser-dept-cb').prop('checked', false);
        jQuery('#cm-newuser-role').val('editor');
        jQuery('#cm-newuser-allow-reassign').prop('checked', true);
        cmOnNewUserRoleChange('editor');
        jQuery('#cm-user-modal-overlay').fadeIn(120).css('display', 'flex');
    }

    function cmOnNewUserRoleChange(role) {
        if (role === 'administrator') {
            jQuery('#cm-newuser-role-tip').html('👑 <strong>Perfil Director / Administrador:</strong> Tendrá acceso global al <strong>Dashboard en Vivo</strong>, al <strong>Tablero Kanban</strong> y a todos los casos de todas las áreas.').css({'background':'#fffbeb', 'border-color':'#fde68a', 'color':'#92400e'});
            jQuery('#cm-newuser-dept-wrap').slideUp(150);
        } else if (role === 'moderator') {
            jQuery('#cm-newuser-role-tip').html('🛡️ <strong>Perfil Subdirector / Moderador:</strong> Podrá ver, atender, derivar y supervisar las solicitudes de <strong>2 o más áreas asignadas</strong>.').css({'background':'#ede9fe', 'border-color':'#ddd6fe', 'color':'#6d28d9'});
            jQuery('#cm-newuser-dept-wrap').slideDown(150);
        } else {
            jQuery('#cm-newuser-role-tip').html('🏢 <strong>Perfil Encargado de Área:</strong> Gestiona las solicitudes dirigidas a los departamentos específicos que le marques a continuación.').css({'background':'#f0f9ff', 'border-color':'#e0f2fe', 'color':'#0369a1'});
            jQuery('#cm-newuser-dept-wrap').slideDown(150);
        }
    }

    function cmSaveNewUserModal() {
        var login         = jQuery('#cm-newuser-login').val().trim();
        var name          = jQuery('#cm-newuser-name').val().trim();
        var email         = jQuery('#cm-newuser-email').val().trim();
        var pass          = jQuery('#cm-newuser-pass').val();
        var role          = jQuery('#cm-newuser-role').val();
        var allowReassign = jQuery('#cm-newuser-allow-reassign').is(':checked') ? 1 : 0;
        
        var depts = [];
        jQuery('.cm-newuser-dept-cb:checked').each(function() {
            depts.push(jQuery(this).val());
        });

        if (!login || !email || !pass) {
            alert('Por favor ingresa usuario, email y contraseña.');
            return;
        }

        if (role !== 'administrator' && depts.length === 0) {
            if (!confirm('No seleccionaste ningún área para este usuario. ¿Deseas crearlo igualmente?')) {
                return;
            }
        }

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_create_area_user',
                login: login,
                name: name,
                email: email,
                pass: pass,
                role: role,
                departments: depts,
                allow_reassign: allowReassign,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                if (res.success) {
                    alert('✓ Usuario creado exitosamente con sus áreas asignadas.');
                    location.reload();
                } else {
                    alert(res.data.message || 'Error al crear el usuario.');
                }
            }
        });
    }

    // Modal de Editar Usuario y Áreas
    function cmOpenEditUserModal(userId, login, name, email, role, assignedDepts, allowReassign) {
        jQuery('#cm-edituser-id').val(userId);
        jQuery('#cm-edituser-login-display').text(login);
        jQuery('#cm-edituser-name').val(name || '');
        jQuery('#cm-edituser-email').val(email || '');
        jQuery('#cm-edituser-pass').val('');
        
        var normalizedRole = (role === 'director' || role === 'administrator') ? 'administrator' : ((role === 'moderator' || role === 'subdirector') ? 'moderator' : 'editor');
        jQuery('#cm-edituser-role').val(normalizedRole);
        cmOnEditUserRoleChange(normalizedRole);

        var canReassign = (allowReassign !== 0 && allowReassign !== '0');
        jQuery('#cm-edituser-allow-reassign').prop('checked', canReassign);

        jQuery('.cm-edituser-dept-cb').prop('checked', false);
        if (Array.isArray(assignedDepts)) {
            assignedDepts.forEach(function(d) {
                jQuery('.cm-edituser-dept-cb[value="' + d + '"]').prop('checked', true);
            });
        }

        jQuery('#cm-edituser-modal-overlay').fadeIn(120).css('display', 'flex');
    }

    function cmOnEditUserRoleChange(role) {
        if (role === 'administrator') {
            jQuery('#cm-edituser-role-tip').html('👑 <strong>Perfil Director / Administrador:</strong> Acceso global al <strong>Dashboard en Vivo</strong>, al <strong>Tablero Kanban</strong> y a todos los casos de todas las áreas.').css({'background':'#fffbeb', 'border-color':'#fde68a', 'color':'#92400e'});
            jQuery('#cm-edituser-dept-wrap').slideUp(150);
        } else if (role === 'moderator') {
            jQuery('#cm-edituser-role-tip').html('🛡️ <strong>Perfil Subdirector / Moderador:</strong> Podrá ver, atender, derivar y supervisar los casos de <strong>múltiples áreas asignadas</strong>.').css({'background':'#ede9fe', 'border-color':'#ddd6fe', 'color':'#6d28d9'});
            jQuery('#cm-edituser-dept-wrap').slideDown(150);
        } else {
            jQuery('#cm-edituser-role-tip').html('🏢 <strong>Perfil Encargado de Área:</strong> Solo podrá ver y gestionar los expedientes de las áreas asignadas seleccionadas.').css({'background':'#f0f9ff', 'border-color':'#e0f2fe', 'color':'#0369a1'});
            jQuery('#cm-edituser-dept-wrap').slideDown(150);
        }
    }

    function cmSaveEditUserModal() {
        var userId        = jQuery('#cm-edituser-id').val();
        var name          = jQuery('#cm-edituser-name').val().trim();
        var email         = jQuery('#cm-edituser-email').val().trim();
        var pass          = jQuery('#cm-edituser-pass').val();
        var role          = jQuery('#cm-edituser-role').val();
        var allowReassign = jQuery('#cm-edituser-allow-reassign').is(':checked') ? 1 : 0;

        var depts = [];
        jQuery('.cm-edituser-dept-cb:checked').each(function() {
            depts.push(jQuery(this).val());
        });

        if (!userId || !email) {
            alert('Por favor ingresa un correo electrónico válido.');
            return;
        }

        var $btn = jQuery('#cm-btn-save-edituser').prop('disabled', true).text('Guardando...');

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_update_area_user',
                user_id: userId,
                name: name,
                email: email,
                pass: pass,
                role: role,
                departments: depts,
                allow_reassign: allowReassign,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                $btn.prop('disabled', false).text('💾 Guardar Cambios de Áreas / Perfil');
                if (res.success) {
                    alert('✓ ' + (res.data.message || 'Perfil y áreas actualizadas exitosamente.'));
                    location.reload();
                } else {
                    alert('Error: ' + (res.data.message || 'No se pudo actualizar el usuario.'));
                }
            },
            error: function() {
                $btn.prop('disabled', false).text('💾 Guardar Cambios de Áreas / Perfil');
                alert('Error de conexión al actualizar usuario.');
            }
        });
    }

    function cmToggleUserSuspension(userId) {
        if (!confirm('¿Deseas cambiar el estado de acceso de este usuario?')) return;

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_toggle_user_suspension',
                user_id: userId,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                if (res.success) {
                    location.reload();
                } else {
                    alert(res.data.message || 'Error al modificar estado del usuario.');
                }
            }
        });
    }

    function cmOpenResetPasswordModal(userId, userName) {
        jQuery('#cm-resetpass-userid').val(userId);
        jQuery('#cm-resetpass-username').text(userName);
        jQuery('#cm-resetpass-new').val('');
        jQuery('#cm-resetpass-modal-overlay').fadeIn(150);
        setTimeout(function() { jQuery('#cm-resetpass-new').focus(); }, 200);
    }

    function cmGenerateRandomPass() {
        var chars = 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789!@#$%&*';
        var pass = '';
        for (var i = 0; i < 12; i++) {
            pass += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        jQuery('#cm-resetpass-new').val(pass);
    }

    function cmSubmitResetPasswordModal() {
        var userId = jQuery('#cm-resetpass-userid').val();
        var newPass = jQuery('#cm-resetpass-new').val().trim();

        if (!userId) {
            alert('Usuario no válido.');
            return;
        }

        if (!newPass || newPass.length < 6) {
            alert('La nueva contraseña debe tener al menos 6 caracteres.');
            jQuery('#cm-resetpass-new').focus();
            return;
        }

        var btn = jQuery('#cm-btn-submit-resetpass');
        btn.prop('disabled', true).text('Guardando...');

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_reset_user_password',
                user_id: userId,
                new_password: newPass,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                btn.prop('disabled', false).text('💾 Guardar Nueva Clave');
                if (res.success) {
                    alert('✓ ' + (res.data.message || 'Contraseña actualizada exitosamente.'));
                    jQuery('#cm-resetpass-modal-overlay').fadeOut(100);
                } else {
                    alert(res.data.message || 'Error al actualizar contraseña.');
                }
            },
            error: function() {
                btn.prop('disabled', false).text('💾 Guardar Nueva Clave');
                alert('Error de conexión.');
            }
        });
    }

    // ═════════════════════════════════════════════════════════════════
    // FUNCIONES JAVASCRIPT DE AUTENTICACIÓN DE DOS FACTORES (2FA)
    // ═════════════════════════════════════════════════════════════════

    var cmCurrent2FASecret = '';

    function cmOpen2FASetupModal() {
        jQuery('#cm-2fa-code-input').val('');
        jQuery('#cm-2fa-secret-text').text('Cargando...');
        jQuery('#cm-2fa-qr-img').attr('src', '');
        jQuery('#cm-btn-submit-2fa').prop('disabled', true).text('Cargando...');
        jQuery('#cm-2fa-setup-modal-overlay').fadeIn(120).css('display', 'flex');

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_2fa_setup_init',
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                jQuery('#cm-btn-submit-2fa').prop('disabled', false).text('✓ Confirmar y Activar 2FA');
                if (res.success && res.data) {
                    cmCurrent2FASecret = res.data.secret;
                    jQuery('#cm-2fa-secret-text').text(res.data.secret);
                    jQuery('#cm-2fa-qr-img').attr('src', res.data.qr_url);
                    setTimeout(function() {
                        jQuery('#cm-2fa-code-input').focus();
                    }, 200);
                } else {
                    alert(res.data.message || 'Error al inicializar 2FA.');
                    cmClose2FAModal();
                }
            },
            error: function() {
                alert('Error de conexión al generar clave 2FA.');
                cmClose2FAModal();
            }
        });
    }

    function cmClose2FAModal() {
        jQuery('#cm-2fa-setup-modal-overlay').fadeOut(100);
    }

    function cmCopy2FASecret() {
        if (!cmCurrent2FASecret) return;
        navigator.clipboard.writeText(cmCurrent2FASecret);
        alert('✓ Clave secreta copiada al portapapeles: ' + cmCurrent2FASecret);
    }

    function cmVerifyAndEnable2FA() {
        var code = jQuery('#cm-2fa-code-input').val().trim();
        if (!code || code.length !== 6) {
            alert('Por favor ingresa el código de 6 dígitos de tu app.');
            jQuery('#cm-2fa-code-input').focus();
            return;
        }

        var btn = jQuery('#cm-btn-submit-2fa');
        btn.prop('disabled', true).text('Verificando...');

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_2fa_verify_and_enable',
                code: code,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                btn.prop('disabled', false).text('✓ Confirmar y Activar 2FA');
                if (res.success) {
                    alert('✓ ' + (res.data.message || '2FA activado exitosamente.'));
                    cmClose2FAModal();
                    jQuery('#cm-2fa-suggestion-banner').slideUp(200);
                    location.reload();
                } else {
                    alert(res.data.message || 'Código incorrecto. Verifica la hora y código de tu app.');
                    jQuery('#cm-2fa-code-input').val('').focus();
                }
            },
            error: function() {
                btn.prop('disabled', false).text('✓ Confirmar y Activar 2FA');
                alert('Error de conexión.');
            }
        });
    }

    function cmAdminDisable2FA(userId, userLogin) {
        if (!confirm('¿Confirmas que deseas desactivar la seguridad 2FA para el usuario "' + userLogin + '"?\nEl usuario podrá ingresar con su contraseña habitual y volver a configurar 2FA si lo desea.')) {
            return;
        }

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_disable_2fa',
                user_id: userId,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                if (res.success) {
                    alert('✓ ' + (res.data.message || '2FA desactivado exitosamente.'));
                    location.reload();
                } else {
                    alert(res.data.message || 'Error al desactivar 2FA.');
                }
            },
            error: function() {
                alert('Error de conexión al desactivar 2FA.');
            }
        });
    }

    var cmCurrentAdminGenerated2FASecret = '';

    // Modal de Gestión 2FA de Usuario (Superadmin)
    function cmOpenAdminUser2FAModal(userId, userLogin, displayName, isEnabled, dateStr) {
        jQuery('#cm-m2fa-userid').val(userId);
        jQuery('#cm-m2fa-userlogin').val(userLogin);
        jQuery('#cm-m2fa-username').text(userLogin);
        jQuery('#cm-m2fa-displayname').text(displayName ? '(' + displayName + ')' : '');

        // Reiniciar panel de generación
        jQuery('#cm-m2fa-generate-panel').hide();
        jQuery('#cm-m2fa-verify-code-input').val('');
        jQuery('#cm-btn-show-generate-2fa').show().text(isEnabled ? '📲 Cambiar / Generar Nueva Clave y QR' : '📲 Asignar / Generar Nueva Clave y QR');

        var statusBox = jQuery('#cm-m2fa-status-box');
        var activeActions = jQuery('#cm-m2fa-active-actions');

        if (isEnabled) {
            statusBox.css({
                'background': '#f0fdf4',
                'border': '1px solid #bbf7d0',
                'color': '#166534'
            }).html(
                '<div style="display:flex; align-items:center; gap:8px; margin-bottom:4px;">' +
                    '<span style="font-size:18px;">🟢</span>' +
                    '<strong style="font-size:13.5px; color:#15803d;">Autenticación de 2 Factores Activa</strong>' +
                '</div>' +
                '<div style="font-size:12px; color:#166534; line-height:1.4;">' +
                    'Este usuario tiene protegida su cuenta con Google Authenticator / Apple. Cada vez que inicie sesión, se le exigirá el código de 6 dígitos.' +
                '</div>' +
                (dateStr ? '<div style="font-size:11.5px; color:#15803d; font-weight:700; margin-top:6px;">🕒 Activado el: ' + dateStr + ' hrs</div>' : '')
            );
            activeActions.show();
        } else {
            statusBox.css({
                'background': '#f8fafc',
                'border': '1px solid #e2e8f0',
                'color': '#64748b'
            }).html(
                '<div style="display:flex; align-items:center; gap:8px; margin-bottom:4px;">' +
                    '<span style="font-size:18px;">⚪</span>' +
                    '<strong style="font-size:13.5px; color:#475569;">2FA No Activado</strong>' +
                '</div>' +
                '<div style="font-size:12px; color:#64748b; line-height:1.4;">' +
                    'Este usuario aún no tiene 2FA configurado. Puedes asignarle y generarle uno ahora mismo pulsando el botón de abajo.' +
                '</div>'
            );
            activeActions.hide();
        }

        jQuery('#cm-admin-manage-2fa-modal-overlay').fadeIn(120).css('display', 'flex');
    }

    function cmCloseAdminUser2FAModal() {
        jQuery('#cm-admin-manage-2fa-modal-overlay').fadeOut(100);
    }

    function cmAdminToggleGenerateUser2FA() {
        var userId = jQuery('#cm-m2fa-userid').val();
        if (!userId) return;

        var panel = jQuery('#cm-m2fa-generate-panel');
        if (panel.is(':visible')) {
            panel.slideUp(150);
            return;
        }

        jQuery('#cm-m2fa-secret-text').text('Generando...');
        jQuery('#cm-m2fa-qr-img').attr('src', '');
        jQuery('#cm-btn-confirm-assign-2fa').prop('disabled', true).text('Generando QR...');

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_generate_user_2fa',
                user_id: userId,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                jQuery('#cm-btn-confirm-assign-2fa').prop('disabled', false).text('✓ Activar y Asignar este 2FA al Usuario');
                if (res.success && res.data) {
                    cmCurrentAdminGenerated2FASecret = res.data.secret;
                    jQuery('#cm-m2fa-secret-text').text(res.data.secret);
                    jQuery('#cm-m2fa-qr-img').attr('src', res.data.qr_url);
                    panel.slideDown(200);
                } else {
                    alert(res.data.message || 'Error al generar 2FA.');
                }
            },
            error: function() {
                alert('Error de conexión al generar 2FA.');
            }
        });
    }

    function cmCopyAdminGenerated2FASecret() {
        if (!cmCurrentAdminGenerated2FASecret) return;
        navigator.clipboard.writeText(cmCurrentAdminGenerated2FASecret);
        alert('✓ Clave de configuración copiada: ' + cmCurrentAdminGenerated2FASecret);
    }

    function cmAdminConfirmAssignUser2FA() {
        var userId = jQuery('#cm-m2fa-userid').val();
        var code   = jQuery('#cm-m2fa-verify-code-input').val().trim();
        if (!userId) return;

        var btn = jQuery('#cm-btn-confirm-assign-2fa');
        btn.prop('disabled', true).text('Guardando y Activando...');

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_assign_user_2fa',
                user_id: userId,
                code: code,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                btn.prop('disabled', false).text('✓ Activar y Asignar este 2FA al Usuario');
                if (res.success) {
                    alert('✓ ' + (res.data.message || '2FA asignado exitosamente al usuario.'));
                    cmCloseAdminUser2FAModal();
                    location.reload();
                } else {
                    alert(res.data.message || 'Error al asignar 2FA.');
                }
            },
            error: function() {
                btn.prop('disabled', false).text('✓ Activar y Asignar este 2FA al Usuario');
                alert('Error de conexión al asignar 2FA.');
            }
        });
    }

    function cmAdminModalDisable2FA() {
        var userId = jQuery('#cm-m2fa-userid').val();
        var userLogin = jQuery('#cm-m2fa-userlogin').val();
        if (!userId) return;

        if (!confirm('¿Confirmas que deseas desactivar la seguridad 2FA para el usuario "' + userLogin + '"?\nEl usuario podrá ingresar con su contraseña habitual inmediatamente.')) {
            return;
        }

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_disable_2fa',
                user_id: userId,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                if (res.success) {
                    alert('✓ ' + (res.data.message || '2FA desactivado exitosamente.'));
                    cmCloseAdminUser2FAModal();
                    location.reload();
                } else {
                    alert(res.data.message || 'Error al desactivar 2FA.');
                }
            },
            error: function() {
                alert('Error de conexión al desactivar 2FA.');
            }
        });
    }

    function cmAdminModalReset2FA() {
        var userId = jQuery('#cm-m2fa-userid').val();
        var userLogin = jQuery('#cm-m2fa-userlogin').val();
        if (!userId) return;

        if (!confirm('¿Deseas restablecer la seguridad 2FA de "' + userLogin + '"?\nSe borrará la vinculación actual y el usuario podrá registrar una nueva app de autenticación en su cuenta.')) {
            return;
        }

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_reset_user_2fa',
                user_id: userId,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                if (res.success) {
                    alert('✓ ' + (res.data.message || '2FA restablecido exitosamente.'));
                    cmCloseAdminUser2FAModal();
                    location.reload();
                } else {
                    alert(res.data.message || 'Error al restablecer 2FA.');
                }
            },
            error: function() {
                alert('Error de conexión al restablecer 2FA.');
            }
        });
    }

    // 🔔 SINTETIZADOR DE AUDIO PROFESIONAL (Web Audio API - Cero dependencias externas)
    function cmPlayNotificationSound(isTest) {
        try {
            var AudioCtx = window.AudioContext || window.webkitAudioContext;
            if (!AudioCtx) return;
            var ctx = new AudioCtx();

            // Tono 1: Campana armónica cristalina (587 Hz - Re)
            var osc1 = ctx.createOscillator();
            var gain1 = ctx.createGain();
            osc1.type = 'sine';
            osc1.frequency.setValueAtTime(587.33, ctx.currentTime);
            gain1.gain.setValueAtTime(0.25, ctx.currentTime);
            gain1.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
            osc1.connect(gain1);
            gain1.connect(ctx.destination);
            osc1.start(ctx.currentTime);
            osc1.stop(ctx.currentTime + 0.35);

            // Tono 2: Timbre de confirmación brillante (880 Hz - La)
            setTimeout(function() {
                var osc2 = ctx.createOscillator();
                var gain2 = ctx.createGain();
                osc2.type = 'sine';
                osc2.frequency.setValueAtTime(880, ctx.currentTime);
                gain2.gain.setValueAtTime(0.30, ctx.currentTime);
                gain2.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.50);
                osc2.connect(gain2);
                gain2.connect(ctx.destination);
                osc2.start(ctx.currentTime);
                osc2.stop(ctx.currentTime + 0.50);
            }, 110);

            if (isTest) {
                cmShowLiveFloatingToast({
                    icon: '🚀',
                    badge: 'AVISO EN TIEMPO REAL (PRUEBA)',
                    badge_bg: '#dcfce7',
                    badge_color: '#15803d',
                    case_id: 0,
                    ticket_code: 'DEMO-LIVE',
                    title: '¡Notificación en Vivo Activa!',
                    message: 'Así se verán los avisos flotantes cuando llegue una solicitud o se modifique un caso de tu área.',
                    department: 'Todas las Áreas',
                    time: 'Ahora'
                });
            }
        } catch(e) {
            console.log('Audio notification:', e);
        }
    }

    // 🔔 SOLICITAR Y GESTIONAR PERMISOS DE NOTIFICACIÓN NATIVA DE CHROME / NAVEGADOR
    function cmRequestChromeNotifications() {
        if (!("Notification" in window)) {
            alert('Tu navegador no soporta notificaciones de escritorio.');
            return;
        }
        if (Notification.permission === 'granted') {
            try {
                var testN = new Notification('🚀 Ingecodex Form: Notificaciones Activas', {
                    body: 'Los avisos de escritorio resaltarán sobre todas las aplicaciones cuando lleguen o se modifiquen casos.',
                    icon: '<?php echo esc_url(CM_PLUGIN_URL . "assets/images/logo.png"); ?>',
                    requireInteraction: true,
                    tag: 'cm-test-active'
                });
                testN.onclick = function() {
                    window.focus();
                    this.close();
                };
            } catch(e) { console.log(e); }
            cmUpdateNotificationUI();
        } else if (Notification.permission !== 'denied') {
            Notification.requestPermission().then(function(permission) {
                if (permission === 'granted') {
                    try {
                        var welcomeN = new Notification('🔔 Ingecodex: Avisos de Escritorio Activados', {
                            body: '¡Excelente! Ahora recibirás alertas en primer plano cuando haya novedades en tus formularios.',
                            icon: '<?php echo esc_url(CM_PLUGIN_URL . "assets/images/logo.png"); ?>',
                            requireInteraction: true,
                            tag: 'cm-welcome'
                        });
                        welcomeN.onclick = function() {
                            window.focus();
                            this.close();
                        };
                    } catch(e) { console.log(e); }
                }
                cmUpdateNotificationUI();
            });
        } else {
            alert('Las notificaciones de Chrome están bloqueadas en tu navegador. Para activarlas, haz clic en el icono de candado o configuración al lado de http://localhost:8000 en la barra de Chrome y selecciona "Permitir Notificaciones".');
        }
    }

    function cmUpdateNotificationUI() {
        var btns = document.querySelectorAll('#cm-btn-chrome-notif, .cm-btn-chrome-notif-action');
        if ("Notification" in window) {
            btns.forEach(function(btn) {
                if (Notification.permission === 'granted') {
                    btn.innerHTML = '🔔 <span style="display:inline-block; width:7px; height:7px; border-radius:50%; background:#10b981; margin-right:3px;"></span> Avisos Chrome Activos';
                    btn.style.color = '#059669';
                    btn.style.borderColor = '#a7f3d0';
                    btn.style.background = '#ecfdf5';
                    btn.title = 'Notificaciones nativas de escritorio activas (resaltan sobre todas las aplicaciones)';
                } else if (Notification.permission === 'denied') {
                    btn.innerHTML = '🔕 Avisos Bloqueados';
                    btn.style.color = '#dc2626';
                    btn.style.borderColor = '#fca5a5';
                    btn.style.background = '#fef2f2';
                } else {
                    btn.innerHTML = '🔔 Activar Avisos Chrome';
                }
            });
        }
    }

    // 🌟 MUESTRA AVISO PUBLICITARIO FLOTANTE EN TIEMPO REAL (LIQUID GLASS PRO TOAST)
    function cmShowLiveFloatingToast(notif) {
        // Enviar notificación nativa de Chrome que resalta sobre toda la pantalla
        if ("Notification" in window && Notification.permission === 'granted') {
            try {
                var nativeNotif = new Notification('🔔 Ingecodex: ' + (notif.title || 'Nuevo Caso / Actualización'), {
                    body: (notif.ticket_code ? '[' + notif.ticket_code + '] ' : '') + (notif.message || '') + ' (' + (notif.department || 'General') + ')',
                    icon: '<?php echo esc_url(CM_PLUGIN_URL . "assets/images/logo.png"); ?>',
                    requireInteraction: true, // Se mantiene fija sobre todas las ventanas hasta interactuar
                    tag: 'cm-notif-' + (notif.ticket_code || Math.random().toString(36).substr(2, 6))
                });
                nativeNotif.onclick = function() {
                    window.focus();
                    if (notif.case_id > 0 && typeof cmOpenCaseModal === 'function') {
                        cmOpenCaseModal(notif.case_id);
                    }
                    this.close();
                };
            } catch(e) { console.log('Native notification error:', e); }
        }

        var toastId = 'toast-' + Math.random().toString(36).substr(2, 9);
        var toastHtml = jQuery(
            '<div id="' + toastId + '" class="cm-live-glass-toast" style="background:rgba(255,255,255,0.92); backdrop-filter:blur(24px) saturate(180%); -webkit-backdrop-filter:blur(24px) saturate(180%); border:1.5px solid rgba(255,255,255,0.95); border-radius:16px; padding:16px 18px; box-shadow:0 12px 35px rgba(15,23,42,0.16), 0 2px 10px rgba(0,0,0,0.04); min-width:340px; max-width:420px; pointer-events:auto; position:relative; overflow:hidden; font-family:inherit; transform:translateX(120%); transition:transform 0.35s cubic-bezier(0.16, 1, 0.3, 1); margin-bottom:12px;">' +
                '<!-- Barra de Brillo Superior -->' +
                '<div style="position:absolute; top:0; left:0; right:0; height:3px; background:linear-gradient(90deg, #3874ff, #00d27a, #3874ff); background-size:200% 100%; animation:cmGradientMove 3s linear infinite;"></div>' +
                
                '<!-- Header Toast -->' +
                '<div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:10px;">' +
                    '<div style="display:flex; align-items:center; gap:6px;">' +
                        '<span style="display:inline-flex; align-items:center; gap:5px; font-size:10.5px; font-weight:800; text-transform:uppercase; letter-spacing:0.06em; background:' + (notif.badge_bg || '#e0edff') + '; color:' + (notif.badge_color || '#2563eb') + '; border:1px solid ' + (notif.badge_color || '#2563eb') + '33; padding:2px 8px; border-radius:20px;">' +
                            '<span style="width:6px; height:6px; border-radius:50%; background:' + (notif.badge_color || '#2563eb') + '; box-shadow:0 0 6px ' + (notif.badge_color || '#2563eb') + '; display:inline-block;"></span>' +
                            (notif.badge || 'EN VIVO') +
                        '</span>' +
                    '</div>' +
                    '<button type="button" onclick="jQuery(\'#' + toastId + '\').css(\'transform\', \'translateX(120%)\'); setTimeout(function(){ jQuery(\'#' + toastId + '\').remove(); }, 350);" style="background:rgba(241,245,249,0.8); border:none; color:#64748b; width:22px; height:22px; border-radius:50%; cursor:pointer; font-size:11px; display:flex; align-items:center; justify-content:center; line-height:1; transition:all 0.15s ease;" onmouseover="this.style.background=\'#fee2e2\'; this.style.color=\'#dc2626\';" onmouseout="this.style.background=\'rgba(241,245,249,0.8)\'; this.style.color=\'#64748b\';">✕</button>' +
                '</div>' +

                '<!-- Body Toast -->' +
                '<div style="display:flex; align-items:flex-start; gap:12px;">' +
                    '<div style="width:40px; height:40px; border-radius:12px; background:#f0f9ff; border:1px solid #bae6fd; display:flex; align-items:center; justify-content:center; font-size:20px; flex-shrink:0; box-shadow:0 2px 8px rgba(56,116,255,0.12);">' +
                        (notif.icon || '🔔') +
                    '</div>' +
                    '<div style="flex:1;">' +
                        '<div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap;">' +
                            '<strong style="font-size:13.5px; font-weight:800; color:#0f172a; line-height:1.2;">' + (notif.ticket_code ? '<span style="font-family:monospace; color:#2563eb; background:#eff6ff; padding:1px 6px; border-radius:4px; border:1px solid #bfdbfe; font-size:12px; margin-right:4px;">' + notif.ticket_code + '</span>' : '') + (notif.title || 'Actualización') + '</strong>' +
                        '</div>' +
                        '<p style="font-size:12px; color:#475569; margin:4px 0 0 0; line-height:1.4;">' + (notif.message || '') + '</p>' +
                        '<div style="display:flex; align-items:center; gap:8px; margin-top:6px; font-size:11px; color:#94a3b8;">' +
                            '<span>🏢 ' + (notif.department || 'Área Asignada') + '</span>' +
                            '<span>•</span>' +
                            '<span>' + (notif.time || 'Ahora') + '</span>' +
                        '</div>' +
                    '</div>' +
                '</div>' +

                '<!-- Acciones -->' +
                '<div style="display:flex; align-items:center; justify-content:flex-end; gap:8px; margin-top:10px; padding-top:8px; border-top:1px solid rgba(226,232,240,0.7);">' +
                    (notif.case_id > 0 ? 
                        '<button type="button" style="font-size:11.5px; font-weight:700; height:28px; padding:0 12px; background:#3874ff; color:#ffffff; border:1px solid #3874ff; border-radius:6px; cursor:pointer; box-shadow:0 2px 6px rgba(56,116,255,0.3); display:inline-flex; align-items:center; gap:4px; text-decoration:none;" onclick="cmOpenCaseModal(' + notif.case_id + '); jQuery(\'#' + toastId + '\').remove();">' +
                            '👁️ Abrir Expediente' +
                        '</button>' : '') +
                    '<button type="button" style="font-size:11.5px; font-weight:700; height:28px; padding:0 10px; background:#ffffff; color:#334155; border:1px solid #cbd5e1; border-radius:6px; cursor:pointer; display:inline-flex; align-items:center; gap:4px;" onclick="location.reload();">' +
                        '🔄 Actualizar' +
                    '</button>' +
                '</div>' +
            '</div>'
        );

        jQuery('#cm-live-toast-wrap').prepend(toastHtml);
        setTimeout(function() {
            toastHtml.css('transform', 'translateX(0)');
        }, 30);

        // Auto remover después de 14 segundos
        setTimeout(function() {
            toastHtml.css('transform', 'translateX(120%)');
            setTimeout(function() { toastHtml.remove(); }, 350);
        }, 14000);
    }

    // ⚡ POLLER DE NOTIFICACIONES EN VIVO Y MODIFICACIONES (CADA 15 SEGUNDOS)
    <?php
    global $wpdb;
    $init_max_c = (int)$wpdb->get_var("SELECT MAX(id) FROM {$wpdb->prefix}cm_form_submissions");
    $init_max_u = (int)$wpdb->get_var("SELECT MAX(id) FROM {$wpdb->prefix}cm_case_updates");
    ?>
    var cmLatestCaseId   = <?php echo $init_max_c; ?>;
    var cmLatestUpdateId = <?php echo $init_max_u; ?>;

    function cmCheckLiveSystemUpdates() {
        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_check_live_notifications',
                last_case_id: cmLatestCaseId,
                last_update_id: cmLatestUpdateId,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                if (res.success && res.data) {
                    if (res.data.has_notifications && res.data.notifications.length > 0) {
                        cmPlayNotificationSound(false);
                        res.data.notifications.forEach(function(notif) {
                            cmShowLiveFloatingToast(notif);
                        });
                    }
                    if (res.data.latest_case_id)   cmLatestCaseId   = res.data.latest_case_id;
                    if (res.data.latest_update_id) cmLatestUpdateId = res.data.latest_update_id;
                }
            }
        });
    }

    setInterval(cmCheckLiveSystemUpdates, 15000);
    jQuery(document).ready(function() {
        cmUpdateNotificationUI();
    });
    </script>
    <?php
}

/**
 * AJAX: Guarda o edita un departamento.
 */
function cm_ajax_admin_save_dept() {
    check_ajax_referer('cm_contacto_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Permiso denegado.', 'contacto-multidestino')));
    }

    $name               = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : '';
    $emails             = isset($_POST['emails']) ? sanitize_text_field($_POST['emails']) : '';
    $user_id            = isset($_POST['user_id']) ? absint($_POST['user_id']) : 0;
    $enabled            = !empty($_POST['enabled']) ? 1 : 0;
    $auto_reply_enabled = !empty($_POST['auto_reply_enabled']) ? 1 : 0;
    $auto_reply_delay   = isset($_POST['auto_reply_delay']) ? absint($_POST['auto_reply_delay']) : 0;
    $auto_reply_status  = isset($_POST['auto_reply_status']) ? sanitize_key($_POST['auto_reply_status']) : 'en_proceso';
    $auto_reply_msg     = isset($_POST['auto_reply_msg']) ? wp_kses_post($_POST['auto_reply_msg']) : '';

    if (!$name) {
        wp_send_json_error(array('message' => __('Nombre no válido.', 'contacto-multidestino')));
    }

    $saved = cm_save_department_entry(array(
        'name'               => $name,
        'emails'             => $emails,
        'user_id'            => $user_id,
        'enabled'            => $enabled,
        'auto_reply_enabled' => $auto_reply_enabled,
        'auto_reply_delay'   => $auto_reply_delay,
        'auto_reply_status'  => $auto_reply_status,
        'auto_reply_msg'     => $auto_reply_msg,
    ));

    if ($saved) {
        wp_send_json_success(array('message' => __('Área y configuración de respuesta automática guardada exitosamente.', 'contacto-multidestino')));
    } else {
        wp_send_json_error(array('message' => __('No se pudo guardar el área.', 'contacto-multidestino')));
    }
}
add_action('wp_ajax_cm_admin_save_dept', 'cm_ajax_admin_save_dept');

/**
 * AJAX: Habilita o deshabilita un departamento.
 */
function cm_ajax_admin_toggle_dept() {
    check_ajax_referer('cm_contacto_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Permiso denegado.', 'contacto-multidestino')));
    }

    $name = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : '';
    $res  = cm_toggle_department_status($name);

    if ($res !== false) {
        wp_send_json_success(array('status' => $res));
    } else {
        wp_send_json_error(array('message' => __('Área no encontrada.', 'contacto-multidestino')));
    }
}
add_action('wp_ajax_cm_admin_toggle_dept', 'cm_ajax_admin_toggle_dept');

/**
 * AJAX: Elimina un departamento.
 */
function cm_ajax_admin_delete_dept() {
    check_ajax_referer('cm_contacto_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Permiso denegado.', 'contacto-multidestino')));
    }

    $name = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : '';
    $res  = cm_delete_department_entry($name);

    if ($res) {
        wp_send_json_success();
    } else {
        wp_send_json_error(array('message' => __('No se pudo eliminar.', 'contacto-multidestino')));
    }
}
add_action('wp_ajax_cm_admin_delete_dept', 'cm_ajax_admin_delete_dept');

/**
 * AJAX: Crea un nuevo usuario institucional y le asigna sus áreas y rol.
 */
function cm_ajax_admin_create_area_user() {
    $nonce = isset($_POST['nonce']) ? $_POST['nonce'] : '';
    if (!wp_verify_nonce($nonce, 'cm_contacto_nonce') && !check_ajax_referer('cm_contacto_nonce', 'nonce', false)) {
        wp_send_json_error(array('message' => __('Permiso denegado o sesión expirada.', 'contacto-multidestino')));
    }
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Permiso denegado.', 'contacto-multidestino')));
    }

    $login          = isset($_POST['login']) ? sanitize_user($_POST['login']) : '';
    $name           = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : '';
    $email          = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
    $pass           = isset($_POST['pass']) ? $_POST['pass'] : '';
    $role           = isset($_POST['role']) ? sanitize_key($_POST['role']) : 'editor';
    $departments    = isset($_POST['departments']) ? (array)$_POST['departments'] : (isset($_POST['department']) ? array($_POST['department']) : array());
    $allow_reassign = !empty($_POST['allow_reassign']) ? '1' : '0';

    if (!$login || !is_email($email) || empty($pass)) {
        wp_send_json_error(array('message' => __('Datos inválidos o incompletos.', 'contacto-multidestino')));
    }

    if (username_exists($login) || email_exists($email)) {
        wp_send_json_error(array('message' => __('El nombre de usuario o correo ya está registrado.', 'contacto-multidestino')));
    }

    $user_id = wp_create_user($login, $pass, $email);
    if (is_wp_error($user_id)) {
        wp_send_json_error(array('message' => $user_id->get_error_message()));
    }

    if ($name) {
        wp_update_user(array('ID' => $user_id, 'display_name' => $name));
    }

    // Rol base en WordPress
    $user = new WP_User($user_id);
    $user->set_role('editor');

    // Registrar perfil institucional y permiso de derivación
    if ($role === 'administrator' || $role === 'director') {
        update_user_meta($user_id, 'cm_user_profile', 'director');
    } elseif ($role === 'moderator' || $role === 'subdirector') {
        update_user_meta($user_id, 'cm_user_profile', 'moderator');
    } else {
        update_user_meta($user_id, 'cm_user_profile', 'area_manager');
    }
    update_user_meta($user_id, 'cm_allow_reassign', $allow_reassign);

    // Asignar áreas al usuario
    if (function_exists('cm_set_user_assigned_departments')) {
        cm_set_user_assigned_departments($user_id, $departments);
    }

    // Correo de bienvenida institucional
    $site_name = get_bloginfo('name');
    $login_url = admin_url('admin.php?page=cm-form-submissions');

    if ($role === 'administrator' || $role === 'director') {
        $welcome_subject = sprintf('[%s] Cuenta de Director / Administrador Habilitada (Acceso Total)', $site_name);
        $role_badge_text = '👑 DIRECTOR / ADMINISTRADOR (ACCESO TOTAL)';
        $welcome_heading = '¡Bienvenido al Panel Directivo de ' . esc_html($site_name) . '!';
        $welcome_desc    = 'Tu cuenta ha sido configurada con acceso total y visión global del sistema.';
        $area_label      = '🌐 Acceso Global (Dashboard y Todas las Áreas)';
        $btn_text        = '📊 Ingresar al Dashboard y Control de Casos &rarr;';
        $perm_note       = 'Podrás ver el <strong>Dashboard en Vivo</strong>, el <strong>Tablero Kanban</strong> y monitorear todos los expedientes de la organización.';
    } elseif ($role === 'moderator' || $role === 'subdirector') {
        $welcome_subject = sprintf('[%s] Cuenta de Subdirector / Moderador Multi-Área Habilitada', $site_name);
        $role_badge_text = '🛡️ SUBDIRECTOR / MODERADOR (MULTI-ÁREA)';
        $welcome_heading = '¡Bienvenido al Panel de Gestión de ' . esc_html($site_name) . '!';
        $welcome_desc    = 'Tu cuenta de moderador multi-área ha sido habilitada exitosamente.';
        $area_label      = '🏢 ' . esc_html(!empty($departments) ? implode(', ', $departments) : 'Múltiples Áreas');
        $btn_text        = '📥 Ingresar a la Bandeja de mis Áreas &rarr;';
        $perm_note       = 'Podrás atender, filtrar y responder solicitudes dirigidas a tus departamentos asignados.' . ($allow_reassign === '1' ? ' Cuentas con permisos de derivación entre áreas.' : ' Tu cuenta está configurada para atención exclusiva sin derivación externa.');
    } else {
        $welcome_subject = sprintf('[%s] Tu cuenta de Encargado de Área ha sido creada', $site_name);
        $role_badge_text = '🏢 ENCARGADO DE ÁREA';
        $welcome_heading = '¡Bienvenido al Panel de ' . esc_html($site_name) . '!';
        $welcome_desc    = 'Tu cuenta de encargado de área ha sido creada exitosamente.';
        $area_label      = '🏢 ' . esc_html(!empty($departments) ? implode(', ', $departments) : 'General');
        $btn_text        = '📥 Ingresar a la Bandeja de Casos de mi Área &rarr;';
        $perm_note       = 'Podrás atender, dar continuidad o solicitar la presencia del requirente en tu departamento.' . ($allow_reassign === '1' ? ' Cuentas con permisos de derivación.' : '');
    }

    $welcome_body = '
    <!DOCTYPE html>
    <html lang="es">
    <head><meta charset="UTF-8"></head>
    <body style="font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, sans-serif; background-color: #f1f5f9; padding: 30px 15px; margin: 0;">
        <div style="max-width: 580px; margin: 0 auto; background: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.06); border: 1px solid #e2e8f0;">
            <div style="background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%); padding: 28px 32px; color: #ffffff;">
                <div style="display:inline-block; background:rgba(255,255,255,0.15); padding:4px 12px; border-radius:20px; font-size:11px; font-weight:800; color:#c7d2fe; text-transform:uppercase; letter-spacing:0.05em;">
                    ' . $role_badge_text . '
                </div>
                <h2 style="margin: 10px 0 0 0; font-size: 21px; font-weight: 800; color: #ffffff;">' . $welcome_heading . '</h2>
                <p style="margin: 4px 0 0 0; font-size: 13.5px; color: #cbd5e1;">' . $welcome_desc . '</p>
            </div>
            <div style="padding: 26px 32px;">
                <p style="margin: 0 0 16px 0; font-size: 14.5px; color: #334155;">Hola <strong>' . esc_html($name ? $name : $login) . '</strong>, te compartimos tus credenciales de acceso institucional:</p>
                
                <table style="width: 100%; border-collapse: collapse; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; overflow: hidden; margin-bottom: 20px;">
                    <tr>
                        <td style="padding: 11px 14px; font-weight: 600; color: #475569; border-bottom: 1px solid #e2e8f0; width: 40%;">Perfil / Nivel:</td>
                        <td style="padding: 11px 14px; font-weight: 700; color: #0f172a; border-bottom: 1px solid #e2e8f0;">' . esc_html($role_badge_text) . '</td>
                    </tr>
                    <tr>
                        <td style="padding: 11px 14px; font-weight: 600; color: #475569; border-bottom: 1px solid #e2e8f0;">Áreas Asignadas:</td>
                        <td style="padding: 11px 14px; font-weight: 700; color: #4f46e5; border-bottom: 1px solid #e2e8f0;">' . $area_label . '</td>
                    </tr>
                    <tr>
                        <td style="padding: 11px 14px; font-weight: 600; color: #475569; border-bottom: 1px solid #e2e8f0;">Usuario (Login):</td>
                        <td style="padding: 11px 14px; font-family: monospace; font-weight: 700; color: #0f172a; border-bottom: 1px solid #e2e8f0;">' . esc_html($login) . '</td>
                    </tr>
                    <tr>
                        <td style="padding: 11px 14px; font-weight: 600; color: #475569;">Contraseña de Acceso:</td>
                        <td style="padding: 11px 14px; font-family: monospace; font-weight: 700; color: #0f172a;">' . esc_html($pass) . '</td>
                    </tr>
                </table>

                <div style="background:#f1f5f9; border-left:3px solid #6366f1; padding:10px 14px; border-radius:0 8px 8px 0; font-size:12.5px; color:#475569; line-height:1.45; margin-bottom:20px;">
                    ' . $perm_note . '
                </div>

                <div style="text-align: center; margin: 22px 0 18px 0;">
                    <a href="' . esc_url($login_url) . '" target="_blank" style="display: inline-block; background: #0071e3; color: #ffffff; text-decoration: none; padding: 13px 28px; border-radius: 10px; font-size: 14px; font-weight: 700;">
                        ' . $btn_text . '
                    </a>
                </div>

                <div style="background:#eff6ff; border:1px solid #bfdbfe; border-radius:8px; padding:10px 14px; font-size:12px; color:#1e40af; line-height:1.5;">
                    🔗 <strong>Enlace directo para ingresar:</strong><br>
                    <a href="' . esc_url($login_url) . '" style="color:#0284c7; word-break:break-all;">' . esc_url($login_url) . '</a>
                </div>
            </div>
            <div style="background: #f8fafc; padding: 16px 32px; border-top: 1px solid #e2e8f0; text-align: center; font-size: 12px; color: #94a3b8;">
                Ingecodex Form • ' . esc_html($site_name) . '
            </div>
        </div>
    </body>
    </html>';

    $from_email = get_option('cm_smtp_from', get_option('admin_email'));
    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . esc_html($site_name) . ' <' . $from_email . '>'
    );
    wp_mail($email, $welcome_subject, $welcome_body, $headers);

    wp_send_json_success(array('user_id' => $user_id, 'access_url' => $login_url, 'role' => $role));
}
add_action('wp_ajax_cm_admin_create_area_user', 'cm_ajax_admin_create_area_user');

/**
 * AJAX: Modifica las áreas asignadas y el perfil institucional de un usuario existente.
 */
function cm_ajax_admin_update_area_user() {
    $nonce = isset($_POST['nonce']) ? $_POST['nonce'] : '';
    if (!wp_verify_nonce($nonce, 'cm_contacto_nonce') && !check_ajax_referer('cm_contacto_nonce', 'nonce', false)) {
        wp_send_json_error(array('message' => __('Permiso denegado o sesión expirada.', 'contacto-multidestino')));
    }
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Permiso denegado.', 'contacto-multidestino')));
    }

    $user_id        = isset($_POST['user_id']) ? absint($_POST['user_id']) : 0;
    $name           = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : '';
    $email          = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
    $pass           = isset($_POST['pass']) ? $_POST['pass'] : '';
    $role           = isset($_POST['role']) ? sanitize_key($_POST['role']) : 'editor';
    $departments    = isset($_POST['departments']) ? (array)$_POST['departments'] : array();
    $allow_reassign = !empty($_POST['allow_reassign']) ? '1' : '0';

    if (!$user_id || !is_email($email)) {
        wp_send_json_error(array('message' => __('Datos inválidos.', 'contacto-multidestino')));
    }

    $user_data = array(
        'ID'           => $user_id,
        'user_email'   => $email,
        'display_name' => $name ? $name : '',
    );
    if (!empty($pass)) {
        $user_data['user_pass'] = $pass;
    }
    wp_update_user($user_data);

    // Actualizar perfil de rol institucional y permiso de derivación
    if ($role === 'administrator' || $role === 'director') {
        update_user_meta($user_id, 'cm_user_profile', 'director');
    } elseif ($role === 'moderator' || $role === 'subdirector') {
        update_user_meta($user_id, 'cm_user_profile', 'moderator');
    } else {
        update_user_meta($user_id, 'cm_user_profile', 'area_manager');
    }
    update_user_meta($user_id, 'cm_allow_reassign', $allow_reassign);

    // Actualizar lista de áreas asignadas
    if (function_exists('cm_set_user_assigned_departments')) {
        cm_set_user_assigned_departments($user_id, $departments);
    }

    wp_send_json_success(array('message' => __('Perfil, áreas asignadas y permisos del usuario actualizados exitosamente.', 'contacto-multidestino')));
}
add_action('wp_ajax_cm_admin_update_area_user', 'cm_ajax_admin_update_area_user');
add_action('wp_ajax_cm_admin_update_area_user', 'cm_ajax_admin_update_area_user');

/**
 * AJAX: Guarda una nueva nota rápida personalizada.
 */
function cm_ajax_admin_save_quick_note() {
    $nonce = isset($_POST['nonce']) ? $_POST['nonce'] : '';
    if (!wp_verify_nonce($nonce, 'cm_contacto_nonce') && !check_ajax_referer('cm_contacto_nonce', 'nonce', false)) {
        if (!is_user_logged_in() || (!current_user_can('edit_posts') && !current_user_can('manage_options'))) {
            wp_send_json_error(array('message' => __('Permiso denegado.', 'contacto-multidestino')));
        }
    }

    $title        = isset($_POST['title']) ? sanitize_text_field($_POST['title']) : '';
    $content      = isset($_POST['content']) ? sanitize_textarea_field($_POST['content']) : '';
    $status       = isset($_POST['status']) ? sanitize_key($_POST['status']) : 'en_proceso';
    $req_doc      = !empty($_POST['req_doc']);
    $req_presence = !empty($_POST['req_presence']);

    if (!$title || !$content) {
        wp_send_json_error(array('message' => __('Por favor ingresa un título y el texto de la nota.', 'contacto-multidestino')));
    }

    if (function_exists('cm_save_quick_note')) {
        $saved = cm_save_quick_note($title, $content, $status, $req_doc, $req_presence);
        if ($saved) {
            wp_send_json_success(array('note' => $saved, 'message' => __('Nota rápida guardada exitosamente.', 'contacto-multidestino')));
        }
    }

    wp_send_json_error(array('message' => __('No se pudo guardar la nota rápida.', 'contacto-multidestino')));
}
add_action('wp_ajax_cm_admin_save_quick_note', 'cm_ajax_admin_save_quick_note');

/**
 * AJAX: Elimina una nota rápida personalizada.
 */
function cm_ajax_admin_delete_quick_note() {
    $nonce = isset($_POST['nonce']) ? $_POST['nonce'] : '';
    if (!wp_verify_nonce($nonce, 'cm_contacto_nonce') && !check_ajax_referer('cm_contacto_nonce', 'nonce', false)) {
        if (!is_user_logged_in() || (!current_user_can('edit_posts') && !current_user_can('manage_options'))) {
            wp_send_json_error(array('message' => __('Permiso denegado.', 'contacto-multidestino')));
        }
    }

    $note_id = isset($_POST['note_id']) ? sanitize_key($_POST['note_id']) : '';
    if (!$note_id) {
        wp_send_json_error(array('message' => __('ID de nota no válido.', 'contacto-multidestino')));
    }

    if (function_exists('cm_delete_quick_note')) {
        $deleted = cm_delete_quick_note($note_id);
        if ($deleted) {
            wp_send_json_success(array('message' => __('Nota eliminada exitosamente.', 'contacto-multidestino')));
        }
    }

    wp_send_json_error(array('message' => __('No se pudo eliminar la nota.', 'contacto-multidestino')));
}
add_action('wp_ajax_cm_admin_delete_quick_note', 'cm_ajax_admin_delete_quick_note');

/**
 * AJAX: Restaura las notas rápidas predeterminadas del sistema.
 */
function cm_ajax_admin_reset_quick_notes() {
    $nonce = isset($_POST['nonce']) ? $_POST['nonce'] : '';
    if (!wp_verify_nonce($nonce, 'cm_contacto_nonce') && !check_ajax_referer('cm_contacto_nonce', 'nonce', false)) {
        if (!is_user_logged_in() || (!current_user_can('edit_posts') && !current_user_can('manage_options'))) {
            wp_send_json_error(array('message' => __('Permiso denegado.', 'contacto-multidestino')));
        }
    }

    if (function_exists('cm_restore_default_quick_notes')) {
        cm_restore_default_quick_notes();
        wp_send_json_success(array('message' => __('Notas predeterminadas restauradas.', 'contacto-multidestino')));
    }

    wp_send_json_error(array('message' => __('No se pudo procesar la solicitud.', 'contacto-multidestino')));
}
add_action('wp_ajax_cm_admin_reset_quick_notes', 'cm_ajax_admin_reset_quick_notes');

/**
 * AJAX: Comprueba periódicamente si hay casos nuevos para emitir alerta sonora y visual.
 */
/**
 * AJAX: Monitorea en tiempo real tanto nuevos casos como modificaciones/actualizaciones
 * filtrando por los permisos del usuario (todas las áreas o áreas asignadas).
 */
function cm_ajax_admin_check_live_notifications() {
    check_ajax_referer('cm_contacto_nonce', 'nonce');
    if (!current_user_can('edit_posts') && !current_user_can('manage_options')) {
        wp_send_json_error();
    }

    global $wpdb;
    $table_subs = $wpdb->prefix . 'cm_form_submissions';
    $table_upds = $wpdb->prefix . 'cm_case_updates';

    $last_case_id   = isset($_POST['last_case_id']) ? absint($_POST['last_case_id']) : 0;
    $last_update_id = isset($_POST['last_update_id']) ? absint($_POST['last_update_id']) : 0;

    $user_id    = get_current_user_id();
    $can_global = function_exists('cm_can_view_global_dashboard') ? cm_can_view_global_dashboard() : current_user_can('manage_options');
    $user_deps  = array();
    if (!$can_global && function_exists('cm_get_user_assigned_departments')) {
        $user_deps = cm_get_user_assigned_departments($user_id);
    }

    $notifications = array();

    // 1. Detectar Nuevos Casos
    $where_dept_subs = '';
    if (!$can_global && !empty($user_deps)) {
        $deps_escaped = array_map(function($d) use ($wpdb) { return "'" . esc_sql($d) . "'"; }, $user_deps);
        $where_dept_subs = " AND department IN (" . implode(',', $deps_escaped) . ")";
    } elseif (!$can_global && empty($user_deps)) {
        $where_dept_subs = " AND 1=0";
    }

    if ($last_case_id > 0) {
        $new_cases = $wpdb->get_results($wpdb->prepare(
            "SELECT id, ticket_code, sender_name, department, subject, created_at 
             FROM {$table_subs} 
             WHERE id > %d AND status != 'trash' {$where_dept_subs} 
             ORDER BY id DESC LIMIT 5",
            $last_case_id
        ));

        if (!empty($new_cases)) {
            foreach ($new_cases as $nc) {
                $notifications[] = array(
                    'id'          => 'case-' . $nc->id,
                    'type'        => 'new_case',
                    'icon'        => '🚀',
                    'badge'       => 'NUEVO CASO RECIBIDO',
                    'badge_bg'    => '#dcfce7',
                    'badge_color' => '#15803d',
                    'case_id'     => (int)$nc->id,
                    'ticket_code' => $nc->ticket_code,
                    'title'       => '¡Nuevo Caso: ' . $nc->ticket_code . '!',
                    'message'     => ($nc->sender_name ? $nc->sender_name : 'Nuevo Solicitante') . ' ha ingresado un requerimiento en ' . ($nc->department ? $nc->department : 'Área General') . '.',
                    'department'  => $nc->department ? $nc->department : 'Área General',
                    'time'        => 'Hace un momento',
                );
            }
        }
    }

    // 2. Detectar Modificaciones y Eventos (cm_case_updates)
    if ($last_update_id > 0) {
        $join_clause = "INNER JOIN {$table_subs} s ON u.submission_id = s.id";
        $where_dept_upds = "WHERE u.id > " . absint($last_update_id) . " AND s.status != 'trash'";
        if (!$can_global && !empty($user_deps)) {
            $deps_escaped = array_map(function($d) use ($wpdb) { return "'" . esc_sql($d) . "'"; }, $user_deps);
            $where_dept_upds .= " AND s.department IN (" . implode(',', $deps_escaped) . ")";
        } elseif (!$can_global && empty($user_deps)) {
            $where_dept_upds .= " AND 1=0";
        }

        $new_updates = $wpdb->get_results(
            "SELECT u.id, u.submission_id, u.ticket_code, u.author_name, u.action_type, u.status, u.note, u.created_at, s.department, s.sender_name 
             FROM {$table_upds} u 
             {$join_clause} 
             {$where_dept_upds} 
             ORDER BY u.id DESC LIMIT 5"
        );

        if (!empty($new_updates)) {
            foreach ($new_updates as $nu) {
                $icon = '⚡';
                $badge = 'ACTUALIZACIÓN';
                $badge_bg = '#e0edff';
                $badge_color = '#2563eb';

                if ($nu->action_type === 'reassigned') {
                    $icon = '🔄';
                    $badge = 'CASO DERIVADO / REASIGNADO';
                    $badge_bg = '#ede9fe';
                    $badge_color = '#6d28d9';
                } elseif ($nu->action_type === 'status_change') {
                    $icon = '📌';
                    $badge = 'CAMBIO DE ESTADO';
                    $badge_bg = '#fef3c7';
                    $badge_color = '#92400e';
                } elseif ($nu->action_type === 'attachment' || $nu->action_type === 'user_attachment') {
                    $icon = '📎';
                    $badge = 'NUEVO DOCUMENTO ADJUNTO';
                    $badge_bg = '#f0fdf4';
                    $badge_color = '#166534';
                } elseif ($nu->action_type === 'note' || $nu->action_type === 'user_note') {
                    $icon = '📝';
                    $badge = 'NUEVA NOTA O RESPUESTA';
                    $badge_bg = '#fdf4ff';
                    $badge_color = '#a21caf';
                }

                $clean_note = wp_trim_words(strip_tags($nu->note ? $nu->note : 'Modificación en el expediente'), 12);

                $notifications[] = array(
                    'id'          => 'upd-' . $nu->id,
                    'type'        => $nu->action_type,
                    'icon'        => $icon,
                    'badge'       => $badge,
                    'badge_bg'    => $badge_bg,
                    'badge_color' => $badge_color,
                    'case_id'     => (int)$nu->submission_id,
                    'ticket_code' => $nu->ticket_code,
                    'title'       => 'Caso ' . $nu->ticket_code . ' Actualizado',
                    'message'     => ($nu->author_name ? $nu->author_name : 'Gestor') . ': ' . $clean_note,
                    'department'  => $nu->department ? $nu->department : 'Área Asignada',
                    'time'        => 'Hace un momento',
                );
            }
        }
    }

    $current_max_case = (int)$wpdb->get_var("SELECT MAX(id) FROM {$table_subs}");
    $current_max_upd  = (int)$wpdb->get_var("SELECT MAX(id) FROM {$table_upds}");

    wp_send_json_success(array(
        'has_notifications' => !empty($notifications),
        'notifications'     => $notifications,
        'latest_case_id'    => max($current_max_case, $last_case_id),
        'latest_update_id'  => max($current_max_upd, $last_update_id),
    ));
}
add_action('wp_ajax_cm_admin_check_live_notifications', 'cm_ajax_admin_check_live_notifications');
add_action('wp_ajax_cm_admin_check_new_submissions', 'cm_ajax_admin_check_live_notifications');

/**
 * Construye el payload HTML completo del Expediente Oficial (reutilizable en modal y página completa).
 */
function cm_build_case_inspector_payload($id) {
    if (!current_user_can('edit_posts') && !current_user_can('manage_options')) {
        return new WP_Error('forbidden', __('Permiso denegado.', 'contacto-multidestino'));
    }

    $case = cm_get_submission_by_id($id);
    if (!$case) {
        return new WP_Error('not_found', __('Caso no encontrado.', 'contacto-multidestino'));
    }

    // Si es encargado de área (no Director ni Superadmin), verificar que el caso pertenezca a su área
    if (function_exists('cm_can_view_global_dashboard') && !cm_can_view_global_dashboard()) {
        $user_assigned_dept = function_exists('cm_get_current_user_assigned_department') ? cm_get_current_user_assigned_department() : '';
        if (!empty($user_assigned_dept) && $case->department !== $user_assigned_dept) {
            return new WP_Error('forbidden_dept', __('No tienes permiso para acceder a casos de otra área.', 'contacto-multidestino'));
        }
    }

    $history     = cm_get_case_updates($case->id, false);
    $statuses    = cm_get_case_statuses();
    $departments = cm_get_available_departments(true); // Solo activas para derivar

    $submitted_data = array();
    if (!empty($case->submitted_data)) {
        $decoded = json_decode($case->submitted_data, true);
        if (is_array($decoded)) $submitted_data = $decoded;
    }

    $current_user = wp_get_current_user();
    $current_user_name = $current_user && $current_user->display_name ? $current_user->display_name : ($case->department ? 'Área ' . $case->department : 'Administración');

    ob_start();
    ?>
    <div class="cm-apple-inspector-grid">
        <!-- Columna Izquierda: Datos del Formulario y Solicitante -->
        <div class="cm-inspector-sidebar">
            <div class="cm-apple-card-sm">
                <div class="cm-card-sm-title"><?php _e('Información del Solicitante', 'contacto-multidestino'); ?></div>
                <div class="cm-kv-list">
                    <div class="cm-kv-item">
                        <span class="cm-kv-k">👤 <?php _e('Nombre:', 'contacto-multidestino'); ?></span>
                        <span class="cm-kv-v"><strong><?php echo esc_html($case->sender_name ? $case->sender_name : 'No especificado'); ?></strong></span>
                    </div>
                    <div class="cm-kv-item">
                        <span class="cm-kv-k">✉️ <?php _e('Correo:', 'contacto-multidestino'); ?></span>
                        <span class="cm-kv-v"><a href="mailto:<?php echo esc_attr($case->sender_email); ?>"><?php echo esc_html($case->sender_email); ?></a></span>
                    </div>
                    <?php if ($case->sender_phone) : ?>
                    <div class="cm-kv-item">
                        <span class="cm-kv-k">📞 <?php _e('Teléfono:', 'contacto-multidestino'); ?></span>
                        <span class="cm-kv-v"><?php echo esc_html($case->sender_phone); ?></span>
                    </div>
                    <?php endif; ?>
                    <div class="cm-kv-item">
                        <span class="cm-kv-k">🏢 <?php _e('Área Actual:', 'contacto-multidestino'); ?></span>
                        <span class="cm-kv-v"><span class="cm-tag-dept-sm"><?php echo esc_html($case->department ? $case->department : 'General'); ?></span></span>
                    </div>
                    <div class="cm-kv-item">
                        <span class="cm-kv-k">📋 <?php _e('Formulario de Origen:', 'contacto-multidestino'); ?></span>
                        <span class="cm-kv-v"><strong><?php echo esc_html($case->form_name ? $case->form_name : $case->form_id); ?></strong></span>
                    </div>
                    <div class="cm-kv-item">
                        <span class="cm-kv-k">📅 <?php _e('Fecha de Ingreso:', 'contacto-multidestino'); ?></span>
                        <span class="cm-kv-v"><?php echo date_i18n('d/m/Y - H:i \h\r\s', strtotime($case->created_at)); ?></span>
                    </div>
                    <?php if (!empty($case->updated_at) && $case->updated_at !== $case->created_at) : ?>
                    <div class="cm-kv-item">
                        <span class="cm-kv-k">🔄 <?php _e('Última Actualización:', 'contacto-multidestino'); ?></span>
                        <span class="cm-kv-v"><?php echo date_i18n('d/m/Y - H:i \h\r\s', strtotime($case->updated_at)); ?></span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Campos Completados del Formulario -->
            <div class="cm-apple-card-sm" style="margin-top: 12px;">
                <div class="cm-card-sm-title"><?php _e('Detalle del Formulario', 'contacto-multidestino'); ?></div>
                <div class="cm-fields-compact-list">
                    <?php if (!empty($submitted_data)) : ?>
                        <?php foreach ($submitted_data as $label => $val) : ?>
                            <div class="cm-fitem">
                                <div class="cm-flabel"><?php echo esc_html($label); ?>:</div>
                                <div class="cm-fval"><?php echo nl2br(esc_html($val)); ?></div>
                            </div>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <p style="color:#86868b;font-size:12px;margin:0;"><?php _e('Sin datos adicionales.', 'contacto-multidestino'); ?></p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Documentos y Archivos Adjuntos (Lista Compacta con Scroll) -->
            <?php
            $raw_att = !empty($submission->attachments) ? $submission->attachments : '';
            $attached_items = function_exists('cm_extract_case_attachments') ? cm_extract_case_attachments($history, $submitted_data, $raw_att) : array();
            ?>
            <div class="cm-apple-card-sm" style="margin-top: 12px;">
                <div class="cm-card-sm-title" style="display:flex; justify-content:space-between; align-items:center;">
                    <span>📁 <?php _e('Documentos y Archivos del Caso', 'contacto-multidestino'); ?></span>
                    <span style="font-size:11px; background:<?php echo !empty($attached_items) ? '#e0f2fe' : '#f1f5f9'; ?>; color:<?php echo !empty($attached_items) ? '#0369a1' : '#64748b'; ?>; padding:2px 8px; border-radius:12px; font-weight:700;">
                        <?php echo count($attached_items); ?>
                    </span>
                </div>
                <div style="margin-top:6px;">
                    <?php if (!empty($attached_items)) : ?>
                        <div class="cm-doc-list-scroll">
                            <?php foreach ($attached_items as $att) : 
                                $is_img = !empty($att['is_image']);
                                $url = esc_url($att['url']);
                                $name = esc_html($att['name'] ? $att['name'] : basename($att['url']));
                                $ext = strtoupper($att['ext']);
                                $author = esc_html($att['author'] ? $att['author'] : 'Adjunto');
                                $date = esc_html($att['date'] ? $att['date'] : '');
                            ?>
                                <div class="cm-doc-mini-row">
                                    <div style="display:flex; align-items:center; gap:8px; min-width:0; flex:1;">
                                        <?php if ($is_img) : ?>
                                            <div style="width:30px; height:30px; border-radius:6px; overflow:hidden; background:#f1f5f9; flex-shrink:0; border:1px solid #e2e8f0; cursor:pointer;" onclick="cmOpenDocumentPreview('<?php echo esc_js($url); ?>', '<?php echo esc_js($name); ?>', true)" title="<?php esc_attr_e('Ver imagen', 'contacto-multidestino'); ?>">
                                                <img src="<?php echo $url; ?>" style="width:100%; height:100%; object-fit:cover;" alt="<?php echo $name; ?>" />
                                            </div>
                                        <?php else : ?>
                                            <div style="width:30px; height:30px; border-radius:6px; background:#fee2e2; color:#dc2626; display:flex; align-items:center; justify-content:center; font-size:10.5px; font-weight:800; flex-shrink:0; border:1px solid #fecaca;">
                                                <?php echo $ext ? substr($ext, 0, 3) : 'DOC'; ?>
                                            </div>
                                        <?php endif; ?>
                                        <div style="min-width:0; flex:1;">
                                            <div style="font-size:11.5px; font-weight:700; color:#0f172a; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="<?php echo $name; ?>">
                                                <?php echo $name; ?>
                                            </div>
                                            <div style="font-size:10px; color:#64748b; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                                                👤 <?php echo $author; ?><?php if ($date) : ?> • <?php echo $date; ?><?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div style="display:flex; align-items:center; gap:4px; flex-shrink:0;">
                                        <button type="button" class="cm-btn-view" style="font-size:10.5px; padding:2px 7px; height:24px; display:inline-flex; align-items:center; gap:2px;" onclick="cmOpenDocumentPreview('<?php echo esc_js($url); ?>', '<?php echo esc_js($name); ?>', <?php echo $is_img ? 'true' : 'false'; ?>)" title="<?php esc_attr_e('Ver documento', 'contacto-multidestino'); ?>">
                                            👁️ <?php _e('Ver', 'contacto-multidestino'); ?>
                                        </button>
                                        <a href="<?php echo $url; ?>" target="_blank" download class="cm-apple-btn-secondary" style="font-size:10.5px; padding:2px 6px; height:24px; display:inline-flex; align-items:center; text-decoration:none;" title="<?php esc_attr_e('Descargar original', 'contacto-multidestino'); ?>">
                                            ⬇️
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else : ?>
                        <p style="color:#94a3b8; font-size:11.5px; margin:0; line-height:1.4;">
                            💡 <?php _e('No hay documentos adjuntos aún. Puedes solicitarle al usuario que adjunte antecedentes usando la casilla de solicitud.', 'contacto-multidestino'); ?>
                        </p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Columna Derecha: Acciones, Derivación y Línea de Tiempo -->
        <div class="cm-inspector-main">
            <?php if (!empty($case->is_deleted)) : ?>
                <!-- AVISO DE MODO SOLO LECTURA EN CASO EN PAPELERA -->
                <div class="cm-apple-card-sm" style="background:#fef2f2; border:1.5px solid #fecaca; border-radius:12px; padding:16px 18px; margin-bottom:14px;">
                    <div style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:12px;">
                        <div style="display:flex; align-items:center; gap:12px;">
                            <span style="font-size:28px;">🗑️</span>
                            <div>
                                <strong style="font-size:14px; color:#991b1b; display:block;">
                                    <?php _e('Expediente en Papelera (Modo Solo Lectura)', 'contacto-multidestino'); ?>
                                </strong>
                                <p style="font-size:12px; color:#7f1d1d; margin:3px 0 0 0; line-height:1.4;">
                                    <?php 
                                    $del_by_str = !empty($case->deleted_by) ? esc_html($case->deleted_by) : __('Administración', 'contacto-multidestino');
                                    $del_at_str = !empty($case->deleted_at) ? date_i18n('d/m/Y - H:i \h\r\s', strtotime($case->deleted_at)) : '';
                                    printf(__('Este caso fue enviado a la papelera por <strong>%s</strong>%s. No se pueden realizar modificaciones ni cambiar su estado mientras permanezca en la papelera.', 'contacto-multidestino'), $del_by_str, $del_at_str ? ' el ' . $del_at_str : ''); 
                                    ?>
                                </p>
                            </div>
                        </div>
                        <?php if (current_user_can('manage_options')) : ?>
                            <button 
                                type="button" 
                                class="cm-apple-btn-primary" 
                                style="background:#16a34a; border-color:#15803d; color:#ffffff; font-weight:700; font-size:12.5px; height:32px; padding:0 14px; display:inline-flex; align-items:center; gap:5px; border-radius:8px; box-shadow:0 2px 6px rgba(22,163,74,0.3); cursor:pointer;" 
                                onclick="cmRestoreCase(<?php echo esc_attr($case->id); ?>)"
                            >
                                ♻️ <?php _e('Recuperar este Caso Ahora', 'contacto-multidestino'); ?>
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            <?php else : 
                $curr_user_id      = get_current_user_id();
                $user_can_reassign = true;
                if (!current_user_can('manage_options')) {
                    $allow_meta = get_user_meta($curr_user_id, 'cm_allow_reassign', true);
                    if ($allow_meta === '0') {
                        $user_can_reassign = false;
                    }
                }
            ?>
                <!-- Barra de Pestañas en el Modal / Página -->
                <div class="cm-modal-subnav">
                    <button type="button" id="cm-tab-btn-manage" class="cm-modal-tab-btn active" onclick="cmSwitchModalTab('manage')">
                        ⚙️ <?php _e('Gestión y Solicitudes', 'contacto-multidestino'); ?>
                    </button>
                    <?php if ($user_can_reassign) : ?>
                        <button type="button" id="cm-tab-btn-transfer" class="cm-modal-tab-btn" onclick="cmSwitchModalTab('transfer')">
                            🔄 <?php _e('Derivar a Otra Área', 'contacto-multidestino'); ?>
                        </button>
                    <?php else : ?>
                        <span class="cm-tag-dept" style="background:#f1f5f9; color:#64748b; border:1px solid #e2e8f0; font-size:11px; padding:5px 10px; display:inline-flex; align-items:center; gap:4px;" title="<?php esc_attr_e('Tu cuenta está configurada para atención exclusiva de tu área asignada sin derivación.', 'contacto-multidestino'); ?>">
                            🔒 <?php _e('Atención Exclusiva de Área', 'contacto-multidestino'); ?>
                        </span>
                    <?php endif; ?>
                </div>

                <!-- PANEL 1: GESTIÓN DE ESTADO Y RESPUESTAS (COLAPSABLE POR DEFECTO) -->
                <?php
                $case_st_info = isset($statuses[$case->status]) ? $statuses[$case->status] : array('label' => $case->status, 'icon' => '🔵');
                ?>
                <div id="cm-pane-manage" class="cm-tab-pane" style="display:block;">
                    <div class="cm-apple-card-sm" style="padding:0; overflow:hidden; border:1px solid #e2e8f0; background:#ffffff; border-radius:12px; box-shadow:0 1px 3px rgba(0,0,0,0.03);">
                        
                        <!-- Cabecera Colapsable Interactiva (Clic para abrir / cerrar) -->
                        <div onclick="cmToggleManageForm()" style="display:flex; align-items:center; justify-content:space-between; padding:12px 16px; background:#f8fafc; cursor:pointer; user-select:none; transition:background 0.15s ease;" onmouseover="this.style.background='#f1f5f9';" onmouseout="this.style.background='#f8fafc';">
                            <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
                                <span style="font-size:16px;">⚡</span>
                                <strong style="font-size:13px; color:#0f172a;"><?php _e('Actualizar Estado / Responder al Solicitante', 'contacto-multidestino'); ?></strong>
                                <span style="display:inline-flex; align-items:center; gap:4px; font-size:11px; font-weight:700; background:#ffffff; color:#334155; border:1px solid #cbd5e1; padding:2px 8px; border-radius:12px;">
                                    <?php echo ($case_st_info['icon'] ?? '🔵') . ' ' . esc_html($case_st_info['label'] ?? $case->status); ?>
                                </span>
                            </div>
                            <button type="button" class="cm-apple-btn-secondary" style="font-size:11.5px; height:28px; padding:0 10px; font-weight:700; pointer-events:none; display:inline-flex; align-items:center; gap:4px; background:#ffffff;">
                                <span id="cm-toggle-manage-btn-icon">🔽</span>
                                <span id="cm-toggle-manage-btn-text"><?php _e('Desplegar Formulario', 'contacto-multidestino'); ?></span>
                            </button>
                        </div>

                        <!-- Cuerpo del Formulario Colapsable (Oculto por defecto) -->
                        <div id="cm-manage-form-body" style="display:none; padding:16px 18px; border-top:1px solid #e2e8f0; background:#ffffff;">
                            <div class="cm-form-row-compact">
                                <label><strong><?php _e('Estado del Caso:', 'contacto-multidestino'); ?></strong></label>
                                <select id="cm-select-new-status" class="cm-apple-select-lg">
                                    <?php foreach ($statuses as $st_key => $st_info) : ?>
                                        <option value="<?php echo esc_attr($st_key); ?>" <?php selected($case->status, $st_key); ?>>
                                            <?php echo $st_info['icon'] . ' ' . esc_html($st_info['label']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <!-- Casillas de Requerimiento Especial al Solicitante -->
                            <div style="margin-top: 12px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 10px 12px;">
                                <label style="font-size: 12px; font-weight: 800; color: #1e293b; display: block; margin-bottom: 6px;">
                                    📋 <?php _e('Requerimientos Especiales al Solicitante:', 'contacto-multidestino'); ?>
                                </label>
                                <div style="display: flex; flex-direction: column; gap: 8px;">
                                    <!-- Checkbox Documentos -->
                                    <div>
                                        <label style="display: inline-flex; align-items: center; gap: 6px; font-size: 12px; font-weight: 600; color: #0369a1; cursor: pointer;">
                                            <input type="checkbox" id="cm-check-req-doc" value="1" onchange="cmToggleDocTitleInput(this)" style="border-radius: 4px; accent-color: #0284c7;" />
                                            <span>📁 <?php _e('Solicitar Documentos / Archivos Web (Activa subida en portal)', 'contacto-multidestino'); ?></span>
                                        </label>
                                        <!-- Campo de Título de Documentos (Oculto por defecto) -->
                                        <div id="cm-wrap-doc-title" style="display: none; margin-top: 6px; padding-left: 22px;">
                                            <input 
                                                type="text" 
                                                id="cm-input-doc-title" 
                                                class="cm-apple-input-sm" 
                                                style="height: 32px !important; font-size: 12px; width: 100%; box-sizing: border-box;" 
                                                placeholder="<?php esc_attr_e('Ej: Adjuntar certificado de notas timbrado para continuar con el caso', 'contacto-multidestino'); ?>" 
                                            />
                                            <small style="color: #64748b; font-size: 10.5px; display: block; margin-top: 2px;">
                                                💡 <?php _e('Este título se mostrará en grande en la caja de carga del portal de seguimiento.', 'contacto-multidestino'); ?>
                                            </small>
                                        </div>
                                    </div>

                                    <!-- Checkbox Presencia -->
                                    <label style="display: inline-flex; align-items: center; gap: 6px; font-size: 12px; font-weight: 600; color: #b45309; cursor: pointer;">
                                        <input type="checkbox" id="cm-check-req-presence" value="1" style="border-radius: 4px; accent-color: #f59e0b;" />
                                        <span>🏛️ <?php _e('Solicitar Presencia Física en el Establecimiento', 'contacto-multidestino'); ?></span>
                                    </label>
                                </div>
                            </div>

                            <!-- Gestor de Notas Rápidas y Respuestas Predeterminadas (Colapsable y Personalizable) -->
                            <div style="margin-top: 12px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:12px 14px;">
                                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; flex-wrap:wrap; gap:6px;">
                                    <label style="font-size: 11.5px; color: #1e293b; font-weight: 800; text-transform: uppercase; letter-spacing: 0.05em; display:flex; align-items:center; gap:5px; margin:0;">
                                        ⚡ <?php _e('Notas Rápidas y Respuestas Predeterminadas:', 'contacto-multidestino'); ?>
                                    </label>
                                    <div style="display:flex; align-items:center; gap:6px;">
                                        <button type="button" id="cm-btn-toggle-qn" class="cm-apple-btn-secondary" style="font-size:11px; padding:2px 8px; height:24px; font-weight:700;" onclick="(window.cmToggleQuickNotesSection ? window.cmToggleQuickNotesSection() : (function(){ var c=jQuery('#cm-quick-notes-container'); if(c.is(':visible')){ c.slideUp(150); jQuery('#cm-txt-toggle-qn').text('Mostrar Notas'); } else { c.slideDown(150); jQuery('#cm-txt-toggle-qn').text('Ocultar Notas'); } })())">
                                            👁️ <span id="cm-txt-toggle-qn"><?php _e('Ocultar Notas', 'contacto-multidestino'); ?></span>
                                        </button>
                                        <button type="button" class="cm-btn-view" style="font-size:11px; padding:2px 8px; height:24px; font-weight:700; background:#e0f2fe; color:#0369a1; border:1px solid #bae6fd; display:inline-flex; align-items:center; gap:3px;" onclick="cmToggleNewQuickNoteForm()">
                                            ➕ <?php _e('Nueva Nota', 'contacto-multidestino'); ?>
                                        </button>
                                    </div>
                                </div>

                                <!-- Contenedor Desplegable de Píldoras de Notas Rápidas -->
                                <div id="cm-quick-notes-container" style="display:block;">
                                    <div id="cm-quick-notes-list" style="display:flex; gap:6px; flex-wrap:wrap; margin-bottom:6px;">
                                        <?php 
                                        $saved_quick_notes = function_exists('cm_get_saved_quick_notes') ? cm_get_saved_quick_notes() : array();
                                        if (empty($saved_quick_notes)) : ?>
                                            <div style="font-size:11.5px; color:#64748b; padding:4px 0;">
                                                <?php _e('No hay notas rápidas activas.', 'contacto-multidestino'); ?>
                                                <button type="button" onclick="cmResetDefaultQuickNotes()" style="border:none; background:transparent; color:#0284c7; font-weight:700; cursor:pointer; text-decoration:underline; font-size:11.5px; margin-left:4px;">
                                                    🔄 <?php _e('Restaurar Notas Predeterminadas', 'contacto-multidestino'); ?>
                                                </button>
                                            </div>
                                        <?php else : ?>
                                            <?php foreach ($saved_quick_notes as $qn) : 
                                                $qn_req_doc  = !empty($qn['req_doc']);
                                                $qn_req_pres = !empty($qn['req_presence']);
                                                $qn_status   = !empty($qn['status']) ? $qn['status'] : '';
                                            ?>
                                                <div class="cm-qn-pill-wrap" style="display:inline-flex; align-items:center; gap:4px; background:#ffffff; border:1px solid #cbd5e1; border-radius:16px; padding:3px 10px; box-shadow:0 1px 2px rgba(0,0,0,0.04);">
                                                    <button 
                                                        type="button" 
                                                        style="border:none; background:transparent; padding:0; font-size:11.5px; font-weight:600; color:#1e293b; cursor:pointer;" 
                                                        onclick='cmApplyQuickResponse(<?php echo json_encode($qn['content']); ?>, <?php echo json_encode($qn_status); ?>, <?php echo $qn_req_doc ? "true" : "false"; ?>, <?php echo $qn_req_pres ? "true" : "false"; ?>)'
                                                        title="<?php echo esc_attr($qn['content']); ?>"
                                                    >
                                                        <?php echo esc_html($qn['title']); ?>
                                                    </button>
                                                    <button 
                                                        type="button" 
                                                        style="border:none; background:transparent; color:#94a3b8; font-size:11.5px; font-weight:bold; cursor:pointer; padding:0 0 0 4px; line-height:1; transition:color 0.15s ease;" 
                                                        onmouseover="this.style.color='#ef4444';"
                                                        onmouseout="this.style.color='#94a3b8';"
                                                        onclick="cmDeleteQuickNote('<?php echo esc_js($qn['id']); ?>', event)" 
                                                        title="<?php esc_attr_e('Quitar esta nota rápida de la lista', 'contacto-multidestino'); ?>"
                                                    >
                                                        ✕
                                                    </button>
                                                </div>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <!-- Formulario Desplegable para Agregar Nueva Nota Predeterminada -->
                                <div id="cm-form-new-quick-note" style="display:none; background:#ffffff; border:1.5px dashed #0284c7; border-radius:8px; padding:10px 12px; margin-top:8px;">
                                    <div style="font-size:11.5px; font-weight:800; color:#0369a1; margin-bottom:6px;">
                                        📝 <?php _e('Crear y Guardar Nueva Nota Rápida Predeterminada:', 'contacto-multidestino'); ?>
                                    </div>
                                    <div style="display:flex; gap:8px; flex-wrap:wrap; margin-bottom:6px;">
                                        <input type="text" id="cm-input-qn-title" class="cm-apple-input-sm" style="flex:1; min-width:180px; height:28px !important; font-size:11.5px;" placeholder="<?php esc_attr_e('Título corto (ej: Nota Derivación Externa)', 'contacto-multidestino'); ?>" />
                                        <select id="cm-select-qn-status" class="cm-apple-select" style="height:28px !important; font-size:11.5px;">
                                            <option value="en_proceso"><?php _e('⚙️ En Proceso', 'contacto-multidestino'); ?></option>
                                            <option value="en_revision"><?php _e('🔍 En Revisión', 'contacto-multidestino'); ?></option>
                                            <option value="pendiente_usuario"><?php _e('⚠️ Requiere Usuario', 'contacto-multidestino'); ?></option>
                                            <option value="resuelto"><?php _e('✅ Resuelto / Cerrado', 'contacto-multidestino'); ?></option>
                                        </select>
                                    </div>
                                    <textarea id="cm-input-qn-content" class="cm-apple-textarea" rows="2" style="font-size:11.5px; margin-bottom:6px;" placeholder="<?php esc_attr_e('Texto que se agregará a la respuesta al seleccionar esta nota...', 'contacto-multidestino'); ?>"></textarea>
                                    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px;">
                                        <div style="display:flex; gap:10px;">
                                            <label style="font-size:11px; color:#475569; display:inline-flex; align-items:center; gap:4px; cursor:pointer;">
                                                <input type="checkbox" id="cm-check-qn-doc" value="1" />
                                                <span>📁 <?php _e('Pedir doc', 'contacto-multidestino'); ?></span>
                                            </label>
                                            <label style="font-size:11px; color:#475569; display:inline-flex; align-items:center; gap:4px; cursor:pointer;">
                                                <input type="checkbox" id="cm-check-qn-pres" value="1" />
                                                <span>🏛️ <?php _e('Pedir presencia', 'contacto-multidestino'); ?></span>
                                            </label>
                                        </div>
                                        <div style="display:flex; gap:6px;">
                                            <button type="button" class="cm-apple-btn-secondary" style="font-size:11px; padding:2px 8px; height:26px;" onclick="cmToggleNewQuickNoteForm()">
                                                ✕ <?php _e('Cancelar', 'contacto-multidestino'); ?>
                                            </button>
                                            <button type="button" class="cm-apple-btn-primary" style="font-size:11px; padding:2px 10px; height:26px;" onclick="cmSaveNewQuickNote()">
                                                💾 <?php _e('Guardar y Usar', 'contacto-multidestino'); ?>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="cm-form-row-compact" style="margin-top: 10px;">
                                <label>
                                    <strong><?php _e('Mensaje o Requerimiento Oficial (Visible para el usuario en el portal):', 'contacto-multidestino'); ?></strong>
                                </label>
                                <textarea id="cm-input-case-note" class="cm-apple-textarea" rows="3" placeholder="<?php esc_attr_e('Escribe un comentario, respuesta o instrucción clara...', 'contacto-multidestino'); ?>"></textarea>
                            </div>

                            <div style="margin-top: 10px;">
                                <label for="cm-admin-attach-file" style="font-size:12px;font-weight:600;color:#1d1d1f;display:block;margin-bottom:4px;">
                                    📎 <?php _e('Adjuntar Documento o Certificado Oficial (Opcional, máx 4MB):', 'contacto-multidestino'); ?>
                                </label>
                                <input type="file" id="cm-admin-attach-file" name="admin_attachment" accept=".jpg,.jpeg,.png,.svg,.bmp,.pdf" class="cm-apple-input-sm" style="width:100%; box-sizing:border-box; background:#ffffff;" />
                            </div>

                            <div style="margin-top: 10px; display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
                                <div style="flex:1; min-width:180px;">
                                    <input type="text" id="cm-input-author-name" class="cm-apple-input-sm" value="<?php echo esc_attr($current_user_name); ?>" placeholder="Firma / Funcionario Responsable" />
                                </div>
                                <label class="cm-check-notify" style="display:inline-flex; align-items:center; gap:6px; cursor:pointer; font-size:12px; font-weight:600;">
                                    <input type="checkbox" id="cm-check-notify-user" value="1" <?php echo !empty($case->sender_email) ? 'checked' : 'disabled'; ?> />
                                    <span>📧 <?php _e('Notificar por email al solicitante', 'contacto-multidestino'); ?></span>
                                </label>
                            </div>

                            <div style="margin-top: 12px; display:flex; justify-content:flex-end;">
                                <button type="button" class="cm-apple-btn-primary" onclick="cmSaveCaseUpdate(<?php echo esc_attr($case->id); ?>)">
                                    💾 <?php _e('Guardar y Actualizar Estado', 'contacto-multidestino'); ?>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- PANEL 2: DERIVACIÓN A OTRA ÁREA -->
                <div id="cm-pane-transfer" class="cm-tab-pane" style="display:none;">
                    <?php if ($user_can_reassign) : ?>
                        <div class="cm-apple-card-sm" style="background: #fdfdfd; border-color: #fcd34d;">
                            <div style="display:flex; align-items:center; gap:8px; margin-bottom:10px;">
                                <span style="font-size:18px;">🔄</span>
                                <div>
                                    <strong style="font-size:13px; color:#92400e;"><?php _e('Derivar caso a otro Departamento / Área', 'contacto-multidestino'); ?></strong>
                                    <p style="font-size:11.5px; color:#78350f; margin:2px 0 0 0;">
                                        <?php _e('El caso cambiará de área responsable y se notificará automáticamente a los encargados del nuevo departamento.', 'contacto-multidestino'); ?>
                                    </p>
                                </div>
                            </div>

                            <div class="cm-form-row-compact">
                                <label><strong><?php _e('Selecciona Área de Destino:', 'contacto-multidestino'); ?></strong></label>
                                <select id="cm-select-transfer-dept" class="cm-apple-select-lg">
                                    <option value=""><?php _e('— Seleccionar Área / Departamento —', 'contacto-multidestino'); ?></option>
                                    <?php foreach ($departments as $dkey => $dinfo) : 
                                        $dname = is_array($dinfo) ? ($dinfo['name'] ?? $dkey) : $dinfo;
                                        if ($dname === $case->department) continue;
                                    ?>
                                        <option value="<?php echo esc_attr($dname); ?>">
                                            🏢 <?php echo esc_html($dname); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="cm-form-row-compact" style="margin-top:10px;">
                                <label><strong><?php _e('Motivo de la Derivación (Quedará registrado en el historial):', 'contacto-multidestino'); ?></strong></label>
                                <textarea id="cm-input-transfer-note" class="cm-apple-textarea" rows="2" placeholder="<?php esc_attr_e('Ej: Corresponde gestionar por inspectoría general según el tipo de solicitud...', 'contacto-multidestino'); ?>"></textarea>
                            </div>

                            <div class="cm-form-footer-compact" style="margin-top:12px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px;">
                                <label class="cm-check-notify" style="display:inline-flex; align-items:center; gap:6px; cursor:pointer; font-size:12px; font-weight:600;">
                                    <input type="checkbox" id="cm-check-notify-transfer" value="1" checked />
                                    <span>📧 <?php _e('Notificar a los nuevos encargados por correo', 'contacto-multidestino'); ?></span>
                                </label>
                                <button type="button" class="cm-apple-btn-secondary" style="background:#fef3c7; color:#92400e; border-color:#fde68a; font-weight:700;" onclick="cmExecuteTransferCase(<?php echo esc_attr($case->id); ?>)">
                                    🔄 <?php _e('Ejecutar Derivación', 'contacto-multidestino'); ?>
                                </button>
                            </div>
                        </div>
                    <?php else : ?>
                        <div class="cm-apple-card-sm" style="background: #fffbeb; border:1px solid #fde68a; padding:16px; border-radius:10px;">
                            <strong style="color:#92400e; font-size:13px;">🔒 <?php _e('Función de Derivación Restringida', 'contacto-multidestino'); ?></strong>
                            <p style="color:#b45309; font-size:12px; margin:4px 0 0 0;">
                                <?php _e('Tu perfil de usuario tiene permisos exclusivos para gestionar y responder casos de tu área asignada. Para derivar este caso a otro departamento, solicita asistencia a la Dirección o al Administrador.', 'contacto-multidestino'); ?>
                            </p>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <!-- Línea de Tiempo Apple Pro -->
            <div class="cm-apple-card-sm" style="margin-top: 14px;">
                <div class="cm-card-sm-title" style="display:flex; justify-content:space-between; align-items:center;">
                    <span>📜 <?php _e('Historial y Trazabilidad del Caso', 'contacto-multidestino'); ?></span>
                    <span style="font-size:11px; font-weight:700; color:#64748b; background:#f1f5f9; padding:2px 8px; border-radius:10px;">
                        <?php echo count($history); ?> <?php _e('eventos', 'contacto-multidestino'); ?>
                    </span>
                </div>
                <div class="cm-timeline-apple">
                    <?php if (!empty($history)) : ?>
                        <?php foreach ($history as $h) : 
                            $h_status = isset($statuses[$h->status]) ? $statuses[$h->status] : null;
                            $action_type = !empty($h->action_type) ? $h->action_type : 'update';
                            $is_applicant = (stripos($h->author_name, 'solicitante') !== false);
                            $is_system = (stripos($h->author_name, 'sistema') !== false);
                            $author_icon = $is_system ? '⚙️' : ($is_applicant ? '👤' : '🏛️');
                        ?>
                            <div class="cm-tl-row">
                                <div class="cm-tl-node <?php echo $is_applicant ? 'cm-node-user' : ($action_type === 'transfer' ? 'cm-node-transfer' : ($action_type === 'deleted' ? 'cm-node-deleted' : ($action_type === 'restored' ? 'cm-node-restored' : ''))); ?>"></div>
                                <div class="cm-tl-box <?php echo $action_type === 'transfer' ? 'cm-box-transfer' : ($action_type === 'deleted' ? 'cm-box-deleted' : ($action_type === 'restored' ? 'cm-box-restored' : ($is_applicant ? 'cm-box-user' : ($action_type === 'doc_request' ? 'cm-box-doc-req' : '')))); ?>">
                                    <div class="cm-tl-top">
                                        <div class="cm-tl-author-wrap">
                                            <span class="cm-tl-author-icon"><?php echo ($action_type === 'deleted' ? '🗑️' : ($action_type === 'restored' ? '♻️' : $author_icon)); ?></span>
                                            <strong class="cm-tl-author-name"><?php echo esc_html($h->author_name); ?></strong>
                                        </div>
                                        <div class="cm-tl-badges-wrap">
                                            <?php if ($action_type === 'deleted') : ?>
                                                <span class="cm-badge-mini" style="background:#fee2e2; color:#b91c1c; border:1px solid #fecaca;">
                                                    🗑️ <?php _e('Enviado a Papelera', 'contacto-multidestino'); ?>
                                                </span>
                                            <?php elseif ($action_type === 'restored') : ?>
                                                <span class="cm-badge-mini" style="background:#dcfce7; color:#15803d; border:1px solid #bbf7d0;">
                                                    ♻️ <?php _e('Caso Recuperado', 'contacto-multidestino'); ?>
                                                </span>
                                            <?php elseif ($action_type === 'transfer') : ?>
                                                <span class="cm-badge-mini" style="background:#fef3c7; color:#92400e; border:1px solid #fde68a;">
                                                    🔄 <?php _e('Derivación de Área', 'contacto-multidestino'); ?>
                                                </span>
                                            <?php elseif ($action_type === 'doc_request') : ?>
                                                <span class="cm-badge-mini" style="background:#e0f2fe; color:#0369a1; border:1px solid #bae6fd;">
                                                    📁 <?php _e('Solicitud de Documentos', 'contacto-multidestino'); ?>
                                                </span>
                                            <?php elseif ($action_type === 'applicant_attachment') : ?>
                                                <span class="cm-badge-mini" style="background:#e0f2fe; color:#0369a1; border:1px solid #bae6fd;">
                                                    📎 <?php _e('Documento Aportado', 'contacto-multidestino'); ?>
                                                </span>
                                            <?php elseif ($h_status) : ?>
                                                <span class="cm-badge-mini" style="background:<?php echo esc_attr($h_status['bg_color']); ?>; color:<?php echo esc_attr($h_status['color']); ?>; border:1px solid <?php echo esc_attr($h_status['border'] ?? '#cbd5e1'); ?>;">
                                                    <?php echo $h_status['icon'] . ' ' . esc_html($h_status['label']); ?>
                                                </span>
                                            <?php endif; ?>
                                            <span class="cm-tl-time">🕒 <?php echo date_i18n('d/m/y H:i', strtotime($h->created_at)); ?></span>
                                        </div>
                                    </div>
                                    <?php 
                                        $clean_h_note = trim(preg_replace('/\[REQ_DOC:\s*.*?\]/i', '', $h->note));
                                    ?>
                                    <div class="cm-tl-desc"><?php echo nl2br(wp_kses_post($clean_h_note)); ?></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <p style="color:#86868b;font-size:12px;margin:0;"><?php _e('Sin eventos registrados.', 'contacto-multidestino'); ?></p>
                    <?php endif; ?>
                </div>
            </div>
            


        </div>
    </div>
    <?php
    $html = ob_get_clean();

    // ══════════════════════════════════════════════════════════════════
    // GENERAR INFORME OFICIAL EN TAMAÑO CARTA (PRINT_HTML)
    // ══════════════════════════════════════════════════════════════════
    $public_case_url = function_exists('cm_get_case_tracker_url') ? cm_get_case_tracker_url($case->ticket_code) : home_url('/?codigo=' . $case->ticket_code);

    ob_start();
    ?>
    <div class="cm-letter-print-dossier">
        <div style="border-bottom:2px solid #0f172a; padding-bottom:12px; margin-bottom:18px; display:flex; justify-content:space-between; align-items:flex-start;">
            <div>
                <div style="font-size:10px; font-weight:800; text-transform:uppercase; letter-spacing:0.08em; color:#64748b;">EXPEDIENTE OFICIAL DE TRAZABILIDAD Y GESTIÓN</div>
                <h1 style="font-size:20px; font-weight:800; color:#0f172a; margin:4px 0 2px 0; text-transform:uppercase;"><?php echo esc_html(get_bloginfo('name')); ?></h1>
                <div style="font-size:12px; color:#475569;">Área Asignada: <strong><?php echo esc_html($case->department ? $case->department : 'General'); ?></strong></div>
            </div>
            <div style="text-align:right;">
                <div style="display:flex; align-items:center; justify-content:flex-end; gap:8px;">
                    <span style="font-family:monospace; font-size:20px; font-weight:800; color:#0284c7;"><?php echo esc_html($case->ticket_code); ?></span>
                    <a href="<?php echo esc_url($public_case_url); ?>" target="_blank" class="cm-print-screen-only" style="font-size:11px; font-weight:700; color:#ffffff; background:#0284c7; padding:3px 9px; border-radius:6px; text-decoration:none; display:inline-flex; align-items:center; gap:4px;" title="<?php esc_attr_e('Ir a la página donde el cliente ve su caso', 'contacto-multidestino'); ?>">
                        🌐 <?php _e('Ir al Caso en la Web', 'contacto-multidestino'); ?> ↗
                    </a>
                </div>
                <div style="font-size:11px; color:#64748b; margin-top:3px;">Emisión: <?php echo date_i18n('d/m/Y - H:i \h\r\s'); ?></div>
                <div style="font-size:11px; font-weight:700; color:#059669; margin-top:2px;">Estado: <?php echo esc_html($statuses[$case->status]['label'] ?? ucfirst($case->status)); ?></div>
            </div>
        </div>

        <!-- 1. Datos del Solicitante -->
        <div style="margin-bottom:16px;">
            <h2 style="font-size:13px; font-weight:800; text-transform:uppercase; border-bottom:1px solid #e2e8f0; padding-bottom:4px; margin-bottom:8px; color:#1e293b;">
                1. INFORMACIÓN DEL SOLICITANTE
            </h2>
            <table style="width:100%; border-collapse:collapse; font-size:12px;">
                <tr>
                    <td style="width:25%; padding:4px 0; color:#64748b; font-weight:600;">Nombre Completo:</td>
                    <td style="width:75%; padding:4px 0; font-weight:700; color:#0f172a;"><?php echo esc_html($case->sender_name ? $case->sender_name : 'No especificado'); ?></td>
                </tr>
                <tr>
                    <td style="padding:4px 0; color:#64748b; font-weight:600;">Correo Electrónico:</td>
                    <td style="padding:4px 0; color:#0f172a;"><?php echo esc_html($case->sender_email); ?></td>
                </tr>
                <?php if ($case->sender_phone) : ?>
                <tr>
                    <td style="padding:4px 0; color:#64748b; font-weight:600;">Teléfono de Contacto:</td>
                    <td style="padding:4px 0; color:#0f172a;"><?php echo esc_html($case->sender_phone); ?></td>
                </tr>
                <?php endif; ?>
                <tr>
                    <td style="padding:4px 0; color:#64748b; font-weight:600;">Fecha de Ingreso:</td>
                    <td style="padding:4px 0; color:#0f172a;"><?php echo date_i18n('d \d\e F, Y - H:i \h\r\s', strtotime($case->created_at)); ?></td>
                </tr>
            </table>
        </div>

        <!-- 2. Detalle de la Solicitud Inicial -->
        <?php if (!empty($submitted_data)) : ?>
        <div style="margin-bottom:16px;">
            <h2 style="font-size:13px; font-weight:800; text-transform:uppercase; border-bottom:1px solid #e2e8f0; padding-bottom:4px; margin-bottom:8px; color:#1e293b;">
                2. ANTECEDENTES Y REQUERIMIENTO DEL FORMULARIO
            </h2>
            <table style="width:100%; border-collapse:collapse; font-size:11.5px; border:1px solid #e2e8f0;">
                <?php foreach ($submitted_data as $lbl => $val) : ?>
                    <tr style="border-bottom:1px solid #f1f5f9;">
                        <td style="width:35%; padding:6px 8px; background:#f8fafc; font-weight:600; color:#475569; border-right:1px solid #e2e8f0;"><?php echo esc_html($lbl); ?></td>
                        <td style="width:65%; padding:6px 8px; color:#0f172a;"><?php echo nl2br(esc_html($val)); ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
        <?php endif; ?>

        <!-- 3. Trazabilidad Cronológica y Derivaciones -->
        <div style="margin-bottom:16px;">
            <h2 style="font-size:13px; font-weight:800; text-transform:uppercase; border-bottom:1px solid #e2e8f0; padding-bottom:4px; margin-bottom:8px; color:#1e293b;">
                3. HISTORIAL DE GESTIÓN, DERIVACIONES Y RESOLUCIÓN
            </h2>
            <?php if (!empty($history)) : ?>
                <table style="width:100%; border-collapse:collapse; font-size:11px; border:1px solid #cbd5e1;">
                    <thead>
                        <tr style="background:#f1f5f9; border-bottom:1.5px solid #cbd5e1;">
                            <th style="padding:6px 8px; text-align:left; width:22%;">Fecha / Hora</th>
                            <th style="padding:6px 8px; text-align:left; width:22%;">Responsable</th>
                            <th style="padding:6px 8px; text-align:left; width:18%;">Estado / Acción</th>
                            <th style="padding:6px 8px; text-align:left; width:38%;">Detalle / Motivo</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($history as $hitem) : 
                            $st_lbl = isset($statuses[$hitem->status]) ? $statuses[$hitem->status]['label'] : ucfirst($hitem->status);
                        ?>
                            <tr style="border-bottom:1px solid #e2e8f0;">
                                <td style="padding:5px 8px; color:#64748b;"><?php echo date_i18n('d/m/Y H:i', strtotime($hitem->created_at)); ?></td>
                                <td style="padding:5px 8px; font-weight:700; color:#0f172a;"><?php echo esc_html($hitem->author_name); ?></td>
                                <td style="padding:5px 8px; color:#0284c7; font-weight:600;"><?php echo esc_html($st_lbl); ?></td>
                                <td style="padding:5px 8px; color:#334155;"><?php echo nl2br(strip_tags($hitem->note, '<a><b><strong><br>')); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else : ?>
                <p style="font-size:11px; color:#94a3b8; margin:0;">Sin eventos registrados.</p>
            <?php endif; ?>
        </div>

        <!-- 4. Registro de Documentos y Anexos -->
        <?php if (!empty($attached_items)) : ?>
        <div style="margin-bottom:16px;">
            <h2 style="font-size:13px; font-weight:800; text-transform:uppercase; border-bottom:1px solid #e2e8f0; padding-bottom:4px; margin-bottom:8px; color:#1e293b;">
                4. DOCUMENTOS Y ANEXOS APORTADOS (<?php echo count($attached_items); ?>)
            </h2>
            <table style="width:100%; border-collapse:collapse; font-size:11px; border:1px solid #e2e8f0;">
                <tr style="background:#f8fafc; font-weight:700; color:#475569; border-bottom:1px solid #e2e8f0;">
                    <td style="padding:5px 8px; width:45%;">Nombre del Documento</td>
                    <td style="padding:5px 8px; width:15%;">Formato</td>
                    <td style="padding:5px 8px; width:20%;">Emisor / Autor</td>
                    <td style="padding:5px 8px; width:20%;">Fecha</td>
                </tr>
                <?php foreach ($attached_items as $a_item) : ?>
                    <tr style="border-bottom:1px solid #f1f5f9;">
                        <td style="padding:5px 8px; font-weight:600; color:#0f172a;">📄 <?php echo esc_html($a_item['name']); ?></td>
                        <td style="padding:5px 8px; color:#0284c7; font-weight:700;"><?php echo strtoupper($a_item['ext']); ?></td>
                        <td style="padding:5px 8px; color:#475569;"><?php echo esc_html($a_item['author']); ?></td>
                        <td style="padding:5px 8px; color:#64748b;"><?php echo esc_html($a_item['date']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
        <?php endif; ?>

        <!-- 5. Firmas y Timbres Oficiales -->
        <div style="margin-top:35px; padding-top:15px; page-break-inside:avoid; display:flex; justify-content:space-between; text-align:center;">
            <div style="width:42%; border-top:1.5px solid #0f172a; padding-top:6px;">
                <div style="font-weight:700; font-size:12px; color:#0f172a;">Firma y Timbre</div>
                <div style="font-size:11px; color:#64748b;"><?php echo esc_html($case->department ? 'Encargado ' . $case->department : 'Funcionario Responsable'); ?></div>
            </div>
            <div style="width:42%; border-top:1.5px solid #0f172a; padding-top:6px;">
                <div style="font-weight:700; font-size:12px; color:#0f172a;">V° B° y Timbre Oficial</div>
                <div style="font-size:11px; color:#64748b;">Dirección / Auditoría Institucional</div>
            </div>
        </div>
    </div>
    <?php
    $print_html = ob_get_clean();

    return array(
        'case'        => $case,
        'ticket_code' => $case->ticket_code,
        'tracker_url' => $public_case_url,
        'html'        => $html,
        'print_html'  => $print_html
    );
}

/**
 * AJAX: Retorna el contenido del Modal Apple Inspector con pestañas de Gestión y Derivación.
 */
function cm_ajax_admin_get_case_detail() {
    $nonce = isset($_POST['nonce']) ? $_POST['nonce'] : '';
    if (!wp_verify_nonce($nonce, 'cm_contacto_nonce') && !check_ajax_referer('cm_contacto_nonce', 'nonce', false)) {
        if (!is_user_logged_in() || (!current_user_can('edit_posts') && !current_user_can('manage_options'))) {
            wp_send_json_error(array('message' => __('Permiso denegado o sesión expirada.', 'contacto-multidestino')));
        }
    }
    $id = isset($_POST['id']) ? absint($_POST['id']) : 0;
    $res = cm_build_case_inspector_payload($id);
    if (is_wp_error($res)) {
        wp_send_json_error(array('message' => $res->get_error_message()));
    }
    
    if (function_exists('cm_log_audit_action')) {
        cm_log_audit_action($id, $res['case']->ticket_code, 'viewed', 'Visualizó los detalles del caso en el panel.');
    }
    
    if (current_user_can('manage_options') && function_exists('cm_get_audit_logs')) {
        $res['audit_logs'] = cm_get_audit_logs($id);
    }

    wp_send_json_success($res);
}
add_action('wp_ajax_cm_admin_get_case_detail', 'cm_ajax_admin_get_case_detail');

/**
 * Renderiza la Vista de Pantalla Completa / Página de un Caso en WordPress Admin.
 */
function cm_render_fullpage_case_view($payload) {
    $case = $payload['case'];
    $ticket_code = $payload['ticket_code'];
    $tracker_url = $payload['tracker_url'];
    $statuses = cm_get_case_statuses();
    $status_info = isset($statuses[$case->status]) ? $statuses[$case->status] : array(
        'label'    => ucfirst($case->status),
        'color'    => '#475569',
        'bg_color' => '#f1f5f9',
        'icon'     => '📌'
    );
    ?>
    <div class="wrap cm-apple-wrap cm-full-case-wrap" style="max-width: 1350px; margin: 20px auto;">
        <!-- Cabecera de Navegación Apple Pro -->
        <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px; margin-bottom:18px; padding-bottom:14px; border-bottom:1px solid #e2e8f0;">
            <div style="display:flex; align-items:center; gap:12px; flex-wrap:wrap;">
                <a href="<?php echo cm_get_view_tab_url('inbox'); ?>" class="cm-apple-btn-secondary" style="font-weight:700; display:inline-flex; align-items:center; gap:6px; height:34px; padding:0 14px; text-decoration:none; color:#0f172a; background:#ffffff;">
                    ← <?php _e('Volver a la Bandeja de Casos', 'contacto-multidestino'); ?>
                </a>
                <span class="cm-modal-badge-app" style="font-size:11px;">EXPEDIENTE OFICIAL</span>
                <span id="cm-modal-ticket-title" class="cm-modal-ticket-code" style="font-size:20px; font-weight:800; font-family:monospace; color:#0284c7; background:#e0f2fe; padding:3px 12px; border-radius:6px;">
                    <?php echo esc_html($ticket_code); ?>
                </span>
                <span class="cm-badge-status" id="cm-status-pill-<?php echo esc_attr($case->id); ?>" style="background-color: <?php echo esc_attr($status_info['bg_color']); ?>; color: <?php echo esc_attr($status_info['color']); ?>; border-color: <?php echo esc_attr($status_info['border'] ?? $status_info['color']); ?>;">
                    <?php echo $status_info['icon'] . ' ' . esc_html($status_info['label']); ?>
                </span>
                <a href="<?php echo esc_url($tracker_url); ?>" target="_blank" class="cm-portal-link-btn" style="font-size:12px; font-weight:700; color:#0284c7; background:#e0f2fe; border:1px solid #bae6fd; border-radius:6px; padding:4px 10px; text-decoration:none; display:inline-flex; align-items:center; gap:4px;" title="<?php esc_attr_e('Abrir página pública donde el solicitante ve su caso', 'contacto-multidestino'); ?>">
                    🌐 <?php _e('Ir al Caso en la Web', 'contacto-multidestino'); ?> ↗
                </a>
            </div>
            <div style="display:flex; align-items:center; gap:8px;">
                <button type="button" class="cm-apple-btn-secondary" onclick="cmOpenPrintPreview()" style="font-size:12.5px; font-weight:700; display:inline-flex; align-items:center; gap:5px; padding:6px 14px; background:#ffffff; border-color:#cbd5e1; height:34px;" title="<?php esc_attr_e('Vista Previa e Impresión Oficial en Tamaño Carta', 'contacto-multidestino'); ?>">
                    🖨️ <?php _e('Imprimir Informe (Carta)', 'contacto-multidestino'); ?>
                </button>
            </div>
        </div>

        <!-- Contenedor del Expediente -->
        <div class="cm-full-case-container" style="background:#ffffff; border:1px solid #e2e8f0; border-radius:14px; padding:22px; box-shadow:0 2px 10px rgba(0,0,0,0.03);">
            <?php echo $payload['html']; ?>
        </div>
    </div>

    <!-- MODAL LIGHTBOX DE VISUALIZACIÓN DE DOCUMENTOS/IMÁGENES -->
    <div id="cm-lightbox-modal" class="cm-lightbox-overlay" style="display:none;" onclick="cmCloseDocumentPreview(event)">
        <div class="cm-lightbox-box" onclick="event.stopPropagation();">
            <div class="cm-lightbox-head">
                <span id="cm-lightbox-filename" class="cm-lightbox-title">Documento</span>
                <div class="cm-lightbox-actions">
                    <a id="cm-lightbox-download" href="#" target="_blank" class="cm-apple-btn-secondary" style="font-size:12px; font-weight:700;">
                        ⬇️ <?php _e('Descargar Original', 'contacto-multidestino'); ?>
                    </a>
                    <button type="button" class="cm-apple-modal-close" onclick="cmCloseDocumentPreview()">✕</button>
                </div>
            </div>
            <div class="cm-lightbox-body" id="cm-lightbox-content"></div>
        </div>
    </div>

    <script>
    var cmCurrentCasePrintHtml = <?php echo json_encode($payload['print_html']); ?>;

    window.cmOpenPrintPreview = function() {
        if (!cmCurrentCasePrintHtml) {
            alert('Cargando datos del expediente para imprimir...');
            return;
        }
        
        var ticketCode = '<?php echo esc_js($ticket_code); ?>';
        var printWindow = window.open('', '_blank');
        if (!printWindow) {
            alert('Por favor habilita las ventanas emergentes en tu navegador para abrir el expediente en una página aparte.');
            return;
        }

        var doc = printWindow.document;
        doc.open();
        doc.write('<!DOCTYPE html>' +
            '<html lang="es"><head>' +
            '<meta charset="UTF-8">' +
            '<meta name="viewport" content="width=device-width, initial-scale=1.0">' +
            '<title>Expediente Oficial - ' + ticketCode + '</title>' +
            '<style>' +
            '@page { size: letter portrait; margin: 12mm 15mm; }' +
            '* { box-sizing: border-box; }' +
            'body { margin: 0; padding: 0; background: #525659; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; color: #111827; }' +
            '.cm-print-topbar { position: sticky; top: 0; z-index: 9999; background: #ffffff; padding: 12px 24px; display: flex; align-items: center; justify-content: space-between; box-shadow: 0 2px 10px rgba(0,0,0,0.18); border-bottom: 1px solid #e2e8f0; }' +
            '.cm-print-action-btn { background: #0071e3; color: #ffffff; border: none; border-radius: 8px; padding: 9px 22px; font-size: 14px; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 6px; box-shadow: 0 2px 8px rgba(0,113,227,0.35); transition: background 0.15s ease; }' +
            '.cm-print-action-btn:hover { background: #0077ed; }' +
            '.cm-print-close-btn { background: #f1f5f9; color: #475569; border: 1px solid #cbd5e1; border-radius: 8px; padding: 8px 16px; font-size: 13px; font-weight: 600; cursor: pointer; }' +
            '.cm-print-close-btn:hover { background: #e2e8f0; }' +
            '.cm-dossier-wrap { display: flex; justify-content: center; padding: 28px 16px 60px; }' +
            '.cm-dossier-sheet { width: 100%; max-width: 816px; background: #ffffff; padding: 48px 56px; box-shadow: 0 12px 36px rgba(0,0,0,0.3); border-radius: 4px; min-height: 1056px; }' +
            'table { width: 100%; border-collapse: collapse; }' +
            '@media print {' +
            '  body { background: #ffffff !important; padding: 0 !important; }' +
            '  .cm-print-topbar { display: none !important; }' +
            '  .cm-dossier-wrap { padding: 0 !important; display: block !important; }' +
            '  .cm-dossier-sheet { box-shadow: none !important; padding: 0 !important; border-radius: 0 !important; max-width: 100% !important; min-height: auto !important; }' +
            '}' +
            '</style>' +
            '</head><body>' +
            '<div class="cm-print-topbar">' +
            '  <div style="font-weight:700; font-size:14px; color:#111827;">📄 EXPEDIENTE OFICIAL • ' + ticketCode + '</div>' +
            '  <div style="display:flex; gap:10px; align-items:center;">' +
            '    <button type="button" class="cm-print-action-btn" onclick="window.print()">🖨️ Imprimir Caso Ahora</button>' +
            '    <button type="button" class="cm-print-close-btn" onclick="window.close()">✕ Cerrar Pestaña</button>' +
            '  </div>' +
            '</div>' +
            '<div class="cm-dossier-wrap">' +
            '  <div class="cm-dossier-sheet">' +
            cmCurrentCasePrintHtml +
            '  </div>' +
            '</div>' +
            '</body></html>');
        doc.close();
    };

    window.cmOpenDocumentPreview = function(fileUrl, fileName, isImage) {
        if (isImage) {
            jQuery('#cm-lightbox-filename').text(fileName);
            jQuery('#cm-lightbox-download').attr('href', fileUrl);
            jQuery('#cm-lightbox-content').html('<img src="' + fileUrl + '" class="cm-lightbox-img" alt="' + fileName + '" />');
            jQuery('#cm-lightbox-modal').fadeIn(150).css('display', 'flex');
        } else {
            window.open(fileUrl, '_blank');
        }
    };

    window.cmCloseDocumentPreview = function(e) {
        jQuery('#cm-lightbox-modal').fadeOut(120);
    };

    window.cmToggleManageForm = function() {
        var $body = jQuery('#cm-manage-form-body');
        if ($body.is(':visible')) {
            $body.slideUp(180);
            jQuery('#cm-toggle-manage-btn-icon').text('🔽');
            jQuery('#cm-toggle-manage-btn-text').text('Desplegar Formulario');
        } else {
            $body.slideDown(180);
            jQuery('#cm-toggle-manage-btn-icon').text('🔼');
            jQuery('#cm-toggle-manage-btn-text').text('Ocultar Formulario');
        }
    };

    window.cmSwitchModalTab = function(tab) {
        jQuery('.cm-modal-tab-btn').removeClass('active');
        jQuery('.cm-tab-pane').hide();
        if (tab === 'manage') {
            jQuery('#cm-tab-btn-manage').addClass('active');
            jQuery('#cm-pane-manage').fadeIn(100);
        } else if (tab === 'transfer') {
            jQuery('#cm-tab-btn-transfer').addClass('active');
            jQuery('#cm-pane-transfer').fadeIn(100);
        }
    };

    window.cmToggleDocTitleInput = function(checkbox) {
        if (checkbox.checked) {
            jQuery('#cm-wrap-doc-title').slideDown(120);
            jQuery('#cm-input-doc-title').focus();
        } else {
            jQuery('#cm-wrap-doc-title').slideUp(100);
        }
    };

    window.cmApplyQuickResponse = function(text, status, reqDoc, reqPresence) {
        var $body = jQuery('#cm-manage-form-body');
        if ($body.length && !$body.is(':visible')) {
            $body.slideDown(180);
            jQuery('#cm-toggle-manage-btn-icon').text('🔼');
            jQuery('#cm-toggle-manage-btn-text').text('Ocultar Formulario');
        }

        jQuery('#cm-input-case-note').val(text);
        if (status) {
            jQuery('#cm-select-new-status').val(status);
        }
        if (reqDoc) {
            jQuery('#cm-check-req-doc').prop('checked', true);
            jQuery('#cm-wrap-doc-title').show();
            if (!jQuery('#cm-input-doc-title').val()) {
                jQuery('#cm-input-doc-title').val('Adjuntar documentación solicitada para continuar con el caso');
            }
        }
        if (reqPresence) {
            jQuery('#cm-check-req-presence').prop('checked', true);
        }
    };

    window.cmToggleNewQuickNoteForm = function() {
        var $form = jQuery('#cm-form-new-quick-note');
        if ($form.is(':visible')) {
            $form.slideUp(120);
        } else {
            $form.slideDown(120);
            jQuery('#cm-input-qn-title').focus();
        }
    };

    window.cmSaveNewQuickNote = function() {
        var title   = jQuery('#cm-input-qn-title').val().trim();
        var content = jQuery('#cm-input-qn-content').val().trim();
        var status  = jQuery('#cm-select-qn-status').val();
        var reqDoc  = jQuery('#cm-check-qn-doc').is(':checked') ? 1 : 0;
        var reqPres = jQuery('#cm-check-qn-pres').is(':checked') ? 1 : 0;

        if (!title || !content) {
            alert('Por favor ingresa un título corto y el contenido de la nota.');
            return;
        }

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_save_quick_note',
                title: title,
                content: content,
                status: status,
                req_doc: reqDoc,
                req_presence: reqPres,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                if (res.success && res.data && res.data.note) {
                    var n = res.data.note;
                    var pillHtml = '<div class="cm-qn-pill-wrap" style="display:inline-flex; align-items:center; gap:4px; background:#ffffff; border:1px solid #cbd5e1; border-radius:16px; padding:3px 10px; box-shadow:0 1px 2px rgba(0,0,0,0.04);">' +
                        '<button type="button" style="border:none; background:transparent; padding:0; font-size:11.5px; font-weight:600; color:#1e293b; cursor:pointer;" onclick=\'cmApplyQuickResponse(' + JSON.stringify(n.content) + ', ' + JSON.stringify(n.status) + ', ' + (n.req_doc ? 'true' : 'false') + ', ' + (n.req_presence ? 'true' : 'false') + ')\'>' +
                        jQuery('<div>').text(n.title).html() +
                        '</button>' +
                        '<button type="button" style="border:none; background:transparent; color:#94a3b8; font-size:11.5px; font-weight:bold; cursor:pointer; padding:0 0 0 4px; line-height:1;" onclick="cmDeleteQuickNote(\'' + n.id + '\', event)">✕</button>' +
                        '</div>';
                    
                    jQuery('#cm-quick-notes-list').append(pillHtml);
                    cmApplyQuickResponse(n.content, n.status, n.req_doc, n.req_presence);
                    jQuery('#cm-input-qn-title').val('');
                    jQuery('#cm-input-qn-content').val('');
                    jQuery('#cm-form-new-quick-note').slideUp(120);
                    alert('✓ Nota rápida guardada y aplicada exitosamente.');
                } else {
                    alert('Error: ' + ((res.data && res.data.message) ? res.data.message : 'No se pudo guardar la nota.'));
                }
            },
            error: function() {
                alert('Error de conexión al guardar nota rápida.');
            }
        });
    };

    window.cmToggleQuickNotesSection = function() {
        var $c = jQuery('#cm-quick-notes-container');
        if ($c.is(':visible')) {
            $c.slideUp(150);
            jQuery('#cm-txt-toggle-qn').text('Mostrar Notas');
            try { localStorage.setItem('cm_hide_quick_notes', '1'); } catch(e) {}
        } else {
            $c.slideDown(150);
            jQuery('#cm-txt-toggle-qn').text('Ocultar Notas');
            try { localStorage.removeItem('cm_hide_quick_notes'); } catch(e) {}
        }
    };

    window.cmResetDefaultQuickNotes = function() {
        if (!confirm('¿Deseas restaurar todas las notas rápidas predeterminadas del sistema?')) return;
        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_reset_quick_notes',
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                if (res.success) {
                    alert('✓ Notas rápidas restauradas correctamente.');
                    location.reload();
                } else {
                    alert('Error: ' + ((res.data && res.data.message) ? res.data.message : 'No se pudieron restaurar.'));
                }
            },
            error: function() {
                alert('Error de conexión al restaurar notas.');
            }
        });
    };

    window.cmDeleteQuickNote = function(noteId, event) {
        if (event) event.stopPropagation();
        if (!confirm('¿Quitar esta nota rápida de la lista?')) return;

        var $btn = jQuery(event.target);
        var $pill = $btn.closest('.cm-qn-pill-wrap');

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_delete_quick_note',
                note_id: noteId,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                if (res.success) {
                    $pill.fadeOut(150, function() { jQuery(this).remove(); });
                } else {
                    alert('Error al eliminar: ' + (res.data.message || ''));
                }
            },
            error: function() {
                alert('Error de conexión al eliminar nota.');
            }
        });
    };

    window.cmSaveCaseUpdate = function(submissionId) {
        var newStatus   = jQuery('#cm-select-new-status').val();
        var note        = jQuery('#cm-input-case-note').val();
        var notifyUser  = jQuery('#cm-check-notify-user').is(':checked') ? 1 : 0;
        var reqDoc      = jQuery('#cm-check-req-doc').is(':checked') ? 1 : 0;
        var docTitle    = jQuery('#cm-input-doc-title').val();
        var reqPresence = jQuery('#cm-check-req-presence').is(':checked') ? 1 : 0;
        var authorName  = jQuery('#cm-input-author-name').val();
        var fileInput   = document.getElementById('cm-admin-attach-file');
        
        if (!note && !newStatus && !reqDoc && !reqPresence && (!fileInput || !fileInput.files.length)) {
            alert('Por favor escribe un mensaje o selecciona un estado.');
            return;
        }

        var $btn = jQuery('.cm-apple-btn-primary').prop('disabled', true).text('Guardando...');

        var formData = new FormData();
        formData.append('action', 'cm_admin_update_case');
        formData.append('id', submissionId);
        formData.append('status', newStatus);
        formData.append('note', note);
        formData.append('notify_user', notifyUser);
        formData.append('req_doc', reqDoc);
        formData.append('doc_title', docTitle);
        formData.append('req_presence', reqPresence);
        formData.append('author_name', authorName);
        formData.append('nonce', '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>');

        if (fileInput && fileInput.files.length > 0) {
            formData.append('admin_attachment', fileInput.files[0]);
        }

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(res) {
                $btn.prop('disabled', false).text('💾 Guardar y Actualizar Estado');
                if (res.success) {
                    alert('✓ Expediente actualizado exitosamente.');
                    location.reload();
                } else {
                    alert('Error: ' + (res.data.message || 'No se pudo actualizar el estado.'));
                }
            },
            error: function() {
                $btn.prop('disabled', false).text('💾 Guardar y Actualizar Estado');
                alert('Error de conexión con el servidor.');
            }
        });
    };

    window.cmExecuteTransferCase = function(submissionId) {
        var newDept = jQuery('#cm-select-transfer-dept').val();
        var note    = jQuery('#cm-input-transfer-note').val();
        var notify  = jQuery('#cm-check-notify-transfer').is(':checked') ? 1 : 0;
        var author  = jQuery('#cm-input-author-name').val() || 'Área Responsable';

        if (!newDept) {
            alert('Por favor selecciona el área de destino.');
            return;
        }

        if (!confirm('¿Confirmas que deseas derivar este caso al departamento "' + newDept + '"?')) {
            return;
        }

        var $btn = jQuery('.cm-apple-btn-secondary').prop('disabled', true).text('Derivando...');

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'cm_admin_reassign_case',
                id: submissionId,
                target_department: newDept,
                reason: note,
                author_name: author,
                notify_new_area: notify,
                nonce: '<?php echo wp_create_nonce("cm_contacto_nonce"); ?>'
            },
            success: function(res) {
                if (res.success) {
                    alert('✓ Caso derivado exitosamente a ' + newDept);
                    location.reload();
                } else {
                    $btn.prop('disabled', false).text('🔄 Ejecutar Derivación');
                    alert('Error: ' + (res.data.message || 'No se pudo derivar el caso.'));
                }
            },
            error: function() {
                $btn.prop('disabled', false).text('🔄 Ejecutar Derivación');
                alert('Error de conexión con el servidor.');
            }
        });
    };
    </script>
    <?php
}

/**
 * AJAX: Suspende o reactiva un usuario.
 */
function cm_ajax_admin_toggle_user_suspension() {
    check_ajax_referer('cm_contacto_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Permiso denegado.', 'contacto-multidestino')));
    }

    $user_id = isset($_POST['user_id']) ? absint($_POST['user_id']) : 0;
    if (!$user_id || $user_id === get_current_user_id()) {
        wp_send_json_error(array('message' => __('Acción no permitida sobre este usuario.', 'contacto-multidestino')));
    }

    $new_status = cm_toggle_user_suspension($user_id);
    wp_send_json_success(array('status' => $new_status));
}
add_action('wp_ajax_cm_admin_toggle_user_suspension', 'cm_ajax_admin_toggle_user_suspension');



/**
 * AJAX: Deriva un caso a otra área.
 */
function cm_ajax_admin_reassign_case() {
    $nonce = isset($_POST['nonce']) ? $_POST['nonce'] : '';
    if (!wp_verify_nonce($nonce, 'cm_contacto_nonce') && !check_ajax_referer('cm_contacto_nonce', 'nonce', false)) {
        if (!is_user_logged_in() || (!current_user_can('edit_posts') && !current_user_can('manage_options'))) {
            wp_send_json_error(array('message' => __('Permiso denegado o sesión expirada.', 'contacto-multidestino')));
        }
    }
    if (!current_user_can('edit_posts') && !current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Permiso denegado.', 'contacto-multidestino')));
    }

    // Validar permiso de derivación del usuario actual
    if (!current_user_can('manage_options')) {
        $user_allow_reassign = get_user_meta(get_current_user_id(), 'cm_allow_reassign', true);
        if ($user_allow_reassign === '0') {
            wp_send_json_error(array('message' => __('Permiso denegado: Tu perfil no tiene autorización para derivar casos a otros departamentos. Solo puedes atender tu área asignada.', 'contacto-multidestino')));
        }
    }

    $id              = isset($_POST['id']) ? absint($_POST['id']) : 0;
    $target_dept     = isset($_POST['target_department']) ? sanitize_text_field($_POST['target_department']) : '';
    $reason          = isset($_POST['reason']) ? sanitize_textarea_field($_POST['reason']) : '';
    $author_name     = isset($_POST['author_name']) ? sanitize_text_field($_POST['author_name']) : 'Área Responsable';
    $notify_new_area = !empty($_POST['notify_new_area']);
    $notify_user     = !empty($_POST['notify_user']);

    if (!$id || !$target_dept) {
        wp_send_json_error(array('message' => __('Datos incompletos para derivar el caso.', 'contacto-multidestino')));
    }

    $case = cm_get_submission_by_id($id);
    if (!$case) {
        wp_send_json_error(array('message' => __('No se encontró el caso.', 'contacto-multidestino')));
    }

    if (!empty($case->is_deleted)) {
        wp_send_json_error(array('message' => __('Este caso está en la papelera y no puede derivarse. Debes recuperarlo primero.', 'contacto-multidestino')));
    }

    $result = cm_reassign_case_department($id, $target_dept, $reason, $author_name, $notify_new_area, $notify_user);

    if ($result) {
        if (function_exists('cm_log_audit_action')) {
            cm_log_audit_action($case->id, $case->ticket_code, 'reassigned', "Derivó el caso al área: $target_dept. Razón: $reason");
        }
        wp_send_json_success(array(
            'message'        => sprintf(__('Caso derivado exitosamente al área de "%s".', 'contacto-multidestino'), $target_dept),
            'new_department' => $target_dept,
        ));
    } else {
        wp_send_json_error(array('message' => __('No se pudo derivar el caso.', 'contacto-multidestino')));
    }
}
add_action('wp_ajax_cm_admin_reassign_case', 'cm_ajax_admin_reassign_case');

/**
 * AJAX: Guarda una actualización de estado / solicitud oficial y envía correo si aplica.
 */
function cm_ajax_admin_update_case() {
    $nonce = isset($_POST['nonce']) ? $_POST['nonce'] : '';
    if (!wp_verify_nonce($nonce, 'cm_contacto_nonce') && !check_ajax_referer('cm_contacto_nonce', 'nonce', false)) {
        if (!is_user_logged_in() || (!current_user_can('edit_posts') && !current_user_can('manage_options'))) {
            wp_send_json_error(array('message' => __('Permiso denegado o sesión expirada.', 'contacto-multidestino')));
        }
    }
    if (!current_user_can('edit_posts') && !current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Permiso denegado.', 'contacto-multidestino')));
    }

    $id          = isset($_POST['id']) ? absint($_POST['id']) : 0;
    $status      = isset($_POST['status']) ? sanitize_key($_POST['status']) : '';
    $note        = isset($_POST['note']) ? sanitize_textarea_field($_POST['note']) : '';
    $author_name = isset($_POST['author_name']) ? sanitize_text_field($_POST['author_name']) : 'Administración';
    $notify_user = !empty($_POST['notify_user']) ? 1 : 0;
    $req_doc      = !empty($_POST['req_doc']);
    $doc_title    = isset($_POST['doc_title']) ? sanitize_text_field($_POST['doc_title']) : '';
    $req_presence = !empty($_POST['req_presence']);

    $case = cm_get_submission_by_id($id);
    if (!$case) {
        wp_send_json_error(array('message' => __('No se encontró el caso.', 'contacto-multidestino')));
    }

    if (!empty($case->is_deleted)) {
        wp_send_json_error(array('message' => __('Este caso está en la papelera y no puede modificarse. Debes recuperarlo primero.', 'contacto-multidestino')));
    }

    $statuses = cm_get_case_statuses();
    $status_info = isset($statuses[$status]) ? $statuses[$status] : null;

    // Si el encargado solicitó subir documentos
    $action_type = 'admin_update';
    if ($req_doc) {
        $action_type = 'doc_request';
        if ($doc_title) {
            $note = '[REQ_DOC: ' . $doc_title . "]\n" . $note;
        }
    }

    // Procesar archivo adjunto si fue subido por el encargado / administración
    if (!empty($_FILES['admin_attachment']['name'])) {
        $file = $_FILES['admin_attachment'];
        $max_size = 4 * 1024 * 1024;
        $allowed_extensions = array('jpg', 'jpeg', 'png', 'svg', 'bmp', 'pdf');
        $file_info = pathinfo($file['name']);
        $ext = isset($file_info['extension']) ? strtolower($file_info['extension']) : '';

        if ($file['size'] <= $max_size && in_array($ext, $allowed_extensions, true)) {
            if (!function_exists('wp_handle_upload')) {
                require_once(ABSPATH . 'wp-admin/includes/file.php');
            }
            $upload_overrides = array('test_form' => false);
            $movefile = wp_handle_upload($file, $upload_overrides);
            if ($movefile && !isset($movefile['error'])) {
                $file_url = $movefile['url'];
                $orig_name = sanitize_file_name($file['name']);
                $is_image = in_array($ext, array('jpg', 'jpeg', 'png', 'svg', 'bmp'), true);

                $attach_html = sprintf(
                    '<div class="cm-attachment-pill" style="margin-top:6px; display:inline-flex; align-items:center; gap:6px; background:#eff6ff; border:1px solid #bfdbfe; padding:4px 10px; border-radius:8px; font-size:12px;">' .
                        '<span>%s</span>' .
                        '<a href="%s" target="_blank" style="color:#0284c7; font-weight:700; text-decoration:none;">📄 %s</a>' .
                    '</div>',
                    $is_image ? '🖼️' : '📑',
                    esc_url($file_url),
                    esc_html($orig_name)
                );

                $note = ($note ? $note . "\n" : '') . $attach_html;
            }
        }
    }

    if (!$note && $status) {
        $note = sprintf(__('Actualización de estado a: %s', 'contacto-multidestino'), $status_info ? $status_info['label'] : $status);
    }

    // Registrar actualización en base de datos
    $update_id = cm_add_case_update(array(
        'submission_id' => $case->id,
        'ticket_code'   => $case->ticket_code,
        'author_name'   => $author_name,
        'status'        => $status ? $status : $case->status,
        'action_type'   => $action_type,
        'note'          => $note,
        'is_public'     => 1,
        'notified_user' => $notify_user,
    ));

    if (!$update_id) {
        wp_send_json_error(array('message' => __('Error al registrar la actualización en la base de datos.', 'contacto-multidestino')));
    }

    // Enviar notificación por correo si fue seleccionada
    if ($notify_user && !empty($case->sender_email) && is_email($case->sender_email)) {
        $site_name = get_bloginfo('name');
        $site_url  = home_url();
        $status_label = $status_info ? $status_info['label'] : ucfirst($case->status);

        $email_subject = sprintf('[%s] Actualización de su Caso — %s (%s)', $case->ticket_code, $site_name, $status_label);

        // Construir cuerpo del correo de actualización
        $email_body = cm_build_case_update_email_html(array(
            'ticket_code'         => $case->ticket_code,
            'site_name'           => $site_name,
            'site_url'            => $site_url,
            'sender_name'         => $case->sender_name,
            'nombre_departamento' => $case->department,
            'status_label'        => $status_label,
            'status_color'        => $status_info ? $status_info['color'] : '#2563eb',
            'status_icon'         => $status_info ? $status_info['icon'] : '📌',
            'note'                => $note,
            'author_name'         => $author_name,
        ));

        $from_email = get_option('cm_smtp_from', '');
        if (!is_email($from_email)) $from_email = get_option('cm_smtp_user', '');
        if (!is_email($from_email)) $from_email = get_option('admin_email');

        $headers   = array();
        $headers[] = 'Content-Type: text/html; charset=UTF-8';
        $headers[] = 'From: ' . esc_html($site_name) . ' <' . $from_email . '>';

        wp_mail($case->sender_email, $email_subject, $email_body, $headers);
    }
    
    if (function_exists('cm_log_audit_action')) {
        $audit_action = 'update';
        $audit_desc   = 'Actualizó el caso.';
        if ($status && $status !== $case->status) {
            $audit_action = 'status_changed';
            $audit_desc   = "Cambió el estado a: $status. ";
        }
        if (!empty($note)) {
            if ($audit_action === 'update') {
                $audit_action = 'note_added';
                $audit_desc = 'Agregó una nota/archivo al caso.';
            } else {
                $audit_desc .= 'Además agregó una nota.';
            }
        }
        cm_log_audit_action($case->id, $case->ticket_code, $audit_action, $audit_desc);
    }

    wp_send_json_success(array(
        'message'      => __('Caso actualizado exitosamente.', 'contacto-multidestino'),
        'status'       => $status,
        'status_label' => $status_info ? $status_info['label'] : $status,
        'status_color' => $status_info ? $status_info['color'] : '#475569',
        'status_bg'    => $status_info ? $status_info['bg_color'] : '#f1f5f9',
        'status_icon'  => $status_info ? $status_info['icon'] : '📌',
    ));
}
add_action('wp_ajax_cm_admin_update_case', 'cm_ajax_admin_update_case');

/**
 * AJAX: Elimina un caso del sistema.
 */
function cm_ajax_admin_delete_case() {
    $nonce = isset($_POST['nonce']) ? $_POST['nonce'] : '';
    if (!wp_verify_nonce($nonce, 'cm_contacto_nonce') && !check_ajax_referer('cm_contacto_nonce', 'nonce', false)) {
        if (!is_user_logged_in() || (!current_user_can('edit_posts') && !current_user_can('manage_options'))) {
            wp_send_json_error(array('message' => __('Permiso denegado o sesión expirada.', 'contacto-multidestino')));
        }
    }
    if (!current_user_can('edit_posts') && !current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Permiso denegado.', 'contacto-multidestino')));
    }

    $id = isset($_POST['id']) ? absint($_POST['id']) : 0;
    if (!$id) {
        wp_send_json_error(array('message' => __('ID no válido.', 'contacto-multidestino')));
    }

    $current_user = wp_get_current_user();
    $author_name = ($current_user && $current_user->display_name) ? $current_user->display_name : 'Administrador';

    $deleted = cm_delete_submission($id, $author_name);
    if ($deleted) {
        if (function_exists('cm_log_audit_action')) {
            // We need the ticket_code, let's fetch it
            global $wpdb;
            $ticket_code = $wpdb->get_var($wpdb->prepare("SELECT ticket_code FROM {$wpdb->prefix}cm_form_submissions WHERE id = %d", $id));
            if ($ticket_code) cm_log_audit_action($id, $ticket_code, 'deleted', 'Envió el caso a la papelera.');
        }
        wp_send_json_success(array('message' => __('Caso enviado a la papelera exitosamente.', 'contacto-multidestino')));
    } else {
        wp_send_json_error(array('message' => __('No se pudo mover el caso a la papelera.', 'contacto-multidestino')));
    }
}
add_action('wp_ajax_cm_admin_delete_case', 'cm_ajax_admin_delete_case');

/**
 * AJAX: Restaura un caso desde la papelera (Exclusivo Super Admin).
 */
function cm_ajax_admin_restore_case() {
    $nonce = isset($_POST['nonce']) ? $_POST['nonce'] : '';
    if (!wp_verify_nonce($nonce, 'cm_contacto_nonce') && !check_ajax_referer('cm_contacto_nonce', 'nonce', false)) {
        if (!is_user_logged_in() || !current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permiso denegado o sesión expirada.', 'contacto-multidestino')));
        }
    }
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Permiso denegado. Solo el Administrador puede recuperar casos de la papelera.', 'contacto-multidestino')));
    }

    $id = isset($_POST['id']) ? absint($_POST['id']) : 0;
    if (!$id) {
        wp_send_json_error(array('message' => __('ID no válido.', 'contacto-multidestino')));
    }

    $current_user = wp_get_current_user();
    $author_name = ($current_user && $current_user->display_name) ? $current_user->display_name : 'Super Admin';

    $restored = cm_restore_submission($id, $author_name);
    if ($restored) {
        if (function_exists('cm_log_audit_action')) {
            global $wpdb;
            $ticket_code = $wpdb->get_var($wpdb->prepare("SELECT ticket_code FROM {$wpdb->prefix}cm_form_submissions WHERE id = %d", $id));
            if ($ticket_code) cm_log_audit_action($id, $ticket_code, 'restored', 'Restauró el caso desde la papelera.');
        }
        wp_send_json_success(array('message' => __('Caso recuperado y restaurado a la bandeja activa exitosamente.', 'contacto-multidestino')));
    } else {
        wp_send_json_error(array('message' => __('No se pudo recuperar el caso.', 'contacto-multidestino')));
    }
}
add_action('wp_ajax_cm_admin_restore_case', 'cm_ajax_admin_restore_case');

/**
 * Construye el correo HTML para notificaciones de actualización de casos al usuario.
 */
function cm_build_case_update_email_html($args) {
    $ticket_code         = esc_html($args['ticket_code'] ?? 'CL000000');
    $site_name           = esc_html($args['site_name'] ?? get_bloginfo('name'));
    $site_url            = esc_url($args['site_url'] ?? home_url());
    $sender_name         = esc_html($args['sender_name'] ?? 'Usuario');
    $nombre_departamento = esc_html($args['nombre_departamento'] ?? 'General');
    $status_label        = esc_html($args['status_label'] ?? 'Actualizado');
    $status_color        = esc_attr($args['status_color'] ?? '#2563eb');
    $status_icon         = esc_html($args['status_icon'] ?? '📌');
    $note                = nl2br(esc_html($args['note'] ?? ''));
    $author_name         = esc_html($args['author_name'] ?? 'Área Responsable');
    $date_time           = current_time('d/m/Y H:i') . ' hrs';

    ob_start();
    ?>
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <title><?php echo esc_html($site_name); ?> — Actualización de Caso</title>
    </head>
    <body style="margin:0;padding:0;background-color:#f1f5f9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;color:#1e293b;">
        <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%" style="background-color:#f1f5f9;padding:30px 15px;">
            <tr>
                <td align="center">
                    <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:640px;background-color:#ffffff;border-radius:18px;overflow:hidden;box-shadow:0 10px 30px rgba(15,23,42,0.08);border:1px solid #e2e8f0;">
                        
                        <!-- Encabezado -->
                        <tr>
                            <td style="background:linear-gradient(135deg,#0f172a 0%,#1e1b4b 60%,#312e81 100%);padding:30px 36px;">
                                <div style="display:inline-block;background:rgba(255,255,255,0.15);padding:4px 12px;border-radius:20px;font-size:11px;font-weight:700;color:#c7d2fe;letter-spacing:0.08em;text-transform:uppercase;margin-bottom:10px;">
                                    🔔 ACTUALIZACIÓN OFICIAL DE CASO
                                </div>
                                <h1 style="margin:0;font-size:22px;font-weight:800;color:#ffffff;line-height:1.3;">
                                    <?php echo $site_name; ?>
                                </h1>
                                <p style="margin:6px 0 0 0;font-size:13.5px;color:#e2e8f0;">
                                    El área de <strong><?php echo $nombre_departamento; ?></strong> ha emitido una actualización sobre tu requerimiento.
                                </p>
                            </td>
                        </tr>

                        <!-- Tarjeta del Código y Estado -->
                        <tr>
                            <td style="padding:26px 36px 10px 36px;">
                                <div style="background:#f8faff;border:2px dashed #818cf8;border-radius:14px;padding:18px 20px;text-align:center;">
                                    <div style="font-size:11px;font-weight:700;color:#4338ca;text-transform:uppercase;letter-spacing:0.1em;">
                                        CÓDIGO DE SEGUIMIENTO:
                                    </div>
                                    <div style="font-family:'Courier New',Courier,monospace;font-size:26px;font-weight:900;color:#1e1b4b;letter-spacing:3px;margin:4px 0;">
                                        <?php echo $ticket_code; ?>
                                    </div>
                                    <div style="margin-top:8px;">
                                        <span style="display:inline-block;background-color:<?php echo $status_color; ?>;color:#ffffff;padding:5px 14px;border-radius:20px;font-size:12px;font-weight:700;">
                                            <?php echo $status_icon . ' Estado: ' . $status_label; ?>
                                        </span>
                                    </div>
                                </div>
                            </td>
                        </tr>

                        <!-- Saludo y Mensaje/Solicitud Oficial -->
                        <tr>
                            <td style="padding:15px 36px;">
                                <p style="margin:0 0 14px 0;font-size:14.5px;color:#334155;">
                                    Estimado(a) <strong><?php echo $sender_name; ?></strong>, te informamos las novedades respecto a tu trámite:
                                </p>

                                <!-- Tarjeta del Mensaje Oficial -->
                                <div style="background:#f8fafc;border-left:4px solid <?php echo $status_color; ?>;padding:16px 18px;border-radius:0 10px 10px 0;margin-bottom:16px;">
                                    <div style="font-size:11.5px;font-weight:700;color:#64748b;text-transform:uppercase;margin-bottom:6px;">
                                        📢 Mensaje / Requerimiento del Área (Firmado por <?php echo $author_name; ?> - <?php echo $date_time; ?>):
                                    </div>
                                    <div style="font-size:14px;line-height:1.6;color:#0f172a;">
                                        <?php echo $note; ?>
                                    </div>
                                </div>

                                <?php 
                                $tracking_url = function_exists('cm_get_case_tracker_url') ? esc_url(cm_get_case_tracker_url($ticket_code)) : $site_url;
                                ?>
                                <div style="text-align:center;margin:20px 0 10px 0;">
                                    <a href="<?php echo $tracking_url; ?>" target="_blank" style="display:inline-block;background:#4f46e5;color:#ffffff;text-decoration:none;padding:11px 24px;border-radius:8px;font-size:13.5px;font-weight:700;letter-spacing:0.02em;">
                                        🔍 Ver Estado Completo del Caso en Línea &rarr;
                                    </a>
                                </div>
                            </td>
                        </tr>

                        <!-- Pie del Correo -->
                        <tr>
                            <td style="background-color:#f8fafc;padding:20px 36px;border-top:1px solid #e2e8f0;text-align:center;">
                                <p style="margin:0;font-size:12px;color:#64748b;line-height:1.5;">
                                    Puedes consultar el historial completo ingresando tu código <strong><?php echo $ticket_code; ?></strong> en el portal de seguimiento de nuestro sitio web.
                                </p>
                                <div style="margin-top:10px;font-size:11px;color:#94a3b8;">
                                    Desarrollado con Ingecodex Form • <a href="<?php echo $site_url; ?>" style="color:#4f46e5;text-decoration:none;"><?php echo $site_name; ?></a>
                                </div>
                            </td>
                        </tr>

                    </table>
                </td>
            </tr>
        </table>
    </body>
    </html>
    <?php
    return ob_get_clean();
}
