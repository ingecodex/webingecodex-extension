# Ingecodex Form — Formulario Multidestino & Centro de Casos

[![WordPress Plugin](https://img.shields.io/badge/WordPress-5.8%2B%20Compatible-blue.svg)](https://wordpress.org)
[![PHP Version](https://img.shields.io/badge/PHP-7.4%20--%208.3-777bb4.svg)](https://php.net)
[![License](https://img.shields.io/badge/License-GPLv2-green.svg)](https://www.gnu.org/licenses/gpl-2.0.html)
[![Security](https://img.shields.io/badge/2FA-TOTP%20RFC%206238-brightgreen.svg)](https://ingecodex.com)

**Ingecodex Form** es una suite profesional para WordPress y Elementor que transforma un formulario de contacto tradicional en un **Centro Integral de Casos, Requerimientos y Seguimiento Institucional**.

Diseñado con estándares de interfaz **Apple Pro (macOS inspired)**, incorpora constructor visual en tiempo real, seguridad avanzada con 2FA TOTP, bandeja de expedientes con derivación por departamentos, papelera con auditoría inmutable, y portal público de consulta de estado por código de ticket.

---

## 📚 Historial Completo de Versiones (Changelog)

### 🚀 Versión 2.5.2 — *Gestión Jerárquica Multi-Área, Auto-Respuesta Departamental, Plantillas de Notas Rápidas y Pestañas de Casos*
- **🛡️ Asignación Jerárquica y Multi-Área para Usuarios:**
  - Nuevos roles de acceso: 👑 **Director / Administrador** (visión global), 🛡️ **Subdirector / Moderador** (gestión de 2 o más áreas asignadas), 🏢 **Encargado de Área** (atención exclusiva) y ⚡ **Superadmin WP**.
  - Modal de edición rápida `🏢 Áreas / Perfil` para reasignar múltiples departamentos por casillas con 1 clic ("Marcar Todas" / "Desmarcar").
  - Filtrado adaptativo en la bandeja de entrada para moderadores y supervisores de múltiples áreas.
- **🤖 Respuestas Automáticas por Área (ej. Currículum / Postulaciones):**
  - Configuración independiente por departamento de auto-respuesta.
  - Temporizador configurable: **⚡ Inmediata** o programada a los **5, 10, 15, 30 o 60 minutos**.
  - Asignación de estado automático (🟢 *En Proceso / Tomado*, ⚪ *Resuelto / Finalizado*, 🟡 *En Revisión*) y mensaje oficial de respuesta predeterminado.
- **⚡ Plantillas Rápidas de Notas Predeterminadas en el Inspector:**
  - 6 Notas oficiales predefinidas para trazabilidad, derivación, solicitud de presencia, documentos y cierre.
  - Creador dinámico `➕ Nueva Nota` para redactar, guardar y reutilizar notas personalizadas en 1 clic con opción de eliminar (`✕`).
- **🏢 Selector y Carga Rápida de Áreas Registradas en el Constructor Visual:**
  - En el subpanel *Opciones y Correos Destino* del Form Studio, ahora es posible elegir cualquier área ya registrada en el sistema desde una lista desplegable y añadirla con 1 clic junto con todos sus correos pre-llenados sin tener que volver a escribirlos.
  - Botón *📥 Cargar Todas las Áreas* para importar instantáneamente todos los departamentos creados.
- **✉️ Conmutador de Envío de Confirmación por Correo:**
  - Opción en ajustes para activar o desactivar el envío de comprobante por correo al solicitante; al desactivarlo, se muestra prominentemente el código en pantalla para que el usuario lo anote manualmente sin forzar envío de correo.
- **🎨 Sistema Visual de Estados con Códigos de Color:**
  - Acentos de fila y badges cromáticos: 🔴 **Rojo** para nuevo/recibido, 🟡 **Amarillo/Ámbar** para en revisión, 🟢 **Verde** para tomado/en proceso, 🟣 **Púrpura** para requerimiento al usuario, y ⚪ **Gris** para completado/finalizado.
- **📂 Pestañas de Navegación de Casos en Bandeja:**
  - Vistas rápidas: `📋 Todos los Casos`, `🔥 Activos / En Trámite` y `✅ Completados / Finalizados`.

---

### 🚀 Versión 2.5.1 — *Pro Studio Customizer, Botón Transparente/Glass, Dashboard Ejecutivo y Logo Animado*
- **🎨 Editor Visual Avanzado del Buscador (`cm-tracker-customizer`):**
  - Selector de estilo de botón de búsqueda: **Sólido**, **Transparente / Outline**, **Cristal Glassmorphism** y **Degradado Pro**.
  - Control de redondez de botón configurable (4px, 8px, 12px, 24px Pill).
  - Paletas rápidas de 1 clic (Azul Corporativo, Esmeralda, Índigo, Púrpura, Ámbar, Grafito y Transparente).
  - Selector de vistas multidispositivo en vivo (🖥️ Escritorio, 📱 Tablet, 📲 Móvil).
  - Conmutador directo de modos en Form Studio (📝 Formularios ↔️ 🔍 Buscador por Código).
- **📊 Rediseño del Dashboard Ejecutivo:**
  - Sustitución de columnas verticales por una **Tabla Ejecutiva Compacta de Casos Activos** con estado en tiempo real y acceso rápido.
- **✨ Iconografía Oficial y Donación Animada:**
  - Integración del archivo oficial **`logo.gif`** animado de la aplicación en cabeceras principales y botones de Donación Mercado Pago.
- **🧹 Ocultación Total del Footer de WordPress:**
  - Eliminación automática de `#wpfooter` en todas las pantallas del plugin para una experiencia fluida e independiente.

---

### 🛡️ Versión 2.5.0 — *Seguridad 2FA TOTP, Personalizador del Portal y Modo Firma Digital*
- **🌐 Editor Visual del Portal de Consulta (`Personalizar Portal`):**
  - Módulo administrativo exclusivo para personalizar en tiempo real el buscador público por código (`[seguimiento_caso]`).
  - Selector de colores de alto contraste para el botón de búsqueda (fondo y texto personalizables con protección anti-ocultamiento de temas).
  - Configuración dinámica de títulos, subtítulos, insignias (badges), placeholders y mensajes de ayuda.
  - Modos de visualización: **📜 Firma Automática / Verificación Oficial (Certificado Digital)**, **🍎 Apple Pro Moderno**, **🪟 Cristal Glassmorphism**, y **🌑 Modo Oscuro**.
  - Sello de Verificación Digital Oficial con código Hash SHA1 de autenticidad institucional.
  - Vista previa interactiva en vivo (Live Preview) con simulador de expedientes.
- **Motor Criptográfico TOTP RFC 6238:** Generación y validación nativa de códigos dinámicos de 6 dígitos en PHP puro (cero dependencias externas). Compatible con **Google Authenticator, Microsoft Authenticator y Apple Passwords**.
- **Hook de Login en WordPress:** Exigencia obligatoria del código 2FA en `wp-login.php` para cuentas protegidas.
- **Sugerencia Automática de 2FA:** Banner de bienvenida y recomendación de seguridad para nuevos usuarios y encargados.
- **Panel de Gestión y Asignación Directa para Super Admin:**
  - Nueva columna `🛡️ Seguridad 2FA` en la tabla de usuarios con fecha y hora exacta de activación.
  - Botón **`🔓 Quitar 2FA`** para desbloqueo instantáneo en caso de extravío de teléfono.
  - Botón **`📲 Asignar / Generar Nueva Clave y QR`** para que el Administrador configure y muestre el QR directamente al Director o usuario.
  - Botón **`🔄 Restablecer 2FA`** para forzar una nueva vinculación.
- **Tabla Adaptable:** Diseño responsive fluido con scroll horizontal y alineación en una sola fila de todos los controles (`🔑 Clave`, `✏️ Datos`, `🛡️ 2FA`, `⛔ Suspender`).

---

### 🗑️ Versión 2.4.9 — *Papelera, Auditoría Inmutable y Vista en Página Completa*
- **Papelera de Casos (`tab=trash`):** Protección contra borrado accidental; los casos eliminados se trasladan a la papelera.
- **Filtro en Portal Público:** Los casos en papelera quedan ocultos del portal de seguimiento web (`is_deleted = 0`).
- **Restauración en 1 Clic (`♻️ Recuperar`):** Función exclusiva para el Super Administrador.
- **Auditoría Inmutable:** Registro cronológico detallado de qué usuario envió el caso a la papelera y quién lo recuperó con timestamp.
- **Modo Solo Lectura en Papelera:** Bloqueo de cambios de estado y derivaciones en casos eliminados.
- **Vista en Página Completa (`&view_case=ID`):** Visualización de expedientes en página web dedicada además del visor modal flotante.
- **Impresión Oficial Formato Carta:** Estilos CSS de impresión optimizados para exportar fichas oficiales limpias en PDF/Carta.
- **Limpieza de Marcadores Internos:** Ocultamiento automático de etiquetas técnicas como `[REQ_DOC: ...]` en las notas públicas y del panel.

---

### 📥 Versión 2.4.8 — *Bandeja de Casos, Estados y Portal Público de Seguimiento*
- **Bandeja de Entradas Administrativa (`tab=inbox`):** Panel interactivo para visualizar y gestionar todos los envíos.
- **Portal Público de Seguimiento (`[seguimiento_caso]`):** Página de consulta pública donde el solicitante ingresa su código (ej: `CL849201`) para ver el avance de su solicitud en tiempo real.
- **Flujo de Atención por Estados:** *Recibido, En Revisión, En Proceso, Requiere Presencia / Documentación, Resuelto*.
- **Derivación entre Áreas:** Reasignación de casos entre departamentos con motivo justificado.
- **Notificaciones Automáticas por Email:** Envío de correo al solicitante ante cada cambio de estado o solicitud de antecedentes.
- **Base de Datos Relacional:** Creación de tablas MySQL `cm_submissions` y `cm_case_events` para trazabilidad completa.

---

### 🔔 Versión 2.4.7 — *Estabilidad y Compatibilidad Multidestino*
- Optimización en el enrutamiento de correos a múltiples destinatarios separados por coma.
- Ajustes de compatibilidad en widgets dinámicos de Elementor.

---

### 🚀 Versión 2.4.6 — *Envío AJAX Asíncrono y Subida de Archivos*
- Envío inteligente de formularios vía AJAX con spinner animado y validación de campos sin recargar la página.
- Soporte para subida de adjuntos con Dropzone interactivo (drag & drop), validación estricta de extensiones y límite de peso.

---

### 🔊 Versión 2.4.5 — *Alertas Sonoras Profesionales (Web Audio API)*
- Notificaciones acústicas en tiempo real ante la llegada de nuevos casos mediante tonos armónicos sintetizados con Web Audio API (cero archivos de audio externos).
- Alertas visuales flotantes (Toasts estilo Apple).

---

### 👥 Versión 2.4.4 — *Gestor de Roles y Perfiles de Acceso*
- Separación de perfiles: Encargados de Área (acceso exclusivo a sus solicitudes) vs. Directores / Super Administradores (acceso global a todas las áreas y dashboard analítico).
- Módulo de restablecimiento inmediato de contraseñas de usuarios.

---

### 🎨 Versión 2.4.2 — *Modos de Diseño del Contenedor*
- Estilos visuales para el formulario: Vidrio Glassmorphism con desenfoque de fondo, Plano (Flat), Sombra Moderna y 100% Transparente (para integrarse en fondos de Elementor).
- Personalización de bordes y fondos por campo.

---

### ⚙️ Versión 2.4.1 — *Diagnóstico y Avisos SMTP*
- Panel de alerta exclusivo para administradores con acceso directo a la configuración de correo SMTP.
- Verificación de estado de envío de correos salientes.

---

### 🛠️ Versión 2.4.0 — *Constructor Visual Form Studio y Enrutamiento*
- Lanzamiento del Constructor Visual interactivo **Form Studio** con función de arrastrar y soltar (drag & drop) y previsualización responsive en vivo.
- Enrutamiento dinámico de correos por departamento.
- Modal emergente de Términos y Condiciones con aceptación automática.
- Widget oficial para Elementor.

---

## 🛠️ Shortcodes Disponibles

| Shortcode | Descripción |
| :--- | :--- |
| `[Formulario_Ingecodex]` | Inserta el formulario de contacto principal (Recomendado) |
| `[seguimiento_caso]` | Inserta el portal público de consulta de estado por código de ticket |
| `[formulario_ingecodex]` | Alias alternativo del formulario |
| `[consultar_caso]` | Alias alternativo del portal de seguimiento |

---

## 📦 Instalación

1. Descarga el paquete ZIP de la versión deseada (`ingecodex-form-2.5.0.zip`).
2. En tu WordPress, ve a **Plugins > Añadir nuevo plugin > Subir plugin**.
3. Selecciona el archivo ZIP, pulsa **Instalar ahora** y luego **Activar plugin**.
4. Accede a **Ingecodex Form** en la barra lateral para gestionar la bandeja de casos o configurar formularios.

---

## 📄 Licencia

Este proyecto está bajo la licencia **GPLv2 o posterior**.

Desarrollado por **[Ingecodex](https://ingecodex.com)**.
