<?php
if (!defined('ABSPATH')) {
    exit;
}

function cm_get_default_schema() {
    return array(
        'settings' => array(
            'show_header'            => true,
            'title'                  => 'Formulario de Contacto',
            'subtitle'               => 'Selecciona el departamento al que deseas dirigir tu mensaje.',
            'primary_color'          => '#0071e3',
            'button_text_color'      => '#ffffff',
            'bg_color'               => '#ffffff',
            'label_color'            => '#0f172a',
            'input_bg_color'         => '#f8fafc',
            'input_border_color'     => '#e2e8f0',
            'border_radius'          => '12',
            'shadow'                 => 'md',
            'card_preset'            => 'modern',
            'border_width'           => '1',
            'container_border_color' => '#e2e8f0',
            'button_text'            => 'Enviar Mensaje',
            'button_style'           => 'gradient',
            'success_msg'            => '¡Gracias! Tu mensaje ha sido enviado exitosamente al departamento correspondiente.',
            'destination_emails'     => get_option('cm_default_email', get_option('admin_email')),
            'default_area_name'      => 'General / Consultas',
            'enable_autoresponder'   => true,
            'custom_subject'         => '',
            'show_credit'            => true,
        ),
        'fields' => array(
            array(
                'id'          => 'field_nombre',
                'type'        => 'text',
                'label'       => 'Nombre Completo',
                'placeholder' => 'Ej. Juan Pérez',
                'required'    => true,
                'width'       => '50',
                'help'        => '',
            ),
            array(
                'id'          => 'field_email',
                'type'        => 'email',
                'label'       => 'Correo Electrónico',
                'placeholder' => 'ejemplo@correo.com',
                'required'    => true,
                'width'       => '50',
                'help'        => '',
            ),
            array(
                'id'          => 'field_telefono',
                'type'        => 'phone',
                'label'       => 'Teléfono de Contacto',
                'placeholder' => '+56 9 1234 5678',
                'required'    => false,
                'width'       => '50',
                'help'        => '',
            ),
            array(
                'id'          => 'field_departamento',
                'type'        => 'department',
                'label'       => 'Dirigido a / Departamento',
                'required'    => true,
                'width'       => '50',
                'help'        => '',
                'options'     => array(
                    array('nombre' => 'General / Consultas',  'email' => ''),
                    array('nombre' => 'Convivencia Escolar',  'email' => 'convivencia@colegio.cl'),
                    array('nombre' => 'Programa PIE',         'email' => 'pie@colegio.cl'),
                    array('nombre' => 'Dirección y Rectoría', 'email' => 'direccion@colegio.cl'),
                ),
            ),
            array(
                'id'          => 'field_mensaje',
                'type'        => 'textarea',
                'label'       => 'Mensaje o Comentario',
                'placeholder' => 'Escribe aquí tu consulta...',
                'required'    => true,
                'width'       => '100',
                'help'        => '',
            ),
            array(
                'id'          => 'field_adjunto',
                'type'        => 'file',
                'label'       => 'Adjuntar Archivo (opcional)',
                'placeholder' => '',
                'required'    => false,
                'width'       => '100',
                'help'        => 'PDF, DOCX, XLSX, JPG, PNG, ZIP. Máx 5 MB.',
            ),
            array(
                'id'              => 'field_terminos',
                'type'            => 'terms',
                'label'           => 'He leído y acepto los',
                'required'        => false,
                'width'           => '100',
                'help'            => '',
                'has_terms'       => true,
                'terms_title'     => 'Políticas y Términos de Servicio',
                'terms_content'   => "1. PROTECCIÓN DE DATOS\nLos datos suministrados a través de este formulario serán tratados de forma estrictamente confidencial.\n\n2. FINALIDAD DEL CONTACTO\nLa información proporcionada se utilizará exclusivamente para responder a su requerimiento.\n\n3. SEGURIDAD\nNo compartimos su información con terceros.",
            ),
        ),
    );
}

function cm_get_templates_catalog() {
    return array(
        'colegio' => array(
            'id'          => 'colegio',
            'title'       => 'Contacto Colegios y Multidestino',
            'category'    => 'Educación',
            'icon'        => '🏫',
            'badge'       => 'Más Popular',
            'desc'        => 'Enrutamiento a Dirección, Convivencia Escolar, Inspectoría, PIE, adjunto y modal de términos.',
            'fields_info' => '6 campos • Multidestino • Modal Términos',
        ),
        'cotizacion' => array(
            'id'          => 'cotizacion',
            'title'       => 'Cotización y Servicios B2B',
            'category'    => 'Negocios',
            'icon'        => '💼',
            'badge'       => 'Recomendado',
            'desc'        => 'Empresa, selector de tipo de servicio, rango de presupuesto, detalles del proyecto y adjunto de requerimientos.',
            'fields_info' => '7 campos • Presupuesto • Adjuntos',
        ),
        'citas' => array(
            'id'          => 'citas',
            'title'       => 'Citas Médicas y de Salud',
            'category'    => 'Salud',
            'icon'        => '🩺',
            'badge'       => 'Salud',
            'desc'        => 'Agendamiento para clínicas y consultas médicas con selector de fecha, especialidad y horario preferido.',
            'fields_info' => '6 campos • Selector de Fecha • Especialidades',
        ),
        'inmobiliaria' => array(
            'id'          => 'inmobiliaria',
            'title'       => 'Inmobiliaria y Visita a Propiedades',
            'category'    => 'Negocios',
            'icon'        => '🏢',
            'badge'       => 'Inmobiliaria',
            'desc'        => 'Comprar/Arrendar, tipo de inmueble (depto/casa/terreno), código de propiedad y fecha de visita.',
            'fields_info' => '7 campos • Operación • Fecha de Visita',
        ),
        'soporte' => array(
            'id'          => 'soporte',
            'title'       => 'Tickets de Soporte Técnico TI',
            'category'    => 'Tecnología',
            'icon'        => '🛠️',
            'badge'       => 'Soporte',
            'desc'        => 'Recepción de incidencias con niveles de prioridad (Baja/Media/Alta), sistema afectado y captura de error.',
            'fields_info' => '6 campos • Prioridades • Captura de Pantalla',
        ),
        'encuesta' => array(
            'id'          => 'encuesta',
            'title'       => 'Encuesta de Satisfacción y NPS',
            'category'    => 'Servicios',
            'icon'        => '⭐',
            'badge'       => 'Interactiva',
            'desc'        => 'Evaluación de servicio con calificación por 5 estrellas (★★★★★), área evaluada y sugerencias.',
            'fields_info' => '5 campos • Calificación 5 Estrellas • Comentarios',
        ),
        'admision' => array(
            'id'          => 'admision',
            'title'       => 'Admisión y Postulación Académica',
            'category'    => 'Educación',
            'icon'        => '🎓',
            'badge'       => 'Admisión',
            'desc'        => 'Datos del alumno, curso a postular, datos del apoderado, adjunto de certificados y términos.',
            'fields_info' => '8 campos • Certificados • Apoderado',
        ),
        'restaurante' => array(
            'id'          => 'restaurante',
            'title'       => 'Reserva de Mesa y Gastronomía',
            'category'    => 'Servicios',
            'icon'        => '🍕',
            'badge'       => 'Gastronomía',
            'desc'        => 'Número de comensales, fecha y turno (almuerzo/cena), sector (salón/terraza) y requerimientos especiales.',
            'fields_info' => '7 campos • Personas • Turno • Sector',
        ),
        'automotriz' => array(
            'id'          => 'automotriz',
            'title'       => 'Test Drive y Venta Automotriz',
            'category'    => 'Negocios',
            'icon'        => '🚗',
            'badge'       => 'Ventas',
            'desc'        => 'Modelo de interés, sucursal, entrega en parte de pago, fecha estimada de compra y contacto comercial.',
            'fields_info' => '6 campos • Sucursales • Parte de Pago',
        ),
        'legal' => array(
            'id'          => 'legal',
            'title'       => 'Consulta Legal y Jurídica',
            'category'    => 'Servicios',
            'icon'        => '⚖️',
            'badge'       => 'Confidencial',
            'desc'        => 'Área jurídica (laboral, civil, penal, corporativo), resumen del caso, adjunto de antecedentes y secreto profesional.',
            'fields_info' => '6 campos • Especialidades • Documentos',
        ),
        'fitness' => array(
            'id'          => 'fitness',
            'title'       => 'Inscripción y Membresía Gym',
            'category'    => 'Salud',
            'icon'        => '🏋️',
            'badge'       => 'Fitness',
            'desc'        => 'Plan de membresía, sede de entrenamiento, declaración médica o lesiones previas y términos de uso.',
            'fields_info' => '6 campos • Planes • Sedes • Salud',
        ),
        'lead' => array(
            'id'          => 'lead',
            'title'       => 'Captura de Leads y Asesoría Express',
            'category'    => 'Marketing',
            'icon'        => '🎯',
            'badge'       => 'Alta Conversión',
            'desc'        => 'Diseño ligero y directo pensado para maximizar la tasa de conversión en páginas de aterrizaje y campañas.',
            'fields_info' => '4 campos • Rápido • Alta Conversión',
        ),
        'blank' => array(
            'id'          => 'blank',
            'title'       => 'Lienzo en Blanco',
            'category'    => 'Básico',
            'icon'        => '📄',
            'badge'       => 'Desde Cero',
            'desc'        => 'Comienza desde cero y construye tu formulario arrastrando y soltando campos según tus necesidades.',
            'fields_info' => '0 campos • Personalización total',
        ),
    );
}

function cm_get_template_schema($key) {
    $base_settings = array(
        'show_header'            => true,
        'primary_color'          => '#0071e3',
        'button_text_color'      => '#ffffff',
        'bg_color'               => '#ffffff',
        'label_color'            => '#0f172a',
        'input_bg_color'         => '#f8fafc',
        'input_border_color'     => '#e2e8f0',
        'border_radius'          => '12',
        'max_width'              => '840px',
        'shadow'                 => 'md',
        'card_preset'            => 'modern',
        'border_width'           => '1',
        'container_border_color' => '#e2e8f0',
        'button_text'            => 'Enviar Mensaje',
        'button_style'           => 'gradient',
        'success_msg'            => '¡Gracias! Tu solicitud ha sido enviada exitosamente.',
        'destination_emails'     => get_option('cm_default_email', get_option('admin_email')),
        'default_area_name'      => 'General / Consultas',
        'enable_autoresponder'   => true,
        'custom_subject'         => '',
        'show_credit'            => true,
    );

    switch ($key) {
        case 'cotizacion':
            $base_settings['title'] = 'Solicitud de Cotización';
            $base_settings['subtitle'] = 'Cuéntanos sobre tu proyecto y te enviaremos una propuesta a tu medida.';
            $base_settings['button_text'] = 'Solicitar Cotización';
            $base_settings['card_preset'] = 'flat';
            $base_settings['primary_color'] = '#2563eb';
            return array(
                'settings' => $base_settings,
                'fields'   => array(
                    array('id' => 'field_nombre', 'type' => 'text', 'label' => 'Nombre Completo', 'placeholder' => 'Ej. Juan Pérez', 'required' => true, 'width' => '50'),
                    array('id' => 'field_email', 'type' => 'email', 'label' => 'Correo Electrónico', 'placeholder' => 'ejemplo@empresa.com', 'required' => true, 'width' => '50'),
                    array('id' => 'field_telefono', 'type' => 'phone', 'label' => 'Teléfono / WhatsApp', 'placeholder' => '+56 9 1234 5678', 'required' => false, 'width' => '50'),
                    array('id' => 'field_empresa', 'type' => 'text', 'label' => 'Empresa u Organización', 'placeholder' => 'Nombre de tu empresa', 'required' => false, 'width' => '50'),
                    array('id' => 'field_servicio', 'type' => 'select', 'label' => 'Servicio Requerido', 'required' => true, 'width' => '50', 'options' => array(
                        array('nombre' => 'Desarrollo de Software / Web', 'email' => ''),
                        array('nombre' => 'Diseño UX/UI & Branding', 'email' => ''),
                        array('nombre' => 'Marketing Digital & SEO', 'email' => ''),
                        array('nombre' => 'Consultoría Especializada', 'email' => ''),
                    )),
                    array('id' => 'field_presupuesto', 'type' => 'select', 'label' => 'Presupuesto Estimado', 'required' => false, 'width' => '50', 'options' => array(
                        array('nombre' => 'Menos de $500.000 CLP', 'email' => ''),
                        array('nombre' => '$500.000 - $1.500.000 CLP', 'email' => ''),
                        array('nombre' => '$1.500.000 - $3.000.000 CLP', 'email' => ''),
                        array('nombre' => 'Más de $3.000.000 CLP', 'email' => ''),
                    )),
                    array('id' => 'field_mensaje', 'type' => 'textarea', 'label' => 'Detalles del Proyecto', 'placeholder' => 'Describe los objetivos, alcance y plazos de tu proyecto...', 'required' => true, 'width' => '100'),
                    array('id' => 'field_adjunto', 'type' => 'file', 'label' => 'Adjuntar Brief o Especificaciones (opcional)', 'required' => false, 'width' => '100', 'help' => 'PDF, DOCX, ZIP. Máx 5 MB.'),
                    array('id' => 'field_terminos', 'type' => 'terms', 'label' => 'Acepto la', 'required' => true, 'width' => '100', 'has_terms' => true, 'terms_link_text' => 'Política de Privacidad y Confidencialidad', 'terms_title' => 'Política de Privacidad', 'terms_content' => "Los datos de su proyecto serán tratados con absoluta confidencialidad y bajo acuerdo de no divulgación."),
                )
            );

        case 'citas':
            $base_settings['title'] = 'Reserva tu Cita Online';
            $base_settings['subtitle'] = 'Selecciona la fecha y especialidad para confirmar tu atención.';
            $base_settings['button_text'] = 'Confirmar Cita';
            $base_settings['card_preset'] = 'rounded';
            $base_settings['primary_color'] = '#0891b2';
            return array(
                'settings' => $base_settings,
                'fields'   => array(
                    array('id' => 'field_nombre', 'type' => 'text', 'label' => 'Nombre y Apellidos', 'placeholder' => 'Ej. María González', 'required' => true, 'width' => '50'),
                    array('id' => 'field_rut', 'type' => 'text', 'label' => 'RUT / Identificación', 'placeholder' => '12.345.678-9', 'required' => true, 'width' => '50'),
                    array('id' => 'field_email', 'type' => 'email', 'label' => 'Correo Electrónico', 'placeholder' => 'maria@correo.com', 'required' => true, 'width' => '50'),
                    array('id' => 'field_telefono', 'type' => 'phone', 'label' => 'Teléfono de Contacto', 'placeholder' => '+56 9 8765 4321', 'required' => true, 'width' => '50'),
                    array('id' => 'field_especialidad', 'type' => 'department', 'label' => 'Especialidad / Área', 'required' => true, 'width' => '50', 'options' => array(
                        array('nombre' => 'Medicina General', 'email' => ''),
                        array('nombre' => 'Pediatría', 'email' => ''),
                        array('nombre' => 'Odontología', 'email' => ''),
                        array('nombre' => 'Psicología', 'email' => ''),
                        array('nombre' => 'Kinesiología', 'email' => ''),
                    )),
                    array('id' => 'field_fecha', 'type' => 'date', 'label' => 'Fecha de Preferencia', 'placeholder' => 'dd/mm/aaaa', 'required' => true, 'width' => '50'),
                    array('id' => 'field_horario', 'type' => 'select', 'label' => 'Jornada Preferida', 'required' => false, 'width' => '50', 'options' => array(
                        array('nombre' => 'Mañana (09:00 - 13:00)', 'email' => ''),
                        array('nombre' => 'Tarde (14:00 - 18:00)', 'email' => ''),
                    )),
                    array('id' => 'field_motivo', 'type' => 'textarea', 'label' => 'Motivo de Consulta o Comentarios', 'placeholder' => 'Breve descripción del motivo de tu cita...', 'required' => false, 'width' => '100'),
                    array('id' => 'field_terminos', 'type' => 'terms', 'label' => 'He leído y acepto los', 'required' => true, 'width' => '100', 'has_terms' => true, 'terms_link_text' => 'Términos de Agendamiento', 'terms_title' => 'Términos de Reserva', 'terms_content' => "Le contactaremos para confirmar la disponibilidad exacta del horario solicitado."),
                )
            );

        case 'inmobiliaria':
            $base_settings['title'] = 'Consulta de Propiedad & Visita';
            $base_settings['subtitle'] = 'Déjanos tus datos para coordinar una visita guiada o recibir la ficha completa.';
            $base_settings['button_text'] = 'Coordinar Visita';
            $base_settings['primary_color'] = '#0f766e';
            return array(
                'settings' => $base_settings,
                'fields'   => array(
                    array('id' => 'field_nombre', 'type' => 'text', 'label' => 'Nombre y Apellidos', 'placeholder' => 'Tu nombre completo', 'required' => true, 'width' => '50'),
                    array('id' => 'field_email', 'type' => 'email', 'label' => 'Correo Electrónico', 'placeholder' => 'tu@correo.com', 'required' => true, 'width' => '50'),
                    array('id' => 'field_telefono', 'type' => 'phone', 'label' => 'Teléfono / WhatsApp', 'placeholder' => '+56 9 0000 0000', 'required' => true, 'width' => '50'),
                    array('id' => 'field_operacion', 'type' => 'radio', 'label' => 'Tipo de Operación', 'required' => true, 'width' => '50', 'options' => array(
                        array('nombre' => 'Comprar', 'email' => ''),
                        array('nombre' => 'Arrendar', 'email' => ''),
                        array('nombre' => 'Vender una Propiedad', 'email' => ''),
                    )),
                    array('id' => 'field_tipo_inmueble', 'type' => 'select', 'label' => 'Tipo de Inmueble', 'required' => true, 'width' => '50', 'options' => array(
                        array('nombre' => 'Departamento', 'email' => ''),
                        array('nombre' => 'Casa / Condominio', 'email' => ''),
                        array('nombre' => 'Oficina Comercial', 'email' => ''),
                        array('nombre' => 'Terreno / Parcela', 'email' => ''),
                    )),
                    array('id' => 'field_codigo', 'type' => 'text', 'label' => 'Código o Dirección de la Propiedad', 'placeholder' => 'Ej. DEPTO-402 o Av. Providencia 1234', 'required' => false, 'width' => '50'),
                    array('id' => 'field_fecha_visita', 'type' => 'date', 'label' => 'Fecha Estimada para la Visita', 'placeholder' => 'dd/mm/aaaa', 'required' => false, 'width' => '50'),
                    array('id' => 'field_mensaje', 'type' => 'textarea', 'label' => 'Preguntas o Consultas Adicionales', 'placeholder' => 'Indícanos si tienes dudas sobre financiamiento, entrega inmediata, etc.', 'required' => false, 'width' => '100'),
                    array('id' => 'field_terminos', 'type' => 'terms', 'label' => 'Acepto recibir información y los', 'required' => true, 'width' => '100', 'has_terms' => true, 'terms_link_text' => 'Términos de Privacidad Inmobiliaria', 'terms_title' => 'Políticas de Privacidad', 'terms_content' => "Tus datos solo se usarán para contactarte sobre la propiedad de tu interés."),
                )
            );

        case 'soporte':
            $base_settings['title'] = 'Mesa de Ayuda y Soporte Técnico';
            $base_settings['subtitle'] = 'Envía tu reporte de incidencia y nuestro equipo te responderá a la brevedad.';
            $base_settings['button_text'] = 'Crear Ticket de Soporte';
            $base_settings['card_preset'] = 'glassmorphism';
            $base_settings['primary_color'] = '#d97706';
            return array(
                'settings' => $base_settings,
                'fields'   => array(
                    array('id' => 'field_nombre', 'type' => 'text', 'label' => 'Nombre del Usuario', 'placeholder' => 'Tu nombre completo', 'required' => true, 'width' => '50'),
                    array('id' => 'field_email', 'type' => 'email', 'label' => 'Correo de Contacto', 'placeholder' => 'tu@correo.com', 'required' => true, 'width' => '50'),
                    array('id' => 'field_modulo', 'type' => 'department', 'label' => 'Módulo o Sistema Afectado', 'required' => true, 'width' => '50', 'options' => array(
                        array('nombre' => 'Plataforma Web', 'email' => 'soporte-web@colegio.cl'),
                        array('nombre' => 'Correo Institucional', 'email' => 'soporte-mail@colegio.cl'),
                        array('nombre' => 'Acceso y Contraseñas', 'email' => 'soporte-cuentas@colegio.cl'),
                        array('nombre' => 'Equipos y Redes', 'email' => 'soporte-redes@colegio.cl'),
                    )),
                    array('id' => 'field_urgencia', 'type' => 'radio', 'label' => 'Nivel de Prioridad', 'required' => true, 'width' => '50', 'options' => array(
                        array('nombre' => 'Baja (Consulta general)', 'email' => ''),
                        array('nombre' => 'Media (Problema no bloqueante)', 'email' => ''),
                        array('nombre' => 'Alta (Sistema detenido / Bloqueo)', 'email' => ''),
                    )),
                    array('id' => 'field_asunto', 'type' => 'text', 'label' => 'Asunto / Resumen del Problema', 'placeholder' => 'Ej. Error al iniciar sesión en el portal', 'required' => true, 'width' => '100'),
                    array('id' => 'field_descripcion', 'type' => 'textarea', 'label' => 'Descripción Paso a Paso', 'placeholder' => 'Explica qué estabas haciendo y qué mensaje de error apareció...', 'required' => true, 'width' => '100'),
                    array('id' => 'field_adjunto', 'type' => 'file', 'label' => 'Adjuntar Captura de Pantalla o Log', 'required' => false, 'width' => '100', 'help' => 'PNG, JPG, PDF. Máx 5 MB.'),
                )
            );

        case 'encuesta':
            $base_settings['title'] = 'Encuesta de Satisfacción y Experiencia';
            $base_settings['subtitle'] = 'Tu opinión nos ayuda a seguir mejorando nuestros servicios.';
            $base_settings['button_text'] = 'Enviar Evaluación';
            $base_settings['card_preset'] = 'flat';
            $base_settings['primary_color'] = '#f59e0b';
            return array(
                'settings' => $base_settings,
                'fields'   => array(
                    array('id' => 'field_nombre', 'type' => 'text', 'label' => 'Nombre (opcional)', 'placeholder' => 'Tu nombre', 'required' => false, 'width' => '50'),
                    array('id' => 'field_email', 'type' => 'email', 'label' => 'Correo Electrónico (opcional)', 'placeholder' => 'tu@correo.com', 'required' => false, 'width' => '50'),
                    array('id' => 'field_area', 'type' => 'select', 'label' => 'Área o Servicio Evaluado', 'required' => true, 'width' => '100', 'options' => array(
                        array('nombre' => 'Atención al Cliente / Recepción', 'email' => ''),
                        array('nombre' => 'Soporte y Post-Venta', 'email' => ''),
                        array('nombre' => 'Servicio Académico / Docente', 'email' => ''),
                        array('nombre' => 'Administración y Pagos', 'email' => ''),
                    )),
                    array('id' => 'field_calificacion', 'type' => 'rating', 'label' => '¿Cómo calificarías tu experiencia general?', 'required' => true, 'width' => '100'),
                    array('id' => 'field_recomienda', 'type' => 'radio', 'label' => '¿Recomendarías nuestros servicios a un amigo o familiar?', 'required' => true, 'width' => '100', 'options' => array(
                        array('nombre' => 'Definitivamente Sí (10/10)', 'email' => ''),
                        array('nombre' => 'Probablemente Sí', 'email' => ''),
                        array('nombre' => 'Tal vez', 'email' => ''),
                        array('nombre' => 'No por el momento', 'email' => ''),
                    )),
                    array('id' => 'field_comentarios', 'type' => 'textarea', 'label' => '¿Qué aspectos destacarías o qué podríamos mejorar?', 'placeholder' => 'Escribe tus comentarios y sugerencias...', 'required' => false, 'width' => '100'),
                )
            );

        case 'admision':
            $base_settings['title'] = 'Formulario de Admisión y Postulación';
            $base_settings['subtitle'] = 'Completa los datos del postulante y apoderado para iniciar el proceso de postulación.';
            $base_settings['button_text'] = 'Enviar Postulación';
            $base_settings['primary_color'] = '#0066cc';
            return array(
                'settings' => $base_settings,
                'fields'   => array(
                    array('id' => 'field_alumno', 'type' => 'text', 'label' => 'Nombre Completo del Postulante', 'placeholder' => 'Nombres y Apellidos del alumno', 'required' => true, 'width' => '50'),
                    array('id' => 'field_nacimiento', 'type' => 'date', 'label' => 'Fecha de Nacimiento del Alumno', 'placeholder' => 'dd/mm/aaaa', 'required' => true, 'width' => '50'),
                    array('id' => 'field_curso', 'type' => 'select', 'label' => 'Curso al que Postula', 'required' => true, 'width' => '50', 'options' => array(
                        array('nombre' => 'Educación Parvularia (Pre-Kínder / Kínder)', 'email' => 'admision-parvulos@colegio.cl'),
                        array('nombre' => 'Educación Básica (1° a 6° Básico)', 'email' => 'admision-basica@colegio.cl'),
                        array('nombre' => 'Educación Media (7° Básico a 4° Medio)', 'email' => 'admision-media@colegio.cl'),
                    )),
                    array('id' => 'field_apoderado', 'type' => 'text', 'label' => 'Nombre del Apoderado o Tutor', 'placeholder' => 'Nombre del padre, madre o tutor', 'required' => true, 'width' => '50'),
                    array('id' => 'field_email_apod', 'type' => 'email', 'label' => 'Correo Electrónico del Apoderado', 'placeholder' => 'apoderado@correo.com', 'required' => true, 'width' => '50'),
                    array('id' => 'field_tel_apod', 'type' => 'phone', 'label' => 'Teléfono Móvil del Apoderado', 'placeholder' => '+56 9 0000 0000', 'required' => true, 'width' => '50'),
                    array('id' => 'field_adjunto_notas', 'type' => 'file', 'label' => 'Adjuntar Certificado de Nacimiento / Notas (PDF o Foto)', 'required' => false, 'width' => '100', 'help' => 'PDF, JPG, PNG. Máx 5 MB.'),
                    array('id' => 'field_observaciones', 'type' => 'textarea', 'label' => 'Antecedentes Médicos o Comentarios Relevantes', 'placeholder' => 'Alergias, necesidades educativas especiales o información adicional...', 'required' => false, 'width' => '100'),
                    array('id' => 'field_terminos', 'type' => 'terms', 'label' => 'He leído y acepto el', 'required' => true, 'width' => '100', 'has_terms' => true, 'terms_link_text' => 'Reglamento de Admisión Escolar', 'terms_title' => 'Reglamento de Admisión', 'terms_content' => "La postulación no garantiza matrícula automática y está sujeta a la disponibilidad de vacantes del nivel."),
                )
            );

        case 'restaurante':
            $base_settings['title'] = 'Reserva de Mesa & Gastronomía';
            $base_settings['subtitle'] = 'Asegura tu lugar con nosotros y disfruta de una experiencia gastronómica inolvidable.';
            $base_settings['button_text'] = 'Confirmar Mi Reserva';
            $base_settings['card_preset'] = 'rounded';
            $base_settings['primary_color'] = '#dc2626';
            return array(
                'settings' => $base_settings,
                'fields'   => array(
                    array('id' => 'field_nombre', 'type' => 'text', 'label' => 'Nombre para la Reserva', 'placeholder' => 'Ej. Familia Rojas', 'required' => true, 'width' => '50'),
                    array('id' => 'field_telefono', 'type' => 'phone', 'label' => 'Teléfono Móvil de Contacto', 'placeholder' => '+56 9 1234 5678', 'required' => true, 'width' => '50'),
                    array('id' => 'field_email', 'type' => 'email', 'label' => 'Correo Electrónico (para confirmación)', 'placeholder' => 'correo@ejemplo.com', 'required' => true, 'width' => '50'),
                    array('id' => 'field_personas', 'type' => 'number', 'label' => 'Cantidad de Personas', 'placeholder' => 'Ej. 4', 'required' => true, 'width' => '50'),
                    array('id' => 'field_fecha', 'type' => 'date', 'label' => 'Fecha de la Reserva', 'placeholder' => 'dd/mm/aaaa', 'required' => true, 'width' => '50'),
                    array('id' => 'field_turno', 'type' => 'select', 'label' => 'Turno y Horario', 'required' => true, 'width' => '50', 'options' => array(
                        array('nombre' => 'Almuerzo: 13:00 a 15:30 hrs', 'email' => ''),
                        array('nombre' => 'Cena Temprana: 19:30 a 21:30 hrs', 'email' => ''),
                        array('nombre' => 'Cena Tardía: 22:00 a 00:00 hrs', 'email' => ''),
                    )),
                    array('id' => 'field_sector', 'type' => 'radio', 'label' => 'Sector de Preferencia', 'required' => false, 'width' => '100', 'options' => array(
                        array('nombre' => 'Salón Principal Climatizado', 'email' => ''),
                        array('nombre' => 'Terraza al Aire Libre', 'email' => ''),
                        array('nombre' => 'Zona Lounge / Bar', 'email' => ''),
                    )),
                    array('id' => 'field_alergias', 'type' => 'textarea', 'label' => 'Peticiones Especiales, Alergias o Celebraciones', 'placeholder' => 'Indícanos si celebran un cumpleaños, aniversario o si hay alergias alimentarias...', 'required' => false, 'width' => '100'),
                    array('id' => 'field_terminos', 'type' => 'terms', 'label' => 'Acepto las', 'required' => true, 'width' => '100', 'has_terms' => true, 'terms_link_text' => 'Políticas de Reserva y Cancelación', 'terms_title' => 'Políticas de Reserva', 'terms_content' => "Las reservas se mantendrán por un máximo de 15 minutos de tolerancia tras la hora pactada."),
                )
            );

        case 'automotriz':
            $base_settings['title'] = 'Cotización & Solicitud de Test Drive';
            $base_settings['subtitle'] = 'Elige tu vehículo ideal y pruébalo en la sucursal más cercana.';
            $base_settings['button_text'] = 'Agendar Test Drive';
            $base_settings['card_preset'] = 'glassmorphism';
            $base_settings['primary_color'] = '#334155';
            return array(
                'settings' => $base_settings,
                'fields'   => array(
                    array('id' => 'field_nombre', 'type' => 'text', 'label' => 'Nombre y Apellidos', 'placeholder' => 'Tu nombre completo', 'required' => true, 'width' => '50'),
                    array('id' => 'field_email', 'type' => 'email', 'label' => 'Correo Electrónico', 'placeholder' => 'tu@correo.com', 'required' => true, 'width' => '50'),
                    array('id' => 'field_telefono', 'type' => 'phone', 'label' => 'Teléfono / WhatsApp', 'placeholder' => '+56 9 0000 0000', 'required' => true, 'width' => '50'),
                    array('id' => 'field_modelo', 'type' => 'select', 'label' => 'Modelo de Interés', 'required' => true, 'width' => '50', 'options' => array(
                        array('nombre' => 'SUV Familiar 7 Pasajeros', 'email' => ''),
                        array('nombre' => 'Sedán Ejecutivo Confort', 'email' => ''),
                        array('nombre' => 'Camioneta Pick-Up 4x4', 'email' => ''),
                        array('nombre' => 'Vehículo Eléctrico / Híbrido', 'email' => ''),
                        array('nombre' => 'Hatchback Urbano Compacto', 'email' => ''),
                    )),
                    array('id' => 'field_sucursal', 'type' => 'department', 'label' => 'Sucursal Preferida', 'required' => true, 'width' => '50', 'options' => array(
                        array('nombre' => 'Sucursal Las Condes', 'email' => 'ventas-oriente@automotriz.cl'),
                        array('nombre' => 'Sucursal Santiago Centro', 'email' => 'ventas-centro@automotriz.cl'),
                        array('nombre' => 'Sucursal Viña del Mar', 'email' => 'ventas-costa@automotriz.cl'),
                        array('nombre' => 'Sucursal Concepción', 'email' => 'ventas-sur@automotriz.cl'),
                    )),
                    array('id' => 'field_parte_pago', 'type' => 'radio', 'label' => '¿Deseas entregar tu vehículo actual en parte de pago?', 'required' => false, 'width' => '50', 'options' => array(
                        array('nombre' => 'Sí, deseo tasar mi auto', 'email' => ''),
                        array('nombre' => 'No, compra directa', 'email' => ''),
                    )),
                    array('id' => 'field_plazo', 'type' => 'select', 'label' => 'Fecha Estimada de Compra', 'required' => false, 'width' => '100', 'options' => array(
                        array('nombre' => 'Inmediata (Este mes)', 'email' => ''),
                        array('nombre' => 'En los próximos 1 a 3 meses', 'email' => ''),
                        array('nombre' => 'Solo estoy cotizando y comparando', 'email' => ''),
                    )),
                    array('id' => 'field_terminos', 'type' => 'terms', 'label' => 'Acepto ser contactado por un asesor y los', 'required' => true, 'width' => '100', 'has_terms' => true, 'terms_link_text' => 'Términos de Test Drive', 'terms_title' => 'Términos de Test Drive', 'terms_content' => "Para realizar el Test Drive es requisito obligatorio presentar licencia de conducir vigente al momento de la prueba."),
                )
            );

        case 'legal':
            $base_settings['title'] = 'Consulta Jurídica Confidencial';
            $base_settings['subtitle'] = 'Comunícate con nuestro equipo de abogados especialistas de forma privada.';
            $base_settings['button_text'] = 'Solicitar Consulta Legal';
            $base_settings['card_preset'] = 'flat';
            $base_settings['primary_color'] = '#1e293b';
            return array(
                'settings' => $base_settings,
                'fields'   => array(
                    array('id' => 'field_nombre', 'type' => 'text', 'label' => 'Nombre y Apellidos', 'placeholder' => 'Tu nombre completo', 'required' => true, 'width' => '50'),
                    array('id' => 'field_telefono', 'type' => 'phone', 'label' => 'Teléfono Confidencial', 'placeholder' => '+56 9 1234 5678', 'required' => true, 'width' => '50'),
                    array('id' => 'field_email', 'type' => 'email', 'label' => 'Correo Electrónico', 'placeholder' => 'tu@correo.com', 'required' => true, 'width' => '50'),
                    array('id' => 'field_area_legal', 'type' => 'department', 'label' => 'Especialidad Jurídica Requerida', 'required' => true, 'width' => '50', 'options' => array(
                        array('nombre' => 'Derecho Laboral y Despidos', 'email' => 'laboral@estudiojuridico.cl'),
                        array('nombre' => 'Derecho Civil e Inmobiliario', 'email' => 'civil@estudiojuridico.cl'),
                        array('nombre' => 'Derecho de Familia y Herencias', 'email' => 'familia@estudiojuridico.cl'),
                        array('nombre' => 'Derecho Corporativo y Empresas', 'email' => 'corporativo@estudiojuridico.cl'),
                        array('nombre' => 'Derecho Penal y Defensa', 'email' => 'penal@estudiojuridico.cl'),
                    )),
                    array('id' => 'field_resumen', 'type' => 'textarea', 'label' => 'Resumen Breve de los Hechos o Consulta', 'placeholder' => 'Explica los antecedentes principales de tu caso...', 'required' => true, 'width' => '100'),
                    array('id' => 'field_adjunto_doc', 'type' => 'file', 'label' => 'Adjuntar Documentos Relevantes (contratos, cartas, finiquito, etc.)', 'required' => false, 'width' => '100', 'help' => 'PDF, DOCX, ZIP. Máx 5 MB.'),
                    array('id' => 'field_terminos', 'type' => 'terms', 'label' => 'Acepto el', 'required' => true, 'width' => '100', 'has_terms' => true, 'terms_link_text' => 'Acuerdo de Secreto Profesional y Confidencialidad', 'terms_title' => 'Secreto Profesional', 'terms_content' => "Toda la información suministrada se encuentra amparada bajo el estricto deber de secreto profesional."),
                )
            );

        case 'fitness':
            $base_settings['title'] = 'Inscripción & Membresía Fitness';
            $base_settings['subtitle'] = 'Empieza tu entrenamiento hoy mismo y alcanza tu mejor versión.';
            $base_settings['button_text'] = 'Quiero Mi Membresía';
            $base_settings['card_preset'] = 'rounded';
            $base_settings['primary_color'] = '#16a34a';
            return array(
                'settings' => $base_settings,
                'fields'   => array(
                    array('id' => 'field_nombre', 'type' => 'text', 'label' => 'Nombre y Apellidos', 'placeholder' => 'Tu nombre completo', 'required' => true, 'width' => '50'),
                    array('id' => 'field_edad', 'type' => 'number', 'label' => 'Edad', 'placeholder' => 'Ej. 28', 'required' => true, 'width' => '50'),
                    array('id' => 'field_email', 'type' => 'email', 'label' => 'Correo Electrónico', 'placeholder' => 'tu@correo.com', 'required' => true, 'width' => '50'),
                    array('id' => 'field_telefono', 'type' => 'phone', 'label' => 'Teléfono WhatsApp', 'placeholder' => '+56 9 0000 0000', 'required' => true, 'width' => '50'),
                    array('id' => 'field_plan', 'type' => 'select', 'label' => 'Plan de Membresía de Interés', 'required' => true, 'width' => '50', 'options' => array(
                        array('nombre' => 'Plan Mensual Libre (Sin Permanencia)', 'email' => ''),
                        array('nombre' => 'Plan Semestral PRO (20% Descuento)', 'email' => ''),
                        array('nombre' => 'Plan Anual VIP All-Inclusive', 'email' => ''),
                        array('nombre' => 'Pase Diario de Prueba', 'email' => ''),
                    )),
                    array('id' => 'field_sede', 'type' => 'department', 'label' => 'Sede Principal de Entrenamiento', 'required' => true, 'width' => '50', 'options' => array(
                        array('nombre' => 'Sede Central Providencia', 'email' => 'providencia@gymfitness.cl'),
                        array('nombre' => 'Sede Las Condes / Apoquindo', 'email' => 'lascondes@gymfitness.cl'),
                        array('nombre' => 'Sede Santiago Centro', 'email' => 'centro@gymfitness.cl'),
                        array('nombre' => 'Sede Viña del Mar', 'email' => 'vina@gymfitness.cl'),
                    )),
                    array('id' => 'field_condicion_medica', 'type' => 'textarea', 'label' => '¿Posees alguna lesión previa, cirugía o condición médica?', 'placeholder' => 'Indícanos si tienes alguna condición a tener en cuenta para tu rutina...', 'required' => false, 'width' => '100'),
                    array('id' => 'field_terminos', 'type' => 'terms', 'label' => 'Declaro estar apto para actividad física y acepto los', 'required' => true, 'width' => '100', 'has_terms' => true, 'terms_link_text' => 'Términos y Condiciones del Gimnasio', 'terms_title' => 'Reglamento y Términos de Uso', 'terms_content' => "El usuario declara bajo su responsabilidad que se encuentra en condiciones de salud aptas para la práctica de ejercicios físicos."),
                )
            );

        case 'lead':
            $base_settings['title'] = '¡Recibe Asesoría Gratuita!';
            $base_settings['subtitle'] = 'Déjanos tus datos y un especialista se pondrá en contacto contigo hoy mismo.';
            $base_settings['button_text'] = 'Quiero Mi Asesoría Gratis';
            $base_settings['card_preset'] = 'transparent';
            $base_settings['primary_color'] = '#6366f1';
            return array(
                'settings' => $base_settings,
                'fields'   => array(
                    array('id' => 'field_nombre', 'type' => 'text', 'label' => 'Nombre Completo', 'placeholder' => 'Tu nombre', 'required' => true, 'width' => '100'),
                    array('id' => 'field_email', 'type' => 'email', 'label' => 'Correo Electrónico', 'placeholder' => 'ejemplo@correo.com', 'required' => true, 'width' => '100'),
                    array('id' => 'field_telefono', 'type' => 'phone', 'label' => 'Teléfono Móvil / WhatsApp', 'placeholder' => '+56 9 0000 0000', 'required' => true, 'width' => '100'),
                    array('id' => 'field_objetivo', 'type' => 'select', 'label' => '¿Cuál es tu principal objetivo?', 'required' => false, 'width' => '100', 'options' => array(
                        array('nombre' => 'Aumentar mis ventas y clientes', 'email' => ''),
                        array('nombre' => 'Optimizar y digitalizar procesos', 'email' => ''),
                        array('nombre' => 'Reducir costos operativos', 'email' => ''),
                        array('nombre' => 'Otra consulta específica', 'email' => ''),
                    )),
                    array('id' => 'field_terminos', 'type' => 'terms', 'label' => 'Acepto recibir contacto y los', 'required' => true, 'width' => '100', 'has_terms' => true, 'terms_link_text' => 'Términos de Privacidad', 'terms_title' => 'Términos de Privacidad', 'terms_content' => "Tus datos solo se usarán para brindarte la asesoría solicitada. No enviamos spam."),
                )
            );

        case 'blank':
            $base_settings['title'] = 'Nuevo Formulario';
            $base_settings['subtitle'] = 'Personaliza este formulario agregando campos desde el panel izquierdo.';
            return array(
                'settings' => $base_settings,
                'fields'   => array()
            );

        case 'colegio':
        default:
            return cm_get_default_schema();
    }
}

function cm_render_admin_builder() {
    $form_id = isset($_GET['form']) ? sanitize_key($_GET['form']) : get_option('cm_current_form_id', '');
    $schema  = ($form_id && function_exists('cm_get_form')) ? cm_get_form($form_id) : null;
    if (!$schema || !is_array($schema)) {
        $schema = get_option('cm_form_builder_schema', null);
        if (!$schema || !is_array($schema)) {
            $schema = cm_get_default_schema();
        }
    }
    $s = isset($schema['settings']) ? $schema['settings'] : array();
    ?>
    <div class="cm-studio-wrapper">

        <?php if (trim((string)($s['destination_emails'] ?? '')) === '') : ?>
        <div class="cm-mail-alert" id="cm-mail-alert">
            <div class="cm-mail-alert-icon">✉️</div>
            <div class="cm-mail-alert-text">
                <strong>Falta configuración de correo en la extensión Ingecodex</strong>
                <span>Este formulario no tiene destinatario asignado: los mensajes no llegarán a ningún correo.</span>
            </div>
            <div class="cm-mail-alert-actions">
                <button type="button" class="cm-btn cm-btn-primary" id="cm-alert-fix-dest">Definir destinatario</button>
                <a class="cm-btn cm-btn-secondary" href="<?php echo esc_url(admin_url('admin.php?page=cm-form-smtp')); ?>">Servidor SMTP</a>
            </div>
        </div>
        <?php endif; ?>

        <!-- ══ HEADER: marca + acciones principales ══ -->
        <header class="cm-studio-header">
            <div class="cm-studio-brand">
                <a href="https://www.ingecodex.com" target="_blank" rel="noopener" title="Visitar www.ingecodex.com" style="display:flex;align-items:center;gap:12px;text-decoration:none;">
                    <div class="cm-brand-icon"><img src="<?php echo esc_url(CM_PLUGIN_URL . 'imag/diagrama.gif'); ?>" alt="Ingecodex Form" draggable="false" /></div>
                    <h1>Ingecodex Form <small>BY INGECODEX.COM</small></h1>
                </a>
            </div>

            <div class="cm-studio-header-actions">
                <span id="cm-form-shortcode-chip" title="Clic para copiar el shortcode de este formulario" style="display:none; cursor:pointer; font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 12px; font-weight: 700; color: #065f46; background: #d1fae5; border: 1px solid #6ee7b7; border-radius: 8px; padding: 7px 10px; white-space: nowrap; user-select: all;"></span>
                <button type="button" class="cm-btn cm-btn-secondary" id="cm-btn-preview-modal">👁️ Vista Previa</button>
                <button type="button" class="cm-btn cm-btn-secondary" id="cm-btn-publish-modal">🚀 Publicar / Insertar</button>
                <button type="button" class="cm-btn cm-btn-primary" id="cm-save-schema-btn">💾 Guardar Cambios</button>
            </div>
        </header>

        <!-- ══ FORMBAR: gestión del formulario actual ══ -->
        <div class="cm-formbar">
            <span style="font-size: 11px; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: 0.04em;">Formulario:</span>
            <select id="cm-form-selector" class="cm-prop-select" style="width:auto; min-width:180px; max-width:260px; height:36px; background:#ffffff;"></select>
            <input type="text" id="cm-form-name-input" class="cm-prop-input" style="width:200px; height:36px; background:#ffffff; font-weight:600;" placeholder="Nombre del formulario" title="Nombre de este formulario (se guarda con Guardar Cambios)" />
            <span style="width:1px; height:22px; background:#e2e8f0;"></span>
            <button type="button" class="cm-btn cm-btn-secondary" id="cm-btn-new-form" title="Abrir Galería de Plantillas y Crear Nuevo Formulario" style="color:#0066cc;">🏛️ Galería / ＋ Nuevo</button>
            <button type="button" class="cm-btn cm-btn-secondary" id="cm-btn-dup-form" title="Duplicar formulario actual">⧉ Duplicar</button>
            <button type="button" class="cm-btn cm-btn-secondary" id="cm-btn-del-form" title="Eliminar formulario actual">🗑</button>
        </div>

        <!-- ══ ÁREA PRINCIPAL EN 3 COLUMNAS ══ -->
        <div class="cm-studio-body">

            <!-- ══ PALETA DE ELEMENTOS (Izquierda) ══ -->
            <aside class="cm-studio-sidebar cm-sidebar-left">
                <div class="cm-sidebar-header">
                    <h2>📦 Elementos</h2>
                    <p>Haz clic para añadir al formulario</p>
                </div>
                <div class="cm-palette-search-wrap">
                    <input type="text" class="cm-palette-search" id="cm-palette-filter" placeholder="🔍 Buscar elemento..." />
                </div>

                <div class="cm-palette-group-title">Campos de Texto</div>
                <div class="cm-components-grid">
                    <div class="cm-component-card" data-type="text">
                        <svg class="cm-comp-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 7V4h16v3M9 20h6M12 4v16"/></svg>
                        <span>Texto Corto</span>
                    </div>
                    <div class="cm-component-card" data-type="email">
                        <svg class="cm-comp-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                        <span>Correo Electrónico</span>
                    </div>
                    <div class="cm-component-card" data-type="phone">
                        <svg class="cm-comp-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                        <span>Teléfono</span>
                    </div>
                    <div class="cm-component-card" data-type="textarea">
                        <svg class="cm-comp-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                        <span>Área de Texto</span>
                    </div>
                    <div class="cm-component-card" data-type="number">
                        <svg class="cm-comp-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                        <span>Número</span>
                    </div>
                    <div class="cm-component-card" data-type="url">
                        <svg class="cm-comp-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
                        <span>Sitio Web / URL</span>
                    </div>
                </div>

                <div class="cm-palette-group-title">Selección y Opciones</div>
                <div class="cm-components-grid">
                    <div class="cm-component-card" data-type="department">
                        <svg class="cm-comp-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                        <span>Departamentos ✉️</span>
                    </div>
                    <div class="cm-component-card" data-type="select">
                        <svg class="cm-comp-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
                        <span>Lista Desplegable</span>
                    </div>
                    <div class="cm-component-card" data-type="radio">
                        <svg class="cm-comp-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="4" fill="currentColor"/></svg>
                        <span>Opción Única</span>
                    </div>
                    <div class="cm-component-card" data-type="checkbox">
                        <svg class="cm-comp-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
                        <span>Casilla Simple</span>
                    </div>
                </div>

                <div class="cm-palette-group-title">Especiales e Interactivos</div>
                <div class="cm-components-grid">
                    <div class="cm-component-card" data-type="terms" style="border-color: #c7d2fe; background: #eef2ff;">
                        <svg class="cm-comp-icon" style="color: #0071e3;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
                        <span style="font-weight: 700; color: #0066cc;">📜 Términos / Modal</span>
                    </div>
                    <div class="cm-component-card" data-type="file">
                        <svg class="cm-comp-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                        <span>Subir Archivo</span>
                    </div>
                    <div class="cm-component-card" data-type="date">
                        <svg class="cm-comp-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                        <span>Fecha</span>
                    </div>
                    <div class="cm-component-card" data-type="rating">
                        <svg class="cm-comp-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                        <span>Calificación</span>
                    </div>
                    <div class="cm-component-card" data-type="heading">
                        <svg class="cm-comp-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 12h12M6 4v16M18 4v16"/></svg>
                        <span>Subtítulo / Sección</span>
                    </div>
                    <div class="cm-component-card" data-type="divider">
                        <svg class="cm-comp-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="12" x2="21" y2="12"/></svg>
                        <span>Separador</span>
                    </div>
                    <div class="cm-component-card" data-type="hidden">
                        <svg class="cm-comp-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                        <span>Campo Oculto</span>
                    </div>
                </div>
            </aside>

            <!-- ══ CANVAS (Centro) ══ -->
            <main class="cm-studio-canvas-area">
                <div class="cm-canvas-toolbar">
                    <div class="cm-view-modes">
                        <button type="button" class="cm-view-btn active" data-view="desktop">🖥️ Escritorio</button>
                        <button type="button" class="cm-view-btn" data-view="tablet">📱 Tablet</button>
                        <button type="button" class="cm-view-btn" data-view="mobile">📲 Móvil</button>
                    </div>
                    <div class="cm-canvas-status">
                        <span id="cm-canvas-hint">Haz clic en un campo para editar sus opciones</span>
                    </div>
                </div>

                <div class="cm-canvas-viewport desktop-view" id="cm-canvas-viewport">
                    <div class="cm-canvas-card" id="cm-form-canvas">
                        <div class="cm-canvas-form-header-wrap" id="cm-canvas-header-wrap">
                            <div class="cm-canvas-form-header" id="cm-canvas-form-header">
                                <div class="cm-header-badge-row" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                                    <span class="cm-field-label-chip" style="margin-bottom: 0;">✏️ Encabezado del Formulario</span>
                                    <button type="button" id="cm-hide-header-btn" class="cm-action-btn" title="Ocultar / Quitar Encabezado" style="width: auto; padding: 2px 8px; font-size: 11px; color: #ef4444; height: auto;">✕ Quitar</button>
                                </div>
                                <h2 contenteditable="true" id="cm-live-title">Título del Formulario</h2>
                                <p contenteditable="true" id="cm-live-subtitle">Descripción del formulario...</p>
                            </div>
                            <div id="cm-add-header-btn-wrap" style="display: none; margin-bottom: 20px; text-align: center;">
                                <button type="button" id="cm-show-header-btn" class="cm-btn cm-btn-outline" style="margin: 0; width: auto; padding: 8px 16px;">+ Agregar Título y Subtítulo al Formulario</button>
                            </div>
                        </div>
                        <div id="cm-canvas-fields-container" class="cm-canvas-fields-list"></div>
                        <div class="cm-canvas-submit-preview">
                            <button type="button" class="cm-preview-submit-btn" id="cm-preview-submit">Enviar Mensaje</button>
                        </div>
                        <div id="cm-canvas-credit-preview" style="text-align: right; margin-top: 14px; font-size: 11px; color: #94a3b8;">
                            Diseñado por <span style="color: #0071e3; font-weight: 600;">Ingecodex.com</span>
                        </div>
                    </div>
                </div>
            </main>

            <!-- ══ INSPECTOR (Derecha) ══ -->
            <aside class="cm-studio-sidebar cm-sidebar-right">
                <div class="cm-tabs-nav">
                    <button type="button" class="cm-tab-btn active" data-tab="field-properties">Campo</button>
                    <button type="button" class="cm-tab-btn" data-tab="form-design">Diseño</button>
                    <button type="button" class="cm-tab-btn" data-tab="form-settings">Ajustes</button>
                </div>

                <!-- Pestaña 1: Propiedades del Campo -->
                <div class="cm-tab-content active" id="tab-field-properties">
                    <div class="cm-inspector-field-selector-wrap">
                        <label>Campo Activo</label>
                        <select id="cm-inspector-field-selector" class="cm-prop-select"></select>
                    </div>

                    <div style="padding: 20px;">
                        <div id="cm-no-field-selected" class="cm-empty-inspector">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M15 15l6 6m-6-6a6 6 0 110-12 6 6 0 010 12z"/></svg>
                            <h4>Sin campo seleccionado</h4>
                            <p>Haz clic en cualquier campo del canvas o usa el selector de arriba.</p>
                        </div>

                        <div id="cm-field-inspector-form" style="display: none;">
                            <div id="cm-field-type-badge" class="cm-type-badge"></div>

                            <div class="cm-prop-section">
                                <p class="cm-prop-section-title">Configuración del Campo</p>
                                <div class="cm-prop-group">
                                    <label for="cm-prop-label">Etiqueta / Título</label>
                                    <input type="text" id="cm-prop-label" class="cm-prop-input" placeholder="Ej. Nombre Completo" />
                                </div>
                                <div class="cm-prop-group" id="cm-group-placeholder">
                                    <label for="cm-prop-placeholder">Placeholder</label>
                                    <input type="text" id="cm-prop-placeholder" class="cm-prop-input" placeholder="Ej. Juan Pérez" />
                                </div>
                                <div class="cm-prop-group">
                                    <label for="cm-prop-help">Texto de Ayuda (opcional)</label>
                                    <input type="text" id="cm-prop-help" class="cm-prop-input" placeholder="Ej. Ingresa tu nombre completo" />
                                </div>
                            </div>

                            <div class="cm-prop-section">
                                <p class="cm-prop-section-title">Presentación</p>
                                <div class="cm-prop-row">
                                    <div class="cm-prop-group">
                                        <label for="cm-prop-width">Ancho del Campo</label>
                                        <select id="cm-prop-width" class="cm-prop-select">
                                            <option value="100">100% — Fila Completa</option>
                                            <option value="50">50% — Media Fila</option>
                                        </select>
                                    </div>
                                    <div class="cm-prop-group">
                                        <label>Obligatorio</label>
                                        <div class="cm-switch-row" style="margin-top: 6px;">
                                            <label class="cm-switch">
                                                <input type="checkbox" id="cm-prop-required" />
                                                <span class="cm-slider"></span>
                                            </label>
                                            <span style="font-size: 12px; color: #64748b;" id="cm-req-label">Opcional</span>
                                        </div>
                                    </div>
                                </div>

                                <div id="cm-prop-pos-group" class="cm-prop-section" style="display:none; background:#f8faff; border-radius:10px; padding:14px; border:1px solid #e0e7ff;">
                                    <p class="cm-prop-section-title" style="color:#0066cc;">📐 Posición en el Lienzo (%)</p>
                                    <div class="cm-prop-row">
                                        <div class="cm-prop-group">
                                            <label for="cm-prop-pos-x">X (izquierda)</label>
                                            <input type="number" id="cm-prop-pos-x" class="cm-prop-input" min="0" max="100" step="0.5" />
                                        </div>
                                        <div class="cm-prop-group">
                                            <label for="cm-prop-pos-y">Y (arriba)</label>
                                            <input type="number" id="cm-prop-pos-y" class="cm-prop-input" min="0" max="100" step="0.5" />
                                        </div>
                                    </div>
                                    <div class="cm-prop-row">
                                        <div class="cm-prop-group">
                                            <label for="cm-prop-pos-w">Ancho (%)</label>
                                            <input type="number" id="cm-prop-pos-w" class="cm-prop-input" min="5" max="100" step="1" />
                                        </div>
                                        <div class="cm-prop-group"></div>
                                    </div>
                                </div>
                            </div>

                            <!-- Subpanel dinámico de Términos y Condiciones Flotantes -->
                            <div id="cm-prop-terms-section" class="cm-prop-section" style="display: none; background: #f8faff; border-radius: 10px; padding: 14px; border: 1px solid #e0e7ff;">
                                <p class="cm-prop-section-title" style="color: #0066cc;">📜 Modal de Términos y Condiciones</p>
                                
                                <div class="cm-prop-group">
                                    <label for="cm-prop-terms-link">Texto del Enlace Clickeable</label>
                                    <input type="text" id="cm-prop-terms-link" class="cm-prop-input" placeholder="Términos y Condiciones" />
                                </div>

                                <div class="cm-prop-group">
                                    <label for="cm-prop-terms-title">Título del Modal Popup</label>
                                    <input type="text" id="cm-prop-terms-title" class="cm-prop-input" placeholder="Políticas y Términos de Servicio" />
                                </div>

                                <div class="cm-prop-group">
                                    <label for="cm-prop-terms-content">Contenido Completo que Leerá el Usuario</label>
                                    <textarea id="cm-prop-terms-content" class="cm-prop-textarea" rows="6" placeholder="Escribe aquí las cláusulas o políticas..."></textarea>
                                </div>
                            </div>

                            <!-- Subpanel dinámico de Opciones / Correos Múltiples -->
                            <div id="cm-prop-department-section" class="cm-prop-section" style="display: none;">
                                <p class="cm-prop-section-title">Opciones y Correos Destino</p>
                                <div class="cm-inspector-subpanel">
                                    <p class="cm-subpanel-desc">Define las opciones y los correos que recibirán el mensaje. Separa múltiples correos con coma.</p>
                                    <div id="cm-department-options-list"></div>
                                    <button type="button" id="cm-add-dep-option-btn" class="cm-btn cm-btn-outline">+ Añadir Opción</button>
                                </div>
                            </div>

                            <!-- Subpanel de Estilo Individual por Campo -->
                            <div class="cm-prop-section">
                                <p class="cm-prop-section-title">🎨 Estilo Individual del Campo</p>
                                <div class="cm-prop-group">
                                    <label>Color del Borde</label>
                                    <div class="cm-color-row">
                                        <input type="color" id="cm-prop-custom-border" class="cm-prop-color" value="#e2e8f0" />
                                        <input type="text" id="cm-prop-custom-border-hex" class="cm-color-hex" value="#e2e8f0" maxlength="7" />
                                    </div>
                                </div>
                                <div class="cm-prop-group">
                                    <label>Color de Fondo</label>
                                    <div class="cm-color-row">
                                        <input type="color" id="cm-prop-custom-bg" class="cm-prop-color" value="#f8fafc" />
                                        <input type="text" id="cm-prop-custom-bg-hex" class="cm-color-hex" value="#f8fafc" maxlength="7" />
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <!-- Pestaña 2: Diseño Visual Global -->
                <div class="cm-tab-content" id="tab-form-design">
                    <div style="padding: 20px;">

                        <div class="cm-prop-section">
                            <p class="cm-prop-section-title">📐 Modo de Lienzo</p>

                            <div class="cm-prop-group">
                                <label>Disposición de los Campos</label>
                                <select id="cm-setting-pos-mode" class="cm-prop-select">
                                    <option value="" <?php selected(empty($s['pos_mode']), true); ?>>Flujo Automático (una bajo otra)</option>
                                    <option value="1" <?php selected(!empty($s['pos_mode']), true); ?>>Posición Libre (arrastrar y soltar)</option>
                                </select>
                            </div>

                            <div class="cm-prop-group" id="cm-group-canvas-h" style="<?php echo empty($s['pos_mode']) ? 'display:none;' : ''; ?>">
                                <label for="cm-setting-canvas-h">Altura del Lienzo (px)</label>
                                <input type="number" id="cm-setting-canvas-h" class="cm-prop-input" min="200" max="2000" step="10" value="<?php echo esc_attr($s['canvas_h'] ?? 760); ?>" />
                                <div style="display:flex;gap:6px;margin-top:8px;">
                                    <button type="button" id="cm-btn-auto-arrange" class="cm-btn cm-btn-outline" style="flex:1;font-size:11px;margin:0;padding:7px 4px;" title="Distribuye todos los campos automáticamente">⚡ Generar Diseño</button>
                                    <button type="button" id="cm-btn-autofit-h" class="cm-btn cm-btn-outline" style="flex:1;font-size:11px;margin:0;padding:7px 4px;" title="Ajusta la altura al contenido real">⤢ Ajustar Altura</button>
                                </div>
                            </div>
                        </div>

                        <div class="cm-prop-section">
                            <p class="cm-prop-section-title">🏛️ Estilo del Contenedor (Tarjeta) <span id="cm-editing-device-badge" style="display:none; background:#0071e3; color:#fff; font-size:10px; padding:2px 7px; border-radius:4px; margin-left:4px;"></span></p>

                            <div class="cm-prop-group">
                                <label>Ancho Máximo del Formulario</label>
                                <div style="display:flex; align-items:center; gap:8px;">
                                    <input type="range" id="cm-setting-max-width-range" min="280" max="1200" step="10" style="flex:1; accent-color:#0071e3;" />
                                    <input type="number" id="cm-setting-max-width-num" class="cm-prop-input" min="280" max="1600" step="10" style="width:76px; height:32px;" />
                                    <span style="font-size:11px; color:#64748b;">px</span>
                                </div>
                                <label style="display:flex; align-items:center; gap:6px; margin-top:6px; font-size:12px; color:#475569;">
                                    <input type="checkbox" id="cm-setting-max-width-full" /> 100% (ancho completo de la columna)
                                </label>
                                <button type="button" id="cm-inherit-max-width" class="cm-inherit-link" style="display:none; margin-top:5px; background:none; border:none; color:#0071e3; font-size:11px; cursor:pointer; padding:0; text-decoration:underline;">↺ Heredar de Escritorio</button>
                            </div>

                            <div class="cm-prop-group">
                                <label for="cm-setting-density">Densidad Vertical (Altura)</label>
                                <select id="cm-setting-density" class="cm-prop-select">
                                    <option value="compact">🤏 Compacto — formulario más bajo</option>
                                    <option value="normal" <?php selected($s['density'] ?? 'normal', 'normal'); ?>>Normal (Estándar)</option>
                                    <option value="roomy">🌬️ Espacioso — más aire</option>
                                </select>
                                <button type="button" id="cm-inherit-density" class="cm-inherit-link" style="display:none; margin-top:5px; background:none; border:none; color:#0071e3; font-size:11px; cursor:pointer; padding:0; text-decoration:underline;">↺ Heredar de Escritorio</button>
                            </div>

                            <div class="cm-prop-group">
                                <label for="cm-setting-card-preset">Preset de Tarjeta</label>
                                <select id="cm-setting-card-preset" class="cm-prop-select">
                                    <option value="modern" <?php selected($s['card_preset'] ?? 'modern', 'modern'); ?>>Moderno con Sombra</option>
                                    <option value="flat" <?php selected($s['card_preset'] ?? 'modern', 'flat'); ?>>Plano Minimalista (Flat)</option>
                                    <option value="glassmorphism" <?php selected($s['card_preset'] ?? 'modern', 'glassmorphism'); ?>>Cristal Glassmorphism (Translúcido)</option>
                                    <option value="paper" <?php selected($s['card_preset'] ?? 'modern', 'paper'); ?>>📓 Papel Cuadriculado</option>
                                    <option value="rounded" <?php selected($s['card_preset'] ?? 'modern', 'rounded'); ?>>Extra Redondeado (26px)</option>
                                </select>
                            </div>

                            <label style="display:flex;align-items:center;gap:8px;margin-bottom:14px;font-size:12px;color:#475569;cursor:pointer;">
                                <input type="checkbox" id="cm-setting-bg-transparent" <?php checked(in_array($s['bg_color'] ?? '', array('transparent', 'rgba(0, 0, 0, 0)'), true)); ?> />
                                Fondo transparente (sin tarjeta, se integra a la página)
                            </label>

                            <div class="cm-prop-group">
                                <label for="cm-setting-border-width">Grosor de Borde del Contenedor</label>
                                <select id="cm-setting-border-width" class="cm-prop-select">
                                    <option value="0" <?php selected($s['border_width'] ?? '1', '0'); ?>>0px (Sin borde)</option>
                                    <option value="1" <?php selected($s['border_width'] ?? '1', '1'); ?>>1px (Fino)</option>
                                    <option value="2" <?php selected($s['border_width'] ?? '1', '2'); ?>>2px (Medio)</option>
                                    <option value="3" <?php selected($s['border_width'] ?? '1', '3'); ?>>3px (Grueso)</option>
                                </select>
                            </div>

                            <div class="cm-prop-group">
                                <label>Color de Borde del Contenedor</label>
                                <div class="cm-color-row">
                                    <input type="color" id="cm-setting-container-border" class="cm-prop-color" value="<?php echo esc_attr($s['container_border_color'] ?? '#e2e8f0'); ?>" />
                                    <input type="text" id="cm-setting-container-border-hex" class="cm-color-hex" value="<?php echo esc_attr($s['container_border_color'] ?? '#e2e8f0'); ?>" maxlength="7" />
                                </div>
                            </div>
                        </div>

                        <div class="cm-prop-section">
                            <p class="cm-prop-section-title">🎨 Colores de Elementos</p>

                            <div class="cm-prop-group">
                                <label>Color Principal (Botón y Enfoque)</label>
                                <div class="cm-color-row">
                                    <input type="color" id="cm-setting-primary-color" class="cm-prop-color" value="<?php echo esc_attr($s['primary_color'] ?? '#0071e3'); ?>" />
                                    <input type="text" id="cm-setting-primary-color-hex" class="cm-color-hex" value="<?php echo esc_attr($s['primary_color'] ?? '#0071e3'); ?>" maxlength="7" />
                                </div>
                            </div>

                            <div class="cm-prop-group">
                                <label>Color del Texto del Botón</label>
                                <div class="cm-color-row">
                                    <input type="color" id="cm-setting-btn-text-color" class="cm-prop-color" value="<?php echo esc_attr($s['button_text_color'] ?? '#ffffff'); ?>" />
                                    <input type="text" id="cm-setting-btn-text-color-hex" class="cm-color-hex" value="<?php echo esc_attr($s['button_text_color'] ?? '#ffffff'); ?>" maxlength="7" />
                                </div>
                            </div>

                            <div class="cm-prop-group">
                                <label>Fondo de la Tarjeta</label>
                                <div class="cm-color-row">
                                    <input type="color" id="cm-setting-bg-color" class="cm-prop-color" value="<?php echo esc_attr($s['bg_color'] ?? '#ffffff'); ?>" />
                                    <input type="text" id="cm-setting-bg-color-hex" class="cm-color-hex" value="<?php echo esc_attr($s['bg_color'] ?? '#ffffff'); ?>" maxlength="7" />
                                </div>
                            </div>

                            <div class="cm-prop-group">
                                <label>Color de Etiquetas / Títulos</label>
                                <div class="cm-color-row">
                                    <input type="color" id="cm-setting-label-color" class="cm-prop-color" value="<?php echo esc_attr($s['label_color'] ?? '#0f172a'); ?>" />
                                    <input type="text" id="cm-setting-label-color-hex" class="cm-color-hex" value="<?php echo esc_attr($s['label_color'] ?? '#0f172a'); ?>" maxlength="7" />
                                </div>
                            </div>

                            <div class="cm-prop-group">
                                <label>Fondo de Campos de Entrada</label>
                                <div class="cm-color-row">
                                    <input type="color" id="cm-setting-input-bg" class="cm-prop-color" value="<?php echo esc_attr($s['input_bg_color'] ?? '#f8fafc'); ?>" />
                                    <input type="text" id="cm-setting-input-bg-hex" class="cm-color-hex" value="<?php echo esc_attr($s['input_bg_color'] ?? '#f8fafc'); ?>" maxlength="7" />
                                </div>
                            </div>

                            <div class="cm-prop-group">
                                <label>Color de Borde de Campos</label>
                                <div class="cm-color-row">
                                    <input type="color" id="cm-setting-input-border" class="cm-prop-color" value="<?php echo esc_attr($s['input_border_color'] ?? '#e2e8f0'); ?>" />
                                    <input type="text" id="cm-setting-input-border-hex" class="cm-color-hex" value="<?php echo esc_attr($s['input_border_color'] ?? '#e2e8f0'); ?>" maxlength="7" />
                                </div>
                            </div>
                        </div>

                        <div class="cm-prop-section">
                            <p class="cm-prop-section-title">🔲 Forma y Sombra</p>

                            <div class="cm-prop-group">
                                <label>Bordes Redondeados (px)</label>
                                <div class="cm-range-row">
                                    <input type="range" id="cm-setting-radius" min="0" max="30" value="<?php echo esc_attr($s['border_radius'] ?? '12'); ?>" class="cm-prop-range" />
                                    <span class="cm-range-val" id="cm-radius-val"><?php echo esc_html($s['border_radius'] ?? '12'); ?>px</span>
                                </div>
                            </div>

                            <div class="cm-prop-group">
                                <label for="cm-setting-shadow">Sombra de la Tarjeta</label>
                                <select id="cm-setting-shadow" class="cm-prop-select">
                                    <option value="none" <?php selected($s['shadow'] ?? 'md', 'none'); ?>>Sin sombra</option>
                                    <option value="sm" <?php selected($s['shadow'] ?? 'md', 'sm'); ?>>Sutil</option>
                                    <option value="md" <?php selected($s['shadow'] ?? 'md', 'md'); ?>>Moderada</option>
                                    <option value="lg" <?php selected($s['shadow'] ?? 'md', 'lg'); ?>>Prominente</option>
                                </select>
                            </div>
                        </div>

                        <div class="cm-prop-section">
                            <p class="cm-prop-section-title">🔘 Botón de Envío</p>
                            <div class="cm-prop-group">
                                <label for="cm-setting-btn-text">Texto del Botón</label>
                                <input type="text" id="cm-setting-btn-text" class="cm-prop-input" value="<?php echo esc_attr($s['button_text'] ?? 'Enviar Mensaje'); ?>" />
                            </div>
                            <div class="cm-prop-group">
                                <label for="cm-setting-btn-style">Estilo del Botón</label>
                                <select id="cm-setting-btn-style" class="cm-prop-select">
                                    <option value="gradient" <?php selected($s['button_style'] ?? 'gradient', 'gradient'); ?>>Degradado Índigo/Violeta</option>
                                    <option value="solid" <?php selected($s['button_style'] ?? 'gradient', 'solid'); ?>>Color Sólido</option>
                                    <option value="outline" <?php selected($s['button_style'] ?? 'gradient', 'outline'); ?>>Contorno (Outline)</option>
                                    <option value="rounded" <?php selected($s['button_style'] ?? 'gradient', 'rounded'); ?>>Pill (Completamente Redondeado)</option>
                                </select>
                            </div>
                            <div class="cm-prop-group">
                                <label for="cm-setting-btn-align">Posición del Botón</label>
                                <select id="cm-setting-btn-align" class="cm-prop-select">
                                    <option value="left" <?php selected($s['btn_align'] ?? 'left', 'left'); ?>>⬅ Izquierda</option>
                                    <option value="center" <?php selected($s['btn_align'] ?? 'left', 'center'); ?>>⬌ Centrado</option>
                                    <option value="right" <?php selected($s['btn_align'] ?? 'left', 'right'); ?>>➡ Derecha</option>
                                </select>
                            </div>
                            <div class="cm-prop-group">
                                <label for="cm-setting-btn-size">Tamaño del Botón</label>
                                <select id="cm-setting-btn-size" class="cm-prop-select">
                                    <option value="sm" <?php selected($s['btn_size'] ?? 'md', 'sm'); ?>>Chico</option>
                                    <option value="md" <?php selected($s['btn_size'] ?? 'md', 'md'); ?>>Normal</option>
                                    <option value="lg" <?php selected($s['btn_size'] ?? 'md', 'lg'); ?>>Grande</option>
                                </select>
                            </div>
                            <label style="display:flex;align-items:center;gap:8px;margin-bottom:14px;font-size:12px;color:#475569;cursor:pointer;">
                                <input type="checkbox" id="cm-setting-btn-fullwidth" <?php checked(!empty($s['btn_fullwidth'])); ?> />
                                Ancho completo (ocupa todo el formulario)
                            </label>
                        </div>

                        <div class="cm-prop-section">
                            <p class="cm-prop-section-title">🏷️ Créditos</p>
                            <div class="cm-prop-group">
                                <div class="cm-switch-row">
                                    <label style="margin: 0; font-size: 13px;">Mostrar "Diseñado por Ingecodex.com"</label>
                                    <label class="cm-switch">
                                        <input type="checkbox" id="cm-setting-show-credit" <?php checked($s['show_credit'] ?? true, true); ?> />
                                        <span class="cm-slider"></span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Pestaña 3: Ajustes del Formulario -->
                <div class="cm-tab-content" id="tab-form-settings">
                    <div style="padding: 20px;">
                        <div class="cm-prop-section">
                            <p class="cm-prop-section-title">ℹ️ Encabezado del Formulario</p>
                            
                            <div class="cm-prop-group">
                                <div class="cm-switch-row" style="margin-bottom: 12px;">
                                    <label style="margin: 0; font-weight: 600;">Mostrar Título y Subtítulo</label>
                                    <label class="cm-switch">
                                        <input type="checkbox" id="cm-setting-show-header" <?php checked($s['show_header'] ?? true, true); ?> />
                                        <span class="cm-slider"></span>
                                    </label>
                                </div>
                            </div>

                            <div id="cm-header-inputs-group">
                                <div class="cm-prop-group">
                                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px;">
                                        <label for="cm-setting-title" style="margin: 0;">Título del Formulario</label>
                                        <button type="button" id="cm-clear-title-btn" style="background: none; border: none; font-size: 11px; color: #ef4444; cursor: pointer; padding: 0;">✕ Limpiar</button>
                                    </div>
                                    <input type="text" id="cm-setting-title" class="cm-prop-input" value="<?php echo esc_attr($s['title'] ?? ''); ?>" placeholder="Ej. Formulario de Contacto (o dejar vacío)" />
                                </div>
                                <div class="cm-prop-group">
                                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px;">
                                        <label for="cm-setting-subtitle" style="margin: 0;">Subtítulo / Descripción</label>
                                        <button type="button" id="cm-clear-subtitle-btn" style="background: none; border: none; font-size: 11px; color: #ef4444; cursor: pointer; padding: 0;">✕ Limpiar</button>
                                    </div>
                                    <textarea id="cm-setting-subtitle" class="cm-prop-textarea" rows="3" placeholder="Ej. Selecciona el departamento al que deseas dirigir tu mensaje."><?php echo esc_textarea($s['subtitle'] ?? ''); ?></textarea>
                                </div>
                                <p style="font-size: 11px; color: #94a3b8; margin: 6px 0 0 0; line-height: 1.4;">💡 Si dejas los campos vacíos o desactivas el interruptor, no se mostrará ningún encabezado en el formulario.</p>
                            </div>
                        </div>

                        <div class="cm-prop-section" style="background: #f8faff; border-radius: 12px; padding: 16px; border: 1.5px solid #e0e7ff;">
                            <p class="cm-prop-section-title" style="color: #0066cc;">📬 Destinatarios y Envío de Correos</p>
                            
                            <div class="cm-prop-group">
                                <label for="cm-setting-dest-emails">Correo(s) de Destino del Formulario</label>
                                <input type="text" id="cm-setting-dest-emails" class="cm-prop-input" value="<?php echo esc_attr($s['destination_emails'] ?? get_option('cm_default_email', get_option('admin_email'))); ?>" placeholder="contacto@colegio.cl, direccion@colegio.cl" />
                                <p style="font-size: 11px; color: #64748b; margin: 5px 0 0 0; line-height: 1.4;">💡 Si este formulario no contiene selector de departamento (o como respaldo general), los mensajes se enviarán a estos correos separados por coma.</p>
                            </div>

                            <div class="cm-prop-group">
                                <label for="cm-setting-default-area">Nombre del Área / Asunto Predeterminado</label>
                                <input type="text" id="cm-setting-default-area" class="cm-prop-input" value="<?php echo esc_attr($s['default_area_name'] ?? 'General / Consultas'); ?>" placeholder="Ej. Solicitud General o Admisiones" />
                            </div>

                            <div class="cm-prop-group">
                                <label for="cm-setting-custom-subject">Asunto Personalizado del Correo (Opcional)</label>
                                <input type="text" id="cm-setting-custom-subject" class="cm-prop-input" value="<?php echo esc_attr($s['custom_subject'] ?? ''); ?>" placeholder="Ej. [CL] Nuevo Requerimiento desde la Web" />
                            </div>

                            <div class="cm-prop-group" style="margin-top: 14px; padding-top: 12px; border-top: 1px dashed #cbd5e1;">
                                <div class="cm-switch-row">
                                    <div>
                                        <div style="font-size: 13px; font-weight: 700; color: #1e293b;">Comprobante al Remitente</div>
                                        <div style="font-size: 11px; color: #64748b;">Enviar correo de confirmación con código de seguimiento (CL123456)</div>
                                    </div>
                                    <label class="cm-switch">
                                        <input type="checkbox" id="cm-setting-enable-autoresponder" <?php checked($s['enable_autoresponder'] ?? true, true); ?> />
                                        <span class="cm-slider"></span>
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="cm-prop-section">
                            <p class="cm-prop-section-title">✉️ Mensaje de Confirmación</p>
                            <div class="cm-prop-group">
                                <label for="cm-setting-success-msg">Mensaje tras Envío Exitoso</label>
                                <textarea id="cm-setting-success-msg" class="cm-prop-textarea" rows="3" placeholder="¡Gracias! Tu mensaje ha sido enviado exitosamente."><?php echo esc_textarea($s['success_msg'] ?? ''); ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </aside>
        </div>

        <a class="cm-credit-bar" href="https://www.ingecodex.com" target="_blank" rel="noopener" title="Visitar www.ingecodex.com">
            ⚡ Aplicación creada por <strong>www.ingecodex.com</strong><span>— haz clic para visitar</span>
        </a>
    </div>

    <!-- ═══════════════════════════════════════════
         MODAL: VISTA PREVIA
    ════════════════════════════════════════════ -->
    <div id="cm-confirm-overlay" class="cm-confirm-overlay">
        <div class="cm-confirm-box">
            <div class="cm-confirm-icon" id="cm-confirm-icon">⚠️</div>
            <h3 id="cm-confirm-title"></h3>
            <p id="cm-confirm-msg"></p>
            <div class="cm-confirm-actions">
                <button type="button" class="cm-btn cm-btn-secondary" id="cm-confirm-cancel">Cancelar</button>
                <button type="button" class="cm-btn cm-confirm-ok danger" id="cm-confirm-ok">Eliminar</button>
            </div>
        </div>
    </div>
    <div id="cm-preview-modal" style="display:none;position:fixed;inset:0;z-index:99999;background:rgba(15,23,42,0.6);align-items:center;justify-content:center;backdrop-filter:blur(4px);">
        <div style="background:#f0f4f9;border-radius:20px;width:90%;max-width:780px;max-height:90vh;overflow:hidden;display:flex;flex-direction:column;box-shadow:0 24px 64px rgba(0,0,0,0.25);">
            <div style="background:#fff;padding:16px 24px;border-bottom:1px solid #e2e8f0;display:flex;align-items:center;justify-content:space-between;flex-shrink:0;">
                <div style="display:flex;align-items:center;gap:12px;">
                    <div style="width:32px;height:32px;background:linear-gradient(135deg,#0071e3,#0066cc);border-radius:8px;display:flex;align-items:center;justify-content:center;color:#fff;font-size:14px;">👁</div>
                    <div>
                        <div style="font-size:14px;font-weight:700;color:#0f172a;">Vista Previa del Formulario</div>
                        <div style="font-size:11px;color:#94a3b8;">Desarrollado por Ingecodex (ingecodex.com)</div>
                    </div>
                </div>
                <div style="display:flex;align-items:center;gap:10px;">
                    <div style="display:flex;gap:4px;background:#f1f5f9;padding:3px;border-radius:8px;">
                        <button onclick="cmPreviewSize('100%')" style="background:#fff;border:none;padding:5px 12px;border-radius:6px;font-size:11px;font-weight:600;color:#0071e3;cursor:pointer;box-shadow:0 1px 3px rgba(0,0,0,0.1);">🖥 Escritorio</button>
                        <button onclick="cmPreviewSize('768px')" style="background:transparent;border:none;padding:5px 12px;border-radius:6px;font-size:11px;font-weight:600;color:#64748b;cursor:pointer;">📱 Tablet</button>
                        <button onclick="cmPreviewSize('390px')" style="background:transparent;border:none;padding:5px 12px;border-radius:6px;font-size:11px;font-weight:600;color:#64748b;cursor:pointer;">📲 Móvil</button>
                    </div>
                    <button onclick="document.getElementById('cm-preview-modal').style.display='none'" style="background:#fee2e2;border:none;color:#ef4444;width:32px;height:32px;border-radius:8px;cursor:pointer;font-size:16px;">✕</button>
                </div>
            </div>
            <div style="flex:1;overflow:auto;padding:24px;display:flex;justify-content:center;align-items:flex-start;">
                <iframe id="cm-preview-iframe"
                    src="<?php echo esc_url(admin_url('admin-ajax.php?action=cm_preview_form&nonce=' . wp_create_nonce('cm_preview_nonce'))); ?>"
                    style="width:100%;max-width:100%;min-height:500px;border:none;border-radius:12px;box-shadow:0 4px 24px rgba(0,0,0,0.08);background:#fff;transition:max-width 0.3s ease;">
                </iframe>
            </div>
        </div>
    </div>

    <!-- ═══════════════════════════════════════════
         MODAL: INSERTAR EN PÁGINA
    ════════════════════════════════════════════ -->
    <div id="cm-publish-modal" style="display:none;position:fixed;inset:0;z-index:99999;background:rgba(15,23,42,0.6);align-items:center;justify-content:center;backdrop-filter:blur(4px);">
        <div style="background:#fff;border-radius:20px;width:90%;max-width:680px;max-height:88vh;overflow-y:auto;box-shadow:0 24px 64px rgba(0,0,0,0.25);">
            <div style="background:linear-gradient(135deg,#0071e3,#0066cc);padding:28px 28px 24px;border-radius:20px 20px 0 0;position:relative;">
                <button onclick="document.getElementById('cm-publish-modal').style.display='none'" style="position:absolute;top:16px;right:16px;background:rgba(255,255,255,0.2);border:none;color:#fff;width:32px;height:32px;border-radius:8px;cursor:pointer;font-size:16px;">✕</button>
                <div style="font-size:28px;margin-bottom:8px;">🚀</div>
                <h2 style="color:#fff;font-size:20px;font-weight:700;margin:0 0 6px;">Publicar Formulario Ingecodex</h2>
                <p style="color:rgba(255,255,255,0.8);font-size:13px;margin:0;">Elige cómo insertar el formulario en tus páginas</p>
            </div>

            <!-- Shortcode badge -->
            <div style="padding:20px 28px;border-bottom:1px solid #f1f5f9;">
                <p style="font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;color:#94a3b8;margin:0 0 10px;">Shortcode Principal Ingecodex</p>
                <div style="display:flex;align-items:center;gap:10px;background:#f8fafc;border:2px dashed #c7d2fe;border-radius:10px;padding:14px 16px;">
                    <code style="flex:1;font-size:16px;font-weight:700;color:#0071e3;letter-spacing:0.05em;" id="cm-shortcode-text">[Formulario_Ingecodex]</code>
                    <button onclick="cmCopyShortcode()" id="cm-copy-btn" style="background:linear-gradient(135deg,#0071e3,#0066cc);border:none;color:#fff;padding:8px 16px;border-radius:8px;cursor:pointer;font-size:12px;font-weight:600;">📋 Copiar</button>
                </div>
                <p style="font-size:12px;color:#64748b;margin:8px 0 0;">Pega este shortcode en cualquier página o widget (también se reconoce <code>[formulario_contacto]</code>).</p>
            </div>

            <!-- Métodos de inserción -->
            <div style="padding:24px 28px;">
                <p style="font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;color:#94a3b8;margin:0 0 16px;">Método de Inserción</p>

                <div style="display:flex;gap:0;background:#f1f5f9;border-radius:10px;padding:3px;margin-bottom:20px;" id="cm-method-tabs">
                    <button onclick="cmShowMethod('elementor')" id="tab-elementor" style="flex:1;padding:9px;border:none;border-radius:8px;background:#fff;color:#0071e3;font-size:12px;font-weight:700;cursor:pointer;box-shadow:0 1px 4px rgba(0,0,0,0.1);">⚡ Elementor</button>
                    <button onclick="cmShowMethod('gutenberg')" id="tab-gutenberg" style="flex:1;padding:9px;border:none;border-radius:8px;background:transparent;color:#64748b;font-size:12px;font-weight:600;cursor:pointer;">📝 Gutenberg</button>
                    <button onclick="cmShowMethod('classic')" id="tab-classic" style="flex:1;padding:9px;border:none;border-radius:8px;background:transparent;color:#64748b;font-size:12px;font-weight:600;cursor:pointer;">📄 Clásico</button>
                    <button onclick="cmShowMethod('builders')" id="tab-builders" style="flex:1;padding:9px;border:none;border-radius:8px;background:transparent;color:#64748b;font-size:12px;font-weight:600;cursor:pointer;">🧩 Otros Builders</button>
                </div>

                <!-- Método: Elementor -->
                <div id="method-elementor" class="cm-method-content">
                    <div style="display:flex;gap:16px;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:12px;padding:16px;margin-bottom:16px;">
                        <div style="font-size:24px;">💡</div>
                        <div>
                            <div style="font-weight:700;color:#15803d;margin-bottom:4px;">Widget Nativo: "Formulario Ingecodex"</div>
                            <div style="font-size:13px;color:#166534;line-height:1.5;">En el panel de Elementor busca la palabra <strong>"Ingecodex"</strong> o <strong>"Formulario"</strong> y arrastra el widget directamente al lienzo.</div>
                        </div>
                    </div>
                </div>

                <!-- Método: Gutenberg -->
                <div id="method-gutenberg" class="cm-method-content" style="display:none;">
                    <p style="font-size:13px;color:#334155;">1. Agrega un bloque <strong>Shortcode</strong>.<br>2. Pega <code>[Formulario_Ingecodex]</code>.<br>3. Guarda tu página.</p>
                </div>

                <!-- Método: Clásico -->
                <div id="method-classic" class="cm-method-content" style="display:none;">
                    <p style="font-size:13px;color:#334155;">Pega <code>[Formulario_Ingecodex]</code> directamente en el contenido del editor.</p>
                </div>

                <!-- Método: Otros Builders -->
                <div id="method-builders" class="cm-method-content" style="display:none;">
                    <p style="font-size:13px;color:#334155;margin:0 0 12px;">En todos estos builders funciona igual: inserta su elemento de <strong>Shortcode / Código</strong> y pega el shortcode de arriba.</p>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
                        <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:12px 14px;"><strong style="font-size:13px;color:#1d1d1f;">Divi</strong><p style="margin:4px 0 0;font-size:12px;color:#64748b;line-height:1.5;">Módulo <em>Texto</em> o <em>Código</em> → pega el shortcode.</p></div>
                        <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:12px 14px;"><strong style="font-size:13px;color:#1d1d1f;">Beaver Builder</strong><p style="margin:4px 0 0;font-size:12px;color:#64748b;line-height:1.5;">Módulo <em>Shortcode</em> → pega el shortcode.</p></div>
                        <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:12px 14px;"><strong style="font-size:13px;color:#1d1d1f;">Oxygen Builder</strong><p style="margin:4px 0 0;font-size:12px;color:#64748b;line-height:1.5;">Elemento <em>Shortcode</em> (+) → pega el shortcode.</p></div>
                        <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:12px 14px;"><strong style="font-size:13px;color:#1d1d1f;">WPBakery</strong><p style="margin:4px 0 0;font-size:12px;color:#64748b;line-height:1.5;">Elemento <em>Text Block</em> o <em>Raw HTML</em> → pega el shortcode.</p></div>
                        <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:12px 14px;"><strong style="font-size:13px;color:#1d1d1f;">Bricks Builder</strong><p style="margin:4px 0 0;font-size:12px;color:#64748b;line-height:1.5;">Elemento <em>Shortcode</em> → pega el shortcode.</p></div>
                        <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:12px 14px;"><strong style="font-size:13px;color:#1d1d1f;">Breakdance</strong><p style="margin:4px 0 0;font-size:12px;color:#64748b;line-height:1.5;">Elemento <em>Shortcode</em> → pega el shortcode.</p></div>
                    </div>
                    <p style="font-size:12px;color:#94a3b8;margin:12px 0 0;">💡 Para elegir un formulario específico usa la versión con ID que aparece en el chip verde del editor.</p>
                </div>
            </div>

            <div style="padding:16px 28px;border-top:1px solid #f1f5f9;background:#f8fafc;border-radius:0 0 20px 20px;text-align:right;">
                <button onclick="document.getElementById('cm-publish-modal').style.display='none'" style="padding:9px 20px;background:#e2e8f0;border:none;border-radius:8px;font-size:13px;font-weight:600;color:#475569;cursor:pointer;">Cerrar</button>
            </div>
        </div>
    </div>

    <!-- ═══════════════════════════════════════════════════════════
         MODAL: GALERÍA DE PLANTILLAS & NUEVO FORMULARIO
         ═══════════════════════════════════════════════════════════ -->
    <div id="cm-gallery-modal" style="display:none;position:fixed;inset:0;z-index:99999;background:rgba(15,23,42,0.7);align-items:center;justify-content:center;backdrop-filter:blur(6px);padding:20px;box-sizing:border-box;">
        <div style="background:#ffffff;border-radius:20px;width:100%;max-width:980px;max-height:88vh;display:flex;flex-direction:column;box-shadow:0 25px 60px rgba(0,0,0,0.3);border:1px solid #e2e8f0;overflow:hidden;animation:cmScaleUp 0.25s cubic-bezier(0.16,1,0.3,1) forwards;">
            
            <!-- Header Modal -->
            <div style="padding:22px 28px;background:linear-gradient(135deg, #1e1b4b, #312e81, #0071e3);color:#fff;display:flex;align-items:center;justify-content:space-between;position:relative;">
                <div>
                    <div style="display:flex;align-items:center;gap:10px;">
                        <span style="font-size:24px;">🏛️</span>
                        <h3 style="margin:0;font-size:19px;font-weight:700;color:#fff;">Galería de Plantillas & Nuevo Formulario</h3>
                    </div>
                    <p style="margin:4px 0 0;font-size:13px;color:#c7d2fe;">Selecciona una plantilla prediseñada para comenzar al instante o crea un formulario en blanco.</p>
                </div>
                <button type="button" id="cm-close-gallery-btn" onclick="document.getElementById('cm-gallery-modal').style.display='none'" style="background:rgba(255,255,255,0.2);border:none;color:#fff;width:34px;height:34px;border-radius:8px;cursor:pointer;font-size:16px;display:flex;align-items:center;justify-content:center;transition:background 0.15s;">✕</button>
            </div>

            <!-- Toolbar de Filtro y Nombre -->
            <div style="padding:16px 28px;background:#f8fafc;border-bottom:1px solid #e2e8f0;display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:14px;">
                <div style="display:flex;align-items:center;gap:8px;flex:1;min-width:280px;">
                    <label for="cm-new-form-name" style="font-size:12.5px;font-weight:700;color:#334155;white-space:nowrap;">Nombre del Formulario:</label>
                    <input type="text" id="cm-new-form-name" class="cm-prop-input" value="Nuevo Formulario" placeholder="Ej. Contacto Admisión 2026" style="flex:1;max-width:320px;height:38px;padding:0 12px;border:1.5px solid #cbd5e1;border-radius:8px;font-size:13px;background:#fff;" />
                </div>
                <div style="display:flex;gap:6px;flex-wrap:wrap;" id="cm-gallery-filter-tabs">
                    <button type="button" class="cm-gallery-filter-btn active" data-cat="all" style="padding:6px 12px;font-size:12px;font-weight:600;border-radius:6px;border:1px solid #cbd5e1;background:#0071e3;color:#fff;cursor:pointer;">Todos</button>
                    <button type="button" class="cm-gallery-filter-btn" data-cat="Educación" style="padding:6px 12px;font-size:12px;font-weight:600;border-radius:6px;border:1px solid #cbd5e1;background:#fff;color:#475569;cursor:pointer;">Educación</button>
                    <button type="button" class="cm-gallery-filter-btn" data-cat="Negocios" style="padding:6px 12px;font-size:12px;font-weight:600;border-radius:6px;border:1px solid #cbd5e1;background:#fff;color:#475569;cursor:pointer;">Negocios</button>
                    <button type="button" class="cm-gallery-filter-btn" data-cat="Salud" style="padding:6px 12px;font-size:12px;font-weight:600;border-radius:6px;border:1px solid #cbd5e1;background:#fff;color:#475569;cursor:pointer;">Salud</button>
                    <button type="button" class="cm-gallery-filter-btn" data-cat="Servicios" style="padding:6px 12px;font-size:12px;font-weight:600;border-radius:6px;border:1px solid #cbd5e1;background:#fff;color:#475569;cursor:pointer;">Servicios</button>
                    <button type="button" class="cm-gallery-filter-btn" data-cat="Tecnología" style="padding:6px 12px;font-size:12px;font-weight:600;border-radius:6px;border:1px solid #cbd5e1;background:#fff;color:#475569;cursor:pointer;">Tecnología</button>
                    <button type="button" class="cm-gallery-filter-btn" data-cat="Marketing" style="padding:6px 12px;font-size:12px;font-weight:600;border-radius:6px;border:1px solid #cbd5e1;background:#fff;color:#475569;cursor:pointer;">Marketing</button>
                </div>
            </div>

            <!-- Catálogo de Tarjetas de Plantilla (Grid) -->
            <div style="padding:24px 28px;overflow-y:auto;max-height:calc(88vh - 200px);background:#f1f5f9;">
                <div style="display:grid;grid-template-columns:repeat(auto-fill, minmax(280px, 1fr));gap:20px;" id="cm-gallery-cards-grid">
                    <?php 
                    $templates = cm_get_templates_catalog();
                    foreach ($templates as $t) : 
                        $badge_bg = ($t['id'] === 'colegio') ? '#ecfdf5;color:#065f46;border:1px solid #a7f3d0;' : (($t['id'] === 'blank') ? '#f1f5f9;color:#475569;border:1px solid #cbd5e1;' : '#eef2ff;color:#0066cc;border:1px solid #c7d2fe;');
                    ?>
                        <div class="cm-gallery-card" data-template="<?php echo esc_attr($t['id']); ?>" data-category="<?php echo esc_attr($t['category']); ?>" style="background:#ffffff;border:1.5px solid #e2e8f0;border-radius:14px;padding:20px;display:flex;flex-direction:column;justify-content:space-between;box-shadow:0 4px 12px rgba(0,0,0,0.04);transition:all 0.2s ease;cursor:pointer;position:relative;overflow:hidden;">
                            <div>
                                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
                                    <span style="font-size:32px;"><?php echo esc_html($t['icon']); ?></span>
                                    <span style="font-size:11px;font-weight:700;padding:3px 8px;border-radius:6px;background:<?php echo $badge_bg; ?>"><?php echo esc_html($t['badge']); ?></span>
                                </div>
                                <h4 style="margin:0 0 6px 0;font-size:15px;font-weight:700;color:#0f172a;line-height:1.3;"><?php echo esc_html($t['title']); ?></h4>
                                <p style="margin:0 0 12px 0;font-size:12.5px;color:#64748b;line-height:1.45;min-height:36px;"><?php echo esc_html($t['desc']); ?></p>
                            </div>
                            
                            <div>
                                <div style="font-size:11.5px;color:#0066cc;background:#f8faff;border:1px solid #e0e7ff;padding:6px 10px;border-radius:6px;margin-bottom:14px;font-weight:600;">
                                    📌 <?php echo esc_html($t['fields_info']); ?>
                                </div>
                                <button type="button" class="cm-use-template-btn" data-template="<?php echo esc_attr($t['id']); ?>" data-default-name="<?php echo esc_attr($t['title']); ?>" style="width:100%;padding:10px 16px;background:linear-gradient(135deg, #0071e3, #0066cc);color:#fff;border:none;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:6px;box-shadow:0 2px 8px rgba(0,113,227,0.25);transition:all 0.15s ease;">
                                    ✨ Usar Esta Plantilla
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Footer Modal -->
            <div style="padding:14px 28px;background:#ffffff;border-top:1px solid #e2e8f0;display:flex;align-items:center;justify-content:space-between;">
                <span style="font-size:12px;color:#94a3b8;">Desarrollado por <strong>Ingecodex.com</strong> — Diseñado para Elementor y WordPress</span>
                <button type="button" onclick="document.getElementById('cm-gallery-modal').style.display='none'" style="padding:8px 18px;background:#f1f5f9;border:1px solid #cbd5e1;border-radius:8px;font-size:13px;font-weight:600;color:#475569;cursor:pointer;">Cancelar</button>
            </div>

        </div>
    </div>

    <!-- Modales JS helpers -->
    <script>
    function cmPreviewSize(width) {
        var iframe = document.getElementById('cm-preview-iframe');
        if (iframe) {
            iframe.style.maxWidth = width;
        }
    }
    function cmCopyShortcode() {
        var code = document.getElementById('cm-shortcode-text').innerText;
        navigator.clipboard.writeText(code).then(function() {
            var btn = document.getElementById('cm-copy-btn');
            btn.innerText = '✓ ¡Copiado!';
            btn.style.background = '#10b981';
            setTimeout(function() {
                btn.innerText = '📋 Copiar';
                btn.style.background = '';
            }, 2000);
        });
    }
    function cmShowMethod(name) {
        ['elementor', 'gutenberg', 'classic', 'builders'].forEach(function(m) {
            var el = document.getElementById('method-' + m);
            var tab = document.getElementById('tab-' + m);
            if (el) el.style.display = (m === name) ? 'block' : 'none';
            if (tab) {
                tab.style.background = (m === name) ? '#fff' : 'transparent';
                tab.style.color = (m === name) ? '#0071e3' : '#64748b';
                tab.style.fontWeight = (m === name) ? '700' : '600';
            }
        });
    }
    document.addEventListener('DOMContentLoaded', function() {
        var btnPublish = document.getElementById('cm-btn-publish-modal');
        if (btnPublish) {
            btnPublish.addEventListener('click', function() {
                var modal = document.getElementById('cm-publish-modal');
                if (modal) modal.style.display = 'flex';
            });
        }
    });
    </script>
    <?php
}

function cm_ajax_sanitize_schema($schema) {
    if (!is_array($schema)) return array('settings' => array(), 'fields' => array());
    $clean = array('settings' => array(), 'fields' => array());
    if (isset($schema['settings']) && is_array($schema['settings'])) {
        foreach ($schema['settings'] as $k => $v) {
            $key = sanitize_key($k);
            if ($key === 'device_overrides' && is_array($v)) {
                $clean_dev = array();
                foreach (array('tablet', 'mobile') as $dev) {
                    if (!empty($v[$dev]) && is_array($v[$dev])) {
                        $sub = array();
                        foreach (array('max_width', 'density') as $ok) {
                            if (!empty($v[$dev][$ok]) && $v[$dev][$ok] !== 'inherit') $sub[$ok] = sanitize_text_field(wp_unslash($v[$dev][$ok]));
                        }
                        if ($sub) $clean_dev[$dev] = $sub;
                    }
                }
                $clean['settings'][$key] = $clean_dev;
            } elseif (is_bool($v) || is_int($v)) {
                $clean['settings'][$key] = $v;
            } elseif ($key === 'success_msg') {
                $clean['settings'][$key] = sanitize_textarea_field(wp_unslash($v));
            } else {
                $clean['settings'][$key] = sanitize_text_field(wp_unslash($v));
            }
        }
    }
    if (!empty($schema['fields']) && is_array($schema['fields'])) {
        foreach ($schema['fields'] as $field) {
            if (!is_array($field)) continue;
            $f = array();
            foreach ($field as $k => $v) {
                switch ($k) {
                    case 'options':
                        $opts = array();
                        if (is_array($v)) {
                            foreach ($v as $opt) {
                                if (is_array($opt)) {
                                    $o = array('nombre' => sanitize_text_field(wp_unslash($opt['nombre'] ?? '')));
                                    if (!empty($opt['email'])) $o['email'] = sanitize_email($opt['email']);
                                    $opts[] = $o;
                                } else {
                                    $opts[] = sanitize_text_field(wp_unslash($opt));
                                }
                            }
                        }
                        $f[$k] = $opts;
                        break;
                    case 'terms_content':
                        $f[$k] = sanitize_textarea_field(wp_unslash($v));
                        break;
                    default:
                        $f[sanitize_key($k)] = is_scalar($v) ? sanitize_text_field(wp_unslash($v)) : $v;
                }
            }
            $clean['fields'][] = $f;
        }
    }
    return $clean;
}

add_action('wp_ajax_cm_save_form_schema', function () {
    check_ajax_referer('cm_contacto_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error(array('message' => 'Sin permisos'));

    $schema = json_decode(wp_unslash($_POST['schema'] ?? ''), true);
    if (!is_array($schema)) wp_send_json_error(array('message' => 'Esquema inválido'));

    $form_id   = isset($_POST['form_id']) ? sanitize_key($_POST['form_id']) : '';
    $form_name = isset($_POST['form_name']) ? sanitize_text_field(wp_unslash($_POST['form_name'])) : '';

    $saved_id = cm_save_form($form_id, $form_name, cm_ajax_sanitize_schema($schema));
    update_option('cm_current_form_id', $saved_id);

    wp_send_json_success(array('form_id' => $saved_id, 'forms' => cm_get_forms_for_select()));
});

add_action('wp_ajax_cm_new_form', function () {
    check_ajax_referer('cm_contacto_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error(array('message' => 'Sin permisos'));

    $name     = sanitize_text_field(wp_unslash($_POST['form_name'] ?? 'Nuevo Formulario'));
    $template = sanitize_key($_POST['template'] ?? 'blank');
    $schema   = cm_get_template_schema($template);
    $id       = cm_save_form('', $name, $schema);
    update_option('cm_current_form_id', $id);
    wp_send_json_success(array('form_id' => $id, 'forms' => cm_get_forms_for_select()));
});

add_action('wp_ajax_cm_duplicate_form', function () {
    check_ajax_referer('cm_contacto_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error(array('message' => 'Sin permisos'));

    $src_id = isset($_POST['form_id']) ? sanitize_key($_POST['form_id']) : '';
    $forms  = cm_get_all_forms();
    if (!isset($forms[$src_id])) wp_send_json_error(array('message' => 'Formulario no encontrado'));
    $name = $forms[$src_id]['name'] . ' (copia)';
    $id   = cm_save_form('', $name, $forms[$src_id]['schema']);
    update_option('cm_current_form_id', $id);
    wp_send_json_success(array('form_id' => $id, 'forms' => cm_get_forms_for_select()));
});

add_action('wp_ajax_cm_delete_form', function () {
    check_ajax_referer('cm_contacto_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error(array('message' => 'Sin permisos'));

    $form_id = isset($_POST['form_id']) ? sanitize_key($_POST['form_id']) : '';
    if (!cm_delete_form($form_id)) wp_send_json_error(array('message' => 'No se puede eliminar (mínimo 1 formulario)'));
    update_option('cm_current_form_id', '');
    wp_send_json_success(array('forms' => cm_get_forms_for_select()));
});

add_action('wp_ajax_cm_set_default_form', function () {
    check_ajax_referer('cm_contacto_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error(array('message' => 'Sin permisos'));

    $form_id = isset($_POST['form_id']) ? sanitize_key($_POST['form_id']) : '';
    $forms   = cm_get_all_forms();
    if (!isset($forms[$form_id])) wp_send_json_error(array('message' => 'Formulario no encontrado'));
    foreach ($forms as &$f) $f['is_default'] = false;
    unset($f);
    $forms[$form_id]['is_default'] = true;
    update_option('cm_forms', $forms);
    update_option('cm_current_form_id', $form_id);
    wp_send_json_success(array('forms' => cm_get_forms_for_select()));
});

add_action('wp_ajax_cm_preview_form', function () {
    check_ajax_referer('cm_preview_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_die('Sin permisos');

    
    $form_id = isset($_REQUEST['form']) ? sanitize_key($_REQUEST['form']) : '';
    $schema  = ($form_id && function_exists('cm_get_form')) ? cm_get_form($form_id) : cm_get_default_schema();

    require_once CM_PLUGIN_DIR . 'includes/form-renderer.php';
    $preview_atts = array('id' => $form_id);
    if (!empty($_REQUEST['preview_schema'])) {
        $decoded = json_decode(wp_unslash($_REQUEST['preview_schema']), true);
        if (is_array($decoded)) $preview_atts['schema'] = cm_ajax_sanitize_schema($decoded);
    }
    $form_html = cm_render_dynamic_form($preview_atts);

    $css_url = CM_PLUGIN_URL . 'assets/css/contacto-style.css';
    $js_url  = CM_PLUGIN_URL . 'assets/js/contacto-script.js';
    $jq_url  = includes_url('js/jquery/jquery.min.js');
    $nonce   = wp_create_nonce('cm_contacto_nonce');
    ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Vista Previa</title>
<link rel="stylesheet" href="<?php echo esc_url($css_url); ?>?v=<?php echo time(); ?>" />
    <script src="<?php echo esc_url($jq_url); ?>"></script>
<script>
var cm_ajax_object = { ajax_url: <?php echo json_encode(admin_url('admin-ajax.php')); ?>, nonce: <?php echo json_encode($nonce); ?> };
</script>
</head>
<body style="margin:0;padding:24px;background:#f1f5f9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;">
<?php echo $form_html; ?>
<script src="<?php echo esc_url($js_url); ?>?v=<?php echo time(); ?>"></script>
</body>
</html>
    <?php
    wp_die();
});
