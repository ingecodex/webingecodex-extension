<?php
if (!defined('ABSPATH')) {
    exit;
}

$departamentos = get_option('cm_departamentos', array());
$max_file_size = get_option('cm_max_file_size', 5);
?>

<div class="cm-form-container">
    <div id="cm-form-response" class="cm-response-msg" style="display: none;"></div>

    <form id="cm-contact-form" class="cm-contact-form" method="post" enctype="multipart/form-data">
        <?php wp_nonce_field('cm_contacto_nonce', 'cm_nonce_field'); ?>
        
        <!-- Campo Honeypot para evitar Spam de bots -->
        <div style="display:none !important;" aria-hidden="true">
            <input type="text" name="cm_website" tabindex="-1" autocomplete="off" />
        </div>

        <div class="cm-form-row cm-form-row-2">
            <div class="cm-form-group">
                <label for="cm_nombre"><?php _e('Nombre Completo', 'contacto-multidestino'); ?> <span class="cm-required">*</span></label>
                <div class="cm-input-wrapper">
                    <svg class="cm-input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                    <input type="text" id="cm_nombre" name="cm_nombre" class="cm-input" placeholder="Ej. Juan Pérez" required />
                </div>
            </div>

            <div class="cm-form-group">
                <label for="cm_email"><?php _e('Correo Electrónico', 'contacto-multidestino'); ?> <span class="cm-required">*</span></label>
                <div class="cm-input-wrapper">
                    <svg class="cm-input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
                    <input type="email" id="cm_email" name="cm_email" class="cm-input" placeholder="ejemplo@correo.com" required />
                </div>
            </div>
        </div>

        <div class="cm-form-row cm-form-row-2">
            <div class="cm-form-group">
                <label for="cm_telefono"><?php _e('Teléfono de Contacto', 'contacto-multidestino'); ?></label>
                <div class="cm-input-wrapper">
                    <svg class="cm-input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                    <input type="tel" id="cm_telefono" name="cm_telefono" class="cm-input" placeholder="+56 9 1234 5678" />
                </div>
            </div>

            <div class="cm-form-group">
                <label for="cm_departamento"><?php _e('Dirigido a / Departamento', 'contacto-multidestino'); ?> <span class="cm-required">*</span></label>
                <div class="cm-input-wrapper">
                    <svg class="cm-input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                    <select id="cm_departamento" name="cm_departamento" class="cm-select" required>
                        <option value=""><?php _e('-- Selecciona el destinatario --', 'contacto-multidestino'); ?></option>
                        <?php if (!empty($departamentos)) : ?>
                            <?php foreach ($departamentos as $index => $dep) : ?>
                                <option value="<?php echo esc_attr($index); ?>">
                                    <?php echo esc_html($dep['nombre']); ?>
                                </option>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <option value="0"><?php _e('Consultas Generales', 'contacto-multidestino'); ?></option>
                        <?php endif; ?>
                    </select>
                </div>
            </div>
        </div>

        <div class="cm-form-group">
            <label for="cm_mensaje"><?php _e('Mensaje o Comentario', 'contacto-multidestino'); ?> <span class="cm-required">*</span></label>
            <div class="cm-textarea-wrapper">
                <textarea id="cm_mensaje" name="cm_mensaje" class="cm-textarea" rows="5" placeholder="Escribe aquí tu consulta o comentario..." required></textarea>
            </div>
        </div>

        <div class="cm-form-group">
            <label for="cm_adjunto"><?php _e('Adjuntar Archivo (opcional)', 'contacto-multidestino'); ?></label>
            <div class="cm-file-dropzone">
                <input type="file" id="cm_adjunto" name="cm_adjunto" class="cm-file-input" accept=".jpg,.jpeg,.png,.pdf,.doc,.docx,.xls,.xlsx,.zip" />
                <div class="cm-file-content">
                    <svg class="cm-file-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="17 8 12 3 7 8"></polyline><line x1="12" y1="3" x2="12" y2="15"></line></svg>
                    <span class="cm-file-text"><?php _e('Arrastra o haz clic para subir tu archivo', 'contacto-multidestino'); ?></span>
                    <small class="cm-field-help"><?php printf(__('PDF, DOCX, XLSX, JPG, PNG, ZIP. Máx %d MB.', 'contacto-multidestino'), $max_file_size); ?></small>
                </div>
            </div>
        </div>

        <div class="cm-form-submit-row">
            <button type="submit" id="cm-submit-btn" class="cm-submit-button">
                <svg class="cm-send-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
                <span class="cm-btn-text"><?php _e('Enviar Mensaje', 'contacto-multidestino'); ?></span>
                <span class="cm-btn-spinner" style="display: none;"></span>
            </button>
        </div>
    </form>
</div>
