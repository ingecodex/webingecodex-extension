(function($) {
    'use strict';

    $(document).ready(function() {

        $('.cm-contact-form').each(function() {
        var $form       = $(this);
        var $response   = $form.closest('.cm-form-container').find('.cm-response-msg').first();
        var $submitBtn  = $form.find('.cm-submit-button');
        var $btnText    = $submitBtn.find('.cm-btn-text');
        var $btnSpinner = $submitBtn.find('.cm-btn-spinner');

        if (!$form.length) return;

        $(document).on('click', '.cm-open-terms-link', function(e) {
            e.preventDefault();
            e.stopPropagation();
            var targetModalId = $(this).data('modal-target');
            if (targetModalId) {
                $('#' + targetModalId).fadeIn(200).css('display', 'flex');
                $('body').css('overflow', 'hidden');
            }
        });

        $(document).on('click', '.cm-close-terms-btn', function(e) {
            e.preventDefault();
            e.stopPropagation();
            var targetModalId = $(this).data('modal-target');
            if (targetModalId) {
                $('#' + targetModalId).fadeOut(150);
                $('body').css('overflow', '');
            }
        });

        $(document).on('click', '.cm-terms-modal-backdrop', function(e) {
            if ($(e.target).hasClass('cm-terms-modal-backdrop')) {
                $(this).fadeOut(150);
                $('body').css('overflow', '');
            }
        });

        $(document).on('click', '.cm-accept-terms-btn', function(e) {
            e.preventDefault();
            var targetModalId = $(this).data('modal-target');
            var checkboxId    = $(this).data('checkbox-id');

            if (checkboxId) {
                $('#' + checkboxId).prop('checked', true).trigger('change');
            }
            if (targetModalId) {
                $('#' + targetModalId).fadeOut(150);
                $('body').css('overflow', '');
            }
        });

        $(document).on('change', '.cm-file-input', function() {
            var $input    = $(this);
            var $dropzone = $input.closest('.cm-file-dropzone');
            var $text     = $dropzone.find('.cm-file-text');
            var $help     = $dropzone.find('.cm-field-help');

            if (this.files && this.files.length > 0) {
                var file = this.files[0];
                var sizeStr = (file.size < 1048576)
                    ? (file.size / 1024).toFixed(1) + ' KB'
                    : (file.size / 1048576).toFixed(2) + ' MB';

                $dropzone.addClass('cm-file-selected').css({
                    'border-color': 'var(--cm-primary, #4f46e5)',
                    'background-color': '#eef2ff'
                });

                $text.html('✅ <strong>' + escapeHtml(file.name) + '</strong> (' + sizeStr + ')');
                $help.html('<span style="color: #4f46e5; cursor: pointer; text-decoration: underline;" class="cm-clear-file">Haz clic aquí para cambiar o quitar el archivo</span>');
            } else {
                resetDropzone($dropzone);
            }
        });

        $(document).on('click', '.cm-clear-file', function(e) {
            e.preventDefault();
            e.stopPropagation();
            var $dropzone = $(this).closest('.cm-file-dropzone');
            var $input    = $dropzone.find('.cm-file-input');
            $input.val('');
            resetDropzone($dropzone);
        });

        function resetDropzone($dropzone) {
            $dropzone.removeClass('cm-file-selected').css({
                'border-color': '',
                'background-color': ''
            });
            $dropzone.find('.cm-file-text').text('Arrastra o haz clic para subir tu archivo');
            $dropzone.find('.cm-field-help').text('PDF, DOCX, XLSX, JPG, PNG, ZIP. Máx 5 MB.');
        }

        $(document).on('dragover dragenter', '.cm-file-dropzone', function(e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).css({
                'border-color': 'var(--cm-primary, #4f46e5)',
                'background-color': '#eef2ff',
                'transform': 'scale(1.01)'
            });
        });

        $(document).on('dragleave drop', '.cm-file-dropzone', function(e) {
            e.preventDefault();
            e.stopPropagation();
            if (!$(this).hasClass('cm-file-selected')) {
                $(this).css({
                    'border-color': '',
                    'background-color': '',
                    'transform': ''
                });
            } else {
                $(this).css({ 'transform': '' });
            }
        });

        $form.on('submit', function(e) {
            e.preventDefault();

            $response.hide().removeClass('cm-success cm-error').html('');

            var formData = new FormData(this);
            formData.append('action', 'cm_submit_form');
            var formId = this.getAttribute('data-form-id');
            if (formId) {
                formData.append('cm_form_id', formId);
            }
            if (typeof cm_ajax_object !== 'undefined' && cm_ajax_object.nonce) {
                formData.append('cm_nonce', cm_ajax_object.nonce);
            }

            $submitBtn.prop('disabled', true);
            var originalBtnText = $btnText.text();
            var sendingText = (typeof cm_ajax_object !== 'undefined' && cm_ajax_object.strings && cm_ajax_object.strings.sending)
                ? cm_ajax_object.strings.sending
                : 'Enviando...';

            $btnText.text(sendingText);
            $btnSpinner.show();

            var ajaxUrl = (typeof cm_ajax_object !== 'undefined' && cm_ajax_object.ajax_url)
                ? cm_ajax_object.ajax_url
                : '/wp-admin/admin-ajax.php';

            $.ajax({
                url: ajaxUrl,
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(res) {
                    $btnSpinner.hide();
                    $submitBtn.prop('disabled', false);
                    $btnText.text(originalBtnText);

                    if (res.success) {
                        var successHtml = '<div style="display:flex;align-items:flex-start;gap:12px;text-align:left;">' +
                            '<div style="font-size:22px;line-height:1;margin-top:2px;">✅</div>' +
                            '<div style="flex:1;">' +
                                '<div style="font-size:15px;font-weight:700;color:#065f46;line-height:1.4;">' + (res.data.message || '¡Tu mensaje ha sido enviado exitosamente!') + '</div>' +
                                (res.data.ticket_code ? '<div style="margin-top:10px;padding:10px 14px;background:#ffffff;border:1.5px dashed #10b981;border-radius:8px;display:inline-block;"><span style="font-size:11px;font-weight:700;color:#047857;text-transform:uppercase;letter-spacing:0.05em;display:block;">Código de Seguimiento / Comprobante:</span><code style="font-family:monospace;font-size:17px;font-weight:900;color:#065f46;letter-spacing:2px;display:inline-block;margin-top:3px;">' + res.data.ticket_code + '</code></div>' : '') +
                            '</div>' +
                        '</div>';

                        $response.addClass('cm-success').html(successHtml).slideDown();
                        $form[0].reset();
                        $form.find('.cm-file-dropzone').each(function() {
                            resetDropzone($(this));
                        });

                        $('html, body').animate({
                            scrollTop: $response.offset().top - 80
                        }, 400);
                    } else {
                        var errorMsg = res.data && res.data.message ? res.data.message : 'Ocurrió un error al enviar el formulario.';
                        $response.addClass('cm-error').html(errorMsg).slideDown();
                    }
                },
                error: function() {
                    $btnSpinner.hide();
                    $submitBtn.prop('disabled', false);
                    $btnText.text(originalBtnText);
                    $response.addClass('cm-error').html('Error de conexión al enviar el formulario. Por favor inténtalo de nuevo.').slideDown();
                }
            });
        });

        function escapeHtml(text) {
            var map = {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            };
            return text.replace(/[&<>"']/g, function(m) { return map[m]; });
        }
        });
    });

})(jQuery);
