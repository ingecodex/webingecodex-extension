<?php
/**
 * Ingecodex Form — Base de Datos de Envíos y Seguimiento de Casos
 * Gestión de tablas MySQL para registrar cada mensaje y su historial de estados.
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Crea o actualiza las tablas personalizadas de base de datos para envíos y seguimiento.
 */
function cm_create_database_tables() {
    global $wpdb;

    $charset_collate = $wpdb->get_charset_collate();
    $table_submissions = $wpdb->prefix . 'cm_form_submissions';
    $table_updates     = $wpdb->prefix . 'cm_case_updates';

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    // Tabla principal de envíos
    $sql_submissions = "CREATE TABLE $table_submissions (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        ticket_code varchar(32) NOT NULL,
        form_id varchar(64) NOT NULL DEFAULT '',
        form_name varchar(255) NOT NULL DEFAULT '',
        sender_name varchar(255) DEFAULT '',
        sender_email varchar(255) DEFAULT '',
        sender_phone varchar(100) DEFAULT '',
        department varchar(255) DEFAULT '',
        subject varchar(255) DEFAULT '',
        submitted_data longtext DEFAULT '',
        attachments longtext DEFAULT '',
        status varchar(50) NOT NULL DEFAULT 'recibido',
        ip_address varchar(100) DEFAULT '',
        user_agent text DEFAULT '',
        created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        UNIQUE KEY ticket_code (ticket_code),
        KEY form_id (form_id),
        KEY status (status),
        KEY created_at (created_at)
    ) $charset_collate;";

    // Tabla de actualizaciones / historial de cada caso
    $sql_updates = "CREATE TABLE $table_updates (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        submission_id bigint(20) unsigned NOT NULL,
        ticket_code varchar(32) NOT NULL,
        author_name varchar(255) NOT NULL DEFAULT 'Sistema',
        status varchar(50) NOT NULL DEFAULT '',
        action_type varchar(50) NOT NULL DEFAULT 'update',
        note longtext NOT NULL,
        is_public tinyint(1) NOT NULL DEFAULT 1,
        notified_user tinyint(1) NOT NULL DEFAULT 0,
        created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        KEY submission_id (submission_id),
        KEY ticket_code (ticket_code),
        KEY created_at (created_at)
    ) $charset_collate;";

    dbDelta($sql_submissions);
    dbDelta($sql_updates);

    update_option('cm_db_version', '2.4.8');
}

/**
 * Obtiene los estados posibles del caso con sus etiquetas, colores e íconos.
 */
function cm_get_case_statuses() {
    return array(
        'recibido' => array(
            'label'       => __('Recibido', 'contacto-multidestino'),
            'description' => __('Formulario ingresado, a la espera de confirmación del área.', 'contacto-multidestino'),
            'color'       => '#2563eb', // Azul
            'bg_color'    => '#eff6ff',
            'border'      => '#93c5fd',
            'icon'        => '📥',
            'step'        => 1,
        ),
        'en_revision' => array(
            'label'       => __('En Revisión', 'contacto-multidestino'),
            'description' => __('El área responsable está revisando los antecedentes.', 'contacto-multidestino'),
            'color'       => '#7c3aed', // Púrpura
            'bg_color'    => '#f5f3ff',
            'border'      => '#c4b5fd',
            'icon'        => '🔍',
            'step'        => 2,
        ),
        'en_proceso' => array(
            'label'       => __('En Proceso / Gestión', 'contacto-multidestino'),
            'description' => __('El caso se encuentra en trámite activo de gestión.', 'contacto-multidestino'),
            'color'       => '#0284c7', // Cyan
            'bg_color'    => '#f0f9ff',
            'border'      => '#7dd3fc',
            'icon'        => '⚙️',
            'step'        => 3,
        ),
        'pendiente_usuario' => array(
            'label'       => __('Requiere Acción / Presencia del Solicitante', 'contacto-multidestino'),
            'description' => __('Se solicita información adicional o la presencia física de la persona.', 'contacto-multidestino'),
            'color'       => '#d97706', // Ámbar / Alerta
            'bg_color'    => '#fffbeb',
            'border'      => '#fde68a',
            'icon'        => '⚠️',
            'step'        => 3,
        ),
        'resuelto' => array(
            'label'       => __('Resuelto / Finalizado', 'contacto-multidestino'),
            'description' => __('El caso fue gestionado y concluido satisfactoriamente.', 'contacto-multidestino'),
            'color'       => '#16a34a', // Verde
            'bg_color'    => '#f0fdf4',
            'border'      => '#86efac',
            'icon'        => '✅',
            'step'        => 4,
        ),
        'cerrado' => array(
            'label'       => __('Cerrado / Desestimado', 'contacto-multidestino'),
            'description' => __('El caso se encuentra cerrado.', 'contacto-multidestino'),
            'color'       => '#475569', // Gris oscuro
            'bg_color'    => '#f8fafc',
            'border'      => '#cbd5e1',
            'icon'        => '🔒',
            'step'        => 4,
        ),
    );
}

/**
 * Inserta un nuevo envío en la base de datos y crea su primer registro histórico.
 */
function cm_insert_submission($args = array()) {
    global $wpdb;
    $table = $wpdb->prefix . 'cm_form_submissions';

    $ticket_code     = !empty($args['ticket_code']) ? sanitize_text_field($args['ticket_code']) : cm_generate_ticket_code();
    $form_id         = !empty($args['form_id']) ? sanitize_text_field($args['form_id']) : 'principal';
    $form_name       = !empty($args['form_name']) ? sanitize_text_field($args['form_name']) : 'Formulario';
    $sender_name     = !empty($args['sender_name']) ? sanitize_text_field($args['sender_name']) : '';
    $sender_email    = !empty($args['sender_email']) ? sanitize_email($args['sender_email']) : '';
    $sender_phone    = !empty($args['sender_phone']) ? sanitize_text_field($args['sender_phone']) : '';
    $department      = !empty($args['department']) ? sanitize_text_field($args['department']) : 'General';
    $subject         = !empty($args['subject']) ? sanitize_text_field($args['subject']) : '';
    $submitted_data  = !empty($args['submitted_data']) ? (is_string($args['submitted_data']) ? $args['submitted_data'] : wp_json_encode($args['submitted_data'])) : '{}';
    $attachments     = !empty($args['attachments']) ? (is_string($args['attachments']) ? $args['attachments'] : wp_json_encode($args['attachments'])) : '';
    $status          = !empty($args['status']) ? sanitize_key($args['status']) : 'recibido';
    $ip_address      = !empty($_SERVER['REMOTE_ADDR']) ? sanitize_text_field($_SERVER['REMOTE_ADDR']) : '';
    $user_agent      = !empty($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(substr($_SERVER['HTTP_USER_AGENT'], 0, 500)) : '';
    $now             = current_time('mysql');

    // Asegurar que las tablas existan
    if ($wpdb->get_var("SHOW TABLES LIKE '$table'") !== $table) {
        cm_create_database_tables();
    }

    $result = $wpdb->insert(
        $table,
        array(
            'ticket_code'    => $ticket_code,
            'form_id'        => $form_id,
            'form_name'      => $form_name,
            'sender_name'    => $sender_name,
            'sender_email'   => $sender_email,
            'sender_phone'   => $sender_phone,
            'department'     => $department,
            'subject'        => $subject,
            'submitted_data' => $submitted_data,
            'attachments'    => $attachments,
            'status'         => $status,
            'ip_address'     => $ip_address,
            'user_agent'     => $user_agent,
            'created_at'     => $now,
            'updated_at'     => $now,
        ),
        array('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')
    );

    if ($result) {
        $submission_id = $wpdb->insert_id;

        // Crear primer hito en el historial del caso
        cm_add_case_update(array(
            'submission_id' => $submission_id,
            'ticket_code'   => $ticket_code,
            'author_name'   => 'Sistema Web',
            'status'        => $status,
            'action_type'   => 'created',
            'note'          => sprintf(__('Formulario recibido correctamente y asignado al área de %s.', 'contacto-multidestino'), $department),
            'is_public'     => 1,
            'notified_user' => 1,
        ));

        return array(
            'id'          => $submission_id,
            'ticket_code' => $ticket_code,
        );
    }

    return false;
}

/**
 * Añade una actualización o evento en el historial del caso.
 */
function cm_add_case_update($args = array()) {
    global $wpdb;
    $table = $wpdb->prefix . 'cm_case_updates';

    $submission_id = !empty($args['submission_id']) ? absint($args['submission_id']) : 0;
    $ticket_code   = !empty($args['ticket_code']) ? sanitize_text_field($args['ticket_code']) : '';
    $author_name   = !empty($args['author_name']) ? sanitize_text_field($args['author_name']) : 'Administrador';
    $status        = !empty($args['status']) ? sanitize_key($args['status']) : '';
    $action_type   = !empty($args['action_type']) ? sanitize_key($args['action_type']) : 'update';
    $note          = !empty($args['note']) ? wp_kses_post($args['note']) : '';
    $is_public     = isset($args['is_public']) ? (int)$args['is_public'] : 1;
    $notified_user = isset($args['notified_user']) ? (int)$args['notified_user'] : 0;
    $now           = current_time('mysql');

    if (!$submission_id && $ticket_code) {
        $sub = cm_get_submission_by_code($ticket_code);
        if ($sub) {
            $submission_id = $sub->id;
        }
    }

    if (!$submission_id) {
        return false;
    }

    $inserted = $wpdb->insert(
        $table,
        array(
            'submission_id' => $submission_id,
            'ticket_code'   => $ticket_code,
            'author_name'   => $author_name,
            'status'        => $status,
            'action_type'   => $action_type,
            'note'          => $note,
            'is_public'     => $is_public,
            'notified_user' => $notified_user,
            'created_at'    => $now,
        ),
        array('%d', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%s')
    );

    // Actualizar estado y fecha en la tabla principal
    if ($inserted && $status) {
        $wpdb->update(
            $wpdb->prefix . 'cm_form_submissions',
            array(
                'status'     => $status,
                'updated_at' => $now,
            ),
            array('id' => $submission_id),
            array('%s', '%s'),
            array('%d')
        );
    }

    return $inserted ? $wpdb->insert_id : false;
}

/**
 * Obtiene un caso por su ID.
 */
function cm_get_submission_by_id($id) {
    global $wpdb;
    $table = $wpdb->prefix . 'cm_form_submissions';
    $id = absint($id);
    return $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", $id));
}

/**
 * Obtiene un caso por su Código de Seguimiento (Ticket).
 */
function cm_get_submission_by_code($ticket_code) {
    global $wpdb;
    $table = $wpdb->prefix . 'cm_form_submissions';
    $ticket_code = sanitize_text_field(trim($ticket_code));
    if (!$ticket_code) return null;

    return $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE ticket_code = %s", $ticket_code));
}

/**
 * Obtiene el historial de eventos de un caso.
 */
function cm_get_case_updates($submission_id_or_code, $public_only = false) {
    global $wpdb;
    $table = $wpdb->prefix . 'cm_case_updates';

    if (is_numeric($submission_id_or_code)) {
        $id = absint($submission_id_or_code);
        $where = $public_only ? "WHERE submission_id = $id AND is_public = 1" : "WHERE submission_id = $id";
    } else {
        $code = sanitize_text_field(trim($submission_id_or_code));
        $where = $public_only ? $wpdb->prepare("WHERE ticket_code = %s AND is_public = 1", $code) : $wpdb->prepare("WHERE ticket_code = %s", $code);
    }

    return $wpdb->get_results("SELECT * FROM $table $where ORDER BY created_at ASC");
}

/**
 * Obtiene la lista de envíos con filtros y paginación para el panel de administración.
 */
function cm_get_submissions($args = array()) {
    global $wpdb;
    $table = $wpdb->prefix . 'cm_form_submissions';

    // Asegurar que la tabla exista
    if ($wpdb->get_var("SHOW TABLES LIKE '$table'") !== $table) {
        cm_create_database_tables();
    }

    $defaults = array(
        'form_id'    => '',
        'status'     => '',
        'department' => '',
        'search'     => '',
        'limit'      => 20,
        'offset'     => 0,
        'orderby'    => 'created_at',
        'order'      => 'DESC',
    );
    $args = wp_parse_args($args, $defaults);

    $where_clauses = array('1=1');
    $query_params  = array();

    if (!empty($args['form_id'])) {
        $where_clauses[] = 'form_id = %s';
        $query_params[]  = sanitize_text_field($args['form_id']);
    }

    if (!empty($args['status'])) {
        $where_clauses[] = 'status = %s';
        $query_params[]  = sanitize_text_field($args['status']);
    }

    if (!empty($args['department'])) {
        $where_clauses[] = 'department = %s';
        $query_params[]  = sanitize_text_field($args['department']);
    }

    if (!empty($args['search'])) {
        $search_term = '%' . $wpdb->esc_like(trim($args['search'])) . '%';
        $where_clauses[] = '(ticket_code LIKE %s OR sender_name LIKE %s OR sender_email LIKE %s OR department LIKE %s OR subject LIKE %s)';
        $query_params[]  = $search_term;
        $query_params[]  = $search_term;
        $query_params[]  = $search_term;
        $query_params[]  = $search_term;
        $query_params[]  = $search_term;
    }

    $where_sql = implode(' AND ', $where_clauses);
    $orderby   = in_array(strtoupper($args['orderby']), array('ID', 'CREATED_AT', 'UPDATED_AT', 'TICKET_CODE', 'STATUS')) ? $args['orderby'] : 'created_at';
    $order     = strtoupper($args['order']) === 'ASC' ? 'ASC' : 'DESC';
    $limit     = absint($args['limit']);
    $offset    = absint($args['offset']);

    $sql = "SELECT * FROM $table WHERE $where_sql ORDER BY $orderby $order LIMIT $limit OFFSET $offset";

    if (!empty($query_params)) {
        $sql = $wpdb->prepare($sql, $query_params);
    }

    $items = $wpdb->get_results($sql);

    // Contar total
    $count_sql = "SELECT COUNT(*) FROM $table WHERE $where_sql";
    if (!empty($query_params)) {
        $count_sql = $wpdb->prepare($count_sql, $query_params);
    }
    $total = (int)$wpdb->get_var($count_sql);

    return array(
        'items' => $items,
        'total' => $total,
    );
}

/**
 * Obtiene estadísticas generales de envíos para el dashboard.
 */
function cm_get_submission_stats($department = '') {
    global $wpdb;
    $table = $wpdb->prefix . 'cm_form_submissions';

    if ($wpdb->get_var("SHOW TABLES LIKE '$table'") !== $table) {
        return array(
            'total'             => 0,
            'recibido'          => 0,
            'en_revision'       => 0,
            'en_proceso'        => 0,
            'pendiente_usuario' => 0,
            'resuelto'          => 0,
            'cerrado'           => 0,
        );
    }

    $where = '1=1';
    if (!empty($department)) {
        $where = $wpdb->prepare("department = %s", sanitize_text_field($department));
    }

    $results = $wpdb->get_results("SELECT status, COUNT(*) as count FROM $table WHERE $where GROUP BY status");

    $stats = array(
        'total'             => 0,
        'recibido'          => 0,
        'en_revision'       => 0,
        'en_proceso'        => 0,
        'pendiente_usuario' => 0,
        'resuelto'          => 0,
        'cerrado'           => 0,
    );

    foreach ($results as $row) {
        if (isset($stats[$row->status])) {
            $stats[$row->status] = (int)$row->count;
        }
        $stats['total'] += (int)$row->count;
    }

    return $stats;
}

/**
 * Obtiene métricas analíticas avanzadas, desglose por departamentos y actividad en vivo para el Dashboard.
 */
function cm_get_dashboard_analytics() {
    global $wpdb;
    $sub_table = $wpdb->prefix . 'cm_form_submissions';
    $upd_table = $wpdb->prefix . 'cm_case_updates';

    $stats = cm_get_submission_stats();
    
    // Agrupación ejecutiva
    $iniciados   = (int)$stats['recibido'];
    $continuidad = (int)($stats['en_revision'] + $stats['en_proceso']);
    $pendientes  = (int)$stats['pendiente_usuario'];
    $finalizados = (int)($stats['resuelto'] + $stats['cerrado']);
    $total       = (int)$stats['total'];
    $tasa_cierre = $total > 0 ? round(($finalizados / $total) * 100, 1) : 0;

    // Desglose por Departamento
    $dept_rows = $wpdb->get_results("
        SELECT department, 
               COUNT(*) as total_cases,
               SUM(CASE WHEN status = 'recibido' THEN 1 ELSE 0 END) as count_iniciados,
               SUM(CASE WHEN status IN ('en_revision', 'en_proceso') THEN 1 ELSE 0 END) as count_continuidad,
               SUM(CASE WHEN status = 'pendiente_usuario' THEN 1 ELSE 0 END) as count_pendientes,
               SUM(CASE WHEN status IN ('resuelto', 'cerrado') THEN 1 ELSE 0 END) as count_finalizados
        FROM $sub_table 
        GROUP BY department 
        ORDER BY total_cases DESC
    ");

    // Feed de Actividad Reciente en Vivo (últimas 15 acciones de todas las áreas)
    $recent_activity = $wpdb->get_results("
        SELECT u.*, s.sender_name, s.department as current_department 
        FROM $upd_table u 
        LEFT JOIN $sub_table s ON u.submission_id = s.id 
        ORDER BY u.created_at DESC 
        LIMIT 15
    ");

    return array(
        'total'           => $total,
        'iniciados'       => $iniciados,
        'continuidad'     => $continuidad,
        'pendientes'      => $pendientes,
        'finalizados'     => $finalizados,
        'tasa_cierre'     => $tasa_cierre,
        'departments'     => $dept_rows ? $dept_rows : array(),
        'recent_activity' => $recent_activity ? $recent_activity : array(),
    );
}

/**
 * Obtiene los casos organizados por estado para el Tablero Kanban visual del Dashboard.
 */
function cm_get_kanban_columns_data() {
    global $wpdb;
    $table = $wpdb->prefix . 'cm_form_submissions';

    $iniciados   = $wpdb->get_results("SELECT * FROM $table WHERE status = 'recibido' ORDER BY updated_at DESC LIMIT 25");
    $continuidad = $wpdb->get_results("SELECT * FROM $table WHERE status IN ('en_revision', 'en_proceso') ORDER BY updated_at DESC LIMIT 25");
    $pendientes  = $wpdb->get_results("SELECT * FROM $table WHERE status = 'pendiente_usuario' ORDER BY updated_at DESC LIMIT 25");
    $finalizados = $wpdb->get_results("SELECT * FROM $table WHERE status IN ('resuelto', 'cerrado') ORDER BY updated_at DESC LIMIT 25");

    return array(
        'iniciados'   => $iniciados ? $iniciados : array(),
        'continuidad' => $continuidad ? $continuidad : array(),
        'pendientes'  => $pendientes ? $pendientes : array(),
        'finalizados' => $finalizados ? $finalizados : array(),
    );
}

/**
 * Comprueba si el usuario actual o el ID especificado tiene perfil de Director / Auditor Institucional.
 */
function cm_is_director($user_id = 0) {
    if (!$user_id) $user_id = get_current_user_id();
    if (!$user_id) return false;
    return get_user_meta($user_id, 'cm_user_profile', true) === 'director';
}

/**
 * Comprueba si el usuario tiene permiso para ver el Dashboard Global y todos los casos (Superadmin o Director).
 */
function cm_can_view_global_dashboard($user_id = 0) {
    if (!$user_id) $user_id = get_current_user_id();
    if (!$user_id) return false;
    return user_can($user_id, 'manage_options') || cm_is_director($user_id);
}

/**
 * Obtiene el departamento asignado al usuario actual si es Encargado de Área.
 * Retorna cadena vacía para Superadmin y Directores (acceso global a todas las áreas).
 */
function cm_get_current_user_assigned_department() {
    $current_user_id = get_current_user_id();
    if (!$current_user_id) return '';

    // Superadmin y Directores tienen acceso global a todos los casos
    if (current_user_can('manage_options') || cm_is_director($current_user_id)) {
        return '';
    }

    $deps = cm_get_available_departments(false);
    foreach ($deps as $name => $d) {
        if (!empty($d['user_id']) && (int)$d['user_id'] === (int)$current_user_id) {
            return $name;
        }
    }

    return '';
}

/**
 * Obtiene la lista unificada de áreas/departamentos disponibles en el sistema.
 * @param bool $only_enabled Si es true, retorna solo las áreas activas/habilitadas.
 */
function cm_get_available_departments($only_enabled = false) {
    $departments = array();

    // 1. Áreas registradas manualmente por el Superadmin
    $registry = get_option('cm_departments_registry', array());
    if (is_array($registry) && !empty($registry)) {
        foreach ($registry as $key => $dep) {
            $name    = is_array($dep) ? ($dep['name'] ?? $key) : $dep;
            $enabled = is_array($dep) ? (!isset($dep['enabled']) || $dep['enabled']) : true;
            if ($only_enabled && !$enabled) continue;

            $departments[$name] = array(
                'id'       => is_array($dep) ? ($dep['id'] ?? sanitize_title($name)) : sanitize_title($name),
                'name'     => $name,
                'emails'   => is_array($dep) ? ($dep['emails'] ?? '') : '',
                'user_id'  => is_array($dep) ? ($dep['user_id'] ?? 0) : 0,
                'user'     => is_array($dep) ? ($dep['user'] ?? '') : '',
                'enabled'  => $enabled ? 1 : 0,
            );
        }
    }

    // 2. Extraer áreas configuradas dentro de cada formulario si aún no existen en el registro
    $forms = function_exists('cm_get_all_forms') ? cm_get_all_forms() : array();
    foreach ($forms as $f) {
        $schema = $f['schema'] ?? array();
        $fields = $schema['fields'] ?? array();
        foreach ($fields as $field) {
            if (($field['type'] ?? '') === 'department' || ($field['type'] ?? '') === 'select') {
                $options = $field['options'] ?? array();
                foreach ($options as $opt) {
                    $opt_name = is_array($opt) ? ($opt['nombre'] ?? '') : $opt;
                    $opt_emails = is_array($opt) ? ($opt['email'] ?? '') : '';
                    if ($opt_name && !isset($departments[$opt_name])) {
                        $departments[$opt_name] = array(
                            'id'      => sanitize_title($opt_name),
                            'name'    => $opt_name,
                            'emails'  => $opt_emails,
                            'user_id' => 0,
                            'user'    => 'Administrador General',
                            'enabled' => 1,
                        );
                    }
                }
            }
        }
        // Área por defecto del formulario
        $default_area = $schema['settings']['default_area_name'] ?? '';
        if ($default_area && !isset($departments[$default_area])) {
            $departments[$default_area] = array(
                'id'      => sanitize_title($default_area),
                'name'    => $default_area,
                'emails'  => $schema['settings']['destination_emails'] ?? '',
                'user_id' => 0,
                'user'    => 'Administrador General',
                'enabled' => 1,
            );
        }
    }

    // Si aún está vacío, proveer áreas estándar
    if (empty($departments)) {
        $defaults = array(
            'Dirección General'       => 'direccion@ejemplo.com',
            'Atención al Cliente'     => 'atencion@ejemplo.com',
            'Soporte Técnico'         => 'soporte@ejemplo.com',
            'Administración y Finanzas'=> 'finanzas@ejemplo.com',
            'Convivencia Escolar'     => 'convivencia@ejemplo.com',
        );
        foreach ($defaults as $d => $em) {
            $departments[$d] = array(
                'id'      => sanitize_title($d),
                'name'    => $d,
                'emails'  => $em,
                'user_id' => 0,
                'user'    => 'Administrador General',
                'enabled' => 1,
            );
        }
    }

    return $departments;
}

/**
 * Guarda o actualiza un departamento en el registro del Superadmin.
 */
function cm_save_department_entry($dept_data) {
    $name = sanitize_text_field(trim($dept_data['name'] ?? ''));
    if (!$name) return false;

    $registry = cm_get_available_departments(false);
    $id = !empty($dept_data['id']) ? sanitize_title($dept_data['id']) : sanitize_title($name);

    $user_id   = !empty($dept_data['user_id']) ? absint($dept_data['user_id']) : 0;
    $user_name = sanitize_text_field($dept_data['user'] ?? '');
    if ($user_id > 0) {
        $u = get_userdata($user_id);
        if ($u) $user_name = $u->display_name;
    }

    $registry[$name] = array(
        'id'      => $id,
        'name'    => $name,
        'emails'  => sanitize_text_field($dept_data['emails'] ?? ''),
        'user_id' => $user_id,
        'user'    => $user_name ? $user_name : 'Administrador General',
        'enabled' => isset($dept_data['enabled']) ? ($dept_data['enabled'] ? 1 : 0) : 1,
    );

    update_option('cm_departments_registry', $registry);
    return true;
}

/**
 * Alterna el estado de un departamento entre Habilitado y Deshabilitado.
 */
function cm_toggle_department_status($dept_name) {
    $registry = cm_get_available_departments(false);
    if (!isset($registry[$dept_name])) return false;

    $registry[$dept_name]['enabled'] = empty($registry[$dept_name]['enabled']) ? 1 : 0;
    update_option('cm_departments_registry', $registry);
    return $registry[$dept_name]['enabled'];
}

/**
 * Elimina un departamento del registro.
 */
function cm_delete_department_entry($dept_name) {
    $registry = cm_get_available_departments(false);
    if (isset($registry[$dept_name])) {
        unset($registry[$dept_name]);
        update_option('cm_departments_registry', $registry);
        return true;
    }
    return false;
}

/**
 * Suspende o activa un usuario de WordPress.
 */
function cm_toggle_user_suspension($user_id) {
    $user_id = absint($user_id);
    if (!$user_id) return false;

    $is_suspended = get_user_meta($user_id, 'cm_user_suspended', true);
    if ($is_suspended) {
        delete_user_meta($user_id, 'cm_user_suspended');
        return 'active';
    } else {
        update_user_meta($user_id, 'cm_user_suspended', 1);
        return 'suspended';
    }
}

/**
 * Bloquea el inicio de sesión para usuarios suspendidos.
 */
function cm_check_user_suspension_on_login($user, $username, $password) {
    if ($user instanceof WP_User) {
        $is_suspended = get_user_meta($user->ID, 'cm_user_suspended', true);
        if ($is_suspended) {
            return new WP_Error('cm_account_suspended', __('⚠️ Tu cuenta ha sido suspendida por el Administrador. Contacta a la dirección del sistema.', 'contacto-multidestino'));
        }
    }
    return $user;
}
add_filter('authenticate', 'cm_check_user_suspension_on_login', 30, 3);


/**
 * Deriva un caso de un departamento a otro y registra el evento en el historial.
 */
function cm_reassign_case_department($submission_id, $new_department, $reason = '', $author_name = 'Área Responsable', $notify_new_area = true, $notify_user = false) {
    global $wpdb;
    $submission_id = absint($submission_id);
    $case = cm_get_submission_by_id($submission_id);
    if (!$case) return false;

    $old_department = $case->department ? $case->department : 'Sin Área';
    $new_department = sanitize_text_field(trim($new_department));
    if (!$new_department || $old_department === $new_department) return false;

    $now = current_time('mysql');

    // Actualizar departamento en el registro principal
    $updated = $wpdb->update(
        $wpdb->prefix . 'cm_form_submissions',
        array(
            'department' => $new_department,
            'updated_at' => $now,
        ),
        array('id' => $submission_id),
        array('%s', '%s'),
        array('%d')
    );

    if ($updated !== false) {
        $note_text = sprintf(__('🔄 Caso derivado de "%s" a "%s".', 'contacto-multidestino'), $old_department, $new_department);
        if (!empty($reason)) {
            $note_text .= ' ' . sprintf(__('Motivo: %s', 'contacto-multidestino'), $reason);
        }

        // Registrar evento en la línea de tiempo
        cm_add_case_update(array(
            'submission_id' => $submission_id,
            'ticket_code'   => $case->ticket_code,
            'author_name'   => $author_name,
            'status'        => $case->status,
            'action_type'   => 'transfer',
            'note'          => $note_text,
            'is_public'     => 1,
            'notified_user' => $notify_user ? 1 : 0,
        ));

        // Enviar notificación a la nueva área si está configurado
        if ($notify_new_area) {
            $all_deps = cm_get_available_departments();
            $target_emails = !empty($all_deps[$new_department]['emails']) ? $all_deps[$new_department]['emails'] : get_option('admin_email');
            $parsed_emails = array_values(array_filter(array_map('trim', explode(',', $target_emails)), 'is_email'));

            if (!empty($parsed_emails)) {
                $site_name = get_bloginfo('name');
                $subject   = sprintf('[%s] 🔄 Caso Derivado a su Área: %s — %s', $case->ticket_code, $case->sender_name, $new_department);

                $submitted_data = array();
                if (!empty($case->submitted_data)) {
                    $decoded = json_decode($case->submitted_data, true);
                    if (is_array($decoded)) $submitted_data = $decoded;
                }

                $body = cm_build_executive_email_html(array(
                    'is_confirmation'     => false,
                    'ticket_code'         => $case->ticket_code,
                    'site_name'           => $site_name,
                    'site_url'            => home_url(),
                    'sender_name'         => $case->sender_name,
                    'sender_email'        => $case->sender_email,
                    'nombre_departamento' => $new_department . ' (Derivado desde ' . $old_department . ')',
                    'submitted_data'      => $submitted_data,
                ));

                $from_email = get_option('cm_smtp_from', get_option('admin_email'));
                $headers = array(
                    'Content-Type: text/html; charset=UTF-8',
                    'From: ' . esc_html($site_name) . ' <' . $from_email . '>'
                );

                wp_mail($parsed_emails, $subject, $body, $headers);
            }
        }

        return true;
    }

    return false;
}

/**
 * Elimina un caso y todo su historial de actualizaciones.
 */
function cm_delete_submission($id) {
    global $wpdb;
    $id = absint($id);
    if (!$id) return false;

    $wpdb->delete($wpdb->prefix . 'cm_case_updates', array('submission_id' => $id), array('%d'));
    return $wpdb->delete($wpdb->prefix . 'cm_form_submissions', array('id' => $id), array('%d'));
}

/**
 * AJAX para restablecer la contraseña de un usuario desde el panel de áreas.
 */
function cm_ajax_admin_reset_user_password() {
    check_ajax_referer('cm_contacto_nonce', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Permiso denegado.', 'contacto-multidestino')));
    }

    $user_id      = isset($_POST['user_id']) ? absint($_POST['user_id']) : 0;
    $new_password = isset($_POST['new_password']) ? trim($_POST['new_password']) : '';

    if (!$user_id) {
        wp_send_json_error(array('message' => __('ID de usuario no válido.', 'contacto-multidestino')));
    }

    if (empty($new_password) || strlen($new_password) < 6) {
        wp_send_json_error(array('message' => __('La contraseña debe tener al menos 6 caracteres.', 'contacto-multidestino')));
    }

    $user = get_userdata($user_id);
    if (!$user) {
        wp_send_json_error(array('message' => __('El usuario no existe.', 'contacto-multidestino')));
    }

    wp_set_password($new_password, $user_id);

    wp_send_json_success(array(
        'message'  => sprintf(__('Contraseña actualizada exitosamente para el usuario %s.', 'contacto-multidestino'), $user->user_login),
        'username' => $user->user_login,
    ));
}
add_action('wp_ajax_cm_admin_reset_user_password', 'cm_ajax_admin_reset_user_password');

/**
 * Comprueba si un caso tiene una solicitud activa de documentos pendientes y retorna su título/instrucción.
 */
function cm_get_case_pending_doc_request($history = array(), $case_status = '') {
    if ($case_status === 'resuelto' || $case_status === 'cerrado') {
        return null;
    }

    if (!empty($history)) {
        // Recorrer del más reciente al más antiguo
        $reversed = array_reverse($history);
        foreach ($reversed as $h) {
            if ($h->action_type === 'applicant_attachment') {
                // El usuario ya respondió y subió antecedentes
                return null;
            }
            if ($h->action_type === 'doc_request') {
                $title = __('Adjuntar Documentación Solicitada', 'contacto-multidestino');
                if (preg_match('/\[REQ_DOC:\s*(.*?)\]/i', $h->note, $matches)) {
                    $title = trim($matches[1]);
                }
                return array(
                    'active'      => true,
                    'title'       => $title,
                    'author_name' => $h->author_name,
                    'created_at'  => $h->created_at,
                    'note'        => trim(preg_replace('/\[REQ_DOC:\s*.*?\]/i', '', $h->note)),
                );
            }
        }
    }

    if ($case_status === 'pendiente_usuario') {
        return array(
            'active'      => true,
            'title'       => __('Adjuntar Documentación o Antecedentes Requeridos', 'contacto-multidestino'),
            'author_name' => __('Área Responsable', 'contacto-multidestino'),
            'created_at'  => '',
            'note'        => '',
        );
    }

    return null;
}

/**
 * Extrae y estructura todos los archivos adjuntos presentes en el historial o datos del formulario.
 */
function cm_extract_case_attachments($history = array(), $submitted_data = array()) {
    $attachments = array();

    if (!empty($history)) {
        foreach ($history as $h) {
            $note = $h->note;
            if (preg_match_all('/<a[^>]+href=[\'"]([^\'"]+)[\'"][^>]*>(.*?)<\/a>/is', $note, $matches, PREG_SET_ORDER)) {
                foreach ($matches as $m) {
                    $url = $m[1];
                    $label = strip_tags($m[2]);
                    $path_info = pathinfo(parse_url($url, PHP_URL_PATH));
                    $ext = strtolower($path_info['extension'] ?? '');
                    if (in_array($ext, array('jpg', 'jpeg', 'png', 'svg', 'bmp', 'pdf', 'doc', 'docx', 'xls', 'xlsx'))) {
                        $cleaned_name = trim(str_replace(array('📄', '🖼️', '📑', 'Descargar', 'Ver'), '', $label));
                        if (empty($cleaned_name)) {
                            $cleaned_name = basename(parse_url($url, PHP_URL_PATH));
                        }
                        $attachments[] = array(
                            'url'         => $url,
                            'name'        => $cleaned_name,
                            'ext'         => $ext,
                            'is_image'    => in_array($ext, array('jpg', 'jpeg', 'png', 'svg', 'bmp')),
                            'author'      => $h->author_name,
                            'date'        => date_i18n('d/m/Y H:i', strtotime($h->created_at)),
                            'action_type' => $h->action_type,
                        );
                    }
                }
            }
        }
    }

    if (!empty($submitted_data)) {
        foreach ($submitted_data as $label => $val) {
            if (is_string($val) && filter_var($val, FILTER_VALIDATE_URL)) {
                $path_info = pathinfo(parse_url($val, PHP_URL_PATH));
                $ext = strtolower($path_info['extension'] ?? '');
                if (in_array($ext, array('jpg', 'jpeg', 'png', 'svg', 'bmp', 'pdf'))) {
                    $attachments[] = array(
                        'url'         => $val,
                        'name'        => basename($val),
                        'ext'         => $ext,
                        'is_image'    => in_array($ext, array('jpg', 'jpeg', 'png', 'svg', 'bmp')),
                        'author'      => 'Solicitante (Formulario Inicial)',
                        'date'        => '',
                        'action_type' => 'initial_upload',
                    );
                }
            }
        }
    }

    return $attachments;
}

/**
 * Renderiza una tarjeta interactiva estilo Hoja de Documento (Sheet Card) con miniatura y visualizador.
 */
function cm_render_attachment_sheet_card($att) {
    $is_img = !empty($att['is_image']);
    $url    = esc_url($att['url']);
    $name   = esc_html($att['name'] ? $att['name'] : basename($att['url']));
    $ext    = strtoupper($att['ext']);
    $author = esc_html($att['author'] ? $att['author'] : 'Adjunto');
    $date   = esc_html($att['date'] ? $att['date'] : '');

    ob_start();
    ?>
    <div class="cm-doc-sheet-card" onclick="cmOpenDocumentPreview('<?php echo esc_js($url); ?>', '<?php echo esc_js($name); ?>', <?php echo $is_img ? 'true' : 'false'; ?>)" title="<?php esc_attr_e('Clic para ver documento en tamaño completo', 'contacto-multidestino'); ?>">
        <div class="cm-doc-sheet-corner"></div>
        <div class="cm-doc-sheet-preview">
            <?php if ($is_img) : ?>
                <img src="<?php echo $url; ?>" alt="<?php echo $name; ?>" class="cm-doc-sheet-img" loading="lazy" />
                <div class="cm-doc-sheet-zoom-badge">🔍 <?php _e('Ver Hoja', 'contacto-multidestino'); ?></div>
            <?php else : ?>
                <div class="cm-doc-sheet-pdf-view">
                    <span class="cm-doc-sheet-pdf-icon">📑</span>
                    <span class="cm-doc-sheet-ext-tag"><?php echo $ext; ?></span>
                    <div class="cm-doc-sheet-lines">
                        <div class="cm-doc-line"></div>
                        <div class="cm-doc-line cm-line-short"></div>
                        <div class="cm-doc-line"></div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <div class="cm-doc-sheet-info">
            <div class="cm-doc-sheet-name" title="<?php echo $name; ?>"><?php echo $name; ?></div>
            <div class="cm-doc-sheet-meta">
                <span>👤 <?php echo $author; ?></span>
                <?php if ($date) : ?><span>• <?php echo $date; ?></span><?php endif; ?>
            </div>
            <div class="cm-doc-sheet-foot">
                <span class="cm-doc-badge-pill"><?php echo $ext; ?></span>
                <span class="cm-doc-action-label">👁️ <?php _e('Abrir', 'contacto-multidestino'); ?></span>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
