=== Ingecodex Form — Formulario Multidestino ===
Contributors: ingecodex
Donate link: https://ingecodex.com
Tags: formulario, contacto, multidestino, elementor, ingecodex, email, smtp, terminos y condiciones, seguimiento de casos, tickets
Requires at least: 5.8
Tested up to: 6.7
Stable tag: 2.4.8
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Formulario de Contacto Multidestino profesional con constructor visual interactivo, bandeja de entradas administrativa, gestión y seguimiento de casos por área con solicitudes al solicitante, y portal público de consulta de estado por código de ticket. Diseñado por Ingecodex (ingecodex.com).

== Descripción ==

Ingecodex Form de Ingecodex es una solución avanzada de formulario de contacto para WordPress y Elementor:

* **Bandeja de Entradas y Gestión de Casos (v2.4.8)**: Panel administrativo para ver todos los mensajes enviados a través de cada formulario, confirmar recepción por área, actualizar estados y emitir solicitudes oficiales al solicitante.
* **Portal Público de Seguimiento ([seguimiento_caso])**: Portal interactivo donde los usuarios ingresan su código de ticket (ej. `CL123456`) para ver en tiempo real el avance de su trámite, las solicitudes del área (ej. requerimiento de presencia o antecedentes) y el historial completo.
* **Constructor Visual Integrado (Form Studio)**: Diseña formularios arrastrando y soltando campos en vivo con previsualización responsive (Escritorio, Tablet, Móvil).
* **Enrutamiento Multidestino**: Asigna destinatarios específicos (correos individuales o múltiples separados por coma) a cada opción o departamento.
* **Modal Flotante de Términos y Condiciones**: Ventana emergente con desenfoque de fondo y botón "Aceptar Términos y Marcar Casilla" automático.
* **Modos de Diseño del Contenedor**: Soporte para formularios 100% Transparentes (para integrarse en fondos de Elementor), Planos (Flat), Modernos con Sombra o Cristal Glassmorphism.
* **Estilos por Campo**: Personalización de bordes y fondos individuales por cada campo.
* **Integración Nativa con Elementor**: Widget "Formulario Ingecodex" listo para arrastrar y soltar.
* **Subida de Archivos**: Dropzone interactivo con soporte de drag & drop, validación de extensiones y peso.
* **Envío Inteligente por AJAX**: Sin recargas de página, con spinner de carga y mensajes dinámicos.

== Instalación ==

1. Sube o copia la carpeta `extension-wordpress` en el directorio `/wp-content/plugins/` de tu WordPress.
2. Activa el plugin desde **Plugins > Plugins instalados**.
3. Ve a **Ingecodex Form > Bandeja de Casos** para gestionar los mensajes recibidos o **Editor Visual** para diseñar formularios.
4. Inserta el portal de seguimiento en cualquier página mediante el shortcode `[seguimiento_caso]`.

== Shortcodes Disponibles ==

* **Formularios Dinámicos:**
  * `[Formulario_Ingecodex]` (Shortcode principal recomendado)
  * `[formulario_ingecodex]`
  * `[ingecodex_form]`
  * `[formulario_contacto]` (Retrocompatible)
* **Portal Público de Seguimiento de Casos:**
  * `[seguimiento_caso]` (Recomendado para páginas de consulta)
  * `[consultar_caso]`
  * `[ingecodex_seguimiento]`
  * `[ingecodex_tracking]`

== Integración con Elementor ==

1. Edita cualquier página con **Elementor**.
2. En el buscador de widgets escribe **Ingecodex** o **Formulario**.
3. Arrastra el widget **Formulario Ingecodex** a tu sección.

== Changelog ==

= 2.4.8 =
* Añadida Bandeja de Entradas y Casos en el panel de administración de WordPress.
* Añadido modal interactivo con ícono de Ojo 👁️ para ver los datos completos enviados por el usuario.
* Añadido sistema de confirmación de recepción y gestión de estados por área (Recibido, En Revisión, En Proceso, Requiere Acción/Presencia del Solicitante, Resuelto/Finalizado).
* Añadido registro de notas y solicitudes oficiales del área (ej. solicitud de presencia física del solicitante con cédula, requerimiento de documentos adicionales).
* Añadido Portal Público de Seguimiento (`[seguimiento_caso]`) con consulta en tiempo real por Código de Ticket (`CL123456`).
* Añadido envío de notificaciones por correo electrónico al usuario cuando su caso recibe una actualización o requerimiento.
* Añadida base de datos relacional para almacenamiento de envíos y línea de tiempo histórica de cada caso.

= 2.4.7 =
* Mejoras de estabilidad y soporte para plantillas multidestino.

= 2.4.1 =
* Añadido aviso exclusivo para administradores con acceso directo a "Ajustes de Correo SMTP".

