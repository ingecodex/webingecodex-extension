=== Ingecodex Form — Formulario Multidestino & Centro de Casos ===
Contributors: ingecodex
Donate link: https://link.mercadopago.cl/ingecodex
Tags: formulario, contacto, multidestino, elementor, ingecodex, email, smtp, 2fa, totp, seguridad, papelera, seguimiento de casos, tickets
Requires at least: 5.8
Tested up to: 6.7
Stable tag: 2.5.4
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Formulario de Contacto Multidestino profesional con constructor visual interactivo, autenticación de dos factores (2FA TOTP RFC 6238), bandeja de casos estilo Apple Pro, papelera con auditoría y restauración para Super Admin, gestión por áreas y portal público de seguimiento. Diseñado por Ingecodex (ingecodex.com).

== Descripción ==

Ingecodex Form es una suite completa de gestión de requerimientos y formularios de contacto para WordPress y Elementor:

* **Copia de Seguridad Cifrada (AES-256) y Restauración con 2FA (v2.5.4)**: Exportación e importación completa de expedientes, mensajes de historial, formularios, áreas y configuraciones protegidas con clave criptográfica y validación de doble factor obligatoria.
* **Portal Ejecutivo Standalone Fullscreen**: Experiencia de aplicación web independiente con soporte de vista completa de expedientes, navegación fluida y notificaciones de escritorio.
* **Gestión Jerárquica Multi-Área y Respuestas Automáticas**: Asignación de usuarios Directores, Moderadores Multi-Área y Encargados. Respuesta automática configurable por departamento (inmediata o diferida).
* **Plantillas de Notas Rápidas y Pestañas de Casos Activos/Finalizados**: Notas oficiales integradas, creador y eliminador individual de notas y filtrado por buckets en la bandeja.
* **Autenticación de Dos Factores (2FA TOTP RFC 6238)**: Motor nativo compatible con Google Authenticator, Microsoft Authenticator y Apple Passwords.
* **Bandeja de Entradas y Gestión de Casos Estilo Apple Pro**: Panel administrativo unificado con modo modal y vista en página completa, impresión oficial en formato Carta/PDF, derivación entre áreas y timeline de eventos.
* **Papelera con Restauración Exclusiva y Auditoría Histórica**: Los casos eliminados quedan protegidos en papelera (ocultos del portal público), permitiendo al Super Administrador restaurarlos en cualquier momento.
* **Portal Público de Seguimiento ([seguimiento_caso])**: Portal interactivo donde los solicitantes ingresan su código de ticket (ej. `CL123456`) para ver en tiempo real el avance de su trámite.

== Instalación ==

1. Descarga el paquete `ingecodex-form-2.5.4.zip` o sube la carpeta `extension-wordpress` al directorio `/wp-content/plugins/`.
2. Activa el plugin desde **Plugins > Plugins instalados** en WordPress.
3. Ingresa a **Ingecodex Form > Bandeja de Casos** para gestionar solicitudes o a **Editor Visual** para personalizar tus formularios.
4. Inserta el portal de seguimiento en cualquier página mediante el shortcode `[seguimiento_caso]`.

== Shortcodes Disponibles ==

* **Formularios Dinámicos:**
  * `[Formulario_Ingecodex]` (Shortcode principal recomendado)
  * `[formulario_ingecodex]`
  * `[ingecodex_form]`
  * `[formulario_contacto]`
* **Portal Público de Seguimiento de Casos:**
  * `[seguimiento_caso]` (Recomendado para páginas de consulta)
  * `[consultar_caso]`
  * `[ingecodex_seguimiento]`
  * `[ingecodex_tracking]`

== Changelog ==

= 2.5.4 =
* Respaldo y Restauración Total (Full Backup) con cifrado militar AES-256-CBC y firma de integridad HMAC-SHA256.
* Autenticación obligatoria de Doble Factor (2FA TOTP) para descargar y restaurar copias de seguridad.
* Visualización en Pantalla Completa de expedientes dentro del Portal Ejecutivo sin redirecciones externas a WordPress.
* Eliminación y restauración individual de notas rápidas predeterminadas y personalizadas.
* Optimización de enrutamiento y soporte de query parameters limpios.
* Asignación jerárquica y multi-área para Subdirectores y Moderadores.
* Respuestas automáticas configurables por departamento (ej: Currículum / Postulaciones) con temporizador configurable (inmediata o diferida a minutos).
* Sistema de plantillas de notas rápidas predeterminadas en el Inspector de Casos con creador y eliminador de notas personalizadas.
* Opción para activar o desactivar el envío de correo de confirmación al usuario (con soporte de código en pantalla).
* Sistema visual de códigos de color en filas y badges según estado (Rojo para nuevo, Amarillo para revisión, Verde para en proceso, Gris para finalizado).
* Pestañas rápidas en la bandeja de entrada: Todos los Casos, Activos / En Trámite y Completados / Finalizados.

= 2.5.1 =
* **Editor Visual del Buscador Pro Studio:** Personalización en vivo de botones (Sólido, Transparente / Outline, Cristal Glassmorphism, Degradado Pro), redondez y paletas rápidas.
* **Dashboard Ejecutivo Rediseñado:** Tabla compacta de casos activos con badges de estado y apertura directa de expedientes.
* **Iconografía Oficial Animada:** Integración del logo animado de la aplicación en cabeceras y botón de donación.
* **Ocultación del Footer de WordPress:** Experiencia limpia de app independiente en todas las pantallas.

= 2.5.0 =
* **Seguridad 2FA TOTP RFC 6238:** Motor criptográfico de autenticación de dos factores nativo en PHP puro compatible con Google/Microsoft Authenticator.
* **Personalizador del Portal:** Módulo administrativo para configurar la apariencia y textos del portal de seguimiento por código.
* **Panel de Seguridad para Administrador:** Gestión, asignación directa, generación de códigos QR y desbloqueo de cuentas.

= 2.4.9 =
* **Editor Visual del Portal de Consulta:** Personalizador interactivo para editar en tiempo real los colores, textos, títulos y estilos de la página de búsqueda por código (`[seguimiento_caso]`).
* **Estilo Firma Automática / Verificación Digital:** Modo de presentación con timbre de autenticidad institucional, sello de verificación y código Hash SHA1.
* **Botón de Búsqueda de Alto Contraste:** Control total sobre los colores de fondo y texto del botón con estilos blindados para evitar que los temas lo oculten.
* **Autenticación 2FA TOTP Nativa:** Motor criptográfico RFC 6238 sin dependencias externas. Integración con el formulario de login de WordPress.
* **Sugerencia Automática de 2FA:** Banner interactivo para activar la seguridad de dos factores al iniciar sesión.
* **Tabla de Usuarios Adaptable:** Diseño responsive fluido que mantiene todos los controles en una sola línea horizontal.

= 2.4.9 =
* **Papelera con Restauración y Auditoría:** Casos eliminados ocultos del portal público, protegidos con modo solo lectura e historial inmutable de quién eliminó y quién recuperó.
* **Vista en Página Completa:** Opción para inspeccionar expedientes en página web dedicada además del visor modal.
* **Impresión Oficial Formato Carta:** Estilos CSS de impresión optimizados para exportar fichas oficiales limpias en PDF.
* **Limpieza de Marcadores Internos:** Ocultamiento de etiquetas como `[REQ_DOC: ...]` en las notas públicas y del panel.

= 2.4.8 =
* **Bandeja de Entradas y Casos:** Panel interactivo en el panel de administración de WordPress.
* **Portal Público de Seguimiento:** Portal web (`[seguimiento_caso]`) con consulta en tiempo real por Código de Ticket (`CL123456`).
* **Gestión de Estados por Área:** Recibido, En Revisión, En Proceso, Requiere Presencia / Documentación y Resuelto.
* **Notificaciones por Email:** Envío automático de correos al solicitante ante cada actualización.
* **Base de Datos Relacional:** Tablas MySQL `cm_submissions` y `cm_case_events` para trazabilidad completa.

= 2.4.7 =
* Mejoras en el enrutamiento de correos a múltiples destinatarios y compatibilidad con Elementor.

= 2.4.6 =
* Envío de formularios mediante AJAX inteligente sin recarga de página y subida de archivos adjuntos con validación.

= 2.4.5 =
* Sistema de alertas sonoras en tiempo real mediante Web Audio API y notificaciones flotantes (Toasts).

= 2.4.4 =
* Separación de perfiles de acceso: Encargados de Área vs. Directores / Super Administradores.
* Módulo de restablecimiento inmediato de contraseñas de usuarios.

= 2.4.2 =
* Nuevos modos de diseño del contenedor: Vidrio Glassmorphism, Plano, Sombra Moderna y 100% Transparente.

= 2.4.1 =
* Diagnóstico y avisos exclusivos para administradores en la configuración de correo SMTP.

= 2.4.0 =
* Constructor Visual interactivo Form Studio con arrastrar y soltar (drag & drop) y previsualización responsive en vivo.
* Enrutamiento dinámico de destinatarios por departamento.
* Modal emergente de Términos y Condiciones y Widget para Elementor.
