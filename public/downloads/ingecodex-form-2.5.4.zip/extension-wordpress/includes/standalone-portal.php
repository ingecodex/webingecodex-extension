<?php
/**
 * Portal Ejecutivo Standalone (Independiente de la interfaz de WordPress)
 * Ingecodex Form v2.5.4
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Obtiene la URL limpia del Portal Independiente.
 */
function cm_get_standalone_portal_url($tab = '') {
    $base = home_url('/?cm_portal=1');
    if (!empty($tab)) {
        $base = add_query_arg('tab', $tab, $base);
    }
    return esc_url_raw($base);
}

/**
 * Registra Rewrite Rules para soporte de URL amigable /portal-gestion/
 */
function cm_register_standalone_portal_rewrites() {
    add_rewrite_rule('^portal-gestion/?$', 'index.php?cm_portal=1', 'top');
    add_rewrite_rule('^portal-gestion/([^/]+)/?$', 'index.php?cm_portal=1&tab=$matches[1]', 'top');
}
add_action('init', 'cm_register_standalone_portal_rewrites');

function cm_register_standalone_query_vars($vars) {
    $vars[] = 'cm_portal';
    $vars[] = 'case_id';
    $vars[] = 'tab';
    return $vars;
}
add_filter('query_vars', 'cm_register_standalone_query_vars');

/**
 * Interceptor principal del Portal Standalone en template_redirect.
 */
function cm_handle_standalone_portal_request() {
    // Intentar autenticar desde cookie de WP en esta solicitud
    cm_standalone_maybe_auth_from_cookie();
    $is_portal = false;
    if (isset($_GET['cm_portal']) && $_GET['cm_portal'] == '1') {
        $is_portal = true;
    } elseif (get_query_var('cm_portal') == '1') {
        $is_portal = true;
    }

    if (!$is_portal) {
        return;
    }

    // Desactivar caché y minificación/optimización de LiteSpeed/WP Rocket para el portal
    if (!defined('DONOTCACHEPAGE')) define('DONOTCACHEPAGE', true);
    if (!defined('DONOTMINIFY')) define('DONOTMINIFY', true);
    if (!defined('DONOTCDN')) define('DONOTCDN', true);
    if (!defined('LITESPEED_DISABLE_ALL')) define('LITESPEED_DISABLE_ALL', true);
    
    // Disparar hooks oficiales de LiteSpeed Cache
    do_action('litespeed_disable_all', 'Ingecodex Portal');
    do_action('litespeed_control_set_nocache', 'Ingecodex Portal');
    
    // Configurar headers para forzar al navegador y proxies a no guardar en caché
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Cache-Control: post-check=0, pre-check=0', false);
    header('Pragma: no-cache');

    // Desactivar barra superior de WordPress
    show_admin_bar(false);

    // Procesar Login POST si se envió el formulario
    $login_error = '';
    if (isset($_POST['cm_standalone_login_nonce']) && wp_verify_nonce($_POST['cm_standalone_login_nonce'], 'cm_standalone_login')) {
        $username = sanitize_text_field($_POST['log'] ?? '');
        $password = $_POST['pwd'] ?? '';
        $remember = !empty($_POST['rememberme']);
        $otp_code = sanitize_text_field($_POST['cm_2fa_code'] ?? '');

        if (empty($username) || empty($password)) {
            $login_error = __('Por favor ingresa tu usuario y contraseña.', 'contacto-multidestino');
        } else {
            $user = wp_authenticate($username, $password);
            if (is_wp_error($user)) {
                $login_error = __('Credenciales incorrectas. Verifica tu usuario y contraseña.', 'contacto-multidestino');
            } else {
                // Verificar si tiene 2FA habilitado
                $two_factor_enabled = get_user_meta($user->ID, 'cm_2fa_enabled', true);
                if (!empty($two_factor_enabled)) {
                    if (empty($otp_code)) {
                        $login_error = __('Este usuario tiene 2FA activado. Ingresa el código de 6 dígitos de tu app de autenticación.', 'contacto-multidestino');
                    } else {
                        $secret = get_user_meta($user->ID, 'cm_2fa_secret', true);
                        if (!class_exists('CM_TOTP_Engine') || !CM_TOTP_Engine::verify_code($secret, $otp_code)) {
                            $login_error = __('Código 2FA incorrecto o expirado. Intenta de nuevo.', 'contacto-multidestino');
                        } else {
                            wp_set_current_user($user->ID);
                            wp_set_auth_cookie($user->ID, $remember);
                            if (function_exists('cm_log_audit_action')) {
                                cm_log_audit_action(0, 'SISTEMA', 'login', 'El usuario ha iniciado sesión en el Portal Exclusivo (con 2FA).');
                            }
                            wp_safe_redirect(cm_get_standalone_portal_url());
                            exit;
                        }
                    }
                } else {
                    wp_set_current_user($user->ID);
                    wp_set_auth_cookie($user->ID, $remember);
                    if (function_exists('cm_log_audit_action')) {
                        cm_log_audit_action(0, 'SISTEMA', 'login', 'El usuario ha iniciado sesión en el Portal Exclusivo.');
                    }
                    wp_safe_redirect(cm_get_standalone_portal_url());
                    exit;
                }
            }
        }
    }

    // Si NO está autenticado: Renderizar Pantalla de Login Standalone Liquid Glass
    if (!is_user_logged_in()) {
        cm_render_standalone_login_page($login_error);
        exit;
    }

    // Si está autenticado pero no tiene permisos
    if (!current_user_can('edit_posts') && !current_user_can('manage_options')) {
        wp_die(
            __('No tienes permisos para acceder al Portal Ejecutivo. Contacta a un administrador.', 'contacto-multidestino'),
            __('Acceso Restringido — Ingecodex', 'contacto-multidestino'),
            array('response' => 403)
        );
    }

    // Renderizar la App Ejecutiva Fullscreen
    cm_render_standalone_dashboard_app();
    exit;
}
/**
 * Leer cookie de WordPress manualmente en la misma solicitud (para standalone portal).
 */
function cm_standalone_maybe_auth_from_cookie() {
    if (!is_user_logged_in()) {
        // Intentar autenticar desde la cookie de WP si está presente
        if (!empty($_COOKIE)) {
            foreach ($_COOKIE as $key => $val) {
                if (strpos($key, 'wordpress_logged_in_') === 0) {
                    $user_id = wp_validate_auth_cookie($val, 'logged_in');
                    if ($user_id) {
                        wp_set_current_user($user_id);
                        break;
                    }
                }
            }
        }
    }
}

add_action('template_redirect', 'cm_handle_standalone_portal_request', 1);

/**
 * Pantalla de Login Independiente con estética Liquid Glass / Apple
 */
function cm_render_standalone_login_page($error_msg = '') {
    $site_name = get_bloginfo('name');
    $logo_url  = CM_PLUGIN_URL . 'assets/images/logo.png';
    ?>
    <!DOCTYPE html>
    <html lang="<?php echo esc_attr(get_locale()); ?>">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <title><?php printf(__('Acceso al Portal Ejecutivo — %s', 'contacto-multidestino'), esc_html($site_name)); ?></title>
        <link rel="icon" href="<?php echo esc_url($logo_url); ?>" />
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
        <style>
            *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
            body {
                font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", Roboto, sans-serif;
                background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0f172a 100%);
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 20px;
                color: #0f172a;
                position: relative;
                overflow: hidden;
            }
            /* Esferas de luz ambient (Liquid Aura) */
            .cm-ambient-aura-1 {
                position: absolute; width: 450px; height: 450px; border-radius: 50%;
                background: radial-gradient(circle, rgba(56, 116, 255, 0.35) 0%, rgba(56, 116, 255, 0) 70%);
                top: -100px; left: -100px; filter: blur(60px); pointer-events: none;
            }
            .cm-ambient-aura-2 {
                position: absolute; width: 400px; height: 400px; border-radius: 50%;
                background: radial-gradient(circle, rgba(16, 185, 129, 0.3) 0%, rgba(16, 185, 129, 0) 70%);
                bottom: -80px; right: -80px; filter: blur(60px); pointer-events: none;
            }
            .cm-login-glass-card {
                width: 100%;
                max-width: 420px;
                background: rgba(255, 255, 255, 0.94);
                backdrop-filter: blur(30px) saturate(190%);
                -webkit-backdrop-filter: blur(30px) saturate(190%);
                border: 1.5px solid rgba(255, 255, 255, 0.95);
                border-radius: 24px;
                padding: 36px 32px;
                box-shadow: 0 20px 60px rgba(0, 0, 0, 0.35), 0 2px 10px rgba(255, 255, 255, 0.2) inset;
                position: relative;
                z-index: 10;
                animation: cmCardPop 0.4s cubic-bezier(0.16, 1, 0.3, 1);
            }
            @keyframes cmCardPop {
                from { opacity: 0; transform: scale(0.95) translateY(12px); }
                to { opacity: 1; transform: scale(1) translateY(0); }
            }
            .cm-logo-wrap {
                width: 58px; height: 58px; border-radius: 16px; background: #ffffff;
                border: 1px solid rgba(226, 232, 240, 0.8); display: flex; align-items: center;
                justify-content: center; margin: 0 auto 16px; box-shadow: 0 4px 14px rgba(0, 0, 0, 0.08);
            }
            .cm-logo-wrap img { width: 38px; height: 38px; object-fit: contain; }
            .cm-header-title { font-size: 20px; font-weight: 800; text-align: center; color: #0f172a; letter-spacing: -0.02em; }
            .cm-header-sub { font-size: 13px; color: #64748b; text-align: center; margin-top: 4px; margin-bottom: 24px; }
            .cm-form-group { margin-bottom: 16px; }
            .cm-form-group label { display: block; font-size: 12.5px; font-weight: 700; color: #334155; margin-bottom: 6px; }
            .cm-input-styled {
                width: 100%; height: 42px; padding: 0 14px; font-size: 14px;
                font-family: inherit; color: #0f172a; background: #f8fafc;
                border: 1.5px solid #e2e8f0; border-radius: 12px; outline: none;
                transition: all 0.2s ease;
            }
            .cm-input-styled:focus {
                background: #ffffff; border-color: #3874ff;
                box-shadow: 0 0 0 3.5px rgba(56, 116, 255, 0.15);
            }
            .cm-btn-submit {
                width: 100%; height: 44px; margin-top: 10px;
                background: linear-gradient(135deg, #3874ff 0%, #2563eb 100%);
                color: #ffffff; font-size: 14px; font-weight: 800; font-family: inherit;
                border: none; border-radius: 12px; cursor: pointer;
                box-shadow: 0 4px 14px rgba(56, 116, 255, 0.35);
                display: flex; align-items: center; justify-content: center; gap: 8px;
                transition: all 0.2s ease;
            }
            .cm-btn-submit:hover { transform: translateY(-1px); box-shadow: 0 6px 20px rgba(56, 116, 255, 0.45); }
            .cm-btn-submit:active { transform: translateY(0); }
            .cm-error-box {
                background: #fef2f2; border: 1px solid #fecaca; color: #991b1b;
                border-radius: 10px; padding: 10px 14px; font-size: 12.5px; font-weight: 600;
                margin-bottom: 18px; display: flex; align-items: center; gap: 8px;
            }
            .cm-login-footer {
                text-align: center; margin-top: 24px; font-size: 11.5px; color: #94a3b8;
            }
            .cm-login-footer a { color: #64748b; text-decoration: none; font-weight: 600; }
            .cm-login-footer a:hover { color: #3874ff; }
        </style>
    </head>
    <body>
        <div class="cm-ambient-aura-1"></div>
        <div class="cm-ambient-aura-2"></div>

        <div class="cm-login-glass-card">
            <div class="cm-logo-wrap">
                <img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr($site_name); ?>">
            </div>
            <h1 class="cm-header-title"><?php _e('Portal Ejecutivo de Gestión', 'contacto-multidestino'); ?></h1>
            <p class="cm-header-sub"><?php echo esc_html($site_name); ?> · <?php _e('Acceso Independiente', 'contacto-multidestino'); ?></p>

            <?php if ($error_msg) : ?>
                <div class="cm-error-box">
                    <span>⚠️</span>
                    <div><?php echo esc_html($error_msg); ?></div>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <?php wp_nonce_field('cm_standalone_login', 'cm_standalone_login_nonce'); ?>

                <div class="cm-form-group">
                    <label for="cm_user_log"><?php _e('Usuario o Correo Electrónico', 'contacto-multidestino'); ?></label>
                    <input type="text" name="log" id="cm_user_log" class="cm-input-styled" required autofocus placeholder="admin / tu-correo@dominio.cl">
                </div>

                <div class="cm-form-group">
                    <label for="cm_user_pwd"><?php _e('Contraseña de Acceso', 'contacto-multidestino'); ?></label>
                    <input type="password" name="pwd" id="cm_user_pwd" class="cm-input-styled" required placeholder="••••••••••••">
                </div>

                <div class="cm-form-group">
                    <label for="cm_2fa_code" style="display:flex; justify-content:space-between;">
                        <span><?php _e('Código 2FA (Authenticator)', 'contacto-multidestino'); ?></span>
                        <span style="font-size:11px; font-weight:500; color:#64748b;"><?php _e('Solo si está activo', 'contacto-multidestino'); ?></span>
                    </label>
                    <input type="text" name="cm_2fa_code" id="cm_2fa_code" class="cm-input-styled" placeholder="6 dígitos (ej: 482910)" maxlength="6" inputmode="numeric" autocomplete="one-time-code">
                </div>

                <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:16px; font-size:12px; color:#64748b;">
                    <label style="display:flex; align-items:center; gap:6px; cursor:pointer;">
                        <input type="checkbox" name="rememberme" value="forever" style="accent-color:#3874ff;">
                        <?php _e('Mantener sesión iniciada', 'contacto-multidestino'); ?>
                    </label>
                </div>

                <button type="submit" class="cm-btn-submit">
                    <span>🚀 <?php _e('Ingresar al Portal Ejecutivo', 'contacto-multidestino'); ?></span>
                </button>
            </form>

            <div class="cm-login-footer">
                <p>Ingecodex Form v2.5.4 Pro · <a href="<?php echo esc_url(home_url('/')); ?>">← <?php _e('Volver al Sitio Web', 'contacto-multidestino'); ?></a></p>
            </div>
        </div>
    </body>
    </html>
    <?php
}

/**
 * Renderiza la Aplicación Standalone Fullscreen (Bandeja, Métricas, Departamentos y Gestión).
 */
function cm_render_standalone_dashboard_app() {
    $current_user = wp_get_current_user();
    $user_id      = $current_user->ID;
    $is_superadmin= current_user_can('manage_options');
    $site_name    = get_bloginfo('name');
    $logo_url     = CM_PLUGIN_URL . 'assets/images/logo.png';
    $is_director  = function_exists('cm_is_director') && cm_is_director();
    $can_view_dashboard = $is_superadmin || $is_director;
    $trash_count  = function_exists('cm_get_trash_count') ? cm_get_trash_count() : 0;
    $default_tab  = $can_view_dashboard ? 'dashboard' : 'inbox';
    $tab          = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : $default_tab;
    $logout_url   = wp_logout_url(cm_get_standalone_portal_url());
    
    // Bootstrapping WP correctly for the template
    nocache_headers();
    ?>
    <!DOCTYPE html>
    <html lang="<?php echo esc_attr(get_locale()); ?>" class="cm-portal-page">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <title><?php printf(__('Portal Ejecutivo — %s', 'contacto-multidestino'), esc_html($site_name)); ?></title>
        <link rel="icon" href="<?php echo esc_url($logo_url); ?>" />
        
        <?php
        // Cargar solo jQuery y dashicons, excluir estilos del tema activo
        wp_enqueue_script('jquery');
        wp_enqueue_style('dashicons');
        // Desregistrar estilos del tema para evitar conflictos de color
        add_filter('print_styles_array', function($handles) {
            $exclude = array();
            // Excluir stylesheet principal del tema y child-theme
            if (function_exists('get_stylesheet')) {
                $exclude[] = get_stylesheet();
            }
            if (function_exists('get_template')) {
                $exclude[] = get_template();
            }
            $exclude = array_merge($exclude, array('style', 'theme-style', 'wp-block-library', 'classic-theme-styles', 'global-styles', 'wc-blocks-style'));
            return array_filter($handles, function($h) use ($exclude) {
                return !in_array($h, $exclude);
            });
        });
        wp_print_styles();
        wp_print_scripts();
        ?>

        <link rel="stylesheet" href="<?php echo esc_url(CM_PLUGIN_URL . 'assets/css/builder-admin.css?v=' . CM_VERSION); ?>">
        <script src="<?php echo esc_url(CM_PLUGIN_URL . 'assets/js/builder-admin.js?v=' . CM_VERSION); ?>"></script>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">

        <style>
            /* ═══ RESET GLOBAL PORTAL STANDALONE ══════════════════════════════════
               Máxima especificidad para anular cualquier estilo del tema de WP
               ═══════════════════════════════════════════════════════════════════ */
            html.cm-portal-page,
            html.cm-portal-page body,
            html.cm-portal-page #cm-standalone-wrapper {
                background: #f8fafc !important;
                color: #0f172a !important;
            }
            html.cm-portal-page * {
                font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", Roboto, sans-serif !important;
            }
            *, *::before, *::after { box-sizing: border-box; }
            html, body {
                margin: 0; padding: 0; height: 100%;
                background: #f8fafc;
                font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", Roboto, sans-serif;
                color: #0f172a;
                overflow-x: hidden;
            }
            #cm-standalone-wrapper {
                min-height: 100vh;
                display: flex;
                flex-direction: column;
            }
            .cm-standalone-topbar {
                background: rgba(255, 255, 255, 0.95);
                backdrop-filter: blur(24px) saturate(180%);
                -webkit-backdrop-filter: blur(24px) saturate(180%);
                border-bottom: 1px solid #e2e8f0;
                min-height: 52px;
                padding: 6px 20px;
                display: flex;
                align-items: center;
                justify-content: space-between;
                position: sticky;
                top: 0;
                z-index: 1000;
                flex-wrap: wrap;
                gap: 10px;
            }
            .cm-standalone-brand {
                display: flex;
                align-items: center;
                gap: 10px;
                text-decoration: none;
                color: inherit;
            }
            .cm-standalone-brand img {
                width: 28px;
                height: 28px;
                object-fit: contain;
                border-radius: 7px;
            }
            .cm-standalone-brand span {
                font-size: 13.5px;
                font-weight: 800;
                color: #0f172a;
                letter-spacing: -0.01em;
            }
            .cm-standalone-brand .cm-badge-tag {
                font-size: 10px;
                font-weight: 800;
                background: #eff6ff;
                color: #2563eb;
                padding: 2px 7px;
                border-radius: 12px;
                border: 1px solid #bfdbfe;
            }
            /* Segmented control en topbar standalone */
            .cm-portal-top-nav {
                display: flex;
                align-items: center;
                gap: 4px;
                background: #f1f5f9;
                padding: 3px;
                border-radius: 10px;
                border: 1px solid #e2e8f0;
            }
            .cm-portal-nav-btn {
                display: inline-flex;
                align-items: center;
                gap: 5px;
                padding: 5px 12px;
                font-size: 12px;
                font-weight: 700;
                text-decoration: none;
                color: #475569;
                border-radius: 8px;
                transition: all 0.15s ease;
                white-space: nowrap;
            }
            .cm-portal-nav-btn:hover {
                color: #0f172a;
                background: rgba(255,255,255,0.7);
            }
            .cm-portal-nav-btn.active {
                background: #ffffff;
                color: #0f172a;
                box-shadow: 0 1px 3px rgba(0,0,0,0.08);
            }
            .cm-standalone-user-menu {
                display: flex;
                align-items: center;
                gap: 8px;
            }
            .cm-user-avatar-pill {
                display: inline-flex;
                align-items: center;
                gap: 6px;
                padding: 3px 10px 3px 4px;
                background: #f1f5f9;
                border: 1px solid #e2e8f0;
                border-radius: 20px;
                font-size: 12px;
                font-weight: 700;
                color: #334155;
                cursor: pointer;
            }
            .cm-user-avatar-pill img {
                width: 20px;
                height: 20px;
                border-radius: 50%;
            }
            .cm-standalone-main-content {
                flex: 1;
                padding: 14px 18px 40px;
                max-width: 1720px;
                margin: 0 auto;
                width: 100%;
            }
            .cm-standalone-main-content .wrap.cm-apple-wrap { padding-top: 0 !important; margin-top: 0 !important; }
            .notice, .update-nag, #wpfooter { display: none !important; }

            /* ═══ OVERRIDE AGRESIVO: anula colores del tema WordPress ═══════════ */
            #cm-standalone-wrapper,
            #cm-standalone-wrapper h1,
            #cm-standalone-wrapper h2,
            #cm-standalone-wrapper h3,
            #cm-standalone-wrapper h4,
            #cm-standalone-wrapper h5,
            #cm-standalone-wrapper h6,
            #cm-standalone-wrapper p,
            #cm-standalone-wrapper span:not(.cm-badge-tag):not(.cm-status-pill):not(.cm-apple-version),
            #cm-standalone-wrapper label,
            #cm-standalone-wrapper td,
            #cm-standalone-wrapper th,
            #cm-standalone-wrapper div:not(.cm-standalone-topbar):not(.cm-user-avatar-pill) {
                color: #0f172a;
            }
            .cm-standalone-topbar { background: rgba(255,255,255,0.95) !important; color: #0f172a !important; }
            .cm-standalone-brand span { color: #0f172a !important; }
            body { background-color: #f8fafc !important; color: #0f172a !important; }
            #wpadminbar { display: none !important; }
            html { margin-top: 0 !important; }
        </style>
        <script>
            var ajaxurl = "<?php echo esc_url(admin_url('admin-ajax.php')); ?>";
        </script>
    </head>
    <body id="cm-portal-body">
        <div id="cm-standalone-wrapper">
            <header class="cm-standalone-topbar">
                <a href="<?php echo esc_url(cm_get_standalone_portal_url()); ?>" class="cm-standalone-brand">
                    <img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr($site_name); ?>">
                    <span><?php echo esc_html($site_name); ?></span>
                    <span class="cm-badge-tag">Portal v2.5.4</span>
                </a>

                <!-- Navegación de Pestañas / Bandejas en la barra superior -->
                <?php if ($can_view_dashboard) : ?>
                    <nav class="cm-portal-top-nav">
                        <a href="<?php echo esc_url(cm_get_standalone_portal_url('dashboard')); ?>" class="cm-portal-nav-btn <?php echo $tab === 'dashboard' ? 'active' : ''; ?>">
                            📊 <?php _e('Dashboard', 'contacto-multidestino'); ?>
                        </a>
                        <a href="<?php echo esc_url(cm_get_standalone_portal_url('inbox')); ?>" class="cm-portal-nav-btn <?php echo $tab === 'inbox' ? 'active' : ''; ?>">
                            📥 <?php _e('Casos / Bandeja', 'contacto-multidestino'); ?>
                        </a>
                        <?php if ($is_superadmin) : ?>
                            <a href="<?php echo esc_url(cm_get_standalone_portal_url('departments')); ?>" class="cm-portal-nav-btn <?php echo $tab === 'departments' ? 'active' : ''; ?>">
                                👥 <?php _e('Áreas y Encargados', 'contacto-multidestino'); ?>
                            </a>
                            <a href="<?php echo esc_url(cm_get_standalone_portal_url('trash')); ?>" class="cm-portal-nav-btn <?php echo $tab === 'trash' ? 'active' : ''; ?>" style="<?php echo $trash_count > 0 ? 'color:#dc2626;' : ''; ?>">
                                🗑️ <?php _e('Papelera', 'contacto-multidestino'); ?><?php if ($trash_count > 0) echo ' (' . (int)$trash_count . ')'; ?>
                            </a>
                            <a href="<?php echo esc_url(cm_get_standalone_portal_url('audit')); ?>" class="cm-portal-nav-btn <?php echo $tab === 'audit' ? 'active' : ''; ?>" style="color:#6b21a8;">
                                🕵️ <?php _e('Auditoría', 'contacto-multidestino'); ?>
                            </a>
                        <?php endif; ?>
                    </nav>
                <?php else : ?>
                    <nav class="cm-portal-top-nav">
                        <a href="<?php echo esc_url(cm_get_standalone_portal_url('inbox')); ?>" class="cm-portal-nav-btn active">
                            📥 <?php _e('Mi Bandeja de Casos', 'contacto-multidestino'); ?>
                        </a>
                    </nav>
                <?php endif; ?>

                <div class="cm-standalone-user-menu">
                    <button type="button" id="cm-btn-chrome-notif" class="cm-btn-sound-test" style="font-size:11.5px; height:28px; padding:0 10px; background:#ffffff; color:#334155; border:1px solid #cbd5e1;" onclick="cmRequestChromeNotifications()" title="Activar avisos de escritorio en Chrome">
                        🔔 <span class="hide-if-small"><?php _e('Avisos Chrome', 'contacto-multidestino'); ?></span>
                    </button>

                    <div class="cm-user-avatar-pill" onclick="cmOpenUserProfile(<?php echo (int)$user_id; ?>)" title="<?php _e('Ver ficha y seguridad 2FA', 'contacto-multidestino'); ?>">
                        <?php echo get_avatar($user_id, 20); ?>
                        <span><?php echo esc_html($current_user->display_name); ?></span>
                    </div>

                    <?php if ($is_superadmin) : ?>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=cm-form-submissions')); ?>" style="font-size:11.5px; font-weight:700; height:28px; padding:0 10px; text-decoration:none; background:#ffffff; color:#0369a1 !important; border:1px solid #bae6fd; border-radius:8px; display:inline-flex; align-items:center; gap:4px; box-shadow:0 1px 2px rgba(0,0,0,0.04);" title="<?php _e('Ir al panel wp-admin de WordPress', 'contacto-multidestino'); ?>">
                            ⚙️ <span class="hide-if-small" style="color:#0369a1 !important;">WP-Admin</span>
                        </a>
                    <?php endif; ?>

                    <!-- Donar — visible en topbar del portal -->
                    <a href="https://link.mercadopago.cl/ingecodex" target="_blank" rel="noopener noreferrer"
                       style="font-size:11.5px; height:28px; padding:0 10px; text-decoration:none; background: linear-gradient(135deg,#009ee3,#007eb5); color:#ffffff !important; border:1px solid #0088c6; border-radius:8px; display:inline-flex; align-items:center; gap:5px; font-weight:700;"
                       title="Apoyar el desarrollo con Mercado Pago">
                        <img src="<?php echo esc_url(CM_PLUGIN_URL . 'assets/images/logo.gif'); ?>" alt="" style="width:14px;height:14px;border-radius:50%;object-fit:cover;">
                        <span class="hide-if-small" style="color:#ffffff !important;"><?php _e('Donar', 'contacto-multidestino'); ?></span>
                    </a>

                    <a href="<?php echo esc_url($logout_url); ?>" style="font-size:11.5px; font-weight:700; height:28px; padding:0 10px; text-decoration:none; background:#fff1f2; color:#be123c !important; border:1px solid #fecdd3; border-radius:8px; display:inline-flex; align-items:center; gap:4px;" title="<?php _e('Cerrar sesión de forma segura', 'contacto-multidestino'); ?>">
                        <span style="color:#be123c !important; font-weight:800;">⏻</span> <span class="hide-if-small" style="color:#be123c !important; font-weight:700;"><?php _e('Salir', 'contacto-multidestino'); ?></span>
                    </a>
                </div>
            </header>

            <main class="cm-standalone-main-content">
                <?php
                if (function_exists('cm_render_admin_submissions_page')) {
                    cm_render_admin_submissions_page();
                } else {
                    echo '<div style="padding:40px; text-align:center; color:#64748b;">⚠️ Módulo de gestión de casos no disponible.</div>';
                }
                ?>
            </main>
        </div>

        <?php
        // Usar wp_print_footer_scripts en lugar de wp_footer para evitar que plugins de optimización/temas inyecten scripts duplicados o rotos
        wp_print_footer_scripts();
        ?>
    </body>
    </html>
    <?php
}
