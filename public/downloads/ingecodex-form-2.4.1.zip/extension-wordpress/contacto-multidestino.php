<?php
/**
 * Plugin Name: Ingecodex Form
 * Plugin URI: https://ingecodex.com
 * Description: Constructor visual de formularios con enrutamiento dinámico de correos por departamento, adjuntos y shortcodes automáticos.
 * Version: 2.4.1
 * Author: Ingecodex
 * Author URI: https://ingecodex.com
 * License: GPL2
 * Text Domain: contacto-multidestino
 */

if (!defined('ABSPATH')) {
    exit;
}

define('CM_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('CM_PLUGIN_URL', plugin_dir_url(__FILE__));
define('CM_VERSION', '2.4.1');

require_once CM_PLUGIN_DIR . 'includes/admin-builder.php';
require_once CM_PLUGIN_DIR . 'includes/admin-settings.php';
require_once CM_PLUGIN_DIR . 'includes/form-renderer.php';
require_once CM_PLUGIN_DIR . 'includes/form-handler.php';
require_once CM_PLUGIN_DIR . 'includes/smtp-settings.php';

function cm_get_all_forms() {
    $forms = get_option('cm_forms', array());
    if (!is_array($forms) || empty($forms)) {
        
        $legacy = get_option('cm_form_builder_schema', null);
        if (!$legacy && function_exists('cm_get_default_schema')) {
            require_once CM_PLUGIN_DIR . 'includes/admin-builder.php';
            $legacy = cm_get_default_schema();
        }
        $forms = array(
            'principal' => array(
                'id'         => 'principal',
                'name'       => 'Formulario Principal',
                'is_default' => true,
                'schema'     => $legacy ? $legacy : array('settings' => array(), 'fields' => array()),
            ),
        );
        update_option('cm_forms', $forms);
    }
    return $forms;
}

function cm_get_form($form_id = '') {
    $forms = cm_get_all_forms();
    $form_id = sanitize_key($form_id);
    if ($form_id && isset($forms[$form_id])) {
        return $forms[$form_id]['schema'];
    }
    
    foreach ($forms as $f) {
        if (!empty($f['is_default'])) return $f['schema'];
    }
    $first = reset($forms);
    return $first ? $first['schema'] : null;
}

function cm_get_default_form_id() {
    foreach (cm_get_all_forms() as $id => $f) {
        if (!empty($f['is_default'])) return $id;
    }
    $keys = array_keys(cm_get_all_forms());
    return $keys ? $keys[0] : '';
}

function cm_save_form($form_id, $name, $schema, $is_default = false) {
    $forms   = cm_get_all_forms();
    $form_id = sanitize_key($form_id);
    if (!$form_id) $form_id = 'form-' . substr(md5(uniqid()), 0, 6);

    if ($is_default) {
        foreach ($forms as &$f) $f['is_default'] = false;
        unset($f);
    }

    $forms[$form_id] = array(
        'id'         => $form_id,
        'name'       => sanitize_text_field($name ? $name : ('Formulario ' . count($forms))),
        'is_default' => $is_default || (1 === count($forms)),
        'schema'     => $schema,
    );
    update_option('cm_forms', $forms);

    
    $def = cm_get_form();
    if ($def) update_option('cm_form_builder_schema', $def);

    return $form_id;
}

function cm_delete_form($form_id) {
    $forms   = cm_get_all_forms();
    $form_id = sanitize_key($form_id);
    if (!$form_id || !isset($forms[$form_id]) || 1 >= count($forms)) return false;
    $was_default = !empty($forms[$form_id]['is_default']);
    unset($forms[$form_id]);
    if ($was_default) {
        $first = reset($forms);
        if ($first) $forms[$first['id']]['is_default'] = true;
    }
    update_option('cm_forms', $forms);
    return true;
}

function cm_get_forms_for_select() {
    $out = array();
    foreach (cm_get_all_forms() as $f) {
        $out[$f['id']] = $f['name'] . (!empty($f['is_default']) ? ' ★' : '');
    }
    return $out;
}

function cm_register_admin_menus() {
    add_menu_page(
        'Ingecodex Form',
        'Ingecodex Form',
        'manage_options',
        'cm-form-studio',
        'cm_render_admin_builder',
        'dashicons-feedback',
        25
    );

    add_submenu_page(
        'cm-form-studio',
        'Editor Visual',
        'Editor Visual',
        'manage_options',
        'cm-form-studio',
        'cm_render_admin_builder'
    );

    add_submenu_page(
        'cm-form-studio',
        'Ajustes de Envío (SMTP)',
        'Ajustes de Envío',
        'manage_options',
        'cm-form-smtp',
        'cm_render_smtp_settings_page'
    );
}
add_action('admin_menu', 'cm_register_admin_menus');

add_filter('admin_footer_text', function ($text) {
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if ($screen && strpos($screen->id, 'cm-form') !== false) {
        return 'Aplicación creada por <a href="https://www.ingecodex.com" target="_blank" rel="noopener">www.ingecodex.com</a>';
    }
    return $text;
});

function cm_enqueue_admin_studio_assets($hook) {
    
    if (strpos($hook, 'cm-form-studio') === false && strpos($hook, 'form-studio') === false) {
        return;
    }

    wp_enqueue_style(
        'cm-builder-admin-style',
        CM_PLUGIN_URL . 'assets/css/builder-admin.css',
        array(),
        time()  
    );

    wp_enqueue_script(
        'cm-builder-admin-script',
        CM_PLUGIN_URL . 'assets/js/builder-admin.js',
        array('jquery', 'jquery-ui-sortable'),
        time(),  
        true
    );

    $active_form_id = isset($_GET['form']) ? sanitize_key($_GET['form']) : get_option('cm_current_form_id', '');

    wp_localize_script('cm-builder-admin-script', 'cmBuilderVars', array(
        'ajax_url'       => admin_url('admin-ajax.php'),
        'nonce'          => wp_create_nonce('cm_contacto_nonce'),
        'forms'          => function_exists('cm_get_forms_for_select') ? cm_get_forms_for_select() : array(),
        'shortcodes'     => function_exists('cm_get_form_shortcode_tags') ? cm_get_form_shortcode_tags() : array(),
        'form_id'        => $active_form_id,
        'initial_schema' => function_exists('cm_get_form') ? cm_get_form($active_form_id) : null,
    ));
}
add_action('admin_enqueue_scripts', 'cm_enqueue_admin_studio_assets');

function cm_register_elementor_widget_compat($widgets_manager = null) {
    static $done = false;
    if ($done) return;
    if (!did_action('elementor/loaded') || !class_exists('\Elementor\Widget_Base')) return;

    require_once CM_PLUGIN_DIR . 'includes/elementor-widget.php';
    $widget = new \CM_Elementor_Contact_Widget();

    if (is_object($widgets_manager) && method_exists($widgets_manager, 'register')) {
        $widgets_manager->register($widget);          
    } elseif (is_object($widgets_manager) && method_exists($widgets_manager, 'register_widget_type')) {
        $widgets_manager->register_widget_type($widget); 
    } else {
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type($widget);
    }

    
    if (!class_exists('\CM_Elementor_Contact_Widget_Alias')) {
        eval('class CM_Elementor_Contact_Widget_Alias extends \CM_Elementor_Contact_Widget {
            public function get_name() { return "cm_contacto_multidestino"; }
        }');
    }
    $alias = new \CM_Elementor_Contact_Widget_Alias();
    $wm   = is_object($widgets_manager) ? $widgets_manager : \Elementor\Plugin::instance()->widgets_manager;
    if (method_exists($wm, 'register')) { $wm->register($alias); }
    elseif (method_exists($wm, 'register_widget_type')) { $wm->register_widget_type($alias); }

    $done = true;
}
add_action('elementor/widgets/register', 'cm_register_elementor_widget_compat');       
add_action('elementor/widgets/widgets_registered', function () {                       
    cm_register_elementor_widget_compat(\Elementor\Plugin::instance()->widgets_manager);
});

function cm_enqueue_frontend_scripts() {
    wp_enqueue_style(
        'cm-contacto-style',
        CM_PLUGIN_URL . 'assets/css/contacto-style.css',
        array(),
        filemtime(CM_PLUGIN_DIR . 'assets/css/contacto-style.css')
    );

    wp_enqueue_script(
        'cm-contacto-script',
        CM_PLUGIN_URL . 'assets/js/contacto-script.js',
        array('jquery'),
        filemtime(CM_PLUGIN_DIR . 'assets/js/contacto-script.js'),
        true
    );

    wp_localize_script('cm-contacto-script', 'cm_ajax_object', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('cm_contacto_nonce'),
        'strings'  => array(
            'sending'      => __('Enviando mensaje...', 'contacto-multidestino'),
            'success'      => __('¡Tu mensaje ha sido enviado con éxito! Gracias por contactarnos.', 'contacto-multidestino'),
            'error_generic'=> __('Hubo un error al enviar tu mensaje. Por favor intenta nuevamente.', 'contacto-multidestino')
        )
    ));
}
add_action('wp_enqueue_scripts', 'cm_enqueue_frontend_scripts');

function cm_render_shortcode($atts = array()) {
    require_once CM_PLUGIN_DIR . 'includes/form-renderer.php';
    return cm_render_dynamic_form($atts);
}

function cm_get_form_shortcode_tags() {
    $tags = array();
    $used = array();
    foreach (cm_get_all_forms() as $fid => $f) {
        $base = str_replace('-', '_', sanitize_title($f['name']));
        if (!$base || is_numeric($base)) $base = $fid;
        $tag = 'formulario_ingecodex_' . $base;
        $n   = 2;
        while (isset($used[$tag])) {
            $tag = 'formulario_ingecodex_' . $base . '_' . $n;
            $n++;
        }
        $used[$tag] = true;
        $tags[$fid] = $tag;
    }
    return $tags;
}

function cm_get_form_shortcode_tag($form_id) {
    $map = cm_get_form_shortcode_tags();
    return isset($map[$form_id]) ? $map[$form_id] : '';
}

add_action('init', function () {
    foreach (cm_get_form_shortcode_tags() as $fid => $tag) {
        add_shortcode($tag, function ($atts = array()) use ($fid) {
            $atts       = is_array($atts) ? $atts : array();
            $atts['id'] = $fid;
            return cm_render_shortcode($atts);
        });
    }
});
add_shortcode('Formulario_Ingecodex', 'cm_render_shortcode');
add_shortcode('formulario_ingecodex', 'cm_render_shortcode');
add_shortcode('ingecodex_form', 'cm_render_shortcode');
add_shortcode('formulario_contacto', 'cm_render_shortcode');

function cm_activate_plugin() {
    if (!get_option('cm_form_builder_schema')) {
        update_option('cm_form_builder_schema', cm_get_default_schema());
    }
}
register_activation_hook(__FILE__, 'cm_activate_plugin');
